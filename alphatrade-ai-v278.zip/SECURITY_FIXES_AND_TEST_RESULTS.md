# SECURITY FIXES AND TEST RESULTS — AlphaTrade AI (v236)

كل إصلاح مربوط بالثغرة من `FULL_SECURITY_AUDIT_REPORT.md`، ومعه الاختبار قبل وبعد. نتائج قبل/بعد الخام موجودة بـ `security/results/pentest-before-v234.json` و`security/results/pentest-after.json`.

## الإصلاحات

| الثغرة | الإصلاح | الملفات | قبل | بعد |
| --- | --- | --- | --- | --- |
| V-01 فيضان طلبات من حساب واحد | حد ثابت لكل حساب: 300 طلب/دقيقة لكل الأجهزة سوا (`USER_PER_MINUTE`، أقل قيمة 60)، والرد 429 مع `Retry-After` | `server/index.js` | FAILED — 400 طلب بدون 429 | PASSED |
| V-02 حذف الحساب بيترك بيانات | `mt5.removeAll(uid)` (التوكنات بتبطل فوراً) و`community.forgetUser(uid)` (البلاغات وصورها والمكالمات ومقاعد البث) | `server/index.js`، `server/mt5Bridge.js`، `server/community.js` | FAILED — EA بيرد 200، والبلاغ ظاهر | PASSED — EA بيرد 401، والبلاغ انحذف |
| V-03 رأس COOP ناقص | `Cross-Origin-Opener-Policy: same-origin-allow-popups` | `server/index.js`، `netlify.toml` | FAILED | PASSED |
| V-05 ما في تدوير لـ `AI_KEY_SECRET` (v236) | أداة تدوير بتنسخ البيانات لمجلد جديد، بتعيد تشفير 6 مخازن (مع إعادة تسمية ملفات الصفقات)، بتفحص كل ملف بالسر الجديد، وما بتلمس المجلد الحي | `security/rotate-ai-key.mjs` | ما في طريقة | PASSED (`tests/keyRotation.test.js`) |
| V-11 ما في مراقبة ولا تنبيهات (v236) | سجل أحداث (`security-events.jsonl`، كتابة مؤجلة)، تنبيهات للمالكين (suspicious_signin، admin_probe، api_abuse، sensitive_change)، و`GET /api/admin/security` | `server/securityMonitor.js`، `server/index.js` | ما في | PASSED (6 فحوصات) |
| V-04 الإدارة بدون MFA | `ADMIN_REQUIRE_MFA=1` بيحصر صلاحيات المالك بجلسة فيها خطوة تانية | `server/index.js` | — | PASSED (تست خاص بالخيار) |

## الأدوات والتستات الجديدة

- `security/pentest.mjs`: 127 فحص اختراق ديناميكي على نسخة Staging. بيرجع exit code 1 إذا فشل أي فحص.
- `security/scan.mjs`: فحص أسرار وأنماط كود خطرة. بيفشل على أي High أو Critical.
- `tests/securityPentest.test.js` و`tests/securityScan.test.js`: صاروا جزء من `npm test`، عشان ما ترجع أي ثغرة.
- `.github/workflows/security.yml`: فيه Gitleaks على كل التاريخ، وSemgrep، وnpm audit، وTrivy (ملفات + صورة الحاوية)، وتستات الاختراق، وOWASP ZAP baseline. أي Critical أو High أو سر مكشوف بيمنع النشر.
- `loadtest/local.mjs`: سيناريو `ladder` جديد (من 1 لـ 1000 مستخدم).

## نتائج إعادة الاختبار

| الاختبار | النتيجة |
| --- | --- |
| `npm test` (كل تستات المشروع) | **405 / 405 نجحوا** (كانوا 399؛ انضافوا 6 تستات أمان) |
| `node security/pentest.mjs` على v236 | **127 / 127 PASSED** |
| نفس الـ pentest على النسخة القديمة (v233/v234) | 117 / 121 — الأربع فشلات هي V-01 وV-02 (فحصين) وV-03 |
| `node security/scan.mjs` (المشروع + ملفات البناء) | 0 High/Critical؛ 5 Low/Medium مراجعة يدوياً ومقبولة (`http://x` كأساس لتحليل الروابط، `document.write` بمحتوى escaped) |
| XSS بالمتصفح (43 صفحة) | 0 تنفيذ |
| الفحص الشامل للموقع (Playwright، موبايل + كمبيوتر) | **88 / 88** |
| تست الضغط بعد الإصلاحات | نجاح 100% لحد 1000 مستخدم متزامن، والسيرفر رجع طبيعي بعد الحمل (التفاصيل بتقرير الأداء) |
| Gitleaks / Semgrep / Trivy / ZAP الرسميين | **NOT TESTED هون** (ما في إنترنت ببيئة العمل)، بيشتغلوا بالـ CI |

## المشاكل اللي ضلّت مفتوحة

1. **V-05 (صار إله حل):** التدوير لازم يكون بـ `security/rotate-ai-key.mjs`، مش بتغيير المتغير مباشرة. ملفات صفقات حسابات ما إلها سجل عضوية بتضل على السر القديم، والأداة بتعدّها.
2. **V-06 — الحاوية بتشتغل كـ root:** المطلوب بوقت صيانة: `chown -R 1000:1000` للـ volumes، وبعدين `USER node` بالـ Dockerfile.
3. **CSP:** فيها `'unsafe-inline'` للستايلات، ومصادر `https:` واسعة.
4. **أشياء محظورة من هون:** الاستضافة وDNS وWAF وTLS (testssl) وإعدادات Firebase وStripe الحي والوسيط الحقيقي والمراجعة القانونية.
