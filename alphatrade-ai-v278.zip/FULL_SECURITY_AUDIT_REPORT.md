# FULL SECURITY AUDIT REPORT — AlphaTrade AI (v236)

تاريخ الفحص: 2026-11-04 · النطاق: مستودع المشروع كاملاً (الواجهة، السيرفر، الـ API، التخزين، الدفع، MT5، الذكاء الاصطناعي، إعدادات النشر) على نسخة Staging محلية معزولة. ما في أي اختبار انعمل على الموقع الحي أو على خدمات طرف ثالث.

> الحالات: **PASSED** = انفحص ونجح بدليل · **FAILED** = انفحص وفشل · **NOT TESTED** = ما انفحص · **BLOCKED** = ما في وصول/صلاحية.
> هاد التقرير مش شهادة إن المشروع آمن 100%. في أجزاء (الاستضافة، DNS، WAF، Firebase، Stripe الحي، الوسيط) ما عندي وصول إلها.

## 1. خريطة المشروع ونقاط الدخول

| الطبقة | التقنية | الملفات |
| --- | --- | --- |
| الواجهة | Vanilla JS (ES modules)، Vite، PWA (Service Worker) | `src/`، `index.html`، `public/sw.js` |
| السيرفر | Node.js 22، `node:http` بدون مكتبات تشغيل خارجية | `server/index.js` + 21 وحدة |
| تسجيل الدخول | Firebase Authentication (توكن RS256 بيتحقق منه السيرفر)؛ وضع تجريبي محلي بالمتصفح بدون Firebase | `server/firebaseVerify.js`، `src/services/auth/*` |
| التخزين | ملفات JSON مشفّرة AES-256-GCM (مفتاح من `AI_KEY_SECRET` عبر scrypt)؛ البنك: SQLite مشفّر بمفاتيح لكل حقل | `server/*.js`، `server/bank/*` |
| الدفع | Stripe Checkout + Webhook موقّع | `server/stripe.js` |
| MT5 | جسر EA بتوكن اقتران (بينحفظ الـ hash بس) | `server/mt5Bridge.js` |
| الذكاء الاصطناعي | Anthropic / OpenAI عبر السيرفر بس؛ المفتاح مشفّر بالسيرفر | `server/aiGateway.js`، `src/services/ai/*` |
| النشر | Docker، docker-compose، Render، Netlify | `Dockerfile*`، `compose.yaml`، `render.yaml`، `netlify.toml` |
| تطبيقات الهاتف | **ما في** تطبيق Android/iOS بالمستودع (الموقع PWA بس) | — |

نقاط الدخول (`server/index.js`): حوالي 95 مسار API.

- **عامة:** `/api/health`، `/api/plans`، `/api/ai/status`، `/api/billing/status`.
- **بتوكن مستخدم:** `/api/me/*`، `/api/user/*`، `/api/mt5/*`، `/api/feedback`، `/api/support/*`، `/api/live/*`، `/api/contest*`، `/api/bank/*`، `/api/ai/*`.
- **للمالك بس:** `/api/admin/*`، `/api/ai/config`، `/api/market/config`، `/api/notify/config`، `/api/billing/config`، `/api/billing/admin/summary`، `/api/channel/grant`.
- **بتوكن آلة:** `/api/mt5/ea/*` (توكن الاقتران)، `/api/tv/<token>` (TradingView)، `/api/billing/webhook` (توقيع Stripe).
- **وكلاء ثابتي الوجهة:** `/binance/*`، `/api/market/twelve`، `/ff/*`.
- **الملفات الثابتة:** `--serve-dist`.

## 2. الأدوات المستعملة

| الأداة | الإصدار | الحالة | ملاحظة |
| --- | --- | --- | --- |
| `security/pentest.mjs` (اختبار اختراق ديناميكي، جديد) | v235 على Node 22.23.4 | PASSED — 127/127 | بيشغّل السيرفر الحقيقي بمجلد بيانات مؤقت، وتوكنات اختبار، وStripe وهمي محلي |
| `security/rotate-ai-key.mjs` (تدوير `AI_KEY_SECRET`، جديد) | v236 | PASSED (`tests/keyRotation.test.js`) | |
| `security/scan.mjs` (فحص أسرار بقواعد Gitleaks + أنماط كود خطرة بقواعد Semgrep، جديد) | v235 | PASSED — 0 High/Critical | فحص المشروع وملفات البناء |
| Playwright + Chromium (XSS على المتصفح، فحص شامل 88 نقطة) | 1.63.0 | PASSED | |
| `loadtest/local.mjs` (ضغط وتحمّل) | v235 | PASSED بحدود | التفاصيل بـ `PERFORMANCE_AND_LOAD_TEST_REPORT.md` |
| OWASP ZAP، Semgrep، Gitleaks، Trivy، npm audit | بإصدارات مثبّتة بـ `.github/workflows/security.yml` | **NOT TESTED هون** | بيئة العمل ما فيها إنترنت لتنزيل الأدوات أو قواعد الثغرات. انضافوا لـ CI وبيشتغلوا على GitHub مع كل push |
| Nuclei، testssl.sh | — | **BLOCKED** | بدهم الدومين الحي، وما في تصريح أو وصول للإنتاج من هون |
| OWASP Dependency-Check | — | NOT TESTED | Trivy + npm audit بالـ CI بيغطّوا نفس الهدف |
| MobSF / MASVS / MASTG | — | لا ينطبق | ما في APK ولا IPA بالمستودع |

## 3. الثغرات المكتشفة

| # | الخطورة | المكان | المشكلة | الحالة |
| --- | --- | --- | --- | --- |
| V-01 | Medium | `server/index.js` (`requireUser`) | ما في حد لعدد طلبات الحساب الواحد. توكن مسروق أو سكربت بيقدر يبعت مئات الطلبات بالدقيقة (400 طلب بدون 429) | **مُصلح** — حد 300 طلب/دقيقة لكل حساب (`USER_PER_MINUTE`) |
| V-02 | Medium (خصوصية) | `server/index.js` (`handleDeleteAccount`)، `mt5Bridge.js`، `community.js` | حذف الحساب كان يخلّي ربط MT5 فعّال (توكن الـ EA ضل يرد 200)، وكان يخلّي البلاغات وصورها | **مُصلح** — كل روابط MT5 والبلاغات والصور والمكالمات المفتوحة بتنحذف |
| V-03 | Low | رؤوس HTTP (السيرفر + Netlify) | `Cross-Origin-Opener-Policy` ناقص | **مُصلح** — `same-origin-allow-popups` (تسجيل دخول Google بالنافذة المنبثقة بيضل شغّال) |
| V-04 | Medium | حسابات المالك | صلاحيات الإدارة ما بتتطلب تحقق بخطوتين | **مُصلح كخيار** — `ADMIN_REQUIRE_MFA=1` (مطفي افتراضياً عشان ما ينقفل المالك قبل ما يفعّل MFA بـ Firebase) |
| V-05 | Medium (تشغيلي) | `AI_KEY_SECRET` (مفتاح مفاتيح الـ AI والسوق والإشعارات والأعضاء والمجتمع وصفقات المستخدمين) | ما في تدوير للمفتاح: تغييره بيخلّي الملفات المشفّرة مش مقروءة. البنك إله تدوير (`BANK_MASTER_KEY_PREV`) | **مُصلح (v236)** — `security/rotate-ai-key.mjs` بيعيد تشفير نسخة، وبيفحصها، وما بيلمس المجلد الحي |
| V-06 | Medium (إعداد) | `Dockerfile` | الحاوية بتشتغل كـ root | **مفتوح** — التحويل لـ `USER node` بيكسر كتابة الملفات على الـ volumes الحالية المملوكة لـ root؛ بدّه ترحيل (`chown`) وقت صيانة |
| V-07 | Low | `server/firebaseVerify.js` | سماحية 5 دقايق بعد انتهاء التوكن (clock skew) | مقبول — قيمة شائعة؛ التوكن بيتجدّد كل ساعة |
| V-08 | Low | CSP | `style-src 'unsafe-inline'`، ومصادر `https:` واسعة للصور والإطارات والاتصال | مقبول مؤقتاً — التضييق بدّه جرد لكل الخدمات الخارجية (YouTube، Twitch، الوكلاء) |
| V-09 | Info | `src/services/auth/localAuth.js` | الوضع التجريبي بدون Firebase بيخزّن الحسابات بالمتصفح (PBKDF2-SHA256، 210 ألف دورة) | مقبول للتجربة بس — الإنتاج لازم يكون على Firebase. السيرفر ما بيخزّن كلمات سر أبداً |
| V-11 | Medium | المراقبة | ما في سجل أحداث أمنية ولا تنبيهات: محاولات التوكن والتجسس على مسارات الإدارة والفيضان وتغييرات المالك كانت بتمر بدون ما حدا ينتبه | **مُصلح (v236)** — `server/securityMonitor.js` + تنبيهات للمالكين + `GET /api/admin/security` |
| V-10 | Info | `src/pages/owner.js:35` | `document.write` بنافذة تقرير المالك | مقبول — كل القيم مارقة على `esc()` |

ما انلقت ولا ثغرة Critical أو High على النسخة اللي انفحصت.

## 4. نتائج اختبار الاختراق (127 فحص)

| المجال | الفحوصات | النتيجة |
| --- | --- | --- |
| Authentication bypass وتوكنات مزوّرة (alg none، مفتاح تاني، aud/iss غلط، منتهي، مستقبلي، kid مجهول، payload معدّل، HS256) | 30 | PASSED |
| Broken access control وتصعيد الصلاحيات (17 مسار إدارة، المالك بإيميل مش مؤكد، prototype pollution) | 21 | PASSED |
| IDOR وعزل الحسابات (الهاتف، الصفقات، الكتابة على نفس المعرّف، الحذف، MT5 عرض/حذف/أوامر، البلاغات، التصدير) | 12 | PASSED |
| حذف الحساب (MT5، البلاغات، الهاتف، إعادة المصادقة) | 5 | PASSED بعد الإصلاح (قبل: 2 FAILED) |
| CSRF وCORS (بدون Origin، Origin غريب، preflight) | 3 | PASSED |
| Path traversal وتسريب الملفات (11 مسار، `../` بالـ uid، طلب خام) | 12 | PASSED |
| رؤوس الأمان وكشف المعلومات (CSP، HSTS، XFO، nosniff، Referrer، Permissions، COOP، بدون stack trace، health) | 10 | PASSED بعد الإصلاح (قبل: COOP ناقص) |
| الأسرار (مفتاح السوق، مفتاح AI، توكن الجسر، السجلات) | 4 | PASSED |
| SSRF وOpen redirect | 8 | PASSED |
| الدفع (Webhook بدون توقيع / مزوّر / قديم / مبلغ أقل / حساب تاني / تكرار / وضع live، السعر من المتصفح، التجربة المجانية مرتين) | 10 | PASSED |
| Injection وStored XSS وحدود الحجم | 4 | PASSED |
| Rate limiting (AI، تسجيل الدخول بالوجه، فيضان من حساب واحد) | 3 | PASSED بعد الإصلاح (قبل: الفيضان FAILED) |
| المراقبة (سجل الأحداث، تنبيه admin_probe وapi_abuse، الحذف، ما في أسرار بالسجل، العميل ما بيشوف السجل) | 6 | PASSED (جديد v236) |

إضافة لهيك:

- **XSS بالمتصفح (Playwright):** حقنت payloads `onerror`/`onload` بالاسم وسجل المحادثة والسجل والتنبيهات، ومرّيت على 43 صفحة. ما في ولا تنفيذ سكربت. PASSED.
- **SQL / NoSQL Injection:** ما في قاعدة SQL للتطبيق. البنك على SQLite باستعلامات parameterized، ومغطّى بتستات `tests/bank*.test.js`. التخزين الباقي JSON بدون استعلامات نصية. PASSED.
- **RCE / Command injection / Deserialization:** الماسح ما لقى `eval` ولا `child_process` بكود التطبيق، وكل الـ JSON بينقرأ بـ `JSON.parse` بحدود حجم. PASSED.

## 5. تقرير تشفير API Keys

- **مفاتيح Anthropic / OpenAI / Twelve Data / Telegram / Stripe:** بتنحفظ مشفّرة AES-256-GCM. مفتاح التشفير مشتق بـ scrypt من `AI_KEY_SECRET`، وهو متغير بيئة بالسيرفر ومش جوّا الكود ولا جنب الملفات. المالك بيشوف آخر 4 أحرف بس. PASSED (pentest + `tests/aiGateway.test.js`).
- **الواجهة وملفات البناء:** ما في مفاتيح. `VITE_` فيها بس إعدادات Firebase العامة اللي معمولة أصلاً للمتصفح. PASSED (الماسح + CI).
- **السجلات:** ما فيها توكنات ولا مفاتيح، و`client-error` بيمر على `scrub`. PASSED.
- **توكن MT5 وتوكن TradingView:** بينحفظ الـ HMAC بس، والتوكن بينعرض مرة وحدة. PASSED.
- **Secret Manager / KMS:** BLOCKED، بيعتمد على الاستضافة (Render / Docker secrets). التوصية بـ `PRE_RELEASE_SECURITY_CHECKLIST.md`.
- **التدوير:** البنك بيدعمه (`BANK_MASTER_KEY_PREV`)، و`AI_KEY_SECRET` صار بيدعمه بـ `security/rotate-ai-key.mjs` (v236). بعد التدوير: العملاء بيعيدوا ربط MT5، وبيعيدوا تسجيل بصمة الوجه، وأكواد الإحالة بتتغيّر. هاد مقصود، لأن كلها مشتقة من السر.

## 6. حماية قاعدة البيانات والتخزين

- **العزل:** كل مستخدم إله ملف صفقات مشفّر، اسمه HMAC للـ uid، فما في تخمين ولا traversal. مفحوص.
- **CRUD لمستخدم تاني:** مرفوض (IDOR = PASSED).
- **النسخ الاحتياطي:** نسخ يومية مشفّرة، بتنحفظ آخر 14 بـ `backups/`. تستات `tests/backupHealth.test.js` نجحت. استعادة نسخة على بيئة منفصلة ما انعملت هون: NOT TESTED.
- **قاعدة مكشوفة للإنترنت:** ما في. التخزين ملفات داخل الحاوية، والبنك SQLite محلي.

## 7. حماية الدفع والاشتراكات

- كل تفعيل بيصير بس من Webhook موقّع بـ HMAC-SHA256، ضمن 5 دقايق.
- المبلغ والمنتج والـ uid بيتطابقوا مع metadata موقّعة من السيرفر، وأي تلاعب بيرجع `amount_mismatch` أو `bad_session`.
- الدفعة المكررة ما بتمدّد الاشتراك، وحدث test ما بيفتح موقع live.
- السعر من المتصفح بيتجاهل.
- ما في تخزين لبطاقات ولا CVV (Stripe Checkout).
- كل هاد PASSED على Stripe وهمي محلي.
- Stripe الحي وApple/Google In-App Purchase: BLOCKED، لأن ما في تطبيقات متاجر.

## 8. حماية حسابات المستخدمين

- كلمات السر عند Firebase Auth. السيرفر ما بيخزّن ولا بيستقبل كلمات سر.
- السيرفر بيتحقق من توقيع التوكن والـ audience والـ issuer والصلاحية.
- **صلاحيات الإدارة:** من السيرفر بس (إيميل مؤكد + `ADMIN_EMAILS`)، و`ADMIN_REQUIRE_MFA` اختياري.
- **حذف الحساب:** بيطلب تسجيل دخول خلال آخر 10 دقايق، وكتابة "DELETE".
- **الحماية من التخمين:** حدود لكل IP وكل حساب. قفل الحساب بعد محاولات فاشلة بيصير عند Firebase.
- **إعدادات Firebase الحية** (Google / Apple / استعادة كلمة السر / Email enumeration protection / refresh token revocation): BLOCKED، بتنضبط من Firebase Console.

## 9. حماية MT5 والوسطاء

- كل رابط إله توكن خاص فيه (24 بايت عشوائي، وبينحفظ الـ HMAC بس).
- المستخدم التاني ما بيقدر يشوف ولا يحذف ولا يبعت أوامر (PASSED).
- الـ EA لازم يسمح بالتداول، والأمر ما بيتطبّق مرتين.
- ما في تخزين لكلمات سر MT5 ولا صلاحية سحب.
- حذف الحساب بيبطل كل الروابط (V-02 مُصلح).
- الوسيط الحقيقي: BLOCKED، الاختبار على Demo بس.

## 10. الخصوصية وتسريب البيانات

- **ما في تسريب بين الحسابات:** الهاتف، الصفقات، البلاغات، التصدير، MT5، كلهم PASSED.
- **ردود الـ API:** ما فيها بيانات المالك ولا المفاتيح.
- **حقوق المستخدم:** `/api/user/export` بيعطيه بياناته، و`DELETE /api/user/account` بيحذفها. الدفعات بتضل مجهولة الهوية للمحاسبة.
- **سياسة الخصوصية:** موجودة بصفحة `legal`، ولازم تتراجع قانونياً.
- **البيانات للذكاء الاصطناعي:** بيروح للمزوّد (Anthropic / OpenAI) سياق السوق وصفقات المستخدم المحفوظة بس، بدون إيميل ولا هاتف. لازم ينذكر هاد بسياسة الخصوصية.

## 11. التوافق مع Apple وGoogle والقانون

- **App Store / Google Play:** BLOCKED، ما في تطبيقات بالمستودع.
- **الموقع على Chrome / Safari / Firefox / Edge:** انفحص Chromium بس (Playwright). الباقي NOT TESTED.
- **التوصيات المالية:** بتتطلب ترخيص بكتير من الدول (مثلاً FCA بالمملكة المتحدة، SEC/FINRA وCFTC/NFA بأمريكا، ESMA/MiFID بأوروبا، وهيئة الأوراق المالية بالأردن). إخلاء المسؤولية مش بديل عن الترخيص. **بيحتاج محامي مختص قبل التشغيل التجاري بأي دولة.**
- **البنك الرقمي:** بيشتغل `sandbox` افتراضياً. التشغيل الحقيقي بيتطلب ترخيص مؤسسة مالية وKYC/AML، ما يتشغّل بدونهم.
