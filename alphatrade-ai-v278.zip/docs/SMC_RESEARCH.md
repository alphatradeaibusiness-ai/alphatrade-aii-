# SMC v2 — why so few trades, and what loosening does

## Why only ~30 trades (or fewer)
Measured on BTC 15m (2025-01 → 2026-10, Daily built from 1h): the sequential chain (sweep → structure break → order block → tap → minor CHoCH → FVG → sane stop) leaves ~120 candidate setups. Then the gates remove the rest: **HTF (4h AND Daily must agree) rejected 81, kill zone rejected 33, score 1 → 5 trades.** On 1h: 33 / 19 / 2 → 3 trades. On 5m: 96 / 36 / 3 → 8 trades.

## Code audit (look-ahead, repeats, timing)
- Swings are confirmed 2 bars later (minor: 1) and are only used when `index + len <= current candle`. No future swing is used.
- HTF structure is read from the last CLOSED 4h/Daily bar at the signal time; the forming bar is never used.
- Signals are generated on closed candles only; one open trade at a time; a setup key (`dir|sweep time`) can fire once (no repeats).
- Entry is a market fill at the confirmation candle's close. Real fills differ (latency, spread): the research tool adds a slippage allowance on top of the fee.
- Not implemented: "limit entry at the OB retest". The retest of the order block is already a REQUIRED step before the CHoCH; a separate limit order would not match how the MT5 bridge executes (market only).

## New optional rules (Settings → SMC v2; defaults = original)
htfMode (both / 4h / Daily), declared reversal rule, minimum displacement, minimum FVG, candles allowed between tap and CHoCH, stop buffer, maximum stop (ATR), RSI momentum gate (filter only). Costs: round-trip fee + `slipPct`.

## Reproduce
`node tools/smc_research.mjs --data ./data --symbol BTCUSDT --tfs 15m,5m --fee 0.1 --slip 0.02` (data from `tools/research.mjs`).

## Result (BTC only: it is the only data available to me; no forex data, no spread data)
Time split: first 60% = development, last 40% = out of sample (never used to choose).

Data 2025-01-07 → 2026-10-02 (60779 candles). **Development** 2025-01-07 → 2026-01-21 · **Out of sample** 2026-01-21 → 2026-10-02.

| Variant | Dev trades | Dev win | Dev PF | Dev R/trade | Dev maxDD (R) | Dev loss streak | OOS trades | OOS win | OOS PF | OOS R/trade | OOS maxDD (R) |
|---|---|---|---|---|---|---|---|---|---|---|---|
| A strict (current) | 0 (0.00/mo) | — | — | — | — | — | 2 (0.24/mo) | 50.00% | 1.69 | 0.40 | 1.17 |
| B 4h bias only | 0 (0.00/mo) | — | — | — | — | — | 3 (0.36/mo) | 33.33% | 0.86 | -0.11 | 2.30 |
| C no kill zone | 7 (0.55/mo) | 28.57% | 0.59 | -0.33 | 2.30 | 2 | 12 (1.42/mo) | 25.00% | 0.52 | -0.40 | 5.63 |
| D 4h only + no kill zone | 10 (0.79/mo) | 30.00% | 0.55 | -0.35 | 4.47 | 3 | 14 (1.66/mo) | 28.57% | 0.64 | -0.28 | 6.59 |
| E D + score 70 | 18 (1.42/mo) | 27.78% | 0.51 | -0.39 | 8.82 | 4 | 16 (1.90/mo) | 37.50% | 0.79 | -0.14 | 6.11 |
| F D + reversal rule | 11 (0.87/mo) | 36.36% | 0.70 | -0.21 | 4.47 | 3 | 14 (1.66/mo) | 28.57% | 0.64 | -0.28 | 6.59 |
| G D + RSI gate | 10 (0.79/mo) | 30.00% | 0.55 | -0.35 | 4.47 | 3 | 14 (1.66/mo) | 28.57% | 0.64 | -0.28 | 6.59 |
| H D + displacement ≥1.5 | 6 (0.47/mo) | 33.33% | 0.66 | -0.25 | 3.28 | 3 | 4 (0.47/mo) | 50.00% | 1.71 | 0.41 | 1.17 |
| I D + FVG ≥0.3 ATR | 7 (0.55/mo) | 42.86% | 0.95 | -0.03 | 2.19 | 2 | 11 (1.30/mo) | 18.18% | 0.32 | -0.61 | 6.76 |
| J D + CHoCH within 25 | 14 (1.11/mo) | 28.57% | 0.47 | -0.42 | 6.87 | 4 | 15 (1.78/mo) | 26.67% | 0.58 | -0.34 | 7.74 |
| K no HTF, kill zone on | 1 (0.08/mo) | 0.00% | 0.00 | -1.16 | 1.16 | 1 | 3 (0.36/mo) | 33.33% | 0.87 | -0.10 | 1.17 |
| L 4h only + kill zone | 0 (0.00/mo) | — | — | — | — | — | 3 (0.36/mo) | 33.33% | 0.86 | -0.11 | 2.30 |

## Entry timeframe 5m
Data 2026-04-05 → 2026-10-02 (51841 candles). **Development** 2026-04-05 → 2026-07-22 · **Out of sample** 2026-07-22 → 2026-10-02.

| Variant | Dev trades | Dev win | Dev PF | Dev R/trade | Dev maxDD (R) | Dev loss streak | OOS trades | OOS win | OOS PF | OOS R/trade | OOS maxDD (R) |
|---|---|---|---|---|---|---|---|---|---|---|---|
| A strict (current) | 0 (0.00/mo) | — | — | — | — | — | 1 (0.42/mo) | 0.00% | 0.00 | -1.24 | 1.24 |
| B 4h bias only | 2 (0.56/mo) | 0.00% | 0.00 | -1.22 | 2.44 | 2 | 1 (0.42/mo) | 0.00% | 0.00 | -1.24 | 1.24 |
| C no kill zone | 8 (2.22/mo) | 25.00% | 0.56 | -0.38 | 3.54 | 3 | 1 (0.42/mo) | 100.00% | ∞ | 0.44 | 0.00 |
| D 4h only + no kill zone | 12 (3.33/mo) | 25.00% | 0.38 | -0.54 | 6.50 | 5 | 1 (0.42/mo) | 100.00% | ∞ | 0.44 | 0.00 |
| E D + score 70 | 12 (3.33/mo) | 25.00% | 0.38 | -0.54 | 6.50 | 5 | 6 (2.50/mo) | 16.67% | 0.07 | -0.93 | 5.56 |
| F D + reversal rule | 12 (3.33/mo) | 25.00% | 0.38 | -0.54 | 6.50 | 5 | 1 (0.42/mo) | 100.00% | ∞ | 0.44 | 0.00 |
| G D + RSI gate | 12 (3.33/mo) | 25.00% | 0.38 | -0.54 | 6.50 | 5 | 1 (0.42/mo) | 100.00% | ∞ | 0.44 | 0.00 |
| H D + displacement ≥1.5 | 6 (1.67/mo) | 0.00% | 0.00 | -1.15 | 6.90 | 6 | 0 (0.00/mo) | — | — | — | — |
| I D + FVG ≥0.3 ATR | 9 (2.50/mo) | 11.11% | 0.02 | -1.02 | 9.20 | 6 | 1 (0.42/mo) | 100.00% | ∞ | 0.44 | 0.00 |
| J D + CHoCH within 25 | 13 (3.61/mo) | 23.08% | 0.34 | -0.59 | 7.68 | 5 | 1 (0.42/mo) | 100.00% | ∞ | 0.44 | 0.00 |
| K no HTF, kill zone on | 1 (0.28/mo) | 0.00% | 0.00 | -1.23 | 1.23 | 1 | 1 (0.42/mo) | 0.00% | 0.00 | -1.24 | 1.24 |
| L 4h only + kill zone | 2 (0.56/mo) | 0.00% | 0.00 | -1.22 | 2.44 | 2 | 1 (0.42/mo) | 0.00% | 0.00 | -1.24 | 1.24 |

## Verdict
- The strict original gives 0–3 trades per period: too few to judge, so no claim of 63%.
- Every loosening raises trades to roughly 1–3 per month, but development results are negative (win 25–36%, PF 0.4–0.95) and the out-of-sample results are negative too (win 18–38%, PF 0.3–0.8). The two out-of-sample positives (variant H on 15m: 4 trades; several variants on 5m: 1 trade) are samples far too small to mean anything.
- **No variant reaches 63% out of sample. The strategy, as defined, has no demonstrated edge on this data.** Nothing was kept because of its win rate.
- Limits: one asset, 5m covers only ~6 months, 15m ~21 months; spread/commission for forex pairs and forex data were not available, so forex results are unknown.
