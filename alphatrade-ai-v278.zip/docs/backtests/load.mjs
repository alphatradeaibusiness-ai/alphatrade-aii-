// Loads the saved Twelve Data pages of one market into UTC candles (ascending, de-duplicated).
// Twelve Data returns forex / metals in Australia/Sydney time, crypto in UTC and US ETFs in America/New_York time.
import fs from 'node:fs';
const RAW = '/tmp/claude-0/-home-claude/8ec99056-1357-57a3-bb99-754394c63670/scratchpad/mkt/raw';

const fmtCache = new Map();
function offsetMin(tz, utcMs) {
  if (tz === 'UTC') return 0;
  let f = fmtCache.get(tz);
  if (!f) { f = new Intl.DateTimeFormat('en-US', { timeZone: tz, hourCycle: 'h23', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' }); fmtCache.set(tz, f); }
  const p = Object.fromEntries(f.formatToParts(new Date(utcMs)).map((x) => [x.type, x.value]));
  return (Date.UTC(+p.year, +p.month - 1, +p.day, +p.hour, +p.minute) - utcMs) / 60000;
}
/** 'YYYY-MM-DD HH:MM:SS' wall time in `tz` → UTC seconds. */
export function toUtc(s, tz) {
  const [d, t] = s.split(' '); const [y, mo, da] = d.split('-').map(Number); const [h, mi] = t.split(':').map(Number);
  const wall = Date.UTC(y, mo - 1, da, h, mi);
  let guess = wall - offsetMin(tz, wall) * 60000;
  guess = wall - offsetMin(tz, guess) * 60000;   // second pass settles DST edges
  return guess / 1000;
}

export const TZ = { fx: 'Australia/Sydney', metal: 'Australia/Sydney', crypto: 'UTC', etf: 'America/New_York' };

/** name = file prefix (e.g. 'EURUSD'), interval = '5min' | '1h'; kind = 'fx' | 'metal' | 'crypto' | 'etf'; scale multiplies prices (ETF → index level). */
export function loadMarket(name, interval, kind, scale = 1) {
  const files = fs.readdirSync(RAW).filter((f) => f.startsWith(`${name}_${interval}_`));
  const map = new Map();
  for (const f of files) {
    const lines = fs.readFileSync(`${RAW}/${f}`, 'utf8').split('\n');
    const head = lines[0].split(';');
    const iv = head.indexOf('volume');
    for (const l of lines.slice(1)) {
      if (!l || !/^\d/.test(l)) continue;
      const a = l.split(';'); const time = toUtc(a[0], TZ[kind]);
      const c = { time, open: +a[1] * scale, high: +a[2] * scale, low: +a[3] * scale, close: +a[4] * scale, volume: iv > 0 ? +a[iv] : 0 };
      if (![c.open, c.high, c.low, c.close].every(Number.isFinite)) continue;
      map.set(time, c);
    }
  }
  let out = [...map.values()].sort((a, b) => a.time - b.time);
  if (kind === 'fx' || kind === 'metal') {
    // The provider pads the weekend with flat quotes: drop Friday 21:00 UTC → Sunday 21:00 UTC (the whole sample is in US summer time).
    out = out.filter((c) => { const d = new Date(c.time * 1000); const wd = d.getUTCDay(), h = d.getUTCHours(); return !(wd === 6 || (wd === 5 && h >= 21) || (wd === 0 && h < 21)); });
  }
  return out;
}

/** Aggregate candles to `sec` buckets (UTC). */
export function agg(c, sec) {
  const out = []; let cur = null;
  for (const x of c) {
    const b = Math.floor(x.time / sec) * sec;
    if (!cur || cur.time !== b) { cur = { time: b, open: x.open, high: x.high, low: x.low, close: x.close, volume: x.volume }; out.push(cur); }
    else { cur.high = Math.max(cur.high, x.high); cur.low = Math.min(cur.low, x.low); cur.close = x.close; cur.volume += x.volume; }
  }
  return out;
}
