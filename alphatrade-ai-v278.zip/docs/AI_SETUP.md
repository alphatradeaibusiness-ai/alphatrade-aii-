# AI setup — one key for the whole site (v144)

## How it works
- The owner opens **AI key** in the side menu (visible only to the emails in `VITE_ADMIN_EMAILS`), picks the provider, pastes the key and presses **Save & activate**.
- The server makes a real text request and a small image request with that key. Only if the text request succeeds is the key saved and shown as **Connected**; the image result says whether screenshot/vision features work.
- A failing key is **not** saved; the previous working key stays active. Errors are explained: invalid key, no credit, rate limit, model not available, no permission, vision not supported, provider overloaded, timeout/network.
- The key is stored encrypted (AES-256-GCM, key derived from `AI_KEY_SECRET`) in `SERVER_DATA_DIR/ai-config.json` (mode 600), bound to the owner's verified Firebase account. It is never stored in the browser, never written to logs and never returned (only its last 4 characters, to the owner).
- Every AI feature calls the server, which reads the active key on each request, so replacing the key applies everywhere immediately and deleting it stops every feature (`not_configured`).

| Feature | Endpoint |
|---|---|
| AI assistant (chat) | `POST /api/ai/chat` |
| Technical support mode | `POST /api/ai/support` |
| "Explain with AI" (analysis + strategy results) | `POST /api/ai/explain` |
| Chart screenshot reading (vision) | `POST /api/ai/vision` |
| Smart images: describe / pick for headlines | `POST /api/ai/images/describe`, `/api/ai/images/match` |
| Status / owner config | `GET /api/ai/status`, `PUT|DELETE /api/ai/config`, `POST /api/ai/config/test` |

Prompts are built on the server (`src/services/ai/prompts.js`); the browser sends only data (chart snapshot, strategy results), not prompts. The AI is told to use only that data and to explain why strategies disagree. **An AI key does not give live market data** — prices come from the market data source.

## Requirements (production)
1. Run the Node server: `npm run build && npm start` (serves `dist/` and `/api/ai/*`). A static-only host (Netlify static) cannot run the gateway — deploy the server (e.g. Render/Fly/VPS) or proxy `/api/ai/*` to it.
2. `AI_KEY_SECRET` — 32+ random characters (e.g. `openssl rand -base64 48`). Without it, saving is refused.
3. Firebase Authentication configured (`VITE_FIREBASE_*`, and `FIREBASE_PROJECT_ID` on the server). Users must sign in with Google or email; local demo accounts cannot be verified by the server and cannot use AI.
4. `ADMIN_EMAILS` (server) and `VITE_ADMIN_EMAILS` (browser) = the owner's email, verified in Firebase.
5. A provider account with credit. Anthropic: key from console.anthropic.com. OpenAI-compatible: base URL + model (+ vision model).
6. Keep `SERVER_DATA_DIR` on persistent storage.

## Limits
`AI_USER_PER_MINUTE` (10), `AI_USER_PER_DAY` (200), `AI_IP_PER_MINUTE` (20), plus the existing `AI_DAILY_LIMIT` / `AI_DAILY_PER_IP`.

## Tested
- `tests/aiGateway.test.js`: token verification, error classification, validation, encrypted storage, and an HTTP end-to-end run against a mock provider that returns the real Anthropic/OpenAI error formats (owner-only save, failing keys not saved, all six features, key replacement, delete, no key in responses/logs, per-user limit).
- Browser run against the real server + mock provider: bad key / no-credit messages, connect, assistant, support, explain, screenshot vision, smart images, key replacement reflected in replies, delete stops all features, no direct provider calls from the browser, no key in the page or localStorage.
- **Not tested here:** a real provider call with a real key, and real Firebase sign-in with Google's certificates.

## Market-data key (Twelve Data — gold, indices, forex)
- Same page, second card: **Market data key**. The owner pastes the Twelve Data key; the server checks it with one tiny candle request per class (EUR/USD, XAU/USD, DJI) straight to the provider and saves it only if at least one class returns data. The card shows which classes the plan unlocks (a plan can include forex but not indices).
- Stored encrypted in `SERVER_DATA_DIR/market-config.json` (same `AI_KEY_SECRET`, mode 600, bound to the owner account). The browser only ever sees the last 4 characters; `/api/market/twelve` adds the key on the server.
- Replacing the key clears the proxy cache and the "unavailable symbol" list, so every market is asked again with the new key; deleting it returns gold/indices/forex to demo data. Crypto (Binance public data) never needs a key.
- Endpoints: `GET /api/market/status`, `PUT|DELETE /api/market/config`, `POST /api/market/config/test` (owner only). Market data requests have their own limit (`MARKET_IP_PER_MINUTE`, default 240) and no longer use up the AI daily budget.
- Do not use `VITE_TWELVEDATA_API_KEY`: it is compiled into the public bundle.
- Tested: `tests/marketKey.test.js` + browser run against a Twelve-Data-shaped mock. Not tested here: a real Twelve Data key (the network is restricted).

## Phone alerts (Telegram / ntfy) — v147
- Same page, third card. The owner enters the Telegram bot token + chat id and/or an ntfy topic. **Save** sends a real test message first; a channel that fails (rejected token, chat not started, network) is explained and not saved.
- Stored encrypted (`AI_KEY_SECRET`, mode 600) in `SERVER_NOTIFY_DIR/notify-config.json` (default: `SERVER_DATA_DIR`), bound to the owner. The browser only sees "set" and the last characters. Endpoints: `GET /api/notify/status`, `PUT|DELETE /api/notify/config[?channel=telegram|ntfy]`, `POST /api/notify/config/test`.
- The worker (`server/worker.js`) reads the same file (re-read every 10 s). Saved values win; `TELEGRAM_BOT_TOKEN`, `TELEGRAM_CHAT_ID`, `ALERT_TOPIC` are the fallback. In `compose.yaml` the file lives on the `notify-data` volume (web: read/write, worker: read-only) and **both services need the same `AI_KEY_SECRET`**.
- ntfy topics on ntfy.sh are readable by anyone who knows the name: use a long random one.
- Tested: `tests/notify.test.js` (real server + Telegram/ntfy mocks with their error shapes; worker-side reader) and a browser run. Not tested here: delivery to the real Telegram/ntfy services.

## AI trade review — v147
`POST /api/ai/review`: the Smart log page sends statistics only (overall, by direction/session/asset); the server builds the prompt and returns strengths/weaknesses. Needs the AI key; refuses when there are no closed trades.
