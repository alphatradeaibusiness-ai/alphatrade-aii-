# 24/7 worker (analysis without an open browser tab)

`server/worker.js` runs the same engine as the website (`src/services/signals.js`) on a server: scans, publishes, tracks every second,
sends the MT5 messages (ntfy) and a readable phone alert for every new signal / target / stop.

## Steps
1. On the site: Signals → "Details & settings" → **Download worker-config.json** (your settings and MT5 accounts, secrets included).
2. Put it next to the project as `worker-config.json` (or paste its JSON into the `WORKER_CONFIG` variable).
3. Run `node server/worker.js` (Node 22, no install needed) on any always-on machine: a cheap VPS, a Raspberry Pi, Render/Railway/Fly
   (use `Dockerfile.worker`; mount a persistent disk at `/data` so history and sent-trade marks survive restarts).
4. Optional variables: `ALERT_TOPIC` (an ntfy topic for plain alerts), `TELEGRAM_BOT_TOKEN` + `TELEGRAM_CHAT_ID` (the same alerts to Telegram: create a bot with @BotFather, send it any message, then read your chat id from `https://api.telegram.org/bot<TOKEN>/getUpdates`; keep the token in the host's environment only — never in a `VITE_` variable), `TWELVEDATA_API_KEY` (optional fallback for forex/metals/indices — never with VITE_), `PORT` + `WORKER_TOKEN`
   (health at `/health`, signals at `/signals` with the header `Authorization: Bearer <WORKER_TOKEN>`; `?token=…` still works but ends up in access logs). Without `WORKER_TOKEN`, `/signals` is open to anyone who can reach the port — set it when the port is public.
5. On the iPhone: install **ntfy**, subscribe to the topic(s).

## Important
- **Run it OR the open site as the MT5 sender, not both**: each side keeps its own "already sent" list, so both running means the same
  trade may be sent twice. Keep the site tab closed (or MT5 disabled in the browser) while the worker is on.
- Binance blocks some countries/hosts (e.g. US datacentres). Pick a server region where `data-api.binance.vision` answers.
- Not tested against real Binance, ntfy, or MT5 from here (those hosts are blocked in the build environment); it was tested with a local
  market mock: tracking, target alerts, state persistence.
