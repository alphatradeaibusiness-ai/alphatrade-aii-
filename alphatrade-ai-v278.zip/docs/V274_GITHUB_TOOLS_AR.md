# v274 — أدوات GitHub: شو انفحص، شو اندمج، وليش

تاريخ الفحص: 2026-11-09. كل مستودع انفحص فعلياً عن طريق git: إنه موجود، وتاريخ آخر commit، وملف الرخصة.
القاعدة: ولا أداة بتدخل كود التطبيق اللي بيوصل للمستخدم. اللي اندمج إما **للاختبارات بس** (`tools/vendor`) أو **أداة فحص** بتشتغل من برّا (`tools/security-scan.sh`).

## اللي اندمج فعلاً (8)

| الأداة | المستودع | الرخصة | وين | شو بتعمل |
|---|---|---|---|---|
| gitleaks 8.30.1 | gitleaks/gitleaks | MIT | tools/security-scan.sh | فحص المفاتيح المسرّبة. لقت 10، كلها مفاتيح وهمية بالاختبارات → `.gitleaksignore` |
| trivy 0.76.2 | aquasecurity/trivy | Apache-2.0 | tools/security-scan.sh | فحص إعدادات Docker. لقى 4 ملاحظات → اتصلّحت (مستخدم غير root + فحص صحة) |
| osv-scanner 2.7.1 | google/osv-scanner | Apache-2.0 | tools/security-scan.sh | ثغرات المكتبات المعروفة. **ما قدر يوصل لـ api.osv.dev من بيئة الفحص — ثغرات المكتبات ما انفحصت.** |
| trufflehog 3.99.8 | trufflesecurity/trufflehog | AGPL-3.0 | انشغّل مرة | فحص مفاتيح: 0 نتائج، بس بيتجاهل المفاتيح الوهمية حتى بملف تجربة، فدليله أضعف من gitleaks |
| trading-signals 8.3.0 | bennycode/trading-signals | MIT | tools/vendor + tests | مرجع مستقل لحسابات EMA/RSI/ATR/Bollinger |
| technicalindicators | anandanand84/technicalindicators | MIT | tools/vendor + tests | مرجع ثاني مستقل لنفس المؤشرات |
| fast-check 4.10.2 + pure-rand 8.4.2 | dubzzz/fast-check, dubzzz/pure-rand | MIT | tools/vendor + tests | اختبارات خصائص لحسابات أموال نادي الشركاء |
| OWASP Cheat Sheets | OWASP/CheatSheetSeries | CC BY-SA | مراجعة يدوية | حدود حجم الطلب، مقارنة تواقيع آمنة، منع الخروج من مجلد الموقع، هيدرز الأمان، حد الطلبات — كلها موجودة |

## النتائج

- **المؤشرات:** حسابات التطبيق لـ EMA وRSI وATR وBollinger طابقت المكتبتين على شموع حقيقية (BTC ساعة، ذهب 4 ساعات). جرّبت أكسر الحساب عمداً → الاختبار فشل (4 من 8)، رجّعته → نجح 8 من 8. **ما تغيّر ولا سطر بالمؤشرات** لأنها مشتركة مع EDH.
- **أموال الشركاء:** 3 خصائص × 60 حالة عشوائية: العمولة ما بتكون سالبة، المعلّقة ما بتتعدى حدود الهامش والنسبة، تكرار الـwebhook ما بيخلق عمولة ثانية، وكل استرجاع بيعكس اللي انحسب بالضبط. كسرت منع التكرار عمداً → انمسك؛ كسرت فحص الهامش → انمسك.
- **Docker:** التطبيق والعامل صاروا يشتغلوا بمستخدم `node` مش root، ومعهم HEALTHCHECK.

## انفحص وما اندمج (32)

| المستودع | الرخصة | آخر تحديث | ليش لا |
|---|---|---|---|
| semgrep/semgrep + semgrep-rules | LGPL-2.1 / Semgrep Rules License | 2026-11 | المحرّك بينزل من pip، وpip مسكّر ببيئة الفحص |
| github/codeql | MIT | 2026-11 | بدو CLI ورخصة GitHub لمستودع خاص |
| ossf/scorecard | Apache-2.0 | 2026-11 | بيقيّم مستودع GitHub — المستودع لسا فاضي |
| zaproxy/zaproxy | Apache-2.0 | 2026-11 | فحص اختراق لموقع شغّال — بعد الرفع على Render |
| cure53/DOMPurify | Apache-2.0 | 2026-11 | التطبيق بيعمل escape لكل النصوص؛ مكتبة تشغيل جديدة = مخاطرة أكبر من الفائدة هلأ |
| helmetjs/helmet | MIT | 2026-10 | لـ Express؛ السيرفر عنده نفس الهيدرز يدوياً |
| animir/node-rate-limiter-flexible | ISC | 2026-11 | السيرفر عنده حد طلبات؛ مفيد لما يصير في Redis |
| colinhacks/zod | MIT | 2026-11 | تحقق من المدخلات — مرشّح لجولة جاية بدون ما نكبّر الحزمة |
| eslint-community/eslint-plugin-security, eslint/eslint | Apache-2.0 / MIT | 2026-11 | بدهم npm |
| dequelabs/axe-core | MPL-2.0 | 2026-11 | بناؤه بدو مكتبات npm؛ مرشّح أول للجولة الجاية |
| GoogleChrome/lighthouse | Apache-2.0 | 2026-11 | بدو npm |
| stryker-mutator/stryker-js | Apache-2.0 | 2026-10 | بدو npm؛ عملنا نفس الفكرة يدوياً (كسر الكود عمداً) |
| microsoft/playwright | Apache-2.0 | 2026-11 | مستعمل أصلاً بفحوصات المتصفح |
| tradingview/lightweight-charts | Apache-2.0 | 2026-11 | مستعمل أصلاً بالشارت |
| ccxt/ccxt | MIT | 2026-11 | كبيرة كثير؛ التطبيق بيحكي مع Binance مباشرة |
| binance/binance-spot-api-docs | — | 2026-11 | مرجع للـAPI المستعمل |
| cinar/indicatorts | MIT | 2026-11 | مكتبتين مرجع كفاية |
| TA-Lib/ta-lib-python, bukosabino/ta | BSD / MIT | 2026 | بايثون — للبحث مش للتطبيق |
| kernc/backtesting.py | AGPL-3.0 | 2026-08 | AGPL بتلزم نفتح كود التطبيق إذا اندمجت |
| polakowo/vectorbt | Apache-2.0 + Commons Clause | 2026-11 | Commons Clause بيمنع البيع التجاري |
| freqtrade/freqtrade | GPL-3.0 | 2026-11 | GPL + بوت تداول كامل — مرجع أفكار بس |
| jesse-ai/jesse | MIT | 2026-11 | إطار بايثون كامل — مرجع |
| ranaroussi/quantstats | Apache-2.0 | 2026-11 | بايثون؛ مقاييس الأداء (Sharpe، التراجع) مرشّحة نكتبها بـ JS مع اختبار مقارنة |
| microsoft/qlib | MIT | 2026-10 | منصة أبحاث ML ضخمة |
| hummingbot/hummingbot | Apache-2.0 | 2026-09 | بوت صناعة سوق — خارج نطاق التطبيق |
| twopirllc/pandas-ta | — | — | **المستودع مش موجود على GitHub هلأ** |
| languagetool-org/languagetool | LGPL-2.1 | 2026-11 | Java + خادم؛ يدعم العربي — مرشّح لتدقيق النصوص |
| textlint/textlint, get-alex/alex | MIT | 2026 / 2024 | للإنجليزي بالأساس |
| OWASP/CheatSheetSeries | CC BY-SA | 2026-11 | (استعملناه كمرجع فوق) |

## ما انعمل وليش

- **أدوات «إخفاء كتابة الذكاء الاصطناعي»:** ما اندمجت. تخبية إنه النص من AI عن عملاء تطبيق تداول تضليل. البديل: نصوص عربية طبيعية وواضحة.
- **دمج تلقائي 24/7 بدون مراجعة:** ما انعمل. كل أداة لازم تعدّي فحص واختبار قبل ما تدخل. بعد ما ينرفع الكود على GitHub ويرتبط، بنقدر نعمل مهمة مجدولة أسبوعية بتفحص وبتقترح — مش بتدمج لحالها.
