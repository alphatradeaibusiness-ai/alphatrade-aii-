# Enhancement rules + pseudocode (tested on real BTC data, 5m/15m/30m, 2022-11 → 2026-10)

Numbers are E[R] per trade (gross = fee 0, net = fee 0.04% round trip). IS = first 60%, OOS = last 40%.

| # | Enhancement | Result on real data | Verdict |
|---|---|---|---|
| 1 | MTF alignment (1h/4h EMA trend of last CLOSED bar) | 5m gross 0.02→0.02/0.03; 15m 0.06→0.03; 30m −0.04→−0.03. No OOS gain, fewer trades | not adopted as default (option kept: `htfFactor`) |
| 2 | Session-high/low sweep before entry | 5m OOS −0.20; 15m OOS 0.04 (IS 0.16); 30m OOS −0.19. Flips sign IS→OOS | not adopted |
| 3a | ATR spike block (>2x median of 100) | 5m −0.03→−0.02 OOS; 15m 0.06→0.05; flat | harmless, no edge |
| 3b | Spread filter | candles have no bid/ask: cannot be backtested. Live hook = pseudocode below | untested |
| 4 | SL 1.5×ATR, TP 2.5/3.5/5 (min RR 2.5) | gross 5m 0.02→0.06, 15m 0.06→0.08, but net still −0.23 (5m) / −0.03 (15m) | best of the set, still negative after fees |
| 5 | Daily loss cap in points | 5m: worst day −3,981 → exactly −300/−500/−1000; 0 days over cap; net loss −39.7k → −17.4k (cap 300) | **implemented** (`risk.dailyLossPts`) |

The cap cuts the loss because it cuts the number of trades; it does not create an edge.

## Rules
1. HTF bias: `bias = sign(close_htf - EMA50_htf)` using only closed HTF bars (5m→x12/x48, 15m→x4/x16). Trade only with the bias.
2. Sweep: after price takes the previous session high/low by wick and closes back inside, allow an order-block entry in the opposite direction within 12 bars.
3. Volatility: block when `ATR14 > 2 × median(ATR14, 100)`; block when `spread > 2 × median(spread, 100)` or slippage > limit.
4. Stops: `SL = entry ∓ 1.5·ATR`; targets `[2.5, 3.5, 5]R`; skip if `RR < 2.5`.
5. Kill-switch: block when `max(0, −dayNet) + worstCase(trade) > dailyCapPts`.

## Pseudocode
```
onSignal(s):
  if htfBias(s.symbol) != s.direction: return SKIP
  if not sweptSessionExtreme(s, lookback=12): return SKIP
  if atr(14) > 2*median(atr,100): return SKIP
  if liveSpread() > 2*medianSpread(100) or expectedSlip > maxSlip: return SKIP
  risk = 1.5*atr(14); if rr(s,risk) < 2.5: return SKIP
  worst = risk/pointSize + feePct*entry/pointSize
  if max(0,-realisedLossToday) + worst > dailyCapPts: return HALT_DAY
  open(s, sl=entry-dir*risk, tp=[2.5,3.5,5]*risk)
```
Use: Settings → risk → "Daily loss cap (points)". Same field exists for the monthly cap.

## v81: execution filters now in the app (Settings → "Execution filters")
`src/services/execFilters.js`, applied to classic, SMC v2 and Zone in the backtest AND in live signals (the same engine):
killzone (London 07-10 / NY 12-15 UTC), Silver Bullet hours (NY local 03-04, 10-11, 14-15, DST-aware), ATR band (0.7x-3x of the 20-avg),
PDH/PDL + Asian high/low sweep (opposite direction, 12 bars), CVD divergence (needs taker-buy volume; skipped when the feed has none),
imbalance-void block (unfilled FVG > 1 ATR), and a live-only order-book wall check (two depth snapshots 2s apart; fails open).
All OFF by default. "Apply pro management" sets SL 1.5xATR, targets 1.5/2.5/4, breakeven 1.2R, 1.5xATR trail, killzone + ATR band.
Position split stays thirds at TP1/TP2/TP3 (not 50/50).
Real BTC 15m, fee 0, classic: none n=2465 E=-0.095R; killzone n=926 -0.104; sweep n=422 -0.056; void -0.098; ATR band -0.095. No filter turns it positive.

## v89: 4h order-block gate + anomaly filter (Settings → Execution filters)
`htfOb`: entry must sit inside a same-direction, alive 4h order block (displacement >= 1.5 ATR, close beyond previous extreme, 0.25 ATR tolerance, max 60 bars).
`anomaly`: reject signal candles with an adverse wick >= 50% of range (or > 2x body), a range > 3 ATR (news spike), volume < 0.8x average or opposing volume > 1.5x.
Real BTC, gross of fees, engine run (IS / OOS = first 60% / last 40%):
- 15m  none 0.05 / 0.08 (n 1887) | anomaly 0.09 / 0.12 (n 1237) | htfOb -0.07 / 0.26 (n 114) | both -0.34 / 0.24 (n 67)
- 5m   none 0.08 / 0.01 (n 1788) | anomaly 0.06 / 0.04 (n 999)  | htfOb 0.38 / 0.14 (n 126) | both 0.27 / 0.19 (n 83)
After a 0.04% fee every case is still <= 0 net except small out-of-sample slices (n 23-68). Both are OFF by default.

## v90 — EDH strategy
Previous-UTC-day high/low; SELL when a 5-minute candle closes below the low, BUY when it closes above the high (on 1m candles only the last minute of each 5m slot counts). Stop `slPips`, Target 1 >= 30 pips, Target 2 70–80 pips (thirds: 1/3 at T1, 2/3 at T2, stop to entry after T1). 1 pip = 10 points on gold/crypto, 1 on indices. Optional RSI(14) filter, max signals per side per day. Chart button "EDH" draws PDH/PDL. Included in performance, monthly cards and the signals channel.
Real BTC (500-day-ish cache, all 1 pip = $10): 5m gross +3100 pts / 156 trades, 15m gross +13000 / 527; after 0.04% fees both turn negative (−1343, −5815). Not validated as profitable on BTC; fees dominate.

EDH add-on: liquidity-sweep zones (swing high/low wicked and closed back) and Order Blocks (last opposite candle before a >=2×ATR displacement) are drawn with EDH on. Drawing only; signals/targets unchanged.

EDH execution: breakout read on the 5-minute close; entry on the 1-minute candle that closes it; stop and Target 1 on every 1-minute candle; Target 2 only on a confirmed 5-minute close beyond it (edh.confirm5, default on; Pine input too). On 5m or higher data it behaves as a normal limit.

v97 EDH on both 1m and 5m: levels come from real daily candles (so the 1m chart shows PDH/PDL too); targets are per timeframe (1m: T1 30 / T2 70 / SL 30 pips; 5m and slower: T1 45 / T2 80 / SL 40), editable in Settings. Real BTC 3 Aug–2 Oct 2026, 48 trades each: 1m net +56 pts at 0.1% fee, +2223 at 0.04%; 5m −510 at 0.1%, +1656 at 0.04% (small sample).

v98 AlphaRadar: RSI + volume + ATR filters read straight from the candles (services/radarFilters.js), all-frames mode (5m/15m/1h/4h/1D with per-frame chips), strong/weak/unstable grading, weak and unstable readings hidden unless 'show weak' is on. Real BTC check (2022-2026 1h/4h, 2025-26 15m): the filters did not raise the direction hit-rate (strong 46-48%); average forward return of strong calls +0.09 to +0.11% per call before fees.

## Radar accuracy study (Oct 2026) — no change shipped
Goal: lift radar direction accuracy above 60%. Data: BTCUSDT 15m (2025-26), 1h and 4h (2022-26), ~24,000 radar readings. Candidate conditions: RSI bands, ATR ratio bands, volume ratio, 3-candle stability, candlestick confirmation (engulfing / hammer / shooting star / pin bar, and "no opposite pattern"), body direction, bias strength, SMC agreement, pullback distance from EMA 50. All 1–3 condition combinations (~2,300) were searched on the first 60% of the time line and then checked on the last 40%.
Result: the best in-sample combinations reached 60–67% (e.g. 4h: ATR>1 + volume<0.8 + pullback 66.7%), but on the held-out 40% they fell to 46–54%. No combination with >=60 held-out readings reached 60%. Best pooled out-of-sample: RSI<45 + ATR>1 + stable, 56% on 109 readings (not significant, and picked from ~2,300 tries). Candlestick confirmation did not help (patWith + pullback: 58% train -> 44% test on 15m).
Conclusion: the 60% target is not reachable with these inputs on BTC; tightening filters only found noise. Nothing was added to the live radar.

### Follow-up: liquidity levels added, target 70% — still not reachable
Added features: a same-direction liquidity sweep in the last 24-96 candles, an opposite sweep, distance (in ATR) to the nearest untouched swing high/low ahead and behind, and the previous-day high/low (broken / distance). Same train (first 60%) / test (last 40%) protocol, ~3,000 combinations.
Best in-sample: 4h "RSI>60 + trend + liquidity ahead >3 ATR" 76% -> 40% held-out (n=62); "ATR>1 + pullback + liquidity ahead" 68% -> 49%. Pooled best held-out: RSI<45 + ATR>1 + pullback, 56% (n=84). A few 4h combinations show >=60% on the held-out part, but they were picked by looking at the held-out result, and 4h readings overlap (a 12-candle outcome is shared by 12 consecutive readings), so the real sample is ~12x smaller. Not a validated edge. Nothing shipped.

### Radar ablation (Oct 2026): every part scored on its own
BTC 15m / 1h / 4h, ~24,000 readings, direction hit-rate vs the next 48 / 24 / 12 candles, first 60% (train) and last 40% (test). The "% of windows that went up" baseline is 50.8 / 51.8 / 52.7.
Current formula (trend 30, momentum 25, SMC 30, RSI 15): test 48.6 / 48.4 / 49.0. Removing any one part or keeping only one part: 47.5-49.9 on every timeframe, i.e. every component is the same noise and none of them hurts or helps by more than ~1.5 points. RSI used the other way round (mean-reversion) gives 50.4 / 52.0 / 51.5 — close to the baseline and not stable enough to adopt. No part was removed; no change shipped because nothing here beats chance, so no re-weighting can reach 70%.

## v101 — MT5: multiple saved accounts, connection password, per-account strategies, 85% lock
- Saved accounts (localStorage `mt5v2`, migrated from the old single account): name, account number, server, own channel + connection password, lots, max groups, suffix, strategies, locks. Every enabled account whose strategy list contains the trade's strategy gets the signal, signed with its own password; sent-once tracking is per account.
- "Account password" = connection password (min 10 chars, plain printable characters without " \ |, strength meter, generate / show / hide). It signs every message and is embedded in that account's EA (escaped for MQL5). The broker / trading password is never asked for or stored.
- EA stop ladder: TP1 -> stop to entry (leg 1 closes at TP1); TP2 -> lock Lock2Pct (50); near TP3 (price covers Lock3AtPct = 95% of the way) -> lock Lock3Pct (85) of the TP3 profit. All three editable per account.
- Not done / limits: the EA cannot be compiled here (no MetaEditor) and was never run against a real MT5 terminal; test on a demo account first. Passwords sit in this browser's localStorage (same as before for the old secret).

## v103 — login animation freeze
Cause: dashboard mount + AI model training (fitLogistic, ~2 s on phones) ran on the main thread while the welcome animation played. Fix: overlay holds still while the app mounts, animation starts when frames are smooth, AI training waits for the animation to end, countdown no longer forces layout every frame, fewer particles. Measured max frame gap during the animation: 1333 ms -> 167 ms.

## v104 — security hardening
- CSP now enforced (no inline scripts); verified 0 violations on sign-up, intro and dashboard.
- AI server: same-origin check, per-IP + global daily budget, real-IP behind proxy, optional bearer token, 5 MB body cap, no-store/nosniff.
- Local accounts: PBKDF2-SHA256 (210k), old SHA-256 accounts upgraded at sign-in, constant-time compare, lock-out persists across reloads and grows with repeated failures.
- Not fixable client-side: password reset without email proof, plan enforcement, public Twelve Data key — need Firebase + a backend.

## v105 — full audit
- 29 routes + every button + XSS payloads in every text field: 0 page errors, 0 script executions; undefined-identifier scan over src/server/tools: 0; sign-up/sign-in/profile/password/journal/portfolio/alerts flows verified.
- Hardened: scraped news links (http/https only), calendar impact whitelist (used in a CSS class), avatar data-URL check.

## v106 — EDH + liquidity + engulfing in one indicator (and the honest numbers)
New optional EDH rules (all OFF by default): `needEngulf` (the 5m break bar must engulf the previous 5m body), `engulfBody` (size ratio), `engulfExit` (leave before Target 1 on an opposite engulfing 5m bar), alongside the existing `needSweep` / `obGuard`. Same logic in the site (`edhEngulf`, backtest, live card) and in the Pine script (`pine/EDH_strategy.pine`).
Real BTCUSDT test (5m: 2026-04→2026-10, 1m: 2026-08→2026-10, fee 0.04%, real daily levels from 1h):
- 5m base: 158 trades, win 51.9%, PF 1.08. +engulfing: 77 trades, win 41.6%, PF 0.76. +sweep: 115, 44.3%, PF 0.81. +sweep+engulf: 50, 44.0%, PF 0.80. engulf-exit: win 38.1%, PF 0.94.
- 1m base: 51 trades, win 60.8%, PF 1.25. +engulfing 47.8% / PF 0.55; +sweep 61.7% / PF 1.36 (n=47, inside noise).
- Look-ahead check: trades before a cut are identical with or without the future (0 mismatches).
Conclusion: none of the additions improved EDH out of the box; keep them OFF unless your own data shows otherwise.

## v107 — EDH cleanup: removed what did not help, added the trend filter
Removed from EDH (all measured on real BTCUSDT, fee 0.04%, no look-ahead): RSI filter (zero effect), engulfing filter and engulfing exit (win 52% -> 42% / 38%), sweep requirement and opposing-OB guard (PF 1.08 -> 0.81 / 0.95), several entries per side (PF 0.95), session, ATR-relative, breakout-buffer, loss-per-day and previous-range filters (neutral or inconsistent across timeframes). The sweep boxes / Order Blocks stay as chart context only.
Added: trend filter = trade only with the 200-hour EMA (computed from real 4h closes; falls back to the chart's own closes). Same direction of improvement on 1m, 5m, 15m, 30m:
| tf | no filter (n, win, PF, DD) | with filter |
| 1m | 51, 60.8%, 1.25, 6.1R | 37, 62.2%, 1.26, 5.8R |
| 5m | 158, 51.9%, 1.08, 9.4R | 116, 55.2%, 1.21, 8.6R |
| 15m | 525, 48.4%, 0.93, 31.4R | 417, 49.9%, 1.02, 17.9R |
| 30m | 514, 46.9%, 0.89, 38.1R | 412, 49.0%, 0.98, 27.6R |
Not statistically significant (t < 1 on 5m); the 15m/30m rows are the independent check. Also fixed: the dashboard only loaded 4h/daily candles for SMC, so EDH's daily levels and the trend EMA could be missing on 1m.

## v108 — strategies audit (classic / SMC / zone)
Real BTCUSDT, fee 0.1%, 15m+30m 2025-01→2026-10, 1h+4h 2022-11→2026-10 (`strat_ablate*.mjs`).
- Removed dead code: the legacy SMC order-block engine (`backtestSmcLegacy`, only reachable via an undocumented flag) and the options only it read (`smcTrend`, `confirmMomentum`, `smcHtfFactor`). Switching them off changed nothing in any run.
- Classic: a wider ATR stop (3 instead of 2) plus the shared 200-hour EMA trend gate (4h closes) is the new default. OLD -> NEW: 15m win 49.7->53.2%, PF 0.82->0.83, DD 106->58R; 30m 46.7->45.4%, PF 0.66->0.67, DD 132->77R; 1h 50.6->52.4%, PF 0.86->0.92, DD 47->17R; 4h 53.1->55.6%, PF 1.03->1.25, DD 10.8->10.9R. Thresholds (65/35 etc.) were noisy, not adopted. Still not profitable on 15m/30m.
- SMC v2 and Zone make 0-14 trades in 4 years with the default score gates, so no statistical verdict is possible. What the runs do show: without the higher-timeframe filter or the kill-zone both are clearly worse, so those stay.
- Existing users keep their saved ATR multiple (2); the new default applies to new accounts and "restore defaults".

## v109 — EDH m5 stop + MT5 champion gate
- EDH m5 default SL 40 → 60 (BTC, 36-combo tuning, h4 trend on): win 55% → 66%, max DD 8.6R → 4.0R, expectancy +0.111R. 1m unchanged (n≈37, too few). Saved user settings keep old values.
- MT5 gate (`services/mt5Gate.js`): a trade is sent only if its strategy+tf is the symbol's champion — qualified, daily pips > 0, highest win rate AND highest daily pips, proof ≤ 6 h old. Split leaders, no proof, or no qualified strategy ⇒ no trade (fails closed; also applies to alert-only accounts). EDH 1m is never auto-traded. MT5 page shows per-symbol status and recent blocked trades.
- Limitation: per-currency backtests could not be run offline (only BTC real data available); the site computes proof per symbol from live data (hourly `edhProof` + scan).

## v110 — MT5 approval mode + SMC swing channel
- New per-account `mode`: alert / **approve** / auto. Approve: the EA draws an "OK – open trade" and "Skip" button on the MT5 chart (entry, SL, TP1-3, countdown). Nothing opens until OK is pressed; the panel expires after `ApproveWaitSec` (300 s). OK re-checks slippage, max open trades and symbol before placing the 3 legs, with the same stop management as auto mode.
- New `swing` flag: the account receives only SMC setups on the 15m chart.
- Gate: auto and alert accounts still require the proven champion (v109). Approve accounts receive the setup with "OK?" or "OK? (unproven)" in the notice, because a human decides.
- EA polls every 1 s in approve mode (free ntfy.sh rate-limits; the EA backs off 15 s on HTTP 429). Signals come from the browser scan (60 s on closed candles), so the site tab must stay open.
- Limits: the OK button is in MetaTrader desktop (EA); the ntfy phone notification cannot open the trade by itself. SMC is rare and not proven (see v108).

## v112 — Recommendation channel (AlphaTrading)
- Client picks ONE preferred strategy: EDH, SMC or Confluence (= the existing Zone strategy: supply/demand zones confirmed by a fixed Volume Profile + RSI + Fibonacci). The feed, notifications, pop-up card and the signal bar show that strategy only; the MT5 accounts' strategy list follows it. Classic stays in the engine but is not a channel option.
- New animated recommendation card (`components/signalCard.js`): logo, "AlphaTrading", pair, entry, stop, TP1-3; pops up when a new signal of the chosen strategy arrives (14 s, closable, honours reduced-motion).
- Real monthly summary (`services/channel.js`): every published signal is logged permanently (3000 max) and updated as it moves; per month and strategy: signals + realised pips (stop = −risk, each target = ⅓ of its distance, rest at entry = 0; no fees). Link to the backtest monthly page.
- MT5: new accounts default to approval mode (the client presses OK on the MT5 chart).
- Fix: the shield icon of the risk-guard card on the signals page had no size and stretched the whole page on phones.

## v113 — Daily cap, 62% floor, one-month window, mistake review
- Max 6 signals of a strategy OPEN at the same time (`OPEN_CAP`), not 6 per day: when a trade closes its slot opens again, so no qualifying signal is missed. Counted from the persistent log.
- Minimum real accuracy to qualify lowered 67% → 62% (`MIN_ACCURACY`; still needs 30 trades, positive net points and R, and the out-of-sample check at 60%/10 trades). This admits weaker combinations than before; the MT5 champion gate is unchanged and still demands the best win rate AND daily pips.
- The channel record and learning look back one month only (`WINDOW_DAYS` 30, older rows are dropped).
- Mistake review (`reviewMistakes`): a symbol+timeframe+strategy with ≥4 closed signals in the month, <50% reaching TP1 and negative net pips is paused for 3 days after its latest close, then gets another chance. It does not retune parameters. One month is a small sample.
- Risk guard `maxActive` default 3 → 6 so the 6 open slots can be reached (a value already saved in Settings is kept).

## v115 — OK from the phone, 1 s live card, statistics on top
- Approval accounts: the ntfy phone notification now carries an "OK ✓" button (ntfy http action). It posts `ATAOK|id|ts|sha256(secret|OK|id|ts)` to the account's private channel; the EA (HandleApproval) verifies the signature, checks the age and that the signal is waiting, then runs the same Execute() as the on-chart OK button. Entry, stop and the three targets come from the signal. Replays do nothing (the pending signal is removed). NOT tested on a real phone/MT5 here — test on a demo account.
- Open signals are tracked every second (`TRACK_MS` 1000); the compact card (tiles: entry, stop, TP1-3, live price + pips, progress bar, targets tick off) repaints each second without redrawing the page.
- Statistics card above the channel: last 30 days per strategy (signals, won/closed, pips), the best strategy by real results (needs ≥5 closed signals and positive net pips) with a one-tap "use it" button, and the mistake-review list.

## v116 — Ladder card
- The recommendation card is now one horizontal price ladder (left = stop, right = TP3, always, in both languages): ticks at stop / entry / TP1-3, a glowing dot with a price bubble that glides along the ladder with the live price every second, a green (profit) or red (loss) fill from entry to the dot, targets light up when hit, live pips below. Labels sit in a fixed 5-cell row so close targets never overlap. Opaque background, ~150 px tall.

## v117 — Ladder polish
- Ladder: red risk zone and striped green reward zone, flowing stripes on the filled part, diamond target markers that burst once when reached, comet trail + pulsing ring on the price dot, price bubble whose digits roll to each new price, "next target · distance in pips" chip, entrance animation (zones draw in, markers drop in, the dot lands). Reduced-motion users get a static card.

## v118 — Target 2 = Target 1 + 50 points everywhere
- `applyTpGap` (backtest.js) is applied to classic, SMC, Zone and EDH, so every analysis, chart plan, signal and MT5 message has TP2 exactly `tpGapPts` (default 50, Settings → Plan, 0 = off) points beyond TP1. TP3 keeps its own distance beyond TP2 but never less than the same gap. EDH: TP3 is the old Target 2 (70–80 pips); its thirds are now 1/3 at TP1, 1/3 at TP2, 1/3 at TP3.
- Measured effect on real BTC data (fees 0.1%): classic 1h exp +0.012R → −0.028R, 4h +0.076R → +0.037R, 15m −0.082R → −0.060R; EDH 5m +0.040R → −0.001R (win 66.1% → 65.2%), EDH 15m −0.052R → −0.074R. Slightly worse on most; kept because it was requested explicitly.

## v119 — Target 3 = Target 2 + 30 points everywhere
- `applyTpGap` now takes both gaps: TP2 = TP1 + `tpGapPts` (50), TP3 = TP2 + `tp3GapPts` (30), for classic, SMC, Zone and EDH (Settings → Plan; 0 = that step left as computed). EDH's old "Target 2 pips" no longer affects the targets.
- Measured on real BTC data (fees 0.1%, vs. no gaps): classic 1h +0.012R → −0.035R, 4h +0.076R → +0.018R, 15m −0.082R → −0.059R; EDH 5m +0.040R → −0.003R (win 66.1% → 65.2%), EDH 15m −0.052R → −0.076R. Kept because it was requested; widen the gaps in Settings if it costs too much.

## v120 — Compact signals channel
Signals page decluttered: one-line header, strategy chips with open slots, three small monthly tiles, then a tidy vertical list of small signal cards (empty channel = one muted line). Notification, guard, tracking, learning and qualification settings moved into a collapsed "Details & settings" block.

## v121 — 24/7 worker
`server/worker.js` (+ `Dockerfile.worker`, `docs/WORKER.md`): headless run of the same signals engine with browser shims; settings exported from the site; state persisted to state.json; ntfy alerts; /health.

## v122 — Real data when Binance is blocked
Binance requests fall back: configured host → this site's /binance proxy (Netlify redirect in public/_redirects) → api.binance.com / api1 / api-gcp. The working host is remembered.

## v123 — Monthly scope and no trade limit
Results: current + previous calendar month only (pips, wins ✓ / losses ✗, rate). Open cap (6) and risk maxActive / plan maxPerDay defaults removed (0 = no limit; old saved 6 migrated once). Mistake review stays on a rolling 30 days.

## v124 — Confluence lab (separate page)
New page `#/app/confluence` (side drawer → Analysis → Confluence lab): the Confluence (zone) strategy vs Classic and SMC on 1h/4h since 2022 (as far as the data reaches), table, equity curves, per-year points, honest verdict (needs ≥30 trades each; never 'stronger' on a handful). Read-only: no strategy was changed or removed. BTC result (2022-11 → 2026-10, default settings): Confluence 0–5 trades, Classic negative → no evidence to delete anything.

## v125 — Continuous scanning (no trade-conditions loosened, on purpose)
Scanning no longer pauses while the tab is hidden. Strategy conditions were NOT loosened: BTC test (2022–2026) showed that lowering SMC score / removing kill-zone & HTF filters raises trades (3 → 45–67) but drops win rate to 25–39% with negative expectancy; on 5m/1m SMC and Confluence give ≤1 trade, Classic ~52% (below the 62% gate). Signals are therefore still published the moment a strategy's conditions AND the 62% proof pass, on every scan (60 s), with no daily/open limit.

## v126 — Proven signals only (>= 62%)
Chart-page trade alerts (phone + MT5) now require the strategy/timeframe to be qualified (>=62% overall and on the newest 40%). Fibonacci-break alerts have no measured accuracy, so they are off by default (one-time migration; can be switched on again).

## v127 — SMC research + optional rules
New optional SMC v2 rules (htfMode, reversal, minDisp, fvgMin, maxAfterTap, stopBufAtr, maxRiskAtr, rsiGate; defaults unchanged, verified identical output), slippage in the backtest cost (`slipPct`), `tools/smc_research.mjs` (walk-forward report), `docs/SMC_RESEARCH.md`. Result: no variant reaches 63% out of sample on BTC.

## v128 — Month-by-month detail, strategy report
Monthly page: new 'Month by month' table (strategy / year / month filters; per month trades, W/L, win %, gross win & gross loss pips, net, avg win/loss, loss streak, max DD; open trade separate with floating pips). `src/services/monthlyDetail.js`, `src/components/monthlyDetailTable.js`, `tools/strategy_report.mjs`, `docs/STRATEGY_REPORT.md`. No strategy logic changed; EDH untouched.

## v129 — Automatic best strategy per symbol (this month)
Channel option 'Auto ★': per symbol, from this month's REAL closed signals (open ones excluded): needs >= N closed signals (adjustable, default 5) and a positive net; ranked by net pips / (1 + max drawdown), never by win rate alone; otherwise 'Not enough data' / 'No profitable strategy'. Table shows symbol, strategy, period, trades, net pips, win %, max drawdown; refreshes when signals close. In auto mode the client sees / is notified of / MT5 receives only the symbol's pick. `channel.js` (monthStrategyStats, recommendAuto, channelWants), signals page, tests.

## v130 — Real staged analysis for "Auto ★" (existing feature, no duplicate)
- The existing auto-pick chip/card on the signals page now runs `analyzeAuto()` (src/services/channel.js) when the chip or the new button inside the same card is pressed.
- Stages (scan → evaluate per coin → compare/sufficiency → prepare) fire from the real steps over the stored closed-signal log (`monthStrategyStats` / `recommendAuto`); no fixed values and no timers (only a one-frame yield so the page can paint a stage).
- Result appears only after the last stage: coin, strategy, period, trades, net pips, win rate, max drawdown, reason. No data / no profitable option / unreadable log → stated clearly, no winner.
- Changing the minimum-trades value resets the card to "idle" (a stale result is never shown). Reduced-motion: spinner animation disabled.
- Tests: `tests/mt5.test.js` (analyzeAuto: stage order, values equal monthStrategyStats, noData/noPositive/error). Browser run on mobile + desktop viewports with seeded log.
- Files: src/services/channel.js, src/pages/signals.js, src/i18n/ar.js, src/i18n/en.js, src/styles/fx.css, tests/mt5.test.js, docs/ENHANCEMENTS.md.

## v131 — Code audit: freezes, leaks, logo colour, notifications, security, dead code
Measured with Playwright + Chrome DevTools traces on the built site (mock market data, CPU throttled ×4 to mimic a phone).
- **Chart page freeze (root cause):** the AI engine trained its models on the main thread (up to 2.4 s blocked at a time). It now runs in a Web Worker (`src/services/aiWorker.js`, `aiAsync.js`, pure step in `aiCore.js`); same code and same numbers (test `tests/aiAsync.test.js`), falls back to the main thread if Workers are unavailable. Longest task on the chart page: 2437 ms → 96 ms; total blocked time in 15 s: 6.8 s → 0.5 s.
- **Price axis formatting:** `toLocaleString` with options per label per frame → cached `Intl.NumberFormat` (`fmtNum`), identical output.
- **Hidden chart page:** no repaint / AI / panel updates while another page is open (chart alerts keep working); refreshed on return.
- **Signals page:** the 8000-row log is parsed only when it changes (was ~3 full parses a second); panels rewritten only when their HTML changes; a `click` listener was added to the "clear" button every second (fixed); tracker writes the log once per tick (`logSignals`).
- **Listener leaks:** header and chart panel left `document`/`window` listeners behind on every rebuild (login, logout, language switch): +4 per switch → 0 (AbortController). Tool pages' timers stop when the page is swapped (`runUnmount`), snapshot paste listener removed.
- **Background scanner after logout:** signal scanning and alert checks now stop on sign-out.
- **Signal bar:** prices patched in place; the scrolling strip no longer restarts (jumps) every second.
- **Radar multi / levels:** chart loads and analysis split into separate tasks (opening lag ~300–530 ms → longest task < 75 ms).
- **Animations:** looping decorations pause when their card is off screen or the side menu is closed (resume on view); reduced-motion support unchanged (catch-all in base.css).
- **Logo:** in the light theme the "A" faded to brown (theme text colour leaked into the logo gradient) → logo keeps its gold in every theme.
- **Notifications:** permission errors handled, "blocked/failed" now shown to the user instead of silence; the worker-config download no longer fires twice after enabling notifications.
- **Security:** AI proxy refuses POSTs without an Origin (unless the access token is sent), constant-time token compare, rate limits use the right-most X-Forwarded-For, provider error details no longer echoed; Forex Factory proxy served with `CSP: sandbox` + `nosniff` (Node server and netlify.toml); self-hosted static files get the same CSP/headers as Netlify; X (Twitter) embed allowed in CSP; worker `/signals` accepts a Bearer header with constant-time compare; CSV exports neutralise formula cells. Test: `tests/serverSecurity.test.js`.
- **Removed (confirmed unused, 0 references):** `PALETTES`, `regenerateMt5`, `tfQuality`, `tfScore`, `firebaseApp`, `FIREBASE_CDN`, `prefersReducedMotion`, `translateDom`.
- **Not done / open:** Twelve Data key is still a VITE_ variable (visible in the bundle) — moving it needs a server function; MT5 signing stays sha256(secret|…) for EA compatibility (HMAC would need a new EA); `npm audit` could not run (registry blocked here); `vite build` not available here (built with esbuild, same entry points).

## v132 — Audit, second pass (what v131 left open)
- **Welcome animation stutter after sign-in:** the first chart render (analysis + drawing, ~0.6 s on a phone) and the first market scan ran while the intro played. The first chart render now waits for the intro to finish, and the scanner starts 2.5 s after it. Measured (phone emulation, CPU ×4): long tasks while the intro plays 1.1–3.0 s with blocks of 180–340 ms → none after the first 1.7 s (only the shell build: 200 + 377 ms before the intro starts).
- **Chart frame loop:** the price-glide loop ran at 60 fps forever (also on other pages). It now runs only while the price is moving and otherwise wakes once per second for the countdown (verified: countdown ticks each second, resumes after returning to the page, price glides after each update).
- **Login cards:** two decorative scans animated `top` / `left` (layout every frame) → same paths with `transform`.
- **Checked, no change needed:** session (reload keeps you in; "remember me" off = only this tab; protected pages redirect to login after sign-out; wrong password message); scanner still starts and fills the qualification table; auto-pick analysis (v130) unchanged.
- **Finding (not changed — design decision):** on every page ~17 looping effects animate properties the browser cannot hand to the GPU (gradient-text shimmer, glow filters, conic border spin, wave stroke, box-shadow pulses). Pausing just those drops main-thread load on a content page from ~106 ms/s to ~1 ms/s (phone emulation), but converting them changes how they look.

## v133 — Platform upgrade inside the existing structure (no rebuild, no duplicate tools)
Audit first: most requested tools already existed (scanner, AI card, journal, calendar, position sizing, lab, monthly results, signal log). They were completed, not duplicated. Only two navigation additions: Trust Center (info group) and a Versions tab inside the existing Lab hub.
- **Chart fixes:** overlay labels no longer stick to the chart edge when their candle is scrolled out of view (Fibonacci break tags, liquidity tags, structure breaks); the plan (entry/stop/targets) hides while you look at older candles; pinned target labels sit below the AI badge instead of under it. Pan/zoom: overlays are drawn in price/time coordinates (verified by dragging on desktop and swiping on phone: horizontal swipe pans the chart, vertical swipe scrolls the page).
- **RTL/LTR:** English pages are fully LTR (checked on 30 routes). Arabic: mono cells holding words (dates, "per month", "no limit") now read right-to-left (`unicode-bidi: plaintext`), pricing title follows the page direction. The chart toolbar stays LTR on purpose (chart controls).
- **Combined analysis card** (top of the chart's side column, `components/synthesisCard.js`, logic in `services/synthesis.js`): chart trend, real 4h/daily trend, momentum, RSI extremes, volatility regime, SMC structure, premium/discount and news risk → "leaning long / leaning short / wait" with the reasons. Wait when parts disagree, on demo data, or near high-impact news. Says so when the calendar or higher-timeframe data is unavailable.
- **Scanner "why":** each radar result lists what supports it and what is against it (trend, momentum, structure break, recent strategy accuracy, open setup, filters, news) and a state: live setup / watch only / avoid.
- **Liquidity map** (chart button "Liquidity", any strategy, display only): BOS/CHoCH, order blocks, FVG, premium/discount, BSL/SSL and the last completed Asia / London / New York session highs and lows (approximate UTC hours, intraday timeframes).
- **Journal:** max drawdown and a strategy comparison table from the journal only; EDH and Confluence added to the strategy list. Smart log defaults to your journal; the backtest view is labelled "not your trades".
- **Signal history:** rows that leave the two-month working log go to an archive (latest 4000); a "Full signal history" panel on the signals page filters by symbol, strategy, result and month and exports CSV.
- **Strategy versions** (Lab → Versions): every trading-relevant settings change is a numbered version with what changed; restore with confirmation (display-only options never create versions).
- **Risk Control Center:** the risk page now shows the live guard (today R, open signals, losing streak, held-back signals, current limits) above the position-size calculator — same panel as the signals channel (`components/guardPanel.js`).
- **Trust Center** (`#/app/trust`): data sources with a live status check per instrument, how signals are qualified, AI limits, what is stored where, risk disclosure, and the device activity log.
- **Audit log** (`services/audit.js`): sign-in/up/out (success and failure), password changes, MT5 account add/edit/remove, execution-mode and credential changes (never the values), EA downloads, strategy restores, worker-settings export. Secret-looking fields are masked before storing.
- **MT5:** switching an account to automatic execution needs an explicit confirmation.
- Tests: `synthesis.test.js`, `journalStats.test.js`, `audit.test.js`, `strategyVersions.test.js`, signal-archive test in `mt5.test.js`.
- Not done: encryption of the MT5 connection secret at rest (would need a passphrase on every visit and would stop background execution), HMAC signing (needs a new EA), broker trade import (no broker API in the project).

## v134 — Strict confirmation engine (quality over quantity)
- `src/services/confirm.js`: a BUY / SELL is shown only when independent families agree (structure 3, higher timeframe 3, liquidity 2, confluence zone — Fibonacci pocket / order block / fixed-range volume profile — 2, trend 1, momentum 1, EDH 1, RSI 0.5): weighted evidence ≥ 7, ≥ 4 families, ≤ 1 weight against, structure or higher timeframe among them. Structure or higher timeframe against = hard stop.
- Filters: sideways (efficiency ratio), disorderly volatility, high-impact news, demo data. Levels validated: stop side/size, target side/order, entry near price, last target ≥ 1R (EDH: `confirm.edhMinRR`, default 0.6, because its targets are fixed points), first target pays the fee.
- `src/services/gate.js` applies it on the decision bar (closed candles before the trade opened; memoised). Wired into: chart plan (`analysis.js`), AI idea (`dashboard.js`), signals channel and MT5 bridge (`signals.js`, held-back reasons shown in the guard panel), cap of 2 open confirmed signals (`confirm.maxActive`). Analysis Hub shows CONFIRMED + families, or NO TRADE + reasons.
- Settings: `settings.confirm = { enabled, maxActive, edhMinRR }`. The 62% historical gate is unchanged and still applies.
- Honest limits: the engine outputs evidence, never a win rate. Replay on real BTC data (`confirm_study`): accepted trades are fewer and on some combos slightly better, but the two halves of the data disagree and samples are small — no accuracy claim is supported.

## v135 — Paper trading + Telegram alerts
- Audit first: position-size calculator (Risk), strategy comparison (Strategy lab), signal-history filters, monthly/performance reports, price alerts and ntfy phone alerts already existed — not duplicated.
- `src/services/paper.js` + `src/pages/tools/paper.js` (`#/app/paper`, drawer → Trading tools): virtual account at LIVE prices only (demo prices never open or fill). Entry = live price, user stop + one target, size = risk % of balance, fee per side. Tracks every 5 s while the app is open; after a gap replays 1-minute candles that started after the last check (a candle touching both levels = stop). Optional auto-copy of channel signals that passed the confirmation engine (`sig.confirm`). Stats from closed paper trades only (balance, net, win rate with a "too few trades" note under 20, PF, drawdown, equity curve, CSV).
- `server/telegram.js` + worker: `TELEGRAM_BOT_TOKEN` / `TELEGRAM_CHAT_ID` send the same alerts as ntfy. Token stays in the server environment, is never logged, and is stripped from error messages.
- Tests: `tests/paper.test.js` (8), `tests/telegram.test.js` (4). Browser: paper page on phone (Arabic) and desktop (English): open, validation error, live P/L row, manual close with fee, no horizontal overflow, no console errors.
- Not verified here: a real Telegram send (api.telegram.org is not reachable from the build machine) and automatic TP/SL fills in the browser (the mock price is static; covered by unit tests).

## v136 — MT5 bot: strategy library, scalper, Run / Stop
- `src/services/botStrategies.js`: named strategies saved in the browser (create, edit, duplicate, delete; unique names; validated). Kinds: `signals` (follow Classic / SMC / Zones / EDH through the existing confirmation engine, champion gate and risk guard) and `scalp` (EMA-cross scalper that runs inside the EA). `backtestScalp` replays the EA's exact rules on real candles with the spread charged; `scalpKv` converts pips to price distances for the EA.
- `src/services/mt5.js`: signed `ATACTL|run/stop|ts|sig` and `ATACFG|kind|name|payload|ts|sig` messages (type included in the signature), `readMt5Status` / `parseEaStatus` for the EA's signed `ATAST` reports. Accounts gain `engine` (default `running` = old behaviour), `botId`, `botKind`; a stopped account or a scalper account receives no signal trades.
- EA v3 (`mt5Ea.js`): persisted engine state + active strategy (file `ATA_state_<magic>.txt`), Stop = no new trades (positions keep stop / target), built-in scalper (new candle decision, trend EMA, UTC session, spread cap, one at a time, cooldown, trades/day, daily loss %, time exit, own magic `ScalpMagic`), refuses without `AutoTrade`, refuses REAL accounts unless `ScalpOnReal = true`, status report after each change and every `StatusEverySec`.
- UI (`components/botPanel.js` on the MT5 page): bot control card (choose + activate, Run / Stop with confirmation, EA-reported state vs requested state), "My strategies" library with editor, field validation, warnings (spread vs target, stop near spread, target < stop), test on real candles.
- Tests: `tests/bot.test.js` (7). Browser: phone (Arabic) + desktop (English) with ntfy mocked: create → validation → test → save → activate → Run → signed EA status shown → Stop → "not matching yet" until the EA confirms; no overflow, no script errors.
- Not verified: compiling the MQL5 (no MetaEditor here; braces/parentheses balance checked) and a live MetaTrader run.
- Real-data replay of the scalper (BTCUSDT, 60 days of 1m and 180 days of 5m): every variant tried lost after spread (PF 0.29–0.61; before spread ≈ break-even, PF 0.73–1.10). No scalper setting is presented as profitable.

## v138 — Scalper add-ons (tested one by one on real BTC data)
- New options (site replay + EA): ATR levels (`levels: 'atr'`, `tpAtr`, `slAtr`), pullback entry (`entry: 'pullback'`, `pbWait`), higher-timeframe EMA filter (`htfMin` 60/240, `htfEma`, finished HTF candles only), sideways filter (`erMin`, `erLen`), news filter (`newsMin`, EA only via the MT5 economic calendar, high-impact USD; cannot be replayed here; if the terminal has no calendar the EA logs it and the filter is inactive).
- Method: each add-on alone, then combinations, on BTCUSDT 1m (60 days) and 5m (180 days), spread charged, results split into two halves. Kept as defaults only what reduced losses in BOTH halves on BOTH timeframes: 4h filter, pullback entry, ATR 1.5/1 with a 12-candle time exit. The sideways filter helped on one threshold only (0.15 positive, 0.12 and 0.18 negative, 16–19 trades per half) → treated as noise, default off.
- Result at a 2-pip ($20) spread: 1m old default −1186 pips (PF 0.53) → new default −130 (PF 0.80); 5m −951 (PF 0.75) → −224 (PF 0.83). At a 4-pip spread both still lose clearly (PF 0.37 / 0.59). The scalper is still not profitable; no claim otherwise.
- Strategies saved before v138 keep every add-on off (no silent change); new scalpers start with the kept add-ons. The site test loads 20 000 candles when the HTF filter is on (it needs finished 4h candles).
- Tests: `tests/bot.test.js` now 10.

## v139 — Screenshot AI: SMC/EDH/Fibonacci reading, measured accuracy, no invented numbers
- `ai/visionPrompt.js`: the model must report only what is visible (null otherwise), never give a probability / confidence / win rate, list conflicts and return `noTrade` + no plan when the evidence disagrees. New fields: legibility, structure (BOS/CHoCH), order block, FVG, premium/discount, EDH (only if drawn), Fibonacci (only if drawn). max_tokens 1800.
- `services/snapCheck.js`: reading accuracy of THIS image, measured: symbol known, timeframe supported, read price vs the real live price (≤0.3 % ok, ≤1.5 % warn), levels on the right side, OB/FVG/EDH ranges valid, plan order, plan entry near the live price, "conflict but still a plan" rejected. Score = passed ÷ checks that could be made (n/a never counts).
- `services/snapLog.js`: measured track record of the AI's own plans on real 5-minute candles after each analysis (entry must be touched; first of stop / TP1 decides; both in one candle = stop; the entry candle can only decide a stop; not triggered in 3 days or open 7 days = not counted). Shown with "fewer than 20 plans: not reliable".
- `pages/snapshot.js`: the extra readings, a NO TRADE banner for AI conflicts, the checks card, the record card; every shown plan goes through the strict confirmation engine on live candles (NO TRADE with reasons when it fails). The strategy win-rate label no longer says "real accuracy" (now "strategy win rate in the test").
- Tests: `tests/snapshotAi.test.js` (3). Browser (Anthropic API mocked): phone Arabic plan + conflict, desktop English; no overflow, no script errors.

## v140 — The AI draws on the screenshot
- Prompt: the AI also reads two labels printed on the price axis (value + vertical position), the current-price label position and where the plot ends.
- `services/snapDraw.js`: `calibrate()` maps price → y linearly from the two axis labels and MEASURES the alignment with the current-price label (≤2 % of the image height ok, ≤5 % approximate, more = nothing is drawn; inverted / too-close labels = nothing drawn). `drawPlan()` lists lines and boxes; levels outside the picture are listed, not drawn. `renderAnnotated()` draws supports / resistances (dashed), OB / FVG boxes, EDH (PDH/PDL) and Fibonacci, and the plan (entry, SL, TP1–3, solid) only when the plan passed the confirmation engine; NO TRADE stamp otherwise; labels never cover each other; watermark "AI drawing". Download as PNG.
- The axis consistency is also a check in the reading-accuracy card.
- Tests: calibration / drawing plan in `tests/snapshotAi.test.js`. Browser: a synthetic chart with a known axis — every drawn line lands on its axis label (0 % off).
- Limit: a logarithmic price axis is not linear; the alignment check then fails or warns and the drawing is withheld or marked approximate.

## v141 — Smart images inside AlphaTrade (from the WordPress "AI Smart Images" idea)
- New page `#/app/smart-images` (drawer → News & learning): AI key (shared with the screenshot analysis; saved in this browser only, never printed back — only the last 4 characters), provider, connection test, remove key; where images are placed; the user's image library.
- `services/ai/ask.js`: one general browser request (Claude or OpenAI-compatible) with the user's key.
- `services/smartImages.js`: library in IndexedDB (resized JPEG ≤ 960 px, per browser), "describe with AI" once per image (description, alt, keywords in two languages), keyword pre-filter, ONE AI request per batch of new headlines (≤ 20), only listed ids accepted, null = no image, choices cached (re-checked when the library changes, dropped when an image is deleted).
- News page: each Forex Factory headline shows the chosen picture; without a key / images / network the list is unchanged and never blocked.
- Tests: `tests/smartImages.test.js` (4). Browser (Anthropic API + news mocked), phone Arabic and desktop English: save key (not in the page), test, upload 3 images, describe, news shows gold / bitcoin / Fed pictures and none for an unrelated headline, cached on reload (no new AI call), no overflow, no script errors.
- Limits: the library lives in one browser (no server storage on static hosting); the AI chooses only from the user's own images.

## v142 — The AI key has its own page
- New page `#/app/ai-key` (drawer → Account → "AI key"): provider, model / base URL for OpenAI-compatible APIs, key, save, connection test, remove, where the key is used, how to get one. `components/aiKeyCard.js` is the single key form.
- Chart-screenshot analysis and Smart images no longer have their own key forms; they show a status line (saved …last 4 / not added) with a link to the key page. The screenshot page used to put the saved key into the input's value (in the page DOM) — removed: the key is never written into any page now.
- Browser check (phone Arabic, desktop English): menu link, status without key → link → save → test → status "saved …5555" on both pages, key not in any page's DOM, no overflow, no script errors.

## v143 — AI key page for the site owner only
- `src/config/admin.js`: owner emails (`VITE_ADMIN_EMAILS`, default shheahmad417@gmail.com, case-insensitive).
- The "AI key" menu item and page are shown only to that signed-in email; anyone else opening `#/app/ai-key` sees "only the site owner can manage the AI key", and AI pages show "AI features are managed by the site owner" (no key status, no link).
- Honest limit: on a static site this is interface gating. The key is still never sent to anyone (it stays in the owner's browser). With local accounts anyone could create an account with that email in their own browser — they would only see their own empty key form. For other users to USE AI with the owner's key, put it on the server (ANTHROPIC_API_KEY); then no browser ever receives it.
