# Testing order flow (CVD, funding, open interest) for AlphaRadar

## What the app can and cannot get
| Data | Source | History | Usable for a multi-year test |
|---|---|---|---|
| CVD (net taker volume) | Binance klines, field 9 = taker buy base volume | since 2017, every timeframe | Yes |
| Funding rate | Binance futures `/fapi/v1/fundingRate` | since 2019, every 8 h | Yes |
| Open interest | Binance `/futures/data/openInterestHist` | last ~30 days only | No: needs a vendor (CoinGlass, Kaiko, Tardis) or a daily collector that stores it from today on |
| Taker long/short ratio | Binance `/futures/data/takerlongshortRatio` | last ~30 days | No, same limit |
| Order-book depth / DOM | live stream | not stored | Only forward testing |
The sandbox that built this cannot reach Binance, so nothing below was run on real order-flow data yet. The tool is ready to run on a machine with open network.

## Pre-registered hypotheses (no fitted parameters)
1. **H1 CVD trend**: net taker flow over the last 24 candles (as a share of volume) > 5% → long, < −5% → short.
2. **H2 CVD divergence**: price at a 24-candle high while CVD is negative → short; at a low while CVD is positive → long.
3. **H3 Funding contrarian**: funding z-score (90 days) above +2 → short, below −2 → long.
4. **H4 Absorption**: very heavy volume, small range, one-sided flow → trade against the flow.
5. **H5 OI × price**: open interest up > 2% with price moving > 1% → follow the move (new positions entering). Needs OI history.
6. **H6 Last-bar flow**: strong one-sided taker flow in the last candle → continuation.
Six tests only, written down before the data is touched, so the multiple-testing problem stays small.

## Protocol
- Signals are **non-overlapping**: after a signal the next H candles are skipped (otherwise 12 consecutive readings share one outcome and the sample looks 12× bigger than it is).
- Chronological folds (4) plus a held-out last 40%; no parameter is tuned.
- Fees charged on every trade; the mean net return must be positive.
- Pass = lower end of the Wilson 95% interval above 50% on the whole sample **and** on the last 40%, mean net > 0, ≥ 3 of 4 folds above 50%, n ≥ 100.
- "Exceeds 70%" is only claimed when the lower end of the interval is above 70%; the report prints that column.
- Run on BTC, ETH, SOL and on more than one horizon; a result that exists on one pair only is treated as noise.

## Self-test of the tool (synthetic data, ran here)
With a deliberately planted CVD effect the tool finds it (54.4% on 3,834 signals, PASS); on pure noise it rejects everything (49.9%, 0 false positives out of 6). It also shows the size of the target: even a planted effect that is clearly detectable gives ~54%, not 70%.

## Expectation, stated honestly
Published order-flow research finds measurable predictive power mostly at very short horizons (seconds to minutes) and mostly before costs. Hourly or daily direction above 70% on BTC is far outside what the literature supports; the realistic good outcome is a statistically solid 53–58% that, combined with a stop, a target and fees below the edge, gives a small positive expectancy. The study decides that with data, not with parameters.

## Run
`npm run orderflow -- --symbol BTCUSDT --tf 1h --from 2020-01-01 --h 12 --fee 0.04` → `results/orderflow.md`
`npm run orderflow -- --selftest` checks the statistics offline.

## All asset classes (Forex, indices, crypto)
**Correction first:** every accuracy study so far used BTCUSDT only (the only real data that could be downloaded). Forex, indices, ETH and SOL were never tested, so "below 60% across assets" is a BTC result, not yet an all-asset result.

| Class | Is real order flow available? | What to use |
|---|---|---|
| Crypto (BTC, ETH, SOL, BNB) | Yes: taker buy volume, funding, OI (30 d) | Real CVD, funding, OI (the main test) |
| Index futures / CFDs (SPX500, US30, US100) | Futures have real volume and OI (CME ES/YM/NQ); CFD feeds usually only tick volume | CME volume + OI from a vendor; CFD: candle-based delta proxy |
| Gold | CME GC futures volume + OI; spot has only tick volume | Same as indices |
| Forex | Spot FX is OTC: no central volume, so no true CVD. Real signals: CME FX futures volume/OI, weekly CFTC COT positioning | COT (weekly, free) and CME futures; tick-volume proxy only as a weak substitute |
Because spot FX and CFDs have no real CVD, ">70% for all supported assets" cannot rest on CVD for them; the honest plan is per class, with the pass rule applied to each asset separately.

## Proxy delta (works today on any asset with volume)
`delta = volume × (close − low) / (high − low)` approximates buying minus selling pressure from the candle. Run on real BTC (2022-26, fee 0.04%, non-overlapping signals):
- 4h (H=12): CVD trend 48.2% (44.2–52.2), last-bar flow 45.8%.
- 1h (H=24): CVD trend 47.1% (44.4–49.8), divergence 56.8% (49.7–63.7, net −0.18%, not significant), absorption 49.0%.
- 15m (H=48): trend 47.8%, divergence 52.9%, absorption 50.8%.
No hypothesis passed. This does NOT refute real taker-flow CVD (the proxy is only an estimate from the candle shape), it only shows that candle-based delta adds nothing; so the proxy is not added to the radar.
Run it on any asset: `npm run orderflow -- --file candles.json --proxy --tf 1h --h 24` (candles with time, open, high, low, close, volume).
