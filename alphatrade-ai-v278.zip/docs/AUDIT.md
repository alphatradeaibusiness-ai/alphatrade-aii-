# Strategy audit (real BTCUSDT candles, Jan 2025 – Oct 2026, 0.1% round-trip fee)

Method: the app's own backtest engine, default settings, 15m / 1h / 4h; first 60% of the history = in-sample, last 40% = out-of-sample.

## Findings
1. **No robust edge before costs.** Classic strategy, 15m, no fee: 1,535 trades, 52% wins, E = +0.06R, PF 1.10. With the 0.1% fee: 888 trades, 50% wins, E = −0.11R, PF 0.82 (−62,863 points). Fees, not entries, turn a coin-flip system into a loser.
2. **Fees scale with trade count and shrink with stop size.** On 1m the engine finds 2,991 trades without fees (E +0.08R) and 4 with them (the minimum-stop filter removes the rest). 5m with fees: E −0.22R. Short timeframes cannot pay a 0.1% fee.
3. **Higher timeframe loses less, not nothing.** E[R] with fees: 15m −0.11, 1h −0.07, 4h −0.04.
4. **Long side is the weaker side in this sample** (1h: long −0.16R, short +0.03R). That follows the market regime (BTC was weaker in the sample); it is not a rule to hard-code.
5. **Win rate misleads.** ~50% wins with avg loss > avg win, and 30–40% of trades exit at break-even after TP1, which counts as a "win" while paying fees.
6. **SMC v2 and Zone produce too few trades** (n = 1–4 with defaults; 10–64 when relaxed) to prove anything. Where n ≥ 30 the Zone strategy was negative (E −0.13R … −0.8R).
7. **Parameter search found nothing that holds in and out of sample.** ATR stop ×3, wider targets, minimum-stop ×10/×20, max 2 trades/day, trailing stop, early break-even: every variant was negative in at least one half on 15m and 1h. Trailing stops made the classic strategy worse (−0.17R vs −0.11R).

## Changes made (only those the evidence supports)
- Auto-pick ranks strategy × timeframe by **net R per trade**, needs ≥ 10 trades, and warns when nothing has a positive expectancy (before: raw points with ≥ 5 trades, which favours big stops and lucky small samples).
- Signal channel gate: ≥ 30 trades (was 20), ≥ 10 out-of-sample (was 8), and **net R > 0** overall and out-of-sample, besides the win-rate rules.
- Results page shows expectancy per trade, points before fees, fees paid and net, with a plain verdict.

## Not changed on purpose
Stops, targets, RSI / Fibonacci / volume-profile settings: no variant improved results consistently, so changing them would be curve-fitting.

# Intraday addendum (1m, 5m, 15m, 30m — real BTCUSDT)
Data: 1m 60 days, 5m 180 days, 15m and 30m (resampled) 633 days. Classic strategy, default rules.

| TF | signals/day | win % | gross E[R] (no fee) | median stop | fee as R at 0.1% | break-even round-trip fee |
|---|---|---|---|---|---|---|
| 1m | 49.9 | 50.0 | +0.08 | 0.07% | 1.42R | 0.005% |
| 5m | 8.3 | 50.1 | +0.02 | 0.23% | 0.43R | 0.005% |
| 15m | 2.4 | 51.7 | +0.06 | 0.54% | 0.19R | 0.033% |
| 30m | 1.3 | 47.4 | −0.04 | 0.81% | 0.12R | none (negative before fees) |

1. **The stop is smaller than the fee on 1m/5m.** ATR×2 on 1m is 0.07% of price; a 0.1% round-trip fee costs 1.4R per trade. No entry logic can overcome that. At a 0.04% fee it is still 0.57R on 1m and 0.17R on 5m.
2. **The raw signal is a coin flip.** Gross E[R] between −0.04R and +0.08R, win rate ≈ 50%. On 30m it is negative before any cost.
3. **15m is the only timeframe with a small positive gross edge (+0.06R), and it breaks even only at ≈0.033% round-trip** (maker orders on futures), not with market orders.
4. **Filters tested, none robust:** higher-timeframe trend (×4/×8/×16) *lowered* the gross edge (15m +0.06 → +0.03); RSI/momentum thresholds 65/35 and 70/30; sessions (Asia/EU/US/late); weekend vs weekday; volatility terciles; long vs short. Some cells looked good in one half and flipped in the other; with ~30 cells tested per timeframe a few "wins" are expected by chance (standard error of E[R] is ≈0.07R at n≈300).
5. **Not modelled:** slippage and latency (entry is the signal candle's close). Real intraday results are worse than the backtest.

Change made: the Results page now shows the fee cost per trade in R and warns when it exceeds 0.25R.
