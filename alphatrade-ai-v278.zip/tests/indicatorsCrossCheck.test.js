// v274: the app's own indicator maths checked against two independent open-source libraries on REAL candles
// (tests/fixtures/lab-real.json: Binance BTCUSDT 1h and gold 4h). Test-only — the libraries are not part of the app.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { createRequire } from 'node:module';
import { ema, rsi, atr, bollinger } from '../src/indicators/index.js';
import { EMA, RSI, ATR, BollingerBands } from '../tools/vendor/trading-signals.mjs';

const ti = createRequire(import.meta.url)('../tools/vendor/technicalindicators.cjs');
const fx = JSON.parse(fs.readFileSync(new URL('./fixtures/lab-real.json', import.meta.url)));
const SETS = ['btc1h', 'xau4h'].map((k) => [k, fx[k].map(([time, open, high, low, close]) => ({ time, open, high, low, close }))]);
const WARM = 300; // compare after warm-up: libraries seed the first average differently, Wilder smoothing forgets the seed
const rel = (a, b) => Math.abs(a - b) / Math.max(1e-9, Math.abs(b));
const series = (make, input) => { const ind = make(); return input.map((x) => { ind.add(x); const r = ind.getResult(); return r == null ? null : r; }); };
const worst = (mine, ref, from = WARM) => { let w = 0; for (let i = from; i < mine.length; i++) if (mine[i] != null && ref[i] != null) w = Math.max(w, rel(mine[i], ref[i])); return w; };
const tail = (arr, n) => [...new Array(n - arr.length).fill(null), ...arr];

for (const [name, c] of SETS) {
  const closes = c.map((x) => x.close);
  test(`${name}: EMA(20) matches trading-signals and technicalindicators`, () => {
    const mine = ema(closes, 20);
    assert.ok(worst(mine, series(() => new EMA(20), closes)) < 1e-9);
    assert.ok(worst(mine, tail(ti.EMA.calculate({ period: 20, values: closes }), closes.length)) < 1e-9);
  });
  test(`${name}: RSI(14) matches both libraries`, () => {
    const mine = rsi(closes, 14);
    assert.ok(worst(mine, series(() => new RSI(14), closes)) < 1e-6);
    assert.ok(worst(mine, tail(ti.RSI.calculate({ period: 14, values: closes }), closes.length)) < 1e-3); // technicalindicators rounds RSI to 2 decimals
  });
  test(`${name}: ATR(14) matches both libraries after warm-up`, () => {
    const mine = atr(c, 14);
    assert.ok(worst(mine, series(() => new ATR(14), c.map(({ high, low, close }) => ({ high, low, close })))) < 1e-6);
    assert.ok(worst(mine, tail(ti.ATR.calculate({ period: 14, high: c.map((x) => x.high), low: c.map((x) => x.low), close: closes }), closes.length)) < 1e-6);
  });
  test(`${name}: Bollinger(20, 2) matches both libraries`, () => {
    const mine = bollinger(closes, 20, 2);
    const ref = series(() => new BollingerBands(20, 2), closes);
    assert.ok(worst(mine.mid, ref.map((r) => r && r.middle), 19) < 1e-9);
    assert.ok(worst(mine.upper, ref.map((r) => r && r.upper), 19) < 1e-9);
    assert.ok(worst(mine.lower, ref.map((r) => r && r.lower), 19) < 1e-9);
    const t = tail(ti.BollingerBands.calculate({ period: 20, stdDev: 2, values: closes }), closes.length);
    assert.ok(worst(mine.upper, t.map((r) => r && r.upper), 19) < 1e-9);
  });
}
