// Feedback, support-call signalling, live broadcasts, plans & coupons, analytics and the monthly report (server/community.js).
import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createCommunity, embedUrl } from '../server/community.js';
import { createStripeBilling, CATALOGUE } from '../server/stripe.js';

const SECRET = 'x'.repeat(40);
const PNG = `data:image/png;base64,${Buffer.from('\x89PNG fake image bytes').toString('base64')}`;
function setup(over = {}) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'comm-'));
  const sent = []; const mails = [];
  const members = [{ uid: 'owner1', email: 'boss@x.com', name: 'Boss', lang: 'ar', createdAt: Date.UTC(2026, 0, 1), lastLogin: Date.UTC(2026, 9, 20) }, { uid: 'cust1', email: 'c@x.com', name: 'Cust', lang: 'en', createdAt: Date.UTC(2026, 9, 2), lastLogin: Date.UTC(2026, 9, 25) }];
  const trades = {
    cust1: [
      { id: 't1', symbol: 'BTCUSDT', direction: 'long', tf: '1h', mode: 'live', entry: 100, stop: 90, risk: 10, status: 'done', hits: 3, resultR: 2, riskAmount: 50, savedAt: Date.UTC(2026, 9, 3), closedAt: Date.UTC(2026, 9, 4) / 1000, strategy: 'smc' },
      { id: 't2', symbol: 'XAUUSD', direction: 'short', tf: '15m', mode: 'live', entry: 4000, stop: 4010, risk: 10, status: 'stopped', hits: 0, resultR: -1, riskAmount: 50, savedAt: Date.UTC(2026, 9, 5), closedAt: Date.UTC(2026, 9, 5, 5) / 1000, strategy: 'trend' },
      { id: 't3', symbol: 'BTCUSDT', direction: 'long', tf: '1h', mode: 'demo', entry: 1, stop: 0.5, risk: 0.5, status: 'done', hits: 1, resultR: 1, savedAt: Date.UTC(2026, 9, 6), closedAt: Date.UTC(2026, 9, 6) / 1000 },
    ],
  };
  const c = createCommunity({ dir, secret: SECRET, now: over.now || (() => Date.UTC(2026, 9, 28)), env: over.env || {},
    growth: { members: () => members, deliver: async (uid, n) => { sent.push({ uid, ...n }); return {}; }, sendMail: async (to, subj) => { mails.push({ to, subj }); return true; } },
    userTrades: { list: (uid) => trades[uid] || [] }, isOwnerEmail: (e) => e === 'boss@x.com', pointSize: (s) => (s === 'XAUUSD' ? 0.01 : 1) });
  return { c, sent, mails, dir };
}
const cust = { uid: 'cust1', email: 'c@x.com', name: 'Cust' };
const boss = { uid: 'owner1', email: 'boss@x.com', name: 'Boss' };

test('feedback: validation, images encrypted on disk, owner sees all, customer sees own, status + reply notify the customer', () => {
  const { c, sent, dir } = setup();
  assert.equal(c.submitFeedback(cust, { kind: 'rating', rating: 7 }).error, 'bad_rating');
  assert.equal(c.submitFeedback(cust, { kind: 'bug', text: 'x' }).error, 'text_short');
  assert.equal(c.submitFeedback(cust, { kind: 'bug', text: 'crash on login', images: ['data:text/html;base64,AAAA'] }).error, 'bad_image');
  const r = c.submitFeedback(cust, { kind: 'bug', text: 'Chart does not load on iPhone', images: [PNG] });
  assert.ok(r.item.id); assert.equal(r.item.status, 'new'); assert.equal(r.item.images.length, 1);
  assert.ok(sent.some((n) => n.uid === 'owner1' && n.kind === 'feedback'), 'owners notified');
  const raw = fs.readFileSync(path.join(dir, 'feedback-img', `${r.item.images[0]}.bin`));
  assert.ok(!raw.includes(Buffer.from('fake image bytes')), 'image stored encrypted');
  const img = c.feedbackImage(cust, false, r.item.images[0]); assert.equal(img.type, 'image/png'); assert.ok(img.data.includes(Buffer.from('fake image bytes')));
  assert.equal(c.feedbackImage({ uid: 'other' }, false, r.item.images[0]), null, 'other customers cannot read it');
  assert.equal(c.listFeedback({ uid: 'other' }, false).items.length, 0);
  assert.equal(c.listFeedback(boss, true).items[0].name, 'Cust');
  assert.equal(c.updateFeedback(r.item.id, { status: 'done' }).error, 'bad_status');
  const u = c.updateFeedback(r.item.id, { status: 'progress', reply: 'We are fixing it' });
  assert.equal(u.item.status, 'progress'); assert.equal(u.item.replies[0].text, 'We are fixing it');
  assert.ok(sent.some((n) => n.uid === 'cust1' && n.kind === 'feedback'));
  assert.ok(!fs.readFileSync(path.join(dir, 'community.json')).includes(Buffer.from('fixing')), 'store encrypted');
});

test('support call signalling: offer → owner answer → ICE both ways → end; strangers cannot read a call', () => {
  const { c, sent } = setup();
  assert.equal(c.startCall(cust, { offer: 'nope' }).error, 'bad_offer');
  const s = c.startCall(cust, { offer: 'v=0\r\no=- 1 2 IN IP4 127.0.0.1\r\n' });
  assert.ok(s.id && s.iceServers[0].urls.length);
  assert.ok(sent.some((n) => n.uid === 'owner1' && n.kind === 'call'));
  assert.equal(c.startCall(cust, { offer: 'v=0\r\nsecond call attempt...' }).error, 'call_open');
  assert.equal(c.listCalls().items[0].status, 'ringing');
  assert.equal(c.callState({ uid: 'x' }, false, s.id), null);
  assert.ok(c.callState(boss, true, s.id).offer.startsWith('v=0'));
  assert.equal(c.answerCall(boss, s.id, { answer: 'v=0\r\nanswer-sdp-body-here' }).ok, true);
  c.addIce(cust, false, s.id, { candidate: 'candidate:1 1 udp 1 1.2.3.4 5 typ host' });
  c.addIce(boss, true, s.id, { candidate: 'candidate:2 1 udp 1 5.6.7.8 9 typ host' });
  const callerView = c.callState(cust, false, s.id, { agent: 0 });
  assert.equal(callerView.status, 'active'); assert.ok(callerView.answer); assert.equal(callerView.ice.length, 1); assert.match(callerView.ice[0], /5\.6\.7\.8/);
  assert.match(c.callState(boss, true, s.id, { caller: 0 }).ice[0], /1\.2\.3\.4/);
  assert.equal(c.endCall(cust, false, s.id).ok, true);
  assert.equal(c.callState(cust, false, s.id).status, 'ended');
});

test('TURN relay is offered only when configured', () => {
  assert.equal(setup().c.iceServers().length, 1);
  const t = setup({ env: { TURN_URL: 'turn:turn.example.com:3478', TURN_USER: 'u', TURN_PASS: 'p' } }).c.iceServers();
  assert.equal(t.length, 2); assert.equal(t[1].username, 'u');
});

test('live broadcast: owner starts with a stream link → every member is notified; embed links are safe', async () => {
  const { c, sent } = setup();
  assert.equal((await c.startLive(boss, { title: 'x' })).error, 'bad_title');
  assert.equal((await c.startLive(boss, { title: 'Weekly outlook', url: 'http://insecure.example' })).error, 'bad_url');
  const r = await c.startLive(boss, { title: 'Weekly outlook', topic: 'Gold & BTC', url: 'https://www.youtube.com/watch?v=abcdEFGH123' });
  assert.equal(r.live.host, 'Boss'); assert.match(r.live.embed, /^https:\/\/www\.youtube-nocookie\.com\/embed\/abcdEFGH123/);
  assert.equal(sent.filter((n) => n.kind === 'live').length, 2);
  assert.equal(c.liveState().current.title, 'Weekly outlook');
  c.endLive(); assert.equal(c.liveState().current, null); assert.equal(c.liveState().history[0].title, 'Weekly outlook');
  assert.equal(embedUrl('javascript:alert(1)'), null);
  assert.equal(embedUrl('https://evil.example/page'), null);
  assert.match(embedUrl('https://www.twitch.tv/somechannel', 'site.com'), /parent=site\.com/);
});

test('plans and coupons: validation, quotes, limits, one use per customer, usage totals', () => {
  const { c } = setup();
  assert.equal(c.setPlan('monthly', { price: 0.2 }, CATALOGUE).error, 'bad_price');
  assert.equal(c.setPlan('signals25', { months: 3 }, CATALOGUE).error, 'bad_months');
  assert.equal(c.setPlan('monthly', { price: 99, active: false }, CATALOGUE).plan.cents, 9900);
  assert.equal(c.upsertCoupon({ code: 'ab', type: 'percent', value: 10 }).error, 'bad_code');
  assert.equal(c.upsertCoupon({ code: 'SAVE10', type: 'percent', value: 95 }).error, 'bad_value');
  assert.equal(c.upsertCoupon({ code: 'SAVE10', type: 'percent', value: 10, plans: ['annual'], maxUses: 1 }).coupon.code, 'SAVE10');
  assert.equal(c.quote('SAVE10', 'monthly', 8000).error, 'not_for_plan');
  const q = c.quote('save10', 'annual', 65000, 'cust1');
  assert.equal(q.discountCents, 6500); assert.equal(q.finalCents, 58500);
  c.redeem('SAVE10', q.discountCents, 'cust1');
  assert.equal(c.quote('SAVE10', 'annual', 65000, 'cust2').error, 'used_up');
  c.upsertCoupon({ code: 'TENOFF', type: 'fixed', value: 10, endsAt: '2026-10-01' });
  assert.equal(c.quote('TENOFF', 'monthly', 8000).error, 'expired');
  c.upsertCoupon({ code: 'TENOFF', type: 'fixed', value: 10 });
  assert.equal(c.quote('TENOFF', 'monthly', 8000).finalCents, 7000);
  c.redeem('TENOFF', 1000, 'cust1'); assert.equal(c.quote('TENOFF', 'monthly', 8000, 'cust1').error, 'already_used');
  c.upsertCoupon({ code: 'OFFX', type: 'fixed', value: 10, active: false }); assert.equal(c.quote('OFFX', 'monthly', 8000).error, 'invalid_coupon');
  const l = c.listCoupons(); assert.equal(l.totals.used, 2); assert.equal(l.totals.discountCents, 7500);
  assert.equal(c.deleteCoupon('OFFX').ok, true);
});

test('checkout applies a coupon on the server and the webhook accepts exactly that signed amount', async () => {
  const { c } = setup(); c.upsertCoupon({ code: 'HALF', type: 'percent', value: 50 });
  const bodies = [];
  const access = { subscription: () => null, grant: () => ({ duplicate: false }) };
  const billing = createStripeBilling({ env: { STRIPE_SECRET_KEY: `sk_test_${'a'.repeat(20)}`, STRIPE_WEBHOOK_SECRET: `whsec_${'b'.repeat(20)}`, PUBLIC_URL: 'https://site.test' }, access,
    pricing: { item: (id) => ({ ...CATALOGUE[id], active: true }), quote: c.quote, redeem: c.redeem, secret: SECRET },
    fetchFn: async (_u, o) => { bodies.push(new URLSearchParams(o.body)); return { ok: true, json: async () => ({ url: 'https://checkout.stripe.com/x' }) }; } });
  assert.equal((await billing.checkout({ uid: 'u1', product: 'monthly', coupon: 'NOPE' })).body.code, 'invalid_coupon');
  const r = await billing.checkout({ uid: 'u1', product: 'monthly', coupon: 'half' });
  assert.equal(r.status, 200);
  const b = bodies.at(-1); assert.equal(b.get('line_items[0][price_data][unit_amount]'), '4000');
  const md = Object.fromEntries([...b.entries()].filter(([k]) => k.startsWith('metadata[')).map(([k, v]) => [k.slice(9, -1), v]));
  const session = { object: 'checkout.session', mode: 'payment', payment_status: 'paid', client_reference_id: 'u1', metadata: md, currency: 'usd', amount_subtotal: 4000, amount_total: 4000, total_details: { amount_discount: 0 } };
  assert.equal(billing.apply(session), 'granted');
  assert.equal(c.listCoupons().items[0].used, 1);
  assert.equal(billing.apply({ ...session, amount_subtotal: 3000, amount_total: 3000 }), 'amount_mismatch');
  assert.equal(billing.apply({ ...session, metadata: { ...md, cdisc: '7000' } }), 'bad_session', 'tampered metadata is refused');
});

test('analytics: recommendations, followed, closed results, points, money; executions never invented', () => {
  const { c } = setup();
  c.countReco('cust1', { final: 'buy', strategy: 'smc' }); c.countReco('cust1', { final: 'no_trade' });
  const a = c.analytics().current;
  assert.equal(a.recommendations.generated, 2); assert.equal(a.recommendations.buy, 1); assert.equal(a.recommendations.uniqueUsers, 1);
  assert.equal(a.followed, 2); assert.equal(a.closed, 2); assert.equal(a.wins, 1); assert.equal(a.losses, 1);
  assert.equal(a.successRate, 50); assert.equal(a.totalR, 1);
  assert.equal(a.points, 20 - 1000);   // BTC 2R × 10 / 1 = 20 points; gold −1R × 10 / 0.01 = −1000 points
  assert.equal(a.profitUsd, 100); assert.equal(a.lossUsd, -50);
  assert.equal(a.executedVerified, 0);
  assert.equal(a.customers.total, 2); assert.equal(a.customers.newThisMonth, 1);
  assert.equal(c.report('2026-10').trades.length, 2, 'demo trades are not counted');
});

test('monthly report is built once at the start of the next month and sent to the owners only', async () => {
  const { c, sent, mails } = setup({ now: () => Date.UTC(2026, 10, 1, 1) });
  const r = await c.runMonthly(); assert.equal(r.month, '2026-10'); assert.ok(r.compare);
  assert.equal(await c.runMonthly(), null, 'not twice');
  assert.equal(sent.filter((n) => n.kind === 'report').map((n) => n.uid).join(), 'owner1');
  assert.equal(mails[0].to, 'boss@x.com');
  assert.deepEqual(c.analytics(Date.UTC(2026, 10, 2)).reports, ['2026-10']);
});

test('in-site broadcast: viewers send an offer, the owner answers it, nothing for a link broadcast', async () => {
  const { c } = setup();
  const OFFER = 'v=0\r\no=- 1 2 IN IP4 127.0.0.1\r\ns=-\r\n';
  assert.equal(c.watchLive(cust, { offer: OFFER }).error, 'not_live');
  await c.startLive(boss, { title: 'From the site' });
  assert.equal(c.liveState().current.mode, 'site');
  assert.equal(c.watchLive(cust, { offer: 'nope' }).error, 'bad_offer');
  const w = c.watchLive(cust, { offer: OFFER });
  assert.ok(w.id && Array.isArray(w.iceServers));
  assert.equal(c.watchState({ uid: 'someone-else' }, w.id), null, 'another customer cannot read it');
  const list = c.liveViewers();
  assert.equal(list.waiting.length, 1); assert.equal(list.waiting[0].offer, OFFER);
  assert.equal(c.answerViewer(w.id, { answer: 'x' }).error, 'bad_answer');
  assert.equal(c.answerViewer(w.id, { answer: OFFER.replace('o=- 1', 'o=- 9') }).ok, true);
  assert.equal(c.watchState(cust, w.id).status, 'watching');
  assert.equal(c.liveViewers().watching.length, 1);
  const again = c.watchLive(cust, { offer: OFFER });   // a reload replaces the old connection
  assert.equal(c.liveViewers().waiting.length, 1); assert.equal(c.watchState(cust, w.id), null); assert.ok(again.id);
  assert.equal(c.leaveLive(cust, false, again.id).ok, true);
  c.endLive();
  assert.equal(c.liveViewers().waiting.length + c.liveViewers().watching.length, 0);
  await c.startLive(boss, { title: 'On YouTube', url: 'https://youtu.be/abcdEFGH123' });
  assert.equal(c.liveState().current.mode, 'link');
  assert.equal(c.watchLive(cust, { offer: OFFER }).error, 'not_live');
});
