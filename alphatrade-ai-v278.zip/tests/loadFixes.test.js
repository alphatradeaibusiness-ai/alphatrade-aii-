// v229 load-test fixes: proxy cache (hit / coalescing / stale-if-error / bounded upstream / bounded memory), coalesced writes,
// channel store (no write when nothing changed, payments written at once, outside edits picked up).
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createProxyCache, marketTtl } from '../server/proxyCache.js';
import { writeBehind } from '../server/writeBehind.js';
import { createChannelAccess } from '../server/channelAccess.js';

const fakeFetch = ({ delay = 30, status = 200, fail = false } = {}) => {
  const f = async (url) => { f.calls++; await new Promise((r) => setTimeout(r, delay)); if (f.fail || fail) throw new Error('down');
    return new Response(JSON.stringify({ url, n: f.calls }), { status: f.status ?? status, headers: { 'content-type': 'application/json' } }); };
  f.calls = 0; return f;
};

test('proxy cache: 200 identical requests at once → 1 upstream call; then served from cache', async () => {
  const f = fakeFetch(); const c = createProxyCache({ fetchImpl: f });
  const all = await Promise.all(Array.from({ length: 200 }, () => c.get('https://x/klines?symbol=BTC&interval=1m', { ttl: 2000 })));
  assert.equal(f.calls, 1);
  assert.equal(all.filter((r) => r.cache === 'MISS').length, 1);
  assert.equal(all.filter((r) => r.cache === 'COALESCED').length, 199);
  assert.equal((await c.get('https://x/klines?symbol=BTC&interval=1m', { ttl: 2000 })).cache, 'HIT');
  assert.equal(f.calls, 1);
  await c.get('https://x/klines?symbol=ETH&interval=1m'); assert.equal(f.calls, 2, 'different request → its own call');
});

test('proxy cache: expires after its ttl, serves stale (≤60 s) when the upstream fails, errors only when nothing is cached', async () => {
  const f = fakeFetch({ delay: 1 }); const c = createProxyCache({ fetchImpl: f });
  await c.get('u1', { ttl: 20 }); await new Promise((r) => setTimeout(r, 30));
  f.fail = true;
  const r = await c.get('u1', { ttl: 20 }); assert.equal(r.cache, 'STALE'); assert.equal(r.status, 200);
  await assert.rejects(c.get('never-seen', { ttl: 20 }));
  f.fail = false; f.status = 503;
  await new Promise((r2) => setTimeout(r2, 30));
  assert.equal((await c.get('u1', { ttl: 20 })).cache, 'STALE', 'a 5xx answer does not replace a good one');
});

test('proxy cache: upstream concurrency is bounded and memory is bounded', async () => {
  let active = 0, peak = 0;
  const f = async () => { active++; peak = Math.max(peak, active); await new Promise((r) => setTimeout(r, 15)); active--; return new Response('x'.repeat(1000), { status: 200 }); };
  const c = createProxyCache({ fetchImpl: f, maxUpstream: 5, maxEntries: 50 });
  await Promise.all(Array.from({ length: 100 }, (_, i) => c.get(`k${i}`)));   // 5 running + 95 queued (queue limit 100)
  assert.ok(peak <= 5, `peak ${peak}`);
  assert.ok(c.stats().entries <= 50);
  const flood = await Promise.allSettled(Array.from({ length: 200 }, (_, i) => c.get(`f${i}`)));
  assert.ok(flood.some((r) => r.status === 'rejected' && r.reason.message === 'busy'), 'beyond the queue: refused at once (502), not piled up');
  assert.ok(peak <= 5);
});

test('market ttl: live data short, slow data longer', () => {
  assert.equal(marketTtl('/api/v3/klines?symbol=BTCUSDT&interval=1m&limit=500'), 2000);
  assert.equal(marketTtl('/api/v3/klines?symbol=BTCUSDT&interval=1h'), 5000);
  assert.equal(marketTtl('/api/v3/klines?symbol=BTCUSDT&interval=1d'), 15000);
  assert.equal(marketTtl('/api/v3/depth?symbol=BTCUSDT'), 1000);
  assert.equal(marketTtl('/api/v3/exchangeInfo'), 600000);
});

test('write-behind: many changes → one write; flush writes at once; delay 0 keeps the old synchronous behaviour', async () => {
  let n = 0; const w = writeBehind(() => n++, { delayMs: 40, maxWaitMs: 200 });
  for (let i = 0; i < 100; i++) w.schedule();
  assert.equal(n, 0); await new Promise((r) => setTimeout(r, 60)); assert.equal(n, 1);
  w.schedule(); w.flush(); assert.equal(n, 2); w.flush(); assert.equal(n, 2, 'nothing pending → no write');
  let m = 0; const s = writeBehind(() => m++); s.schedule(); assert.equal(m, 1);
  let k = 0; const busy = writeBehind(() => k++, { delayMs: 30, maxWaitMs: 80 });
  const iv = setInterval(() => busy.schedule(), 10); await new Promise((r) => setTimeout(r, 200)); clearInterval(iv); busy.flush();
  assert.ok(k >= 2, 'a steady stream of changes is still written at least every maxWaitMs');
});

test('channel store: a feed poll with nothing new does not rewrite the file; payments are on disk at once; outside edits are seen', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ca-')); const file = path.join(dir, 'channel-accounts.json');
  const a = createChannelAccess(dir, { writeDelayMs: 50 }); const now = Date.now();
  a.grant('u1', { product: 'monthly', paymentId: 'pi_1', startsAt: now - 1000, until: now + 86_400_000 }, now);
  assert.ok(JSON.parse(fs.readFileSync(file, 'utf8')).u1.subscription, 'payment written immediately');
  const sig = { id: 's1', createdAt: now - 10, status: 'active', symbol: 'BTCUSDT' };
  const f1 = a.feed('u1', [sig], { now }); assert.equal(f1.signals.length, 1);
  await new Promise((r) => setTimeout(r, 80));
  const m1 = fs.statSync(file).mtimeMs;
  assert.ok(JSON.parse(fs.readFileSync(file, 'utf8')).u1.grants.s1, 'the new grant reached the disk');
  await new Promise((r) => setTimeout(r, 20));
  for (let i = 0; i < 20; i++) a.feed('u1', [{ ...sig }], { now });
  await new Promise((r) => setTimeout(r, 80));
  assert.equal(fs.statSync(file).mtimeMs, m1, 'unchanged feed polls never rewrite the file');
  a.feed('u1', [{ ...sig, status: 'tp1' }], { now }); await new Promise((r) => setTimeout(r, 80));
  assert.equal(JSON.parse(fs.readFileSync(file, 'utf8')).u1.grants.s1.snapshot.status, 'tp1', 'a changed recommendation is saved');
  // an outside edit (e.g. a restore) is picked up
  const db = JSON.parse(fs.readFileSync(file, 'utf8')); db.u2 = { subscription: { product: 'annual', startsAt: now - 1, until: now + 1e9 }, grants: {}, addons: [], purchases: ['pi_2'] };
  await new Promise((r) => setTimeout(r, 15)); fs.writeFileSync(file, JSON.stringify(db));
  assert.equal(a.subscription('u2', now)?.product, 'annual');
  assert.equal(a.grant('u3', { product: 'monthly', paymentId: 'pi_1', until: now + 1e6 }, now).duplicate, true, 'a payment id is still single-use');
});
