import test from 'node:test';
import assert from 'node:assert/strict';
import { opensBetween, zonedToUtc, eliteUpdate, eliteEligible, sessionBoard, eliteStats, MAX_PER_OPEN, OPEN_WINDOW_MS, FRESH_MS } from '../src/services/elite.js';

const iso = (t) => new Date(t).toISOString().slice(0, 16);
const sig = (id, over = {}) => ({ id, symbol: 'BTCUSDT', tf: '5m', strategy: 'trend', direction: 'long', entry: 100, stop: 98, targets: [102, 104, 106], status: 'active', tier: 'qualified', accuracy: 66, trades: 40, ...over });

test('market opens follow each city clock (daylight saving) and skip weekends', () => {
  // London 08:00: 07:00 UTC in summer (BST), 08:00 UTC in winter (GMT)
  assert.equal(iso(zonedToUtc(2026, 7, 15, 8, 0, 'Europe/London')), '2026-07-15T07:00');
  assert.equal(iso(zonedToUtc(2026, 11, 4, 8, 0, 'Europe/London')), '2026-11-04T08:00');
  // New York 08:00: 12:00 UTC (EDT) / 13:00 UTC (EST); Tokyo has no DST
  assert.equal(iso(zonedToUtc(2026, 7, 15, 8, 0, 'America/New_York')), '2026-07-15T12:00');
  assert.equal(iso(zonedToUtc(2026, 11, 4, 8, 0, 'America/New_York')), '2026-11-04T13:00');
  assert.equal(iso(zonedToUtc(2026, 11, 4, 9, 0, 'Asia/Tokyo')), '2026-11-04T00:00');
  // a Wednesday has 4 opens; Saturday local opens are skipped (Sydney Monday 07:00 is still Sunday evening UTC)
  const wed = opensBetween(Date.UTC(2026, 10, 3, 18), Date.UTC(2026, 10, 4, 18));
  assert.deepEqual(wed.map((o) => o.id).sort(), ['london', 'newyork', 'sydney', 'tokyo']);
  const sat = opensBetween(Date.UTC(2026, 10, 7, 0), Date.UTC(2026, 10, 7, 23, 59));
  assert.equal(sat.length, 0, 'no opens on Saturday');
  const sun = opensBetween(Date.UTC(2026, 10, 8, 0), Date.UTC(2026, 10, 8, 23, 59));
  assert.deepEqual(sun.map((o) => o.id), ['sydney'], 'Sunday UTC evening = Sydney Monday morning');
});

test('at most two per market open, instant, one per symbol, quality only, frozen once published', () => {
  const open = Date.UTC(2026, 10, 4, 8);   // London 08:00 GMT
  const at = (min) => open + min * 60_000;
  let now = at(5);
  const signals = [
    sig('a', { createdAt: at(2), symbol: 'XAUUSD' }),
    sig('w', { createdAt: at(3), symbol: 'EURUSD', tier: 'watch', accuracy: 58 }),          // never
    sig('e1', { createdAt: at(4), symbol: 'ETHUSDT', tier: 'engine', accuracy: 0, targets: [101, 102, 103] }), // rr 1 → no
  ];
  let st = { picks: [] };
  let r = eliteUpdate(st, signals, now);
  assert.deepEqual(r.added.map((p) => p.sid), ['a'], 'picked at once; watch / weak engine / same symbol refused');
  assert.equal(r.added[0].brand, 'Alpha Elite Signals');
  signals.push(sig('dup', { createdAt: at(8), symbol: 'XAUUSD', accuracy: 80 }));
  assert.equal(eliteUpdate(st, signals, at(9)).added.length, 0, 'a second trade on the same market in the same open is refused');
  signals.push(sig('b', { createdAt: at(20), symbol: 'GBPUSD', accuracy: 70 }), sig('c', { createdAt: at(21), symbol: 'USDJPY', accuracy: 90 }));
  now = at(22); r = eliteUpdate(st, signals, now);
  assert.equal(r.added.length, 1, 'only one slot left'); assert.equal(r.added[0].sid, 'c', 'the better of two simultaneous candidates');
  signals.push(sig('d', { createdAt: at(40), symbol: 'BTCUSDT', accuracy: 95 }));
  r = eliteUpdate(st, signals, at(41));
  assert.equal(r.added.length, 0, 'the open already has its two');
  assert.equal(st.picks.filter((p) => p.sessionKey.endsWith('london')).length, MAX_PER_OPEN);
  // the recommendation hits TP1 then the stop at entry: the pick follows, entry/targets stay frozen
  Object.assign(signals.find((s) => s.id === 'a'), { status: 'be', hits: 1, closedAt: at(60), entry: 999 });
  r = eliteUpdate(st, signals, at(61));
  const a = st.picks.find((p) => p.sid === 'a'); assert.equal(a.status, 'be'); assert.equal(a.hits, 1); assert.equal(a.entry, 100);
});

test('stale or out-of-window recommendations are never published late', () => {
  const open = Date.UTC(2026, 10, 4, 8);
  const st = { picks: [] };
  // issued inside the window but seen 20 min later (server was down): not "instant" any more → skipped
  assert.equal(eliteUpdate(st, [sig('late', { createdAt: open + 10 * 60_000 })], open + 10 * 60_000 + FRESH_MS + 60_000).added.length, 0);
  // issued after the window
  assert.equal(eliteUpdate(st, [sig('after', { createdAt: open + OPEN_WINDOW_MS + 60_000 })], open + OPEN_WINDOW_MS + 61_000).added.length, 0);
  // issued before the open
  assert.equal(eliteUpdate(st, [sig('before', { createdAt: open - 60_000 })], open + 60_000).added.length, 0);
  assert.equal(eliteEligible(sig('x', { status: 'sl' })), false, 'closed recommendations are never picked');
});

test('board and stats', () => {
  const open = Date.UTC(2026, 10, 4, 8);
  const st = { picks: [] }; eliteUpdate(st, [sig('a', { createdAt: open + 60_000 })], open + 120_000);
  const b = sessionBoard(st.picks, open + 30 * 60_000);
  const lon = b.find((x) => x.id === 'london'); assert.equal(lon.state, 'window'); assert.equal(lon.used, 1); assert.equal(lon.max, 2);
  assert.ok(b.every((x) => x.nextOpenAt > open));
  st.picks[0].status = 'tp3'; st.picks[0].hits = 3;
  assert.deepEqual(eliteStats(st.picks), { total: 1, open: 0, closed: 1, wins: 1, winRate: 100 });
});

test('v237: the Elite alert text keeps market and prices in order inside Arabic (isolates), in both languages', async () => {
  const { eliteAlertBody } = await import('../src/services/elite.js');
  const p = { symbol: 'XAUUSD', direction: 'long', entry: 4065.25, stop: 4048.6, targets: [4082, 4099, 4115] };
  const ar = eliteAlertBody(p, 'ar', () => 'XAU/USD'); const en = eliteAlertBody({ ...p, direction: 'short' }, 'en');
  assert.equal(ar, '\u2068XAU/USD\u2069 · شراء · دخول \u20684065.25\u2069 · وقف \u20684048.6\u2069 · الأهداف \u2068TP1 4082\u2069 · \u2068TP2 4099\u2069 · \u2068TP3 4115\u2069');
  assert.equal(en, '\u2068XAUUSD\u2069 · Sell · Entry \u20684065.25\u2069 · Stop \u20684048.6\u2069 · Targets \u2068TP1 4082\u2069 · \u2068TP2 4099\u2069 · \u2068TP3 4115\u2069');
  assert.ok(!eliteAlertBody({ ...p, targets: [] }, 'ar').includes('الأهداف'), 'no targets → no empty label');
});

test('v238: the Telegram message of a pick has one value per line (entry, stop, the three targets)', async () => {
  const { eliteTelegramText } = await import('../src/services/elite.js');
  const ar = eliteTelegramText({ symbol: 'XAUUSD', direction: 'long', entry: 4065.25, stop: 4048.6, targets: [4082, 4099, 4115] }, 'ar', () => 'XAU/USD').split('\n');
  assert.equal(ar.length, 6); assert.match(ar[0], /^🟢 ⁨XAU\/USD⁩ · شراء$/); assert.equal(ar[1], 'دخول: ⁨4065.25⁩'); assert.equal(ar[5], 'الهدف 3: ⁨4115⁩');
  const en = eliteTelegramText({ symbol: 'BTCUSDT', direction: 'short', entry: 1, stop: 2, targets: [0.5] }, 'en').split('\n');
  assert.deepEqual(en, ['🔴 ⁨BTCUSDT⁩ · Sell', 'Entry: ⁨1⁩', 'Stop: ⁨2⁩', 'TP1: ⁨0.5⁩']);
});
