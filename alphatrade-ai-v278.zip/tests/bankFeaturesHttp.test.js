// v150 over HTTP against the real server: passkey gate, issuer webhook signatures, rates, conversion, tax CSV, Web Push delivery, isolation.
import test from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import http from 'node:http';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawn } from 'node:child_process';

const PROJECT = 'alphatrade-test'; const KID = 'k-bank';
const { privateKey, publicKey } = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
const b64u = (b) => Buffer.from(b).toString('base64').replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
function token({ uid = 'owner-uid', email = 'shheahmad417@gmail.com', verified = true, authAgoSec = 10, mfa = false } = {}) {
  const now = Math.floor(Date.now() / 1000);
  const h = b64u(JSON.stringify({ alg: 'RS256', kid: KID, typ: 'JWT' }));
  const p = b64u(JSON.stringify({ iss: `https://securetoken.google.com/${PROJECT}`, aud: PROJECT, sub: uid, iat: now - 10, auth_time: now - authAgoSec, exp: now + 3600, email, email_verified: verified, firebase: { sign_in_provider: 'google.com', ...(mfa ? { sign_in_second_factor: 'phone' } : {}) } }));
  return `${h}.${p}.${b64u(crypto.sign('RSA-SHA256', Buffer.from(`${h}.${p}`), privateKey))}`;
}
const certs = { [KID]: publicKey.export({ type: 'spki', format: 'pem' }) };
function call(port, p, { method = 'GET', tok, body, headers = {}, raw } = {}) {
  return new Promise((resolve, reject) => {
    const data = raw ?? (body === undefined ? null : JSON.stringify(body));
    const h = { origin: `http://127.0.0.1:${port}`, ...(data ? { 'content-type': 'application/json', 'content-length': Buffer.byteLength(data) } : {}), ...(tok ? { authorization: `Bearer ${tok}` } : {}), ...headers };
    for (const k of Object.keys(h)) if (h[k] === null) delete h[k];   // null = do not send this header
    const r = http.request({ host: '127.0.0.1', port, path: p, method, headers: h }, (res) => {
      let buf = ''; res.on('data', (c) => (buf += c)); res.on('end', () => { let j = null; try { j = JSON.parse(buf); } catch { /* not json */ } resolve({ status: res.statusCode, body: j, raw: buf, headers: res.headers }); });
    });
    r.on('error', reject); if (data) r.write(data); r.end();
  });
}
async function startServer(env) {
  const port = 20000 + Math.floor(Math.random() * 20000);
  const child = spawn(process.execPath, ['--no-warnings', 'server/index.js'], { env: { ...process.env, NODE_ENV: 'test', SERVER_PORT: String(port), ...env }, stdio: ['ignore', 'pipe', 'pipe'] });
  let log = ''; child.stdout.on('data', (c) => (log += c)); child.stderr.on('data', (c) => (log += c));
  for (let i = 0; i < 80; i++) { try { await call(port, '/api/bank/status'); break; } catch { await new Promise((r) => setTimeout(r, 100)); } }
  return { port, child, log: () => log };
}
const GOOD_IBAN = 'DE89370400440532013000';
const KYC = { tier: 1, fullName: 'Ada Lovelace', dob: '1990-05-05', nationality: 'DE', address: { country: 'DE', region: 'BE', city: 'Berlin', postal: '10115', line1: 'Invalidenstrasse 1' }, idType: 'passport', idNumber: 'C01X00T47', idExpiry: '2031-01-01' };
let seq = 0; const key = () => `idem-${Date.now()}-${seq++}`;
import { makeAuthenticator } from './helpers/fakeAuthenticator.js';
import { decryptPayload } from '../server/bank/webpush.js';

const KYC2 = { ...KYC, tier: 2, sourceOfFunds: 'salary', proofOfAddressRef: 'vend-123' };
function mock(handler) {
  return new Promise((resolve) => { const s = http.createServer(handler); s.listen(0, '127.0.0.1', () => resolve({ server: s, base: `http://127.0.0.1:${s.address().port}` })); });
}

test('v150 over HTTP: passkey-gated withdrawal, signed issuer webhook, rates + conversion, tax CSV, Web Push, isolation', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'bk5-')); const certFile = path.join(dir, 'certs.json'); fs.writeFileSync(certFile, JSON.stringify(certs));
  const price = await mock((req, res) => { res.writeHead(200, { 'content-type': 'application/json' }); res.end(JSON.stringify({ symbol: 'BTCUSDT', price: '50000' })); });
  const ecb = await mock((req, res) => { res.writeHead(200, { 'content-type': 'text/xml' }); res.end("<Cube><Cube time='2026-10-27'><Cube currency='USD' rate='1.1000'/><Cube currency='JPY' rate='160'/></Cube></Cube>"); });
  const pushed = []; let pushStatus = 201;
  const push = await mock((req, res) => { const ch = []; req.on('data', (c) => ch.push(c)); req.on('end', () => { pushed.push({ headers: req.headers, body: Buffer.concat(ch) }); res.writeHead(pushStatus); res.end(); }); });
  const SECRET = 'w'.repeat(40);
  const { port, child, log } = await startServer({ BANK_MASTER_KEY: 'm'.repeat(48), BANK_MODE: 'sandbox', AI_TEST_CERTS_FILE: certFile, FIREBASE_PROJECT_ID: PROJECT, SERVER_DATA_DIR: dir,
    AI_KEY_SECRET: 'a'.repeat(40), ANTHROPIC_API_KEY: '', AI_IP_PER_MINUTE: '1000', AI_DAILY_PER_IP: '1000', AI_DAILY_LIMIT: '1000',
    BANK_TEST_PRICE_BASE: price.base, BANK_TEST_RATES_BASE: ecb.base, BANK_TEST_PUSH_BASE: push.base, BANK_ISSUER_WEBHOOK_SECRET: SECRET, BANK_VAPID_SUBJECT: 'mailto:ops@example.com' });
  const owner = token(); const alice = token({ uid: 'alice', email: 'alice@example.com' }); const bob = token({ uid: 'bob', email: 'bob@example.com' });
  const c = (p, o) => call(port, p, o);
  const origin = `http://127.0.0.1:${port}`; const auth = makeAuthenticator({ rpId: '127.0.0.1', origin });
  try {
    // KYC 2 + funds
    assert.equal((await c('/api/bank/kyc', { method: 'POST', tok: alice, body: KYC })).status, 200);
    await c('/api/bank/admin/kyc/alice/approve', { method: 'POST', tok: owner, body: {} });
    assert.equal((await c('/api/bank/kyc', { method: 'POST', tok: alice, body: KYC2 })).status, 200);
    await c('/api/bank/admin/kyc/alice/approve', { method: 'POST', tok: owner, body: {} });
    await c('/api/bank/sandbox/fund', { method: 'POST', tok: alice, body: { currency: 'USD', amount: '1000' }, headers: { 'idempotency-key': key() } });

    // passkey registration (first one: sign-in step-up only), then the status says so
    const opts = (await c('/api/bank/passkeys/register-options', { method: 'POST', tok: alice, body: {} })).body;
    assert.equal(opts.publicKey.rp.id, '127.0.0.1');
    const reg = await c('/api/bank/passkeys/register', { method: 'POST', tok: alice, body: { challengeId: opts.challengeId, credential: auth.register(opts), name: 'Laptop' } });
    assert.equal(reg.status, 200, reg.raw); assert.equal((await c('/api/bank/status', { tok: alice })).body.passkeys, 1);
    // a second passkey now needs the first
    const opts2 = (await c('/api/bank/passkeys/register-options', { method: 'POST', tok: alice, body: {} })).body;
    const evil = makeAuthenticator({ rpId: '127.0.0.1', origin });
    assert.equal((await c('/api/bank/passkeys/register', { method: 'POST', tok: alice, body: { challengeId: opts2.challengeId, credential: evil.register(opts2) } })).body.code, 'passkey_required');

    // beneficiary needs a passkey assertion bound to that IBAN
    const benBody = { currency: 'USD', label: 'me', iban: GOOD_IBAN, holder: 'Alice' };
    assert.equal((await c('/api/bank/beneficiaries', { method: 'POST', tok: alice, body: benBody })).body.code, 'passkey_required');
    let ch = (await c('/api/bank/passkeys/challenge', { method: 'POST', tok: alice, body: { purpose: 'beneficiary_add', params: benBody } })).body;
    const ben = await c('/api/bank/beneficiaries', { method: 'POST', tok: alice, body: { ...benBody, passkey: auth.assert(ch) } });
    assert.equal(ben.status, 200, ben.raw);

    // virtual card (passkey) + signed webhook from the "issuer"
    ch = (await c('/api/bank/passkeys/challenge', { method: 'POST', tok: alice, body: { purpose: 'vcard_create', params: { kind: 'standard' } } })).body;
    const card = await c('/api/bank/vcards', { method: 'POST', tok: alice, body: { label: 'web', holder: 'Ada Lovelace', dob: '1990-05-05', passkey: auth.assert(ch) } });
    assert.equal(card.status, 200, card.raw);
    const db = (await import('node:sqlite')); const raw = new db.DatabaseSync(path.join(dir, 'bank', 'bank.db'), { readOnly: true });
    const ref = raw.prepare('SELECT issuer_ref FROM vcards').get().issuer_ref; raw.close();
    const hook = (ev, { t = Math.floor(Date.now() / 1000), secret = SECRET } = {}) => {
      const rawBody = JSON.stringify(ev); const v1 = crypto.createHmac('sha256', secret).update(`${t}.${rawBody}`).digest('hex');
      return c('/api/bank/issuer/webhook', { method: 'POST', raw: rawBody, headers: { 'content-type': 'application/json', 'content-length': Buffer.byteLength(rawBody), origin: null, 'x-issuer-signature': `t=${t},v1=${v1}` } });
    };
    const ev = { type: 'authorization.request', eventId: 'evt_000001', cardRef: ref, merchant: 'Book Shop', category: 'education', amount: '12.50', currency: 'USD' };
    assert.equal((await hook(ev, { secret: 'x'.repeat(40) })).status, 401);
    assert.equal((await hook(ev, { t: Math.floor(Date.now() / 1000) - 3600 })).status, 401);   // stale timestamp
    const dec = await hook(ev); assert.equal(dec.status, 200); assert.equal(dec.body.approved, true);
    assert.equal((await hook(ev)).body.replay, true);   // same event → same answer, no double hold
    assert.equal((await hook({ type: 'transaction.settled', eventId: 'evt_000002', authEventId: 'evt_000001' })).body.ok, true);
    const big = await hook({ ...ev, eventId: 'evt_000003', amount: '5000' }); assert.equal(big.body.approved, false); assert.equal(big.body.reason, 'over_tx_limit');

    // withdrawal: passkey required and bound to the amount
    const wd = { currency: 'USD', amount: '25', beneficiaryId: ben.body.id };
    ch = (await c('/api/bank/passkeys/challenge', { method: 'POST', tok: alice, body: { purpose: 'withdraw', params: wd } })).body;
    const signed = auth.assert(ch);
    assert.equal((await c('/api/bank/withdrawals', { method: 'POST', tok: alice, body: { ...wd, amount: '250', passkey: signed }, headers: { 'idempotency-key': key() } })).body.code, 'passkey_binding_mismatch');
    ch = (await c('/api/bank/passkeys/challenge', { method: 'POST', tok: alice, body: { purpose: 'withdraw', params: wd } })).body;
    // (beneficiary is still cooling off: the passkey passes, the business rule answers)
    assert.equal((await c('/api/bank/withdrawals', { method: 'POST', tok: alice, body: { ...wd, passkey: auth.assert(ch) }, headers: { 'idempotency-key': key() } })).body.code, 'beneficiary_cooling_off');

    // rates + conversion + calculator
    const rates = (await c('/api/bank/fx/rates', { tok: alice })).body; assert.equal(rates.usdPer.EUR, 1.1); assert.equal(rates.usdPer.BTC, 50000);
    assert.equal((await c('/api/bank/fx/calc?from=EUR&to=USD&amount=10', { tok: alice })).body.result, 1100);
    const cv = await c('/api/bank/fx/convert', { method: 'POST', tok: alice, body: { from: 'USD', to: 'EUR', amount: '11' }, headers: { 'idempotency-key': key() } });
    assert.equal(cv.body.receive, 995);

    // Web Push: subscribe a fake device; a notification arrives encrypted with VAPID; only the device keys decrypt it
    const ua = crypto.createECDH('prime256v1'); ua.generateKeys(); const ua_auth = crypto.randomBytes(16);
    const sub = { endpoint: `${push.base}/send/dev1`, keys: { p256dh: ua.getPublicKey().toString('base64url'), auth: ua_auth.toString('base64url') } };
    assert.equal((await c('/api/bank/push/subscribe', { method: 'POST', tok: alice, body: { subscription: { ...sub, endpoint: 'https://evil.example/x' } } })).body.code, 'bad_subscription');
    assert.equal((await c('/api/bank/push/subscribe', { method: 'POST', tok: alice, body: { subscription: sub } })).status, 200);
    await c('/api/bank/notifications/prefs', { method: 'POST', tok: alice, body: { lang: 'en' } });
    await c('/api/bank/freeze', { method: 'POST', tok: alice, body: { on: true } });
    for (let i = 0; i < 30 && !pushed.length; i++) await new Promise((r) => setTimeout(r, 50));
    assert.equal(pushed.length, 1);
    assert.match(pushed[0].headers.authorization, /^vapid t=[\w-]+\.[\w-]+\.[\w-]+, k=[\w-]{87}$/);
    assert.equal(pushed[0].headers['content-encoding'], 'aes128gcm');
    const msg = JSON.parse(decryptPayload(pushed[0].body, ua.getPrivateKey(), ua.getPublicKey(), ua_auth));
    assert.equal(msg.body, 'Your account is frozen'); assert.ok(!pushed[0].body.toString('latin1').includes('frozen'));
    // unfreeze needs the passkey; a 410 from the push service removes the dead subscription
    assert.equal((await c('/api/bank/freeze', { method: 'POST', tok: alice, body: { on: false } })).body.code, 'passkey_required');
    ch = (await c('/api/bank/passkeys/challenge', { method: 'POST', tok: alice, body: { purpose: 'unfreeze', params: {} } })).body;
    pushStatus = 410;
    assert.equal((await c('/api/bank/freeze', { method: 'POST', tok: alice, body: { on: false, passkey: auth.assert(ch) } })).body.frozen, false);
    for (let i = 0; i < 30 && pushed.length < 2; i++) await new Promise((r) => setTimeout(r, 50));
    await new Promise((r) => setTimeout(r, 100));
    await c('/api/bank/freeze', { method: 'POST', tok: alice, body: { on: true } }); await new Promise((r) => setTimeout(r, 200));
    assert.equal(pushed.length, 2);   // the second push got 410 → no third attempt

    // tax CSV is a download, and other users cannot read alice's things
    const csv = await c(`/api/bank/tax.csv?year=${new Date().getUTCFullYear()}`, { tok: alice });
    assert.equal(csv.status, 200); assert.match(csv.headers['content-type'], /text\/csv/); assert.match(csv.headers['content-disposition'], /attachment/);
    const tk = (await c('/api/bank/tickets', { method: 'POST', tok: alice, body: { topic: 'card', subject: 'Help please', body: 'Card question' } })).body;
    assert.equal((await c(`/api/bank/tickets/${tk.id}`, { tok: bob })).status, 404);
    assert.equal((await c('/api/bank/vcards', { tok: bob })).body.items.length, 0);
    assert.equal((await c('/api/bank/admin/dashboard', { tok: alice })).status, 403);
    const dash = (await c('/api/bank/admin/dashboard', { tok: owner })).body; assert.equal(dash.ledger, true); assert.equal(dash.audit, true);
    assert.ok(!log().includes('Alice') && !log().includes(GOOD_IBAN));
  } finally { child.kill(); price.server.close(); ecb.server.close(); push.server.close(); fs.rmSync(dir, { recursive: true, force: true }); }
});
