// AI gateway end to end: starts server/index.js against a local provider mock that speaks the real Anthropic and
// OpenAI wire formats (status codes and error bodies), with users signed by a test RSA key (NODE_ENV=test only).
import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { classify, cleanConfig, createUserLimiter, createStore } from '../server/aiGateway.js';
import { verifyIdToken } from '../server/firebaseVerify.js';

const PROJECT = 'alphatrade-test';
const { privateKey, publicKey } = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
const KID = 'test-kid-1';
const b64u = (b) => Buffer.from(b).toString('base64').replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
function token({ uid = 'owner-uid', email = 'shheahmad417@gmail.com', verified = true, aud = PROJECT, exp = 3600, key = privateKey, kid = KID } = {}) {
  const now = Math.floor(Date.now() / 1000);
  const h = b64u(JSON.stringify({ alg: 'RS256', kid, typ: 'JWT' }));
  const p = b64u(JSON.stringify({ iss: `https://securetoken.google.com/${aud}`, aud, sub: uid, iat: now - 10, auth_time: now - 10, exp: now + exp, email, email_verified: verified, firebase: { sign_in_provider: 'google.com' } }));
  const sig = crypto.sign('RSA-SHA256', Buffer.from(`${h}.${p}`), key);
  return `${h}.${p}.${b64u(sig)}`;
}
const certs = { [KID]: publicKey.export({ type: 'spki', format: 'pem' }) };

test('token verification: signature, audience, expiry, unknown key', () => {
  assert.equal(verifyIdToken(token(), { projectId: PROJECT, certs }).email, 'shheahmad417@gmail.com');
  assert.throws(() => verifyIdToken(token({ aud: 'other' }), { projectId: PROJECT, certs }), /auth:wrong-audience/);
  assert.throws(() => verifyIdToken(token({ exp: -4000 }), { projectId: PROJECT, certs }), /auth:expired/);
  const other = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 }).privateKey;
  assert.throws(() => verifyIdToken(token({ key: other }), { projectId: PROJECT, certs }), /auth:bad-signature/);
  assert.throws(() => verifyIdToken(token({ kid: 'nope' }), { projectId: PROJECT, certs }), /auth:unknown-key/);
  assert.throws(() => verifyIdToken('a.b', { projectId: PROJECT, certs }), /auth:malformed/);
});

test('error classification covers key, credit, limits, model, permission and images', () => {
  assert.equal(classify('anthropic', 401, { error: { type: 'authentication_error' } }), 'invalid_key');
  assert.equal(classify('anthropic', 400, { error: { type: 'invalid_request_error', message: 'Your credit balance is too low to access the Anthropic API.' } }), 'no_credit');
  assert.equal(classify('openai', 429, { error: { code: 'insufficient_quota', message: 'You exceeded your current quota' } }), 'no_credit');
  assert.equal(classify('anthropic', 429, { error: { type: 'rate_limit_error' } }), 'rate_limit');
  assert.equal(classify('anthropic', 404, { error: { type: 'not_found_error', message: 'model: x' } }), 'model_unavailable');
  assert.equal(classify('anthropic', 403, { error: { type: 'permission_error' } }), 'no_permission');
  assert.equal(classify('openai', 400, { error: { message: 'Image input is not supported for this model' } }, { image: true }), 'vision_unsupported');
  assert.equal(classify('anthropic', 529, { error: { type: 'overloaded_error' } }), 'overloaded');
});

test('settings validation and per-user limits', () => {
  assert.equal(cleanConfig({ provider: 'x' }).error, 'provider');
  assert.equal(cleanConfig({ provider: 'anthropic', apiKey: 'short' }).error, 'key_format');
  assert.equal(cleanConfig({ provider: 'openai', apiKey: 'sk-' + 'a'.repeat(30), baseUrl: 'http://evil.example', model: 'm' }).error, 'base_url');
  assert.equal(cleanConfig({ provider: 'openai', apiKey: 'sk-' + 'a'.repeat(30), baseUrl: 'https://api.example.com/v1' }).error, 'model');
  const lim = createUserLimiter({ perMinute: 2, perDay: 3 });
  assert.equal(lim('u', 0), ''); assert.equal(lim('u', 1), ''); assert.equal(lim('u', 2), 'user_rate_minute');
  assert.equal(lim('u', 61_000), ''); assert.equal(lim('u', 122_000), 'user_rate_day');
});

test('store: key encrypted at rest, unreadable with another secret', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'aistore-'));
  const s = createStore({ dir, secret: 'x'.repeat(40) });
  s.save({ provider: 'anthropic', apiKey: 'sk-ant-PLAINTEXT-SHOULD-NOT-APPEAR-123456', last4: '3456' });
  const raw = fs.readFileSync(path.join(dir, 'ai-config.json'), 'utf8');
  assert.ok(!raw.includes('PLAINTEXT'));
  assert.equal(s.load().apiKey, 'sk-ant-PLAINTEXT-SHOULD-NOT-APPEAR-123456');
  assert.equal(s.meta().keyEnc, undefined);
  assert.equal(createStore({ dir, secret: 'y'.repeat(40) }).load(), null);
  assert.equal((fs.statSync(path.join(dir, 'ai-config.json')).mode & 0o777).toString(8), '600');
  fs.rmSync(dir, { recursive: true, force: true });
});

/* ───────── HTTP end to end ───────── */
const listen = (srv) => new Promise((r) => srv.listen(0, '127.0.0.1', () => r(srv.address().port)));
const call = (port, p, { method = 'GET', tok, body } = {}) => new Promise((resolve, reject) => {
  const headers = { origin: `http://127.0.0.1:${port}`, host: `127.0.0.1:${port}`, 'content-type': 'application/json' };
  if (tok) headers.authorization = `Bearer ${tok}`;
  const r = http.request({ host: '127.0.0.1', port, path: p, method, headers }, (res) => { let d = ''; res.on('data', (c) => (d += c)); res.on('end', () => { let j = null; try { j = JSON.parse(d); } catch { /* not JSON */ } resolve({ status: res.statusCode, body: j, raw: d }); }); });
  r.on('error', reject); if (body !== undefined) r.write(typeof body === 'string' ? body : JSON.stringify(body)); r.end();
});

/** Provider mock: behaviour chosen by the key (and model), replies tagged with the key so a key change is visible. */
function providerMock(seen) {
  return http.createServer((q, s) => {
    let d = ''; q.on('data', (c) => (d += c)); q.on('end', () => {
      const j = JSON.parse(d || '{}');
      const oa = q.url.includes('/chat/completions');
      const key = oa ? String(q.headers.authorization || '').replace('Bearer ', '') : String(q.headers['x-api-key'] || '');
      seen.push({ url: q.url, key, model: j.model });
      const hasImage = JSON.stringify(j).includes('"image') ;
      const sys = oa ? (j.messages?.[0]?.content || '') : (j.system || '');
      const err = (code, body) => { s.writeHead(code, { 'content-type': 'application/json' }); s.end(JSON.stringify(body)); };
      if (key.includes('bad')) return err(401, { type: 'error', error: { type: 'authentication_error', message: 'invalid x-api-key' } });
      if (key.includes('broke')) return oa ? err(429, { error: { code: 'insufficient_quota', message: 'You exceeded your current quota' } }) : err(400, { type: 'error', error: { type: 'invalid_request_error', message: 'Your credit balance is too low to access the Anthropic API.' } });
      if (key.includes('rate')) return err(429, { type: 'error', error: { type: 'rate_limit_error', message: 'Number of requests has exceeded your rate limit' } });
      if (j.model === 'claude-nope') return err(404, { type: 'error', error: { type: 'not_found_error', message: 'model: claude-nope' } });
      if (hasImage && key.includes('novision')) return err(400, { type: 'error', error: { type: 'invalid_request_error', message: 'image input is not supported by this model' } });
      const tag = key.slice(-6);
      let text = `OK key=${tag} model=${j.model}`;
      if (sys.includes('reading trading chart') || sys.includes('read trading chart')) text = JSON.stringify({ isChart: true, symbol: 'BTCUSDT', timeframe: '15m', lastPrice: 100, summary: `vision ${tag}` });
      else if (sys.includes('image library')) text = JSON.stringify({ description: `described ${tag}`, alt: 'alt', keywords: ['gold'] });
      else if (sys.includes('illustrations for news')) text = '{"picks":[{"i":0,"id":"img1"},{"i":1,"id":"invented"}]}';
      s.writeHead(200, { 'content-type': 'application/json' });
      s.end(JSON.stringify(oa ? { model: j.model, choices: [{ message: { content: text } }] } : { model: j.model, content: [{ type: 'text', text }] }));
    });
  });
}

async function startServer(env) {
  const port = 20000 + Math.floor(Math.random() * 20000);
  const child = spawn(process.execPath, ['server/index.js'], { env: { ...process.env, NODE_ENV: 'test', SERVER_PORT: String(port), ...env }, stdio: ['ignore', 'pipe', 'pipe'] });
  let log = ''; child.stdout.on('data', (c) => (log += c)); child.stderr.on('data', (c) => (log += c));
  for (let i = 0; i < 60; i++) { try { await call(port, '/api/ai/health'); break; } catch { await new Promise((r) => setTimeout(r, 100)); } }
  return { port, child, log: () => log };
}

test('gateway end to end: owner saves a key only after a real check; every feature uses it; change and delete apply everywhere; key never leaves the server', async () => {
  const seen = [];
  const mock = providerMock(seen); const mp = await listen(mock);
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'aigw-'));
  const certFile = path.join(dir, 'certs.json'); fs.writeFileSync(certFile, JSON.stringify(certs));
  const { port, child, log } = await startServer({ ANTHROPIC_BASE_URL: `http://127.0.0.1:${mp}`, AI_TEST_CERTS_FILE: certFile, FIREBASE_PROJECT_ID: PROJECT, AI_KEY_SECRET: 's'.repeat(48), SERVER_DATA_DIR: dir, ANTHROPIC_API_KEY: '', AI_USER_PER_MINUTE: '100', AI_IP_PER_MINUTE: '1000', AI_DAILY_PER_IP: '1000', AI_DAILY_LIMIT: '1000' });
  const owner = token(); const user = token({ uid: 'user-1', email: 'someone@example.com' });
  const KEY1 = 'sk-ant-api03-good-key-number-one-AAAA11'; const KEY2 = 'sk-ant-api03-good-key-number-two-BBBB22';
  const all = [];
  const c = async (...a) => { const r = await call(port, ...a); all.push(r.raw); return r; };
  try {
    assert.equal((await c('/api/ai/status')).body.state, 'none');
    // nobody but the verified owner can save
    assert.equal((await c('/api/ai/config', { method: 'PUT', body: { provider: 'anthropic', apiKey: KEY1 } })).status, 401);
    assert.equal((await c('/api/ai/config', { method: 'PUT', tok: user, body: { provider: 'anthropic', apiKey: KEY1 } })).status, 403);
    assert.equal((await c('/api/ai/config', { method: 'PUT', tok: token({ verified: false }), body: { provider: 'anthropic', apiKey: KEY1 } })).status, 403);
    // features refuse while nothing is connected
    assert.equal((await c('/api/ai/chat', { method: 'POST', tok: user, body: { messages: [{ role: 'user', content: 'hi' }] } })).body.code, 'not_configured');
    // a failing key is reported with its reason and NOT saved
    for (const [k, code, model] of [['sk-ant-api03-bad-key-xxxxxxxxxxxxx', 'invalid_key'], ['sk-ant-api03-broke-key-xxxxxxxxxxx', 'no_credit'], ['sk-ant-api03-rate-key-xxxxxxxxxxxx', 'rate_limit'], [KEY1, 'model_unavailable', 'claude-nope']]) {
      const r = await c('/api/ai/config', { method: 'PUT', tok: owner, body: { provider: 'anthropic', apiKey: k, model } });
      assert.equal(r.body.ok, false); assert.equal(r.body.code, code); assert.equal(r.body.status.state, 'none');
    }
    // a good key: verified by real requests (text + image) before it is active
    const ok = await c('/api/ai/config', { method: 'PUT', tok: owner, body: { provider: 'anthropic', apiKey: KEY1 } });
    assert.equal(ok.body.ok, true); assert.equal(ok.body.status.state, 'connected'); assert.equal(ok.body.status.vision, true);
    assert.equal(ok.body.status.last4, 'AA11'); assert.equal(ok.body.status.boundTo, 'shheahmad417@gmail.com');
    assert.ok(!fs.readFileSync(path.join(dir, 'ai-config.json'), 'utf8').includes('good-key'));
    const pub = (await c('/api/ai/status', { tok: user })).body;
    assert.equal(pub.state, 'connected'); assert.equal(pub.last4, undefined); assert.equal(pub.provider, undefined);
    // every feature, as a normal signed-in user
    const feats = async (tag) => {
      assert.match((await c('/api/ai/chat', { method: 'POST', tok: user, body: { messages: [{ role: 'user', content: 'hi' }], context: { mode: 'live' } } })).body.reply, new RegExp(`key=${tag}`));
      assert.match((await c('/api/ai/support', { method: 'POST', tok: user, body: { messages: [{ role: 'user', content: 'how do I run the bot?' }], page: '#/app/paper' } })).body.reply, new RegExp(`key=${tag}`));
      assert.match((await c('/api/ai/review', { method: 'POST', tok: user, body: { context: { overall: { n: 12, winRate: 50, avgR: 0.1 }, weaknesses: [] } } })).body.reply, new RegExp(`key=${tag}`));
      assert.equal((await c('/api/ai/review', { method: 'POST', tok: user, body: { context: { overall: { n: 0 } } } })).status, 400);   // nothing to review → no AI call
      assert.match((await c('/api/ai/explain', { method: 'POST', tok: user, body: { context: { symbol: 'BTCUSDT', mode: 'live' } } })).body.reply, new RegExp(`key=${tag}`));
      assert.equal((await c('/api/ai/images/describe', { method: 'POST', tok: user, body: { image: 'data:image/jpeg;base64,AAAA' } })).body.description, `described ${tag}`);
      const m = (await c('/api/ai/images/match', { method: 'POST', tok: user, body: { items: [{ title: 'Gold up' }, { title: 'Yen' }], candidates: [{ id: 'img1', text: 'gold bars' }] } })).body;
      assert.deepEqual(m.picks, [{ i: 0, id: 'img1' }, { i: 1, id: null }]);   // the invented id is dropped
    };
    await feats('AAAA11');
    // without a verified user the features refuse
    assert.equal((await c('/api/ai/chat', { method: 'POST', body: { messages: [{ role: 'user', content: 'hi' }] } })).status, 401);
    assert.equal((await c('/api/ai/chat', { method: 'POST', tok: token({ key: crypto.generateKeyPairSync('rsa', { modulusLength: 2048 }).privateKey }), body: { messages: [{ role: 'user', content: 'hi' }] } })).status, 401);
    // another account with the owner's email cannot replace the key bound to the owner
    assert.equal((await c('/api/ai/config', { method: 'PUT', tok: token({ uid: 'impostor' }), body: { provider: 'anthropic', apiKey: KEY2 } })).body.code, 'not_owner');
    // replacing the key applies to every feature at once
    assert.equal((await c('/api/ai/config', { method: 'PUT', tok: owner, body: { provider: 'anthropic', apiKey: KEY2 } })).body.ok, true);
    await feats('BBBB22');
    // a failed replacement keeps the working key
    assert.equal((await c('/api/ai/config', { method: 'PUT', tok: owner, body: { provider: 'anthropic', apiKey: 'sk-ant-api03-bad-key-yyyyyyyyyyyyy' } })).body.ok, false);
    await feats('BBBB22');
    // a key whose model cannot read images: text features work, image features say so
    assert.equal((await c('/api/ai/config', { method: 'PUT', tok: owner, body: { provider: 'anthropic', apiKey: 'sk-ant-api03-novision-key-CCCC33' } })).body.status.vision, false);
    assert.match((await c('/api/ai/chat', { method: 'POST', tok: user, body: { messages: [{ role: 'user', content: 'hi' }] } })).body.reply, /key=CCCC33/);
    assert.equal((await c('/api/ai/images/describe', { method: 'POST', tok: user, body: { image: 'data:image/jpeg;base64,AAAA' } })).body.code, 'vision_unsupported');
    // OpenAI-compatible provider with its own base URL and models
    const oa = await c('/api/ai/config', { method: 'PUT', tok: owner, body: { provider: 'openai', apiKey: 'sk-oa-good-key-for-openai-DDDD44', baseUrl: `http://127.0.0.1:${mp}/v1`, model: 'text-model', visionModel: 'vision-model' } });
    assert.equal(oa.body.ok, true); assert.equal(oa.body.status.provider, 'openai');
    await feats('DDDD44');
    assert.ok(seen.some((x) => x.url === '/v1/chat/completions' && x.model === 'vision-model'));
    assert.equal((await c('/api/ai/config', { method: 'PUT', tok: owner, body: { provider: 'openai', apiKey: 'sk-oa-broke-key-for-openai-EEEE5', baseUrl: `http://127.0.0.1:${mp}/v1`, model: 'text-model' } })).body.code, 'no_credit');
    // re-check, then delete: everything stops
    assert.equal((await c('/api/ai/config/test', { method: 'POST', tok: owner })).body.ok, true);
    assert.equal((await c('/api/ai/config', { method: 'DELETE', tok: user })).status, 403);
    assert.equal((await c('/api/ai/config', { method: 'DELETE', tok: owner })).body.status.state, 'none');
    for (const p of ['/api/ai/chat', '/api/ai/support', '/api/ai/explain', '/api/ai/images/describe', '/api/ai/images/match']) {
      const r = await c(p, { method: 'POST', tok: user, body: { messages: [{ role: 'user', content: 'x' }], context: {}, image: 'data:image/png;base64,AAAA', items: [{ title: 'a' }], candidates: [{ id: 'a', text: 'b' }] } });
      assert.equal(r.body.code, 'not_configured', p);
    }
    // the key never appears in any response or in the server log
    for (const k of [KEY1, KEY2, 'novision-key-CCCC33', 'good-key-for-openai']) {
      assert.ok(!all.some((r) => r.includes(k)), `response leaked ${k}`);
      assert.ok(!log().includes(k), `log leaked ${k}`);
    }
  } finally { child.kill(); mock.close(); fs.rmSync(dir, { recursive: true, force: true }); }
});

test('gateway: no AI_KEY_SECRET → nothing can be saved; per-user limit answers 429', async () => {
  const seen = []; const mock = providerMock(seen); const mp = await listen(mock);
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'aigw2-'));
  const certFile = path.join(dir, 'certs.json'); fs.writeFileSync(certFile, JSON.stringify(certs));
  const a = await startServer({ ANTHROPIC_BASE_URL: `http://127.0.0.1:${mp}`, AI_TEST_CERTS_FILE: certFile, FIREBASE_PROJECT_ID: PROJECT, AI_KEY_SECRET: '', SERVER_DATA_DIR: dir, ANTHROPIC_API_KEY: '' });
  try {
    assert.equal((await call(a.port, '/api/ai/config', { method: 'PUT', tok: token(), body: { provider: 'anthropic', apiKey: 'sk-ant-api03-good-key-number-one-AAAA11' } })).body.code, 'no_secret');
  } finally { a.child.kill(); }
  const b = await startServer({ ANTHROPIC_BASE_URL: `http://127.0.0.1:${mp}`, AI_TEST_CERTS_FILE: certFile, FIREBASE_PROJECT_ID: PROJECT, AI_KEY_SECRET: 's'.repeat(48), SERVER_DATA_DIR: dir, ANTHROPIC_API_KEY: '', AI_USER_PER_MINUTE: '2' });
  try {
    assert.equal((await call(b.port, '/api/ai/config', { method: 'PUT', tok: token(), body: { provider: 'anthropic', apiKey: 'sk-ant-api03-good-key-number-one-AAAA11' } })).body.ok, true);
    const u = token({ uid: 'u2', email: 'x@example.com' });
    const r = [];
    for (let i = 0; i < 3; i++) r.push((await call(b.port, '/api/ai/chat', { method: 'POST', tok: u, body: { messages: [{ role: 'user', content: 'hi' }] } })).status);
    assert.deepEqual(r, [200, 200, 429]);
  } finally { b.child.kill(); mock.close(); fs.rmSync(dir, { recursive: true, force: true }); }
});
