// The chart's AI now runs in a Web Worker; these checks pin that the numbers did not change and that the fallback works.
import test from 'node:test';
import assert from 'node:assert';

const mem = new Map();
globalThis.localStorage ??= { getItem: (k) => (mem.has(k) ? mem.get(k) : null), setItem: (k, v) => mem.set(k, String(v)), removeItem: (k) => mem.delete(k) };

function candles(n = 700) {
  let s = 11; const rnd = () => ((s = (s * 16807) % 2147483647) / 2147483647);
  const out = []; let p = 100;
  for (let i = 0; i < n; i++) { const o = p; p = Math.max(1, p * (1 + (rnd() - 0.49) * 0.02)); const hi = Math.max(o, p) * (1 + rnd() * 0.004); const lo = Math.min(o, p) * (1 - rnd() * 0.004); out.push({ time: 1_700_000_000 + i * 3600, open: o, high: hi, low: lo, close: p, volume: 100 + rnd() * 50 }); }
  return out;
}

test('aiForAnalysisAsync without Worker support = the same result as computing directly (aiRun), cached by input', async () => {
  const { aiJob, aiJobKey, aiRun } = await import('../src/services/aiLive.js');
  const { aiForAnalysisAsync } = await import('../src/services/aiAsync.js');
  assert.equal(typeof Worker, 'undefined');   // node: the fallback path
  const ds = { symbol: 'BTCUSDT', tf: '1h', candles: candles(), mode: 'live', volumeKind: 'none' };
  const an = { plan: null, rules: { tpR: [1, 2, 3.5] } };
  const job = aiJob(ds, an);
  const direct = aiRun(job);
  const viaAsync = aiForAnalysisAsync(ds, an, () => assert.fail('no callback on the synchronous path'));
  assert.deepEqual(viaAsync, direct);
  assert.strictEqual(aiForAnalysisAsync(ds, an), viaAsync);   // same input → cached object, no retraining
  // the key ignores the forming candle (the engine never looks at it) but changes with a new closed candle
  const forming = { ...ds, candles: ds.candles.slice(0, -1).concat({ ...ds.candles.at(-1), close: ds.candles.at(-1).close * 1.01 }) };
  assert.equal(aiJobKey(aiJob(forming, an)), aiJobKey(job));
  const next = { ...ds, candles: ds.candles.concat({ ...ds.candles.at(-1), time: ds.candles.at(-1).time + 3600 }) };
  assert.notEqual(aiJobKey(aiJob(next, an)), aiJobKey(job));
});
