import {test} from 'node:test';
import assert from 'node:assert/strict';
import {closedBars,analyzeEvidence,validPlan,advanceTracker} from '../src/services/marketAnalysis.js';
const now=Date.UTC(2026,9,23,12),t=now/1000;
const candle=(time,open,high,low,close)=>({time,open,high,low,close});
const higher=Array.from({length:20},(_,i)=>candle(t-(22-i)*14400,100,130,90,100+i));
const daily=[candle(t-172800,100,110,90,100)];
function edh(){const candles=Array.from({length:30},(_,i)=>candle(t-(32-i)*300,100,105,95,100));candles[29]=candle(t-600,105,113,104,112);return {candles,higher,daily,seconds:300,strategy:'edh',order:'market',price:112,now,point:.01};}
test('An incomplete candle is excluded from confirmation',()=>{
 assert.equal(closedBars([candle(t-100,100,115,90,112)],300,now).length,0);
 const input=edh();input.candles[29].time=t-100;assert.equal(analyzeEvidence(input).plan,null);
});
test('EDH requires close beyond previous day and rejects wick-only breaches',()=>{
 const input=edh();const a=analyzeEvidence(input);assert.equal(a.plan.direction,'long');assert.ok(validPlan(a.plan));
 input.candles[29].close=109;assert.equal(analyzeEvidence(input).plan,null);
});
test('EDH cannot silently run on 15m or enter limit on wrong side',()=>{
 const input=edh();input.seconds=900;assert.equal(analyzeEvidence(input).plan,null);
 Object.assign(input,edh(),{order:'limit',price:108});assert.equal(analyzeEvidence(input).plan,null);
});
test('EDH supports pending long and short plans with ordered targets',()=>{
 const input={...edh(),order:'limit'};let p=analyzeEvidence(input).plan;assert.equal(p.entry,110);assert.ok(validPlan(p));
 input.candles[29]=candle(t-600,95,96,85,88);input.price=88;p=analyzeEvidence(input).plan;assert.equal(p.direction,'short');assert.ok(validPlan(p));
});
test('Unavailable price, missing 4H or mixed evidence cannot force a plan',()=>{
 assert.equal(analyzeEvidence({...edh(),price:NaN}).plan,null);
 assert.equal(analyzeEvidence({...edh(),higher:[],strategy:'smc'}).plan,null);
 assert.equal(analyzeEvidence({...edh(),strategy:'smc'}).plan,null);
 assert.equal(validPlan({direction:'long',entry:100,stop:101,targets:[102,103,104]}),false);
});
test('Limit tracking stays pending until entry then latches targets and stop',()=>{
 const p={direction:'long',entry:100,stop:90,targets:[110,120,130]};let s={status:'pending',hits:[],at:0};
 s=advanceTracker(s,p,112,1);assert.equal(s.status,'pending');assert.deepEqual(s.hits,[]);
 s=advanceTracker(s,p,100,2);assert.equal(s.status,'active');s=advanceTracker(s,p,121,3);assert.deepEqual(s.hits,[true,true,false]);
 s=advanceTracker(s,p,89,4);assert.equal(s.status,'stop');assert.equal(advanceTracker(s,p,140,5),s);
});
test('Short tracker, stale/out of order quotes, and terminal TP3',()=>{
 const p={direction:'short',entry:100,stop:110,targets:[90,80,70]};let s={status:'pending',hits:[],at:1};
 assert.equal(advanceTracker(s,p,100,1),s);s=advanceTracker(s,p,100,2);assert.equal(s.status,'active');
 s=advanceTracker(s,p,69,3);assert.equal(s.status,'complete');assert.equal(advanceTracker(s,p,111,4),s);
});
test('SMC/ICT confirms both directions only with sweep, MSS, displacement and array touch',()=>{
 const candles=Array.from({length:30},(_,i)=>candle(t-(32-i)*900,100,102,98,100));
 candles[27]=candle(t-4500,100,101,97,99);
 candles[28]=candle(t-3600,99,103,99,102);
 candles[29]=candle(t-2700,100,109,98,108);
 const input={candles,higher,daily,seconds:900,strategy:'smc',order:'market',price:108,now,point:.01};
 const a=analyzeEvidence(input);assert.equal(a.plan?.direction,'long',JSON.stringify(a.checks));
 const mirror=b=>candle(b.time,200-b.open,200-b.low,200-b.high,200-b.close);
 const short=analyzeEvidence({...input,candles:candles.map(mirror),higher:higher.map(mirror),price:92});assert.equal(short.plan?.direction,'short');
 candles[27].low=98;assert.equal(analyzeEvidence(input).plan,null);
});
