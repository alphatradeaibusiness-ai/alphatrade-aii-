import { orderTargets } from '../src/services/backtest.js';
import assert from 'node:assert';
const l = orderTargets('long', 100, 2, [110, 104, 104.1]);
assert(l[0] < l[1] && l[1] < l[2] && l[0] > 100, JSON.stringify(l));
const s = orderTargets('short', 100, 2, [90, 96]);
assert(s[0] > s[1] && s[1] > s[2] && s[0] < 100, JSON.stringify(s));
console.log('ok', l, s);
