import test from 'node:test';
import assert from 'node:assert/strict';
import { confirmTrade, RULES, WEIGHTS } from '../src/services/confirm.js';

// Deterministic candles: a steady uptrend with small pullbacks, or a flat random-ish chop.
function mk(n, f, t0 = 1_700_000_000) {
  const out = []; let p = 100;
  for (let i = 0; i < n; i++) {
    const o = p; p = f(i, p); const c = p;
    out.push({ time: t0 + i * 900, open: o, high: Math.max(o, c) + 0.3, low: Math.min(o, c) - 0.3, close: c, volume: 100 + (i % 7) * 10 });
  }
  return out;
}
const up = mk(400, (i, p) => p + (i % 6 === 5 ? -0.5 : 0.35));
const flat = mk(400, (i, p) => 100 + Math.sin(i * 1.7) * 0.4 + ((i * 7) % 5) * 0.05);
const htfUp = (candles) => ({ h4: mk(120, (i, p) => p + 0.5, 1_690_000_000), d1: mk(60, (i, p) => p + 1, 1_680_000_000) });
const htfDown = () => ({ h4: mk(120, (i, p) => p - 0.5, 1_690_000_000), d1: mk(60, (i, p) => p - 1, 1_680_000_000) });
const px = (c) => c.at(-1).close;

test('exports weights and rules; structure + higher timeframe weigh most', () => {
  assert.ok(WEIGHTS.structure >= WEIGHTS.trend && WEIGHTS.htf >= WEIGHTS.rsi);
  assert.ok(RULES.minGroups >= 3 && RULES.minScore > 0);
});
test('too few candles → no-trade (data)', () => {
  const r = confirmTrade({ candles: up.slice(0, 50), direction: 'long', entry: 110, stop: 108, targets: [112, 114], mode: 'live' });
  assert.equal(r.verdict, 'no-trade'); assert.ok(r.blockers.includes('data'));
});
test('demo mode never confirms', () => {
  const e = px(up);
  const r = confirmTrade({ candles: up, direction: 'long', entry: e, stop: e - 2, targets: [e + 2, e + 4], htf: htfUp(), mode: 'demo' });
  assert.equal(r.verdict, 'no-trade'); assert.ok(r.blockers.includes('demo'));
});
test('higher timeframe against the trade is a hard conflict', () => {
  const e = px(up);
  const r = confirmTrade({ candles: up, direction: 'long', entry: e, stop: e - 2, targets: [e + 2, e + 4], htf: htfDown(), mode: 'live' });
  assert.equal(r.verdict, 'no-trade'); assert.ok(r.blockers.includes('conflictCore'));
});
test('sideways market is filtered', () => {
  const e = px(flat);
  const r = confirmTrade({ candles: flat, direction: 'long', entry: e, stop: e - 1, targets: [e + 1, e + 2], htf: htfUp(), mode: 'live' });
  assert.equal(r.verdict, 'no-trade'); assert.ok(r.blockers.includes('sideways'));
});
test('high-impact news blocks', () => {
  const e = px(up);
  const r = confirmTrade({ candles: up, direction: 'long', entry: e, stop: e - 2, targets: [e + 2, e + 4], htf: htfUp(), news: { level: 'high' }, mode: 'live' });
  assert.ok(r.blockers.includes('news')); assert.equal(r.verdict, 'no-trade');
});
test('invalid levels are rejected: wrong-side stop, wrong-side target, reward below risk, first target below fees', () => {
  const e = px(up);
  const base = { candles: up, direction: 'long', htf: htfUp(), mode: 'live', entry: e };
  assert.ok(confirmTrade({ ...base, stop: e + 1, targets: [e + 2, e + 4] }).levels.issues.includes('stopSide'));
  assert.ok(confirmTrade({ ...base, stop: e - 2, targets: [e - 1, e + 4] }).levels.issues.includes('targetSide'));
  assert.ok(confirmTrade({ ...base, stop: e - 2, targets: [e + 1, e + 4, e + 3] }).levels.issues.includes('targetOrder'));
  assert.ok(confirmTrade({ ...base, stop: e - 2, targets: [e + 0.5, e + 1] }).levels.issues.includes('rr'));
  assert.ok(confirmTrade({ ...base, stop: e - 2, targets: [e + 0.01, e + 4], feePct: 1 }).levels.issues.includes('tp1Fee'));
  assert.equal(confirmTrade({ ...base, stop: e + 1, targets: [e + 2, e + 4] }).verdict, 'no-trade');
});
test('result carries evidence, never an accuracy / win-rate figure', () => {
  const e = px(up);
  const r = confirmTrade({ candles: up, direction: 'long', entry: e, stop: e - 2, targets: [e + 2, e + 4], htf: htfUp(), mode: 'live' });
  assert.ok(Array.isArray(r.groups) && r.groups.length >= 4);
  for (const k of Object.keys(r)) assert.ok(!/win|accuracy|prob/i.test(k), k);
  assert.ok(['trade', 'no-trade'].includes(r.verdict));
});
test('a short against an uptrend never confirms', () => {
  const e = px(up);
  const r = confirmTrade({ candles: up, direction: 'short', entry: e, stop: e + 2, targets: [e - 2, e - 4], htf: htfUp(), mode: 'live' });
  assert.equal(r.verdict, 'no-trade');
});
test('strict: tightening the rules can only reduce accepted trades', () => {
  const e = px(up);
  const args = { candles: up, direction: 'long', entry: e, stop: e - 2, targets: [e + 2, e + 4], htf: htfUp(), mode: 'live' };
  const loose = confirmTrade({ ...args, rules: { minScore: 0, minGroups: 0, maxAgainst: 99, needCore: false, sidewaysEr: 0, minRR: 0 } });
  const strict = confirmTrade({ ...args, rules: { minScore: 99 } });
  assert.equal(strict.verdict, 'no-trade'); assert.ok(strict.blockers.includes('weak'));
  assert.ok(loose.blockers.length <= strict.blockers.length);
});
