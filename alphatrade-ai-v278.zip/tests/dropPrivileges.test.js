// v275: the server hands its data folders to an unprivileged user and drops root before anything else runs.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { execFileSync } from 'node:child_process';

const isRoot = typeof process.getuid === 'function' && process.getuid() === 0;
const nobody = (() => { try { const l = fs.readFileSync('/etc/passwd', 'utf8').split('\n').find((x) => x.startsWith('nobody:')); return l ? { uid: +l.split(':')[2], gid: +l.split(':')[3] } : null; } catch { return null; } })();
const MOD = path.resolve('server/dropPrivileges.js');
const run = (env) => execFileSync(process.execPath, ['--input-type=module', '-e', `await import(${JSON.stringify(MOD)}); import fs from 'node:fs'; fs.writeFileSync(process.env.SERVER_DATA_DIR + '/probe.txt', 'ok'); console.log(JSON.stringify({ uid: process.getuid(), gid: process.getgid() }));`], { env: { PATH: process.env.PATH, ...env }, encoding: 'utf8' }).trim().split('\n').pop();

test('no RUN_AS_USER: nothing changes', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'dp0-'));
  const out = JSON.parse(run({ SERVER_DATA_DIR: dir }));
  assert.equal(out.uid, process.getuid());
});

test('as root with RUN_AS_USER: root-owned data disk is handed over, then the process runs as that user', { skip: !(isRoot && nobody) && 'needs root and a "nobody" user' }, () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'dp1-')); fs.chmodSync(dir, 0o755);
  fs.mkdirSync(path.join(dir, 'worker')); fs.writeFileSync(path.join(dir, 'worker', 'state.json'), '{}');   // like a disk with old data on it
  fs.symlinkSync('/etc', path.join(dir, 'link-out'));                                                      // must NOT be followed
  const before = fs.statSync('/etc').uid;
  const out = JSON.parse(run({ SERVER_DATA_DIR: dir, RUN_AS_USER: 'nobody' }));
  assert.deepEqual(out, { uid: nobody.uid, gid: nobody.gid });
  assert.equal(fs.statSync(dir).uid, nobody.uid);
  assert.equal(fs.statSync(path.join(dir, 'worker', 'state.json')).uid, nobody.uid);
  assert.equal(fs.readFileSync(path.join(dir, 'probe.txt'), 'utf8'), 'ok', 'the dropped process can write');
  assert.equal(fs.statSync('/etc').uid, before, 'symlinks are not followed');
});

test('unknown RUN_AS_USER fails loudly instead of silently staying root', { skip: !isRoot && 'needs root' }, () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'dp2-'));
  assert.throws(() => run({ SERVER_DATA_DIR: dir, RUN_AS_USER: 'no-such-user-xyz' }));
});
