import test from 'node:test';
import assert from 'node:assert/strict';
const mem = new Map();
globalThis.localStorage = { getItem: (k) => (mem.has(k) ? mem.get(k) : null), setItem: (k, v) => mem.set(k, String(v)), removeItem: (k) => mem.delete(k) };
const S = await import('../src/services/smartImages.js');

const img = (id, description, keywords) => ({ id, name: `${id}.jpg`, data: 'data:image/jpeg;base64,AA', addedAt: Date.now(), desc: { description, alt: description, keywords } });

test('candidates rank images by shared words with the headlines', () => {
  const list = [img('a', 'Gold bars stacked', ['gold', 'bullion']), img('b', 'Bitcoin coin', ['bitcoin', 'crypto']), img('c', 'Federal Reserve building', ['fed', 'bank'])];
  assert.equal(S.candidates(list, ['Bitcoin jumps as ETF inflows grow'])[0].id, 'b');
  assert.equal(S.candidates(list, ['Gold hits a record as the dollar slides'])[0].id, 'a');
});

test('headlines: one AI request for the new ones, cached afterwards, invented ids ignored, off = no request', async () => {
  await S.putImage(img('g', 'Gold bars', ['gold'])); await S.putImage(img('b', 'Bitcoin coin', ['bitcoin'])); await S.putImage({ ...img('x', '', []), desc: null });
  const items = [{ id: 'n1', title: 'Gold record high' }, { id: 'n2', title: 'Bitcoin ETF approved' }, { id: 'n3', title: 'Japan wage data' }];
  let calls = 0; let sent = null;
  const post = async (path, body) => { calls++; sent = { path, body }; return { picks: [{ i: 0, id: 'g' }, { i: 1, id: 'b' }, { i: 2, id: 'made-up' }] }; };
  const r1 = await S.imagesForHeadlines(items, { post });
  assert.equal(calls, 1); assert.equal(r1.get('n1').id, 'g'); assert.equal(r1.get('n2').id, 'b'); assert.equal(r1.has('n3'), false);
  assert.equal(sent.path, '/images/match'); assert.ok(!sent.body.candidates.some((c) => c.id === 'x'), 'undescribed images are not offered');
  const r2 = await S.imagesForHeadlines(items, { post });
  assert.equal(calls, 1, 'cached: no new request'); assert.equal(r2.get('n1').id, 'g');
  S.setSiSettings({ news: false });
  assert.equal((await S.imagesForHeadlines([{ id: 'n9', title: 'Gold' }], { post })).size, 0); assert.equal(calls, 1);
  S.setSiSettings({ news: true });
  // deleting an image drops its cached picks
  await S.deleteImage('g');
  const r3 = await S.imagesForHeadlines(items, { post: async () => { calls++; return { picks: [{ i: 0, id: null }] }; } });
  assert.equal(r3.has('n1'), false); assert.equal(calls, 2);
});

test('describe: goes to the gateway and stores description, alt and keywords; an empty answer fails cleanly', async () => {
  let path = '';
  const out = await S.describeImage(img('d', '', []), 'ar', async (p) => { path = p; return { description: 'سبائك ذهب', alt: 'ذهب', keywords: ['gold', 'ذهب'] }; });
  assert.equal(path, '/images/describe');
  assert.equal(out.desc.description, 'سبائك ذهب'); assert.deepEqual(out.desc.keywords, ['gold', 'ذهب']);
  await assert.rejects(() => S.describeImage(img('e', '', []), 'ar', async () => ({})));
});
