import test from 'node:test';
import assert from 'node:assert/strict';
import { SCAN_JOBS } from '../src/services/scanJobs.js';
import { scanJob } from '../src/services/scanAsync.js';
import { runStrategy, rulesFrom } from '../src/services/backtest.js';
import { evaluateCombo } from '../src/services/comboEval.js';
import { runAllStrategies } from '../src/services/multiStrategy.js';

const mk = (n, sec) => { let p = 50000; const now = Math.floor(Date.now() / 1000 / sec) * sec; const out = []; for (let i = 0; i < n; i++) { const o = p; p *= 1 + Math.sin(i / 37) * 0.0012 + Math.cos(i / 11) * 0.0008; out.push({ time: now - (n - i) * sec, open: o, high: Math.max(o, p) * 1.0007, low: Math.min(o, p) * 0.9993, close: p, volume: 10 }); } return out; };
const inst = { symbol: 'BTCUSDT', type: 'crypto', provider: 'binance', precision: 2, pointSize: 1 };

test('scan jobs (worker) give exactly the same results as the main-thread code', async () => {
  const cs = mk(4000, 300);
  const rules = { ...rulesFrom({}, inst), forced: null, maxPerDay: 0, pointSize: 1, volumeKind: 'taker', openOnLast: false };
  const direct = evaluateCombo(runStrategy('edh', cs, rules).trades);
  const viaJob = await scanJob('proof', { strategy: 'edh', candles: cs, rules });   // no Worker in node → same code inline
  assert.deepEqual({ ...viaJob, open: undefined }, { ...direct, open: undefined });
  assert.deepEqual(SCAN_JOBS.live({ strategy: 'edh', candles: cs, rules }).open, runStrategy('edh', cs, rules).open || null);
  const c6 = mk(600, 60);
  const input = { symbol: 'BTCUSDT', inst, tf: '1m', tfSec: 60, candles: c6, mode: 'live', htf: null, calendar: { events: [], at: Date.now() }, peer: null, nowMs: Date.now(), account: {} };
  const e = SCAN_JOBS.engine({ input, smc: { asset: 'crypto', news: null }, cfg: {} });
  const m = runAllStrategies({ ...input, reading: null });
  assert.equal(e.final === 'no_trade' || ['buy', 'sell'].includes(e.final), true);
  assert.ok(Array.isArray(e.emitted));
  assert.equal(m.strategies.length, 6);
});
