// End-to-end over HTTP: customer pairs an MT5 account, the EA connects, an order is queued from the site, the EA picks it up,
// reports the fill, and the log shows it. Also: another customer cannot see or use the link, wrong tokens / accounts are refused.
import test from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import http from 'node:http';
import { spawn } from 'node:child_process';

test('server: MT5 bridge end to end (pairing → EA hello → order → poll → ack → log)', async () => {
  const PROJECT = 'alphatrade-test'; const KID = 'k-mt5';
  const kp = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
  const b64u = (b) => Buffer.from(b).toString('base64').replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
  const tok = (uid, email) => { const n = Math.floor(Date.now() / 1000); const h = b64u(JSON.stringify({ alg: 'RS256', kid: KID, typ: 'JWT' }));
    const p = b64u(JSON.stringify({ iss: `https://securetoken.google.com/${PROJECT}`, aud: PROJECT, sub: uid, iat: n - 10, auth_time: n - 10, exp: n + 3600, email, email_verified: true, firebase: { sign_in_provider: 'google.com' } }));
    return `${h}.${p}.${b64u(crypto.sign('RSA-SHA256', Buffer.from(`${h}.${p}`), kp.privateKey))}`; };
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'mt5srv-')); const certFile = path.join(dir, 'certs.json');
  fs.writeFileSync(certFile, JSON.stringify({ [KID]: kp.publicKey.export({ type: 'spki', format: 'pem' }) }));
  const port = 20000 + Math.floor(Math.random() * 20000); const O = `http://127.0.0.1:${port}`;
  const child = spawn(process.execPath, ['--no-warnings', 'server/index.js'], { env: { ...process.env, NODE_ENV: 'test', SERVER_PORT: String(port), SERVER_DATA_DIR: dir, AI_KEY_SECRET: 'b'.repeat(40), BANK_MASTER_KEY: '', ANTHROPIC_API_KEY: '', FIREBASE_PROJECT_ID: PROJECT, AI_TEST_CERTS_FILE: certFile }, stdio: 'ignore' });
  const req = (p, { method = 'GET', body, t, bridge, origin = true } = {}) => new Promise((resolve, reject) => {
    const d = body === undefined ? null : JSON.stringify(body);
    const headers = { ...(method !== 'GET' && origin ? { origin: O } : {}), ...(d ? { 'content-type': 'application/json', 'content-length': Buffer.byteLength(d) } : {}), ...(t ? { authorization: `Bearer ${t}` } : {}), ...(bridge ? { 'x-bridge-token': bridge } : {}) };
    const r = http.request({ host: '127.0.0.1', port, path: p, method, headers }, (res) => { let s = ''; res.on('data', (c) => (s += c)); res.on('end', () => { let j = null; try { j = JSON.parse(s); } catch { /* text */ } resolve({ status: res.statusCode, body: j, text: s }); }); });
    r.on('error', reject); if (d) r.write(d); r.end();
  });
  const terminal = (over = {}) => ({ account: '5012345', server: 'MetaQuotes-Demo', company: 'MetaQuotes Ltd.', build: 4500, balance: 10000, equity: 10000, currency: 'USD', leverage: 100, allowTrading: true, maxLot: 0.1, positions: [], ...over });
  try {
    for (let i = 0; i < 80; i++) { try { if ((await req('/api/health')).status === 200) break; } catch { /* starting */ } await new Promise((r) => setTimeout(r, 100)); }
    const me = tok('cust1', 'c1@example.com'); const other = tok('cust2', 'c2@example.com');
    assert.equal((await req('/api/mt5')).status, 401, 'sign-in needed');
    assert.equal((await req('/api/mt5/link', { method: 'POST', t: me, body: { account: 'abc', server: 'X' } })).body.code, 'bad_account');
    const link = await req('/api/mt5/link', { method: 'POST', t: me, body: { account: '5012345', server: 'MetaQuotes-Demo' } });
    assert.equal(link.status, 200); const { token } = link.body; const id = link.body.link.id;
    assert.match(token, /^mt5_[0-9a-f]{48}$/);
    // the EA (no Origin header, token only)
    assert.equal((await req('/api/mt5/ea/hello', { method: 'POST', origin: false, bridge: 'mt5_' + 'f'.repeat(48), body: terminal() })).text, 'ERR|bad_token');
    assert.equal((await req('/api/mt5/ea/hello', { method: 'POST', origin: false, bridge: token, body: terminal({ account: '999' }) })).text, 'ERR|account_mismatch');
    assert.match((await req('/api/mt5/ea/hello', { method: 'POST', origin: false, bridge: token, body: terminal() })).text, /^OK\|\d+$/);
    const view = await req('/api/mt5', { t: me });
    assert.equal(view.body.links[0].connected, true); assert.equal(view.body.links[0].terminal.balance, 10000);
    assert.equal((await req('/api/mt5', { t: other })).body.links.length, 0, 'another customer sees nothing');
    assert.equal((await req(`/api/mt5/link/${id}/order`, { method: 'POST', t: other, body: { side: 'buy', symbol: 'EURUSD', volume: 0.01 } })).status, 404, 'and cannot trade on it');
    // an order from the site
    const q = await req(`/api/mt5/link/${id}/order`, { method: 'POST', t: me, body: { side: 'sell', symbol: 'XAUUSD', volume: 0.02, sl: 2660, tp: 2620 } });
    assert.equal(q.status, 200); const cid = q.body.command.id;
    const poll = await req('/api/mt5/ea/poll', { method: 'POST', origin: false, bridge: token, body: terminal() });
    const lines = poll.text.split('\n');
    assert.match(lines[0], /^OK\|\d+\|2000$/);
    assert.equal(lines[1], `${cid}|sell|XAUUSD|0.02|2660|2620||AlphaTrade AI`);
    assert.equal((await req('/api/mt5/ea/poll', { method: 'POST', origin: false, bridge: token, body: terminal() })).text.split('\n').filter(Boolean).length, 1, 'never delivered twice');
    assert.equal((await req('/api/mt5/ea/ack', { method: 'POST', origin: false, bridge: token, body: { id: cid, ok: true, ticket: '7788', price: 2641.2, retcode: 10009, message: 'done' } })).text.startsWith('OK'), true);
    const log = (await req('/api/mt5', { t: me })).body.links[0].log;
    assert.equal(log[0].status, 'done'); assert.equal(log[0].ticket, '7788'); assert.equal(log[0].symbol, 'XAUUSD');
    // trading switched off in the EA → the site refuses new orders
    await req('/api/mt5/ea/poll', { method: 'POST', origin: false, bridge: token, body: terminal({ allowTrading: false }) });
    assert.equal((await req(`/api/mt5/link/${id}/order`, { method: 'POST', t: me, body: { side: 'buy', symbol: 'EURUSD', volume: 0.01 } })).body.code, 'trading_disabled');
    // the website endpoints still need the site's Origin for writes
    assert.equal((await req('/api/mt5/link', { method: 'POST', t: me, origin: false, body: { account: '1234', server: 'Demo' } })).status, 403);
    assert.equal((await req(`/api/mt5/link/${id}`, { method: 'DELETE', t: me })).status, 200);
    assert.equal((await req('/api/mt5/ea/poll', { method: 'POST', origin: false, bridge: token, body: terminal() })).text, 'ERR|bad_token', 'a removed link stops working at once');
  } finally { child.kill(); }
});
