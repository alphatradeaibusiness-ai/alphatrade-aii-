// Back-test of the assistant: no look-ahead, honest statistics, strict verdict.
import test from 'node:test';
import assert from 'node:assert/strict';
import { backtestSmcIct, stats, judge } from '../src/services/smcBacktest.js';
import { aggregate } from '../src/services/smc2.js';

function walk(seed, n, step = 3600) {
  let p = 100; let s = seed; const rnd = () => { s = (s * 16807) % 2147483647; return s / 2147483647; };
  const out = [];
  for (let i = 0; i < n; i++) {
    const o = p; const c = o + (rnd() - 0.5 + Math.sin(i / 60) * 0.25) * 2; const h = Math.max(o, c) + rnd() * 0.8; const l = Math.min(o, c) - rnd() * 0.8;
    out.push({ time: 1_700_000_000 + i * step, open: o, high: h, low: l, close: c }); p = c;
  }
  return out;
}

test('stats and verdict', () => {
  const s = stats([{ resultR: 2 }, { resultR: -1 }, { resultR: -1 }, { resultR: 3 }]);
  assert.deepEqual({ n: s.n, wins: s.wins, winRate: s.winRate, avgR: s.avgR, totalR: s.totalR, profitFactor: s.profitFactor, maxDD: s.maxDD, maxLossStreak: s.maxLossStreak }, { n: 4, wins: 2, winRate: 0.5, avgR: 0.75, totalR: 3, profitFactor: 2.5, maxDD: 2, maxLossStreak: 2 });
  assert.deepEqual(s.equity, [2, 1, 0, 3]);
  assert.equal(judge({ n: 10, avgR: 1 }, { n: 5, avgR: 1 }), 'too_few');
  assert.equal(judge({ n: 40, avgR: -0.1 }, { n: 12, avgR: 1 }), 'negative');
  assert.equal(judge({ n: 40, avgR: 0.3 }, { n: 12, avgR: -0.2 }), 'not_stable');
  assert.equal(judge({ n: 40, avgR: 0.3 }, { n: 12, avgR: 0.1 }), 'positive');
});

test('no look-ahead: a shorter history gives exactly the same closed trades up to its end', async () => {
  const cs = walk(4242, 1600);
  const htf = { h4: aggregate(cs, 14400), d1: aggregate(cs, 86400) };
  const input = { style: 'swing', execution: 'limit', asset: 'crypto', costPct: 0.1, symbol: 'BTCUSDT', tf: '1h', tfSec: 3600 };
  const full = await backtestSmcIct(cs, input, { htf });
  const cutAt = 1200;
  const part = await backtestSmcIct(cs.slice(0, cutAt), input, { htf });
  assert.ok(full.trades.length > 0, 'the rules trade on this market');
  const end = cs[cutAt - 1].time;
  const fullEarly = full.trades.filter((t) => t.closedAt <= end);
  // every trade the short run closed is identical in the long run
  for (const t of part.trades) assert.ok(fullEarly.some((f) => f.time === t.time && f.entry === t.entry && f.resultR === t.resultR), `trade at ${t.time} differs`);
  assert.ok(['too_few', 'negative', 'not_stable', 'positive'].includes(full.verdict));
  assert.ok(full.conditions.some((c) => c.id === 'sweep'));
  assert.equal(full.all.n, full.trades.length);
  assert.ok(full.trades.every((t, k) => !k || t.time >= full.trades[k - 1].closedAt), 'one position at a time');
});

test('refuses too little history and can be cancelled', async () => {
  assert.equal((await backtestSmcIct(walk(1, 300), { style: 'swing' })).error, 'not_enough_history');
  assert.equal((await backtestSmcIct(walk(1, 900), { style: 'swing' }, { isCancelled: () => true })).error, 'cancelled');
});

import { monteCarlo, compareSettings } from '../src/services/smcBacktest.js';
test('Monte Carlo is repeatable and sensible; settings comparison ranks by the newest period', async () => {
  const rs = [2, -1, -1, 3, -1, 2, -1, -1, 2.5, -1, 1, -1];
  const a = monteCarlo(rs, { riskPct: 1 }); const b = monteCarlo(rs, { riskPct: 1 });
  assert.deepEqual(a, b, 'same seed, same answer');
  assert.ok(a.ddR.p95 >= a.ddR.p50 && a.ddR.p50 >= 1);
  assert.ok(a.ddPct.p95 > 0 && a.ddPct.p95 < 20);
  assert.equal(a.finalR, 3.5, 'reordering never changes the total');
  assert.equal(monteCarlo([1, -1]), null, 'too few trades');
  assert.ok(monteCarlo(rs, { riskPct: 5 }).ddPct.p95 > a.ddPct.p95, 'more risk per trade, deeper drawdown');
  const cs = walk(99, 1000);
  const cmp = await compareSettings(cs, { style: 'swing', execution: 'limit', asset: 'crypto', costPct: 0.1, tfSec: 3600, require: [] }, { htf: { h4: aggregate(cs, 14400), d1: aggregate(cs, 86400) } });
  assert.equal(cmp.rows.length, 4);
  for (let i = 1; i < cmp.rows.length; i++) {
    const p = cmp.rows[i - 1]; const q = cmp.rows[i];
    if ((p.oos.n >= 10) === (q.oos.n >= 10)) assert.ok((p.oos.avgR ?? -99) >= (q.oos.avgR ?? -99));
  }
});

import { riskAdvice, drift, robustness, monteCarlo as mc2 } from '../src/services/smcBacktest.js';
test('risk advice keeps the 1-in-20 drawdown within the limit; Kelly is halved and capped; no edge → 0', () => {
  const good = Array.from({ length: 60 }, (_, i) => (i % 3 === 0 ? 2.5 : -1));
  const a = riskAdvice(good, { maxDDPct: 10 });
  assert.ok(a.riskForDD > 0 && a.riskForDD <= 5);
  assert.ok(mc2(good, { riskPct: a.riskForDD, runs: 800 }).ddPct.p95 <= 10.01);
  assert.ok(riskAdvice(good, { maxDDPct: 20 }).riskForDD > a.riskForDD, 'accepting a deeper drawdown allows more risk');
  assert.ok(a.halfKelly > 0 && a.halfKelly <= 2);
  const bad = Array.from({ length: 60 }, (_, i) => (i % 4 === 0 ? 1.5 : -1));
  assert.equal(riskAdvice(bad).halfKelly, 0);
  assert.equal(riskAdvice([1, -1]), null);
  const d = drift([...Array(30).fill(1), ...Array(20).fill(-1)]);
  assert.equal(d.worse, true); assert.equal(d.recent.avgR, -1);
  assert.equal(drift([1, 2, 3]), null);
  assert.deepEqual(robustness([{ n: 20, avgR: 0.3 }, { n: 15, avgR: 0.1 }, { n: 12, avgR: -0.2 }, { n: 4, avgR: 3 }]), { markets: 4, tested: 3, positive: 2, robust: true });
  assert.equal(robustness([{ n: 20, avgR: 0.3 }, { n: 15, avgR: -0.1 }, { n: 12, avgR: -0.2 }]).robust, false);
});
