// HTTP routes of the community / owner features: customers vs owners (the server enforces it, not the menu).
import test from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import http from 'node:http';
import { spawn } from 'node:child_process';

test('server: feedback, calls, live, plans, coupons and analytics — owner-only routes refuse customers', async () => {
  const PROJECT = 'alphatrade-test'; const KID = 'k-com';
  const kp = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
  const b64u = (b) => Buffer.from(b).toString('base64').replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
  const tok = (uid, email) => { const n = Math.floor(Date.now() / 1000); const h = b64u(JSON.stringify({ alg: 'RS256', kid: KID, typ: 'JWT' }));
    const p = b64u(JSON.stringify({ iss: `https://securetoken.google.com/${PROJECT}`, aud: PROJECT, sub: uid, iat: n - 10, auth_time: n - 10, exp: n + 3600, email, email_verified: true, firebase: { sign_in_provider: 'google.com' } }));
    return `${h}.${p}.${b64u(crypto.sign('RSA-SHA256', Buffer.from(`${h}.${p}`), kp.privateKey))}`; };
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'comsrv-')); const certFile = path.join(dir, 'certs.json');
  fs.writeFileSync(certFile, JSON.stringify({ [KID]: kp.publicKey.export({ type: 'spki', format: 'pem' }) }));
  const port = 20000 + Math.floor(Math.random() * 20000); const O = `http://127.0.0.1:${port}`;
  const child = spawn(process.execPath, ['--no-warnings', 'server/index.js'], { env: { ...process.env, NODE_ENV: 'test', SERVER_PORT: String(port), SERVER_DATA_DIR: dir, AI_KEY_SECRET: 'a'.repeat(40), BANK_MASTER_KEY: '', ANTHROPIC_API_KEY: '', FIREBASE_PROJECT_ID: PROJECT, AI_TEST_CERTS_FILE: certFile, ADMIN_EMAILS: 'boss@example.com' }, stdio: 'ignore' });
  const req = (p, { method = 'GET', body, t } = {}) => new Promise((resolve, reject) => {
    const d = body === undefined ? null : JSON.stringify(body);
    const r = http.request({ host: '127.0.0.1', port, path: p, method, headers: { ...(method !== 'GET' ? { origin: O } : {}), ...(d ? { 'content-type': 'application/json', 'content-length': Buffer.byteLength(d) } : {}), ...(t ? { authorization: `Bearer ${t}` } : {}) } }, (res) => { let s = ''; res.on('data', (c) => (s += c)); res.on('end', () => { let j = null; try { j = JSON.parse(s); } catch { /* */ } resolve({ status: res.statusCode, body: j, headers: res.headers }); }); });
    r.on('error', reject); if (d) r.write(d); r.end();
  });
  try {
    for (let i = 0; i < 80; i++) { try { if ((await req('/api/health')).status === 200) break; } catch { /* starting */ } await new Promise((r) => setTimeout(r, 100)); }
    const cust = tok('cust', 'cust@example.com'); const boss = tok('boss', 'boss@example.com');
    assert.equal((await req('/api/plans')).body.items.find((x) => x.id === 'monthly').price, 80, 'public plans');
    assert.equal((await req('/api/feedback')).status, 401, 'sign-in needed');
    const fb = await req('/api/feedback', { method: 'POST', t: cust, body: { kind: 'bug', text: 'The chart does not load' } });
    assert.equal(fb.status, 200); const id = fb.body.item.id;
    assert.equal((await req(`/api/feedback/${id}`, { method: 'PATCH', t: cust, body: { status: 'resolved' } })).status, 403);
    assert.equal((await req(`/api/feedback/${id}`, { method: 'PATCH', t: boss, body: { status: 'resolved', reply: 'Fixed' } })).body.item.status, 'resolved');
    assert.equal((await req('/api/feedback', { t: cust })).body.items[0].replies[0].text, 'Fixed');
    for (const p of ['/api/admin/analytics', '/api/admin/plans', '/api/admin/coupons', '/api/support/calls']) assert.equal((await req(p, { t: cust })).status, 403, p);
    assert.equal((await req('/api/live/start', { method: 'POST', t: cust, body: { title: 'Hack' } })).status, 403);
    assert.equal((await req('/api/live/start', { method: 'POST', t: boss, body: { title: 'Weekly outlook', url: 'https://youtu.be/abcdEFGH123' } })).status, 200);
    assert.equal((await req('/api/live', { t: cust })).body.current.title, 'Weekly outlook');
    assert.equal((await req('/api/admin/plans', { method: 'PUT', t: boss, body: { id: 'monthly', price: 70 } })).status, 200);
    assert.equal((await req('/api/plans')).body.items.find((x) => x.id === 'monthly').price, 70);
    assert.equal((await req('/api/admin/coupons', { method: 'PUT', t: boss, body: { code: 'WELCOME10', type: 'percent', value: 10 } })).status, 200);
    assert.equal((await req('/api/coupon/check', { method: 'POST', t: cust, body: { code: 'welcome10', product: 'monthly' } })).body.finalCents, 6300);
    const call = await req('/api/support/call', { method: 'POST', t: cust, body: { offer: 'v=0\r\no=- 1 2 IN IP4 127.0.0.1\r\n' } });
    assert.equal(call.status, 200);
    assert.equal((await req('/api/support/calls', { t: boss })).body.items[0].status, 'ringing');
    assert.equal((await req(`/api/support/call/${call.body.id}`, { t: tok('x', 'x@example.com') })).status, 404, 'other customers cannot see the call');
    assert.equal((await req('/api/me/reco', { method: 'POST', t: cust, body: { final: 'buy', strategy: 'smc' } })).status, 200);
    assert.equal((await req('/api/admin/analytics', { t: boss })).body.current.recommendations.generated, 1);
    const st = await req('/api/health');
    assert.match(String(st.headers['permissions-policy'] || ''), /microphone=\(self\)|^$/);
  } finally { child.kill(); }
});
