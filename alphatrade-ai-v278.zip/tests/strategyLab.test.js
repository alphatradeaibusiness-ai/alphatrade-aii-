// v251 Strategy Studio engine, Strategy DNA, Arena score, AI council / X-Ray / scenarios and the mentor list — on REAL candles.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { cleanSpec, backtest, splitTest, strategyDna, dnaSimilarity, arenaScore, DNA_AXES } from '../src/services/strategyLab.js';
import { runCouncil, xray, analogs } from '../src/services/council.js';
import { MENTORS, mentorSystem, mentorById, MENTOR_RULES } from '../src/config/mentors.js';

const FX = JSON.parse(fs.readFileSync(new URL('./fixtures/lab-real.json', import.meta.url), 'utf8'));
const K = (rows) => rows.map(([time, open, high, low, close]) => ({ time, open, high, low, close, volume: 0 }));
const BTC = K(FX.btc1h); const XAU = K(FX.xau4h);
const SPEC = { name: 'Trend pullback', symbol: 'BTCUSDT', tf: '1h', side: 'both', entry: [{ type: 'price_ema', len: 200, dir: 'above' }, { type: 'rsi', len: 14, op: 'lt', level: 40 }], exit: { stopAtr: 1.5, rr: 2, maxBars: 48 } };

test('cleanSpec bounds everything and refuses bad input', () => {
  assert.equal(cleanSpec({ ...SPEC, symbol: 'HACK' }).error, 'symbol');
  assert.equal(cleanSpec({ ...SPEC, tf: '1W' }).error, 'tf');
  assert.equal(cleanSpec({ ...SPEC, entry: [] }).error, 'no_rules');
  assert.equal(cleanSpec({ ...SPEC, entry: [{ type: 'eval' }] }).error, 'rule');
  assert.equal(cleanSpec({ ...SPEC, entry: [{ type: 'ema_cross', fast: 50, slow: 20, dir: 'up' }] }).error, 'ema_order');
  const s = cleanSpec({ ...SPEC, name: '<script>x</script>', entry: [{ type: 'rsi', len: 9999, op: 'zz', level: -5 }], exit: { stopAtr: 100, rr: 0, maxBars: 1e9 } });
  assert.equal(s.name.includes('<'), false);
  assert.deepEqual(s.entry[0], { type: 'rsi', len: 50, op: 'lt', level: 5 });
  assert.deepEqual([s.exit.stopAtr, s.exit.rr, s.exit.maxBars], [6, 0.5, 500]);
  assert.equal(s.market, 'crypto');
});

test('back-test on real BTC 1h: next-open entries, stop-first, costs, no look-ahead', () => {
  const s = cleanSpec(SPEC); const r = backtest(s, BTC);
  assert.ok(r.trades.length >= 10, `trades ${r.trades.length}`);
  for (const t of r.trades) {
    const i = BTC.findIndex((k) => k.time === t.t); assert.ok(i > 0); assert.equal(t.entry, BTC[i].open);   // entry = open of the candle AFTER the signal
    assert.ok(t.exitI > t.i); assert.ok(['stop', 'target', 'time'].includes(t.why));
    if (t.why === 'target') assert.ok(t.r < s.exit.rr && t.r > s.exit.rr - 0.5);   // costs are subtracted
    if (t.why === 'stop') assert.ok(t.r <= -1);
  }
  // no look-ahead: results on the first 800 candles do not change when later candles are appended
  const a = backtest(s, BTC.slice(0, 800)).trades.filter((t) => t.exitI < 760); const b = backtest(s, BTC).trades.filter((t) => t.exitI < 760);
  assert.deepEqual(a.map((t) => [t.t, t.r]), b.map((t) => [t.t, t.r]));
  const sp = splitTest(s, BTC); assert.equal(sp.is.n + sp.oos.n <= sp.all.n + 1, true);
  assert.ok(Number.isFinite(sp.oos.expR) && Number.isFinite(sp.all.maxDdR));
});

test('Strategy DNA is deterministic, rule-order independent, and similarity works', () => {
  const s = cleanSpec(SPEC); const d1 = strategyDna(s); const d2 = strategyDna(cleanSpec({ ...SPEC, entry: [...SPEC.entry].reverse() }));
  assert.match(d1.id, /^DNA-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}$/); assert.equal(d1.id, d2.id);
  assert.equal(d1.vector.length, DNA_AXES.length); assert.ok(d1.vector.every((v) => v >= 0 && v <= 1));
  const other = strategyDna(cleanSpec({ ...SPEC, entry: [{ type: 'breakout', len: 20, dir: 'up' }], exit: { stopAtr: 3, rr: 4, maxBars: 30 } }));
  assert.notEqual(other.id, d1.id); assert.equal(dnaSimilarity(d1.vector, d1.vector), 1);
  assert.ok(dnaSimilarity(d1.vector, other.vector) < 0.95);
  assert.equal(strategyDna(cleanSpec({ ...SPEC, entry: [{ type: 'breakout', len: 20, dir: 'up' }] })).family, 'breakout');
});

test('arena score needs ≥ 10 trades and rewards expectancy', () => {
  assert.equal(arenaScore({ n: 4, expR: 1, pf: 3, maxDdR: 1, totalR: 4 }).ranked, false);
  const good = arenaScore({ n: 30, expR: 0.4, pf: 1.8, maxDdR: 3, totalR: 12 }); const bad = arenaScore({ n: 30, expR: -0.2, pf: 0.7, maxDdR: 9, totalR: -6 });
  assert.ok(good.ranked && bad.ranked && good.score > bad.score);
  assert.equal(arenaScore({ n: 6, expR: 0.2, pf: 1.4, maxDdR: 1, totalR: 1.2 }, { n: 5, expR: 0.1, pf: 1.2, maxDdR: 1, totalR: 0.5 }).n, 11);
});

test('AI council on real candles: 8 agents, a synthesis that keeps disagreements, honest scenarios', () => {
  for (const [c, sym, tf, asset] of [[BTC, 'BTCUSDT', '1h', 'crypto'], [XAU, 'XAUUSD', '4h', 'metal']]) {
    const r = runCouncil({ candles: c, symbol: sym, tf, asset, events: [], now: c.at(-1).time * 1000 + 3600e3 });
    assert.equal(r.agents.length, 8); assert.deepEqual(r.agents.map((a) => a.id).sort(), ['devil', 'execution', 'liquidity', 'news', 'pattern', 'risk', 'sentiment', 'trend']);
    assert.ok(['bullish', 'bearish', 'no_trade'].includes(r.synthesis.view));
    assert.ok(r.synthesis.agree.every((a) => !r.synthesis.disagree.includes(a)));
    assert.ok(!r.synthesis.agree.includes('devil'));
    for (const a of r.agents) for (const e of a.evidence) { assert.ok(e.ar && e.en); assert.ok(['up', 'down', 'risk', 'info'].includes(e.for)); }
    assert.equal(r.scenarios.length, 5);
    if (r.analogs.n < 20) assert.ok(r.scenarios.every((s) => s.p == null)); else assert.ok(r.scenarios.filter((s) => s.id !== 'liquidity').every((s) => s.p >= 0 && s.p <= 1));
    assert.ok(r.xray.zones.every((z) => z.source === 'estimated'));   // no order book given → nothing claims to be real depth
  }
  assert.equal(runCouncil({ candles: BTC.slice(0, 50), symbol: 'BTCUSDT', tf: '1h' }).error, 'few_candles');
});

test('a high-impact event close by makes the council say NO TRADE', () => {
  const now = BTC.at(-1).time * 1000 + 3600e3;
  const r = runCouncil({ candles: BTC, symbol: 'BTCUSDT', tf: '1h', asset: 'crypto', events: [{ title: 'Non-Farm Employment Change', country: 'USD', impact: 'High', time: now + 20 * 60e3 }], now });
  assert.equal(r.synthesis.view, 'no_trade'); assert.equal(r.synthesis.why, 'news');
});

test('X-Ray keeps real order-book walls apart from estimated zones; analogs need ≥ 20 cases', () => {
  const px = BTC.at(-1).close;
  const depth = { bids: [[px * 0.995, 40], [px * 0.99, 2], [px * 0.98, 1]], asks: [[px * 1.004, 35], [px * 1.01, 1]] };
  const x = xray(BTC, { depth }); const walls = x.zones.filter((z) => z.source === 'order_book');
  assert.ok(walls.length >= 2 && walls.some((z) => z.kind === 'wall_bid') && walls.some((z) => z.kind === 'wall_ask'));
  assert.ok(walls.every((z) => z.notional > 0));
  assert.ok(x.zones.filter((z) => z.source === 'estimated').every((z) => !String(z.kind).startsWith('wall')));
  const an = analogs(BTC.slice(0, 160)); if (an.n < 20) assert.equal(an.up, null);
});

test('mentors: six personas, each prompt carries the safety rules, unknown id gives nothing', () => {
  assert.equal(MENTORS.length, 6); assert.equal(new Set(MENTORS.map((m) => m.id)).size, 6);
  for (const m of MENTORS) { assert.ok(m.name.ar && m.name.en && m.method.ar && m.spec.en); const s = mentorSystem(m.id); assert.ok(s.includes(MENTOR_RULES)); }
  assert.match(MENTOR_RULES, /never promise/i);
  assert.equal(mentorSystem('../../etc'), null); assert.equal(mentorById('x'), null);
});
