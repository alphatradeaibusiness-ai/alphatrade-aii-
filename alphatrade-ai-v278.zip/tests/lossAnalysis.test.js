import test from 'node:test';
import assert from 'node:assert/strict';
import { regimeSeries, flagsAt, FLAGS } from '../src/services/regime.js';
import { tagTrades, flagStats, drawdown, learnGate, walkForward } from '../src/services/lossAnalysis.js';

// deterministic pseudo-random candles
function candles(n, seed = 7, vol = 1) {
  let s = seed; const rnd = () => ((s = (s * 1664525 + 1013904223) % 4294967296) / 4294967296);
  const out = []; let p = 100;
  for (let i = 0; i < n; i++) { const d = (rnd() - 0.5) * vol; const o = p; p += d; out.push({ time: 1_700_000_000 + i * 300, open: o, high: Math.max(o, p) + rnd() * 0.2 * vol, low: Math.min(o, p) - rnd() * 0.2 * vol, close: p, volume: 100 + rnd() * 50 }); }
  return out;
}

test('regime flags use only past candles: appending candles never changes an earlier reading', () => {
  const c = candles(900);
  const a = regimeSeries(c.slice(0, 700)); const b = regimeSeries(c);
  for (const i of [300, 500, 699]) {
    assert.equal(a.volRank[i], b.volRank[i]);
    assert.equal(a.liqRank[i], b.liqRank[i]);
    assert.deepEqual(flagsAt(a, i, 'long'), flagsAt(b, i, 'long'));
  }
  assert.ok(flagsAt(b, 800, 'long').every((f) => FLAGS.includes(f)));
});

test('a volatility spike is flagged as high volatility', () => {
  const c = candles(800);
  for (let i = 700; i < 720; i++) { c[i].high += 4; c[i].low -= 4; }
  const R = regimeSeries(c);
  assert.ok(flagsAt(R, 715, 'long').includes('highVol'));
});

const trade = (i, r, flags, t0 = 1_700_000_000) => ({ openTime: t0 + i * 300, closeTime: t0 + i * 300 + 600, direction: 'long', r, points: r, outcome: r > 0 ? 'tp3' : 'sl', hits: 0, flags });

test('drawdown: max drawdown, losing streak and worst day in R', () => {
  const d = drawdown([trade(0, 1), trade(1, -1), trade(2, -1), trade(3, -1), trade(4, 2)]);
  assert.equal(d.maxDrawdownR, 3);
  assert.equal(d.longestLosingStreak, 3);
  assert.equal(d.netR, 0);
});

test('a condition that really loses is learned; one that is as good as the rest is not', () => {
  const ts = [];
  for (let i = 0; i < 80; i++) ts.push(trade(i, i % 2 ? 1 : -1, i % 3 === 0 ? ['range'] : []));
  for (let i = 0; i < 40; i++) ts.push(trade(100 + i, -1, ['highVol']));   // always loses
  assert.deepEqual(learnGate(ts), ['highVol']);
});

test('walk-forward: pure noise does not produce an "improved" verdict', () => {
  let wrong = 0;
  for (let seed = 1; seed <= 30; seed++) {
    let s = seed * 7919; const rnd = () => ((s = (s * 1664525 + 1013904223) % 4294967296) / 4294967296);
    const ts = Array.from({ length: 200 }, (_, i) => trade(i, rnd() < 0.5 ? 1 : -1, FLAGS.filter(() => rnd() < 0.3)));
    if (walkForward(ts).improved) wrong++;
  }
  assert.ok(wrong <= 3, `false improvements: ${wrong}/30`);
});

test('tagTrades attaches the entry index and flags', () => {
  const c = candles(800);
  const R = regimeSeries(c);
  const tg = tagTrades([{ openTime: c[600].time, direction: 'short', r: 1, points: 1 }], c, R);
  assert.equal(tg[0].entryIndex, 600);
  assert.ok(Array.isArray(tg[0].flags));
  assert.equal(flagStats(tg).length, FLAGS.length);
});
