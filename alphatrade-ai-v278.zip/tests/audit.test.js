import test from 'node:test';
import assert from 'node:assert';
const mem = new Map();
globalThis.localStorage = { getItem: (k) => (mem.has(k) ? mem.get(k) : null), setItem: (k, v) => mem.set(k, String(v)), removeItem: (k) => mem.delete(k) };

test('audit: newest first, secrets never stored, capped', async () => {
  const { audit, auditLog } = await import('../src/services/audit.js');
  audit('settings.update', { account: '123', secret: 'hunter2hunter2', topic: 'abc', mode: 'auto' }, 1);
  audit('auth.signin', { email: 'a@b.c' }, 2);
  const l = auditLog();
  assert.equal(l[0].action, 'auth.signin');
  assert.equal(l[1].details.secret, '••••'); assert.equal(l[1].details.topic, '••••'); assert.equal(l[1].details.mode, 'auto');
  assert.ok(!JSON.stringify(l).includes('hunter2'));
  for (let i = 0; i < 600; i++) audit('x', {}, i);
  assert.equal(auditLog().length, 500);
});
