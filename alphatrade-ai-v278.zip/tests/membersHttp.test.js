import test from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import http from 'node:http';
import { spawn } from 'node:child_process';

test('server: sign-in alert reaches the bell, trial once, TradingView URL, sync, owner broadcast, contest', async () => {
  const PROJECT = 'alphatrade-test'; const KID = 'k-mem';
  const kp = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
  const b64u = (b) => Buffer.from(b).toString('base64').replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
  const tok = (uid, email, at) => { const n = Math.floor(Date.now() / 1000); const h = b64u(JSON.stringify({ alg: 'RS256', kid: KID, typ: 'JWT' }));
    const p = b64u(JSON.stringify({ iss: `https://securetoken.google.com/${PROJECT}`, aud: PROJECT, sub: uid, iat: n - 10, auth_time: at ?? n - 10, exp: n + 3600, email, email_verified: true, firebase: { sign_in_provider: 'password' } }));
    return `${h}.${p}.${b64u(crypto.sign('RSA-SHA256', Buffer.from(`${h}.${p}`), kp.privateKey))}`; };
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'mem-')); const certFile = path.join(dir, 'certs.json');
  fs.writeFileSync(certFile, JSON.stringify({ [KID]: kp.publicKey.export({ type: 'spki', format: 'pem' }) }));
  const port = 20000 + Math.floor(Math.random() * 20000); const O = `http://127.0.0.1:${port}`;
  const child = spawn(process.execPath, ['--no-warnings', 'server/index.js'], { env: { ...process.env, NODE_ENV: 'test', SERVER_PORT: String(port), SERVER_DATA_DIR: dir, AI_KEY_SECRET: 'a'.repeat(40), BANK_MASTER_KEY: '', ANTHROPIC_API_KEY: '', FIREBASE_PROJECT_ID: PROJECT, AI_TEST_CERTS_FILE: certFile, TELEGRAM_BOT_TOKEN: '' }, stdio: 'ignore' });
  const req = (p, { method = 'GET', body, t, origin = O, raw = false } = {}) => new Promise((resolve, reject) => {
    const d = body === undefined ? null : typeof body === 'string' ? body : JSON.stringify(body);
    const r = http.request({ host: '127.0.0.1', port, path: p, method, headers: { ...(method !== 'GET' && origin ? { origin } : {}), ...(d ? { 'content-type': raw ? 'text/plain' : 'application/json', 'content-length': Buffer.byteLength(d) } : {}), ...(t ? { authorization: `Bearer ${t}` } : {}) } }, (res) => { let s = ''; res.on('data', (c) => (s += c)); res.on('end', () => { let j = null; try { j = JSON.parse(s); } catch { /* */ } resolve({ status: res.statusCode, body: j }); }); });
    r.on('error', reject); if (d) r.write(d); r.end();
  });
  const n0 = Math.floor(Date.now() / 1000);
  const owner = tok('own', 'shheahmad417@gmail.com'); const sam1 = tok('sam', 'sam@x.co', n0 - 100); const sam2 = tok('sam', 'sam@x.co', n0 - 5);
  try {
    for (let i = 0; i < 80; i++) { try { await req('/api/health'); break; } catch { await new Promise((r) => setTimeout(r, 100)); } }
    assert.equal((await req('/api/me/notices')).status, 401);
    await req('/api/me/signin', { method: 'POST', t: owner, body: { device: 'Mac · Safari' } });
    assert.equal((await req('/api/me/signin', { method: 'POST', t: sam1, body: { device: 'iPhone · Safari', lang: 'ar' } })).body.fresh, true);
    assert.equal((await req('/api/me/signin', { method: 'POST', t: sam1, body: { device: 'iPhone · Safari' } })).body.duplicate, true);
    await req('/api/me/signin', { method: 'POST', t: sam2, body: { device: 'Windows · Edge' } });
    const n = (await req('/api/me/notices', { t: sam2 })).body; assert.equal(n.items[0].kind, 'signin'); assert.match(n.items[0].body, /Windows · Edge/); assert.equal(n.unread, 2);
    assert.equal((await req('/api/me/notices', { t: owner })).body.items.some((x) => x.kind === 'newmember'), true, 'owner told about the new member');
    assert.equal((await req('/api/me/signin', { method: 'POST', t: sam2, origin: null, body: {} })).status, 403, 'writes need our Origin');
    // trial
    assert.equal((await req('/api/me/trial', { method: 'POST', t: sam2, body: {} })).body.ok, true);
    assert.equal((await req('/api/me/trial', { method: 'POST', t: sam2, body: {} })).body.code, 'trial_used');
    assert.equal((await req('/api/billing/me', { t: sam2 })).body.plan, 'annual');
    // TradingView
    const c = (await req('/api/me/connect', { t: sam2 })).body; assert.match(c.tvPath, /^\/api\/tv\/[A-Za-z0-9_-]{20,40}$/); assert.equal(c.telegram.configured, false);
    assert.equal((await req(c.tvPath, { method: 'POST', origin: null, raw: true, body: 'BTC crossed 50k' })).status, 200);
    assert.equal((await req('/api/me/notices', { t: sam2 })).body.items[0].body, 'BTC crossed 50k');
    assert.equal((await req('/api/tv/aaaaaaaaaaaaaaaaaaaaaaaa', { method: 'POST', origin: null, raw: true, body: 'x' })).status, 404);
    // sync + prefs
    assert.equal((await req('/api/me/sync', { method: 'PUT', t: sam2, body: { data: { theme: 'light' }, ts: Date.now() } })).body.ok, true);
    assert.deepEqual((await req('/api/me/sync', { t: sam2 })).body.sync.data, { theme: 'light' });
    assert.equal((await req('/api/me/prefs', { method: 'PUT', t: sam2, body: { news: true, newsCcy: ['USD', 'bad'] } })).body.prefs.newsCcy.join(), 'USD');
    // broadcast (owner only)
    assert.equal((await req('/api/admin/broadcast', { method: 'POST', t: sam2, body: { title: 'x', body: 'y' } })).status, 403);
    assert.equal((await req('/api/admin/broadcast', { method: 'POST', t: owner, body: { title: 'Update', body: 'New charts' } })).body.ok, true);
    assert.equal((await req('/api/me/notices', { t: sam2 })).body.broadcast.title, 'Update');
    // contest
    assert.equal((await req('/api/contest/join', { method: 'POST', t: sam2, body: { nick: 'Sam' } })).body.ok, true);
    const lb = (await req('/api/contest', { t: sam2 })).body; assert.equal(lb.joined, true); assert.equal(lb.nick, 'Sam'); assert.equal(lb.ranked.length, 0);
    assert.equal((await req('/api/contest/award', { method: 'POST', t: sam2, body: { ref: 'sam' } })).status, 403);
    // export includes members data; data file is encrypted
    const ex = (await req('/api/user/export', { t: sam2 })).body; assert.equal(ex.members.contest.nick, 'Sam');
    assert.equal(fs.readFileSync(path.join(dir, 'growth.json'), 'utf8').includes('sam@x.co'), false);
  } finally { child.kill(); }
});
