import { test } from 'node:test';
import assert from 'node:assert/strict';
import { backtestLbr, runStrategy, rulesFrom, LBR_DEFAULTS } from '../src/services/backtest.js';
import { evaluateCombo } from '../src/services/signals.js';

// BTC-like rules: 1 point = 1 USDT, 1 pip = 10 points → TP 30 pips = 300, SL 60 pips = 600, range 15–80 pips = 150–800.
const R = (extra = {}) => ({ pointSize: 1, edhPipPts: 10, feePct: 0, ...extra });
const DAY = Date.UTC(2026, 9, 20) / 1000;          // the test day (00:00 UTC)
const bar = (time, o, h, l, c) => ({ time, open: o, high: h, low: l, close: c, volume: 1 });

/** 10 days of a steady trend (narrow 07:00 ranges, so no other day trades), then the test day from 00:00 to 07:00, then `day` bars from 07:00. */
function series(day, { slope = 2 } = {}) {
  const out = []; let p = 100000; let t = DAY - 10 * 86400;
  while (t < DAY + 7 * 3600) { const o = p; p += slope; out.push(bar(t, o, Math.max(o, p) + 5, Math.min(o, p) - 5, p)); t += 300; }
  const p0 = p;
  day(p0).forEach(([o, h, l, c], k) => out.push(bar(DAY + 7 * 3600 + k * 300, p0 + o, p0 + h, p0 + l, p0 + c)));
  return { candles: out, p0 };
}
const RANGE = Array(6).fill([0, 150, -150, 0]);        // 07:00–07:30: 300 wide = 30 pips
const BREAK_UP = [0, 210, 0, 200];                      // 07:30 closes above the high (p0 + 150)
const FLAT = (n, lvl = 190) => Array(n).fill([lvl, lvl + 10, lvl - 10, lvl]);

test('LBR: breakout, retest of the edge, target 1 → one winning trade at the edge', () => {
  const { candles, p0 } = series(() => [...RANGE, BREAK_UP, [200, 220, 160, 190], [190, 200, 140, 180], [180, 460, 170, 440], ...FLAT(20, 440)]);
  const r = backtestLbr(candles, R());
  assert.equal(r.trades.length, 1);
  const t = r.trades[0];
  assert.equal(t.strategy, 'lbr'); assert.equal(t.direction, 'long'); assert.equal(t.outcome, 'tp1');
  assert.equal(t.entry, p0 + 150); assert.equal(t.initialStop, p0 + 150 - 600); assert.equal(t.targets[0], p0 + 150 + 300);
  assert.equal(t.points, 300); assert.equal(t.r, 0.5);
  assert.equal(t.openTime, DAY + 7 * 3600 + 8 * 300);   // filled on the 07:40 candle
  // fees are charged on every trade (0.04% of the entry, in points)
  const f = backtestLbr(candles, R({ feePct: 0.04 })).trades[0];
  assert.ok(Math.abs(f.points - (300 - 0.0004 * (p0 + 150))) < 1e-6);
});

test('LBR: stop, worst case on the filling candle, no retest, wrong trend, width, timeframe', () => {
  const stop = series(() => [...RANGE, BREAK_UP, [200, 220, 160, 190], [190, 200, 140, 180], [180, 190, -460, -400], ...FLAT(20, -400)]);
  assert.equal(backtestLbr(stop.candles, R()).trades[0].outcome, 'sl');
  assert.equal(backtestLbr(stop.candles, R()).trades[0].points, -600);
  // the candle that fills the order also reaches the stop: counted as a loss (we cannot see inside a candle)
  const both = series(() => [...RANGE, BREAK_UP, [200, 220, 160, 190], [190, 480, -460, 0], ...FLAT(20, 0)]);
  assert.equal(backtestLbr(both.candles, R()).trades[0].outcome, 'sl');
  // price never comes back to the edge within an hour → no trade
  const away = series(() => [...RANGE, BREAK_UP, ...FLAT(30, 300)]);
  const ra = backtestLbr(away.candles, R());
  assert.equal(ra.trades.length, 0); assert.equal(ra.rejects.noRetest, 1);
  // a long breakout against a falling 1-hour trend → no trade that day
  const down = series(() => [...RANGE, BREAK_UP, [200, 220, 160, 190], [190, 200, 140, 180], [180, 460, 170, 440], ...FLAT(20, 440)], { slope: -2 });
  const rd = backtestLbr(down.candles, R());
  assert.equal(rd.trades.length, 0); assert.equal(rd.rejects.trend, 1);
  // a range narrower than 15 pips (here 10) is skipped
  const narrow = series(() => [...Array(6).fill([0, 50, -50, 0]), [0, 110, 0, 100], [100, 120, 40, 60], [60, 400, 50, 380], ...FLAT(20, 380)]);
  assert.equal(backtestLbr(narrow.candles, R()).trades.length, 0);
  // the rules are defined on 5-minute candles only
  const m15 = stop.candles.filter((c) => c.time % 900 === 0);
  assert.deepEqual(backtestLbr(m15, R()).rejects, { tf: 1 });
});

test('LBR: a breakout on the newest closed candle is a working limit order (pending) until the retest', () => {
  const { candles, p0 } = series(() => [...RANGE, BREAK_UP, [200, 220, 180, 200]]);   // last candle (07:35) is still forming
  const r = runStrategy('lbr', candles, R({ openOnLast: false }));
  assert.equal(r.open, null);
  assert.equal(r.pending.direction, 'long'); assert.equal(r.pending.entry, p0 + 150); assert.equal(r.pending.stop, p0 + 150 - 600);
  assert.deepEqual(r.pending.targets, [p0 + 450, p0 + 450, p0 + 450]);
  assert.equal(r.pending.createdTime, DAY + 7 * 3600 + 6 * 300);
  assert.equal(r.pending.expiresTime, DAY + 7 * 3600 + 7 * 300 + 3600);
});

test('LBR defaults: researched settings, BTC only, its own 65% bar', () => {
  assert.deepEqual({ ...LBR_DEFAULTS }, { startH: 7, rangeMin: 30, minW: 15, maxW: 80, windowH: 2, retestMin: 60, tp1: 30, sl: 60, maxMin: 480, symbols: ['BTCUSDT'], minAccuracy: 65 });
  const rules = rulesFrom({ plan: {}, lbr: { tp1: 35 } }, { type: 'crypto', symbol: 'BTCUSDT' });
  assert.equal(rules.lbr.tp1, 35); assert.equal(rules.lbr.sl, 60); assert.equal(rules.edhPipPts, 10);
  // 63% wins over 60 profitable trades: enough for the general 62% bar, not for LBR's 65%
  const trades = Array.from({ length: 100 }, (_, i) => { const w = (i * 63) % 100 < 63; return { closeTime: i, points: w ? 30 : -40, r: w ? 0.5 : -0.67, hits: w ? 1 : 0 }; });
  assert.equal(evaluateCombo(trades).qualified, true);
  assert.equal(evaluateCombo(trades, 65).qualified, false);
});

test('channel stats: a limit order that never filled is not a loss; retired strategies are not channel strategies', async () => {
  const c = await import('../src/services/channel.js');
  assert.deepEqual(c.CHANNEL_STRATEGIES, ['edh', 'lbr']);
  assert.deepEqual(c.RETIRED_STRATEGIES, ['smc', 'classic', 'zone']);
  const now = new Date(2026, 9, 15, 12).getTime(); const at = (d) => new Date(2026, 9, d, 12).getTime();
  const row = (id, status, hits, pips) => ({ id, strategy: 'lbr', symbol: 'BTCUSDT', tf: '5m', createdAt: at(2), closedAt: at(2) + 1, status, hits, pips });
  const h = [row('a', 'tp3', 3, 30), row('b', 'sl', 0, -60), row('c', 'expired', 0, 0), row('d', 'cancelled', 0, 0), row('e', 'pending', 0, 0)];
  assert.deepEqual(c.lastDaysSummary(h, now).lbr, { signals: 3, closed: 2, wins: 1, losses: 1, pips: -30 });
  assert.equal(c.monthStrategyStats(h, now).BTCUSDT.lbr.trades, 2);
});
