import test from 'node:test';
import assert from 'node:assert/strict';
import { prepare, evaluate, scoreSetup, ZONE_WEIGHTS } from '../src/services/zoneStrategy.js';

// A textbook demand-zone buy: a drop, a climb, a quiet base, an impulse out of it, a rally to 112.5 and
// a pullback that dips into the base and closes back out with a long lower wick (inside the 0.5–0.62 pocket).
function build() {
  const c = [];
  const T0 = 1_700_000_000; const step = 300;
  const push = (o, h, l, cl, v = 100) => c.push({ time: T0 + c.length * step, open: o, high: h, low: l, close: cl, volume: v });
  let p = 100;
  for (let i = 0; i < 60; i++) { const d = i % 2 ? 0.3 : -0.3; push(p, p + 0.6, p - 0.6, p + d); p += d; }
  for (let i = 0; i < 12; i++) { push(p, p + 0.2, p - 1.3, p - 1); p -= 1; }            // drop to ~88
  for (let i = 0; i < 10; i++) { push(p, p + 1.3, p - 0.2, p + 1); p += 1; }            // climb to ~98
  for (let i = 0; i < 3; i++) push(98.2, 98.5, 98.1, 98.3);                              // quiet base (zone 98.1–98.5)
  push(98.3, 100.8, 98.2, 100.6);                                                         // impulse out of the base
  p = 100.6;
  for (let i = 0; i < 12; i++) { push(p, p + 1.2, p - 0.1, p + 1); p += 1; }            // rally to ~112.6
  for (let i = 0; i < 11; i++) { push(p, p + 0.1, p - 1.2, p - 1.1); p -= 1.1; }        // pullback, stays above the zone
  push(99.8, 99.9, 98.2, 99.4, 300);                                                      // reaction candle at the zone
  return c;
}
const relaxed = { htf: false, requireVp: false, minVolRatio: 0, minScore: 0 };
const last = (c) => c.length - 1;

test('a textbook demand-zone reaction becomes a market-entry buy with Fibonacci targets', () => {
  const c = build();
  const S = prepare(c, relaxed);
  const { setup: s } = evaluate(S, last(c));
  assert.ok(s, 'setup found');
  assert.equal(s.direction, 'long');
  assert.equal(s.entry, c.at(-1).close, 'market entry at the close of the reaction candle');
  assert.ok(s.stop < s.zone.bottom, 'stop beyond the zone');
  assert.ok(s.ratio >= 0.5 && s.ratio <= 0.65, `in the golden pocket (${s.ratio})`);
  assert.ok(s.targets[0] > s.entry && s.targets[1] > s.targets[0] && s.targets[2] > s.targets[1]);
  assert.ok(s.score > 0 && s.score <= 100);
});

test('no signal on candles that are outside every zone', () => {
  const c = build();
  const S = prepare(c, relaxed);
  for (const i of [100, 110, 120, c.length - 6]) assert.equal(evaluate(S, i).setup, null, `candle ${i}`);
});

test('the higher-timeframe gate blocks it by default (not enough aligned history here)', () => {
  const c = build();
  const S = prepare(c, { ...relaxed, htf: true });
  const r = evaluate(S, last(c));
  assert.equal(r.setup, null);
  assert.equal(r.rejected.reason, 'htf');
});

test('volume gate: a reaction on weak volume is rejected', () => {
  const c = build();
  const S = prepare(c, { ...relaxed, minVolRatio: 5 });
  assert.equal(evaluate(S, last(c)).rejected.reason, 'volume');
});

test('score gate: below the minimum nothing is published', () => {
  const c = build();
  const S = prepare(c, { ...relaxed, minScore: 101 });
  const r = evaluate(S, last(c));
  assert.equal(r.setup, null);
  assert.equal(r.rejected.reason, 'score');
});

test('RSI gate: no buying when RSI is overbought', () => {
  const c = build();
  const S = prepare(c, relaxed);
  S.rsi[last(c)] = 75;
  assert.equal(evaluate(S, last(c)).rejected.reason, 'rsi');
});

test('no look-ahead: the decision on a candle is the same with or without later candles', () => {
  const c = build();
  const extra = c.concat(Array.from({ length: 30 }, (_, k) => { const o = 99.4 + k; return { time: c.at(-1).time + 300 * (k + 1), open: o, high: o + 2, low: o - 3, close: o + 1, volume: 100 }; }));
  const a = evaluate(prepare(c, relaxed), last(c)).setup;
  const b = evaluate(prepare(extra, relaxed), last(c)).setup;
  assert.ok(a && b);
  assert.equal(a.entry, b.entry); assert.equal(a.stop, b.stop); assert.equal(a.score, b.score);
});

test('scoring weights add up to 100 and the parts never exceed them', () => {
  assert.equal(Object.values(ZONE_WEIGHTS).reduce((x, y) => x + y, 0), 100);
  const c = build();
  const S = prepare(c, relaxed);
  const s = evaluate(S, last(c)).setup;
  const sc = scoreSetup(S, s);
  for (const k of Object.keys(ZONE_WEIGHTS)) assert.ok(sc.parts[k] <= ZONE_WEIGHTS[k] + 1e-9, k);
});
