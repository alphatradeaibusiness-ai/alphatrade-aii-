// The user's SMC / ICT trade history on the server: strict validation, one encrypted file per user, isolation over HTTP.
import test from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import http from 'node:http';
import { spawn } from 'node:child_process';
import { cleanTrade, createUserTrades, MAX_TRADES } from '../server/userTrades.js';

const T = 1_761_000_000;
const trade = (x = {}) => ({
  id: 'tr_abc123', symbol: 'BTCUSDT', tf: '1h', style: 'swing', direction: 'long', execution: 'limit', account: 'margin', asset: 'crypto', status: 'pending',
  entry: 100, stop: 98, risk: 2, targets: [104, 106], rr: [2, 3], createdAt: T, savedAt: T * 1000, updatedAt: T * 1000, validUntil: T + 3600, filledAt: null, closedAt: null,
  hits: 0, resultR: null, capital: 1000, riskPct: 1, riskAmount: 10, units: 5, mode: 'live', note: 'x', ...x,
});

test('cleanTrade accepts a valid record and rejects every malformed field', () => {
  assert.ok(cleanTrade(trade()).value);
  for (const bad of [{ id: 'a' }, { symbol: 'btc/usdt' }, { tf: '2h' }, { style: 'x' }, { direction: 'up' }, { execution: 'stop' }, { account: 'vip' }, { status: 'won' },
    { entry: -1 }, { stop: Infinity }, { targets: [] }, { targets: [1, 2, 3, 4], rr: [1, 1, 1, 1] }, { rr: [2] }, { stop: 101 }, { targets: [99, 106] }, { createdAt: 5 }, { hits: 7 }, { resultR: 'x' }, { capital: -3 }]) {
    assert.ok(cleanTrade(trade(bad)).error, JSON.stringify(bad));
  }
  assert.ok(cleanTrade(trade({ direction: 'short', stop: 102, targets: [96, 94] })).value);
  assert.equal(cleanTrade(trade({ note: 'a\u0000b'.repeat(200), extra: '<script>' })).value.note.length, 200);
  assert.equal(cleanTrade(trade({ extra: 1 })).value.extra, undefined, 'unknown fields are dropped');
  assert.deepEqual(cleanTrade(trade({ tags: ['sweep', 'kz_london'], costR: 0.12 })).value.tags, ['sweep', 'kz_london']);
  assert.ok(cleanTrade(trade({ tags: ['<b>'] })).error); assert.ok(cleanTrade(trade({ tags: 'x' })).error); assert.ok(cleanTrade(trade({ costR: -1 })).error);
});

test('store: encrypted at rest, per user, newest update wins, capped, needs a secret', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ut-'));
  assert.equal(createUserTrades({ dir, secret: 'short' }).canSave(), false);
  const s = createUserTrades({ dir, secret: 'k'.repeat(40) });
  assert.ok(s.upsert('alice', trade()).item);
  const raw = fs.readdirSync(path.join(dir, 'user-trades')).map((f) => fs.readFileSync(path.join(dir, 'user-trades', f), 'utf8')).join('');
  assert.ok(!raw.includes('BTCUSDT') && !raw.includes('alice'), 'nothing readable in the file');
  assert.equal(s.list('bob').length, 0, 'another user sees nothing');
  assert.ok(s.upsert('alice', trade({ status: 'active', updatedAt: T * 1000 + 5 })).item);
  assert.equal(s.upsert('alice', trade({ status: 'stopped', updatedAt: T * 1000 + 1 })).stale, true, 'an older copy does not overwrite');
  assert.equal(s.list('alice')[0].status, 'active');
  assert.equal(createUserTrades({ dir, secret: 'z'.repeat(40) }).list('alice').length, 0, 'another secret cannot read it');
  assert.equal(s.remove('alice', 'tr_abc123'), true); assert.equal(s.remove('alice', 'tr_abc123'), false);
  for (let i = 0; i < MAX_TRADES + 5; i++) s.upsert('carol', trade({ id: `tr_${String(i).padStart(6, '0')}`, savedAt: T * 1000 + i }));
  assert.equal(s.list('carol').length, MAX_TRADES);
});

// ── over HTTP ──
const PROJECT = 'alphatrade-test'; const KID = 'k-ut';
const kp = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
const b64u = (b) => Buffer.from(b).toString('base64').replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
function tok(uid, email) {
  const n = Math.floor(Date.now() / 1000); const h = b64u(JSON.stringify({ alg: 'RS256', kid: KID, typ: 'JWT' }));
  const p = b64u(JSON.stringify({ iss: `https://securetoken.google.com/${PROJECT}`, aud: PROJECT, sub: uid, iat: n - 10, auth_time: n - 10, exp: n + 3600, email, email_verified: true, firebase: { sign_in_provider: 'password' } }));
  return `${h}.${p}.${b64u(crypto.sign('RSA-SHA256', Buffer.from(`${h}.${p}`), kp.privateKey))}`;
}
const call = (port, p, { method = 'GET', t, body } = {}) => new Promise((resolve, reject) => {
  const data = body === undefined ? null : JSON.stringify(body);
  const r = http.request({ host: '127.0.0.1', port, path: p, method, headers: { origin: `http://127.0.0.1:${port}`, ...(data ? { 'content-type': 'application/json', 'content-length': Buffer.byteLength(data) } : {}), ...(t ? { authorization: `Bearer ${t}` } : {}) } },
    (res) => { let buf = ''; res.on('data', (c) => (buf += c)); res.on('end', () => { let j = null; try { j = JSON.parse(buf); } catch { /* */ } resolve({ status: res.statusCode, body: j }); }); });
  r.on('error', reject); if (data) r.write(data); r.end();
});

test('HTTP: sign-in required, each user only sees their own trades, bad input refused', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ut-http-')); const certFile = path.join(dir, 'certs.json');
  fs.writeFileSync(certFile, JSON.stringify({ [KID]: kp.publicKey.export({ type: 'spki', format: 'pem' }) }));
  const port = 20000 + Math.floor(Math.random() * 20000);
  const child = spawn(process.execPath, ['--no-warnings', 'server/index.js'], { env: { ...process.env, NODE_ENV: 'test', SERVER_PORT: String(port), AI_TEST_CERTS_FILE: certFile, FIREBASE_PROJECT_ID: PROJECT, SERVER_DATA_DIR: dir, AI_KEY_SECRET: 'a'.repeat(40), ANTHROPIC_API_KEY: '' }, stdio: 'ignore' });
  const c = (p, o) => call(port, p, o); const ann = tok('ann', 'ann@example.com'); const ben = tok('ben', 'ben@example.com');
  try {
    for (let i = 0; i < 80; i++) { try { await c('/api/ai/health'); break; } catch { await new Promise((r) => setTimeout(r, 100)); } }
    assert.equal((await c('/api/user/trades')).status, 401);
    assert.equal((await c('/api/user/trades', { method: 'PUT', t: ann, body: { item: trade() } })).status, 200);
    assert.equal((await c('/api/user/trades', { method: 'PUT', t: ann, body: { item: trade({ stop: 150 }) } })).body.code, 'bad_levels');
    assert.equal((await c('/api/user/trades', { t: ann })).body.items.length, 1);
    assert.equal((await c('/api/user/trades', { t: ben })).body.items.length, 0);
    assert.equal((await c('/api/user/trades/tr_abc123', { method: 'DELETE', t: ben })).status, 404, 'cannot delete another user\'s trade');
    assert.equal((await c('/api/user/trades/tr_abc123', { method: 'DELETE', t: ann })).status, 200);
    assert.equal((await c('/api/ai/smc', { method: 'POST', t: ann, body: { context: { verdict: 'trade' } } })).body.code, 'not_configured', 'AI route exists and needs the AI key');
  } finally { child.kill(); }
});
