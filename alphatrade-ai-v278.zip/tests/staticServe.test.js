// The built site is served with explicit caching: hashed files immutable, the page revalidated, compression + ETag, no HTML-as-JS fallback.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import http from 'node:http';
import zlib from 'node:zlib';
import { spawn } from 'node:child_process';

const get = (port, p, headers = {}) => new Promise((resolve, reject) => {
  http.get({ host: '127.0.0.1', port, path: p, headers }, (res) => { const ch = []; res.on('data', (c) => ch.push(c)); res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, body: Buffer.concat(ch) })); }).on('error', reject);
});

test('static serving: cache policy, ETag/304, brotli/gzip, missing /assets file is 404', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'dist-')); fs.mkdirSync(path.join(dir, 'assets'));
  const js = `console.log(${JSON.stringify('x'.repeat(5000))});`;
  fs.writeFileSync(path.join(dir, 'index.html'), '<!doctype html><html><body>' + 'a'.repeat(2000) + '</body></html>');
  fs.writeFileSync(path.join(dir, 'assets', 'app-abc123.js'), js);
  fs.writeFileSync(path.join(dir, 'icon.png'), Buffer.alloc(3000, 7));
  const port = 20000 + Math.floor(Math.random() * 20000);
  const child = spawn(process.execPath, ['--no-warnings', 'server/index.js', '--serve-dist'], { env: { ...process.env, NODE_ENV: 'test', SERVER_PORT: String(port), STATIC_DIR: dir, SERVER_DATA_DIR: dir }, stdio: 'ignore' });
  try {
    for (let i = 0; i < 80; i++) { try { await get(port, '/'); break; } catch { await new Promise((r) => setTimeout(r, 100)); } }
    const a = await get(port, '/assets/app-abc123.js', { 'accept-encoding': 'br, gzip' });
    assert.equal(a.headers['cache-control'], 'public, max-age=31536000, immutable'); assert.equal(a.headers['content-encoding'], 'br');
    assert.equal(zlib.brotliDecompressSync(a.body).toString(), js); assert.ok(a.body.length < js.length / 5);
    const g = await get(port, '/assets/app-abc123.js', { 'accept-encoding': 'gzip' }); assert.equal(g.headers['content-encoding'], 'gzip'); assert.equal(zlib.gunzipSync(g.body).toString(), js);
    const plain = await get(port, '/assets/app-abc123.js'); assert.equal(plain.headers['content-encoding'], undefined); assert.equal(plain.body.toString(), js);
    const again = await get(port, '/assets/app-abc123.js', { 'if-none-match': a.headers.etag, 'accept-encoding': 'br' }); assert.equal(again.status, 304);
    const page = await get(port, '/some/route'); assert.equal(page.status, 200); assert.equal(page.headers['cache-control'], 'no-cache'); assert.match(page.headers['content-type'], /text\/html/);
    assert.equal(page.headers['x-content-type-options'], 'nosniff'); assert.ok(page.headers['content-security-policy']);
    assert.equal((await get(port, '/assets/missing-zzz.js')).status, 404);
    const png = await get(port, '/icon.png', { 'accept-encoding': 'br' }); assert.equal(png.headers['content-encoding'], undefined); assert.equal(png.headers['cache-control'], 'public, max-age=86400');
    assert.equal((await get(port, '/..%2f..%2fetc/passwd')).status, 403);
  } finally { child.kill(); }
});
