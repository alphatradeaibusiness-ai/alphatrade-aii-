// Market-data key (Twelve Data): owner-only, really tested before it is saved, stored encrypted, used by the market proxy,
// replaced / deleted without leaving the old key active. Runs the real server against a Twelve-Data-shaped mock.
import test from 'node:test';
import assert from 'node:assert';
import crypto from 'node:crypto';
import http from 'node:http';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { classifyMarket, testMarketKey } from '../server/marketProxy.js';

const PROJECT = 'alphatrade-test'; const KID = 'k-market';
const { privateKey, publicKey } = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
const b64u = (b) => Buffer.from(b).toString('base64').replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
function token({ uid = 'owner-uid', email = 'shheahmad417@gmail.com', verified = true } = {}) {
  const now = Math.floor(Date.now() / 1000);
  const h = b64u(JSON.stringify({ alg: 'RS256', kid: KID, typ: 'JWT' }));
  const p = b64u(JSON.stringify({ iss: `https://securetoken.google.com/${PROJECT}`, aud: PROJECT, sub: uid, iat: now - 10, auth_time: now - 10, exp: now + 3600, email, email_verified: verified, firebase: { sign_in_provider: 'google.com' } }));
  return `${h}.${p}.${b64u(crypto.sign('RSA-SHA256', Buffer.from(`${h}.${p}`), privateKey))}`;
}
const certs = { [KID]: publicKey.export({ type: 'spki', format: 'pem' }) };
const listen = (srv) => new Promise((r) => srv.listen(0, '127.0.0.1', () => r(srv.address().port)));
function call(port, p, { method = 'GET', tok, body } = {}) {
  return new Promise((resolve, reject) => {
    const data = body === undefined ? null : JSON.stringify(body);
    const r = http.request({ host: '127.0.0.1', port, path: p, method, headers: { origin: `http://127.0.0.1:${port}`, ...(data ? { 'content-type': 'application/json', 'content-length': Buffer.byteLength(data) } : {}), ...(tok ? { authorization: `Bearer ${tok}` } : {}) } }, (res) => {
      let raw = ''; res.on('data', (c) => (raw += c)); res.on('end', () => { let j = null; try { j = JSON.parse(raw); } catch { /* not json */ } resolve({ status: res.statusCode, body: j, raw }); });
    });
    r.on('error', reject); if (data) r.write(data); r.end();
  });
}
/** Twelve Data in its real error formats. Key substring decides: bad → 401, limit → 429, free → forex only, otherwise everything. */
function twelveMock(seen) {
  return http.createServer((q, s) => {
    const u = new URL(q.url, 'http://x'); const key = u.searchParams.get('apikey') || ''; const sym = u.searchParams.get('symbol');
    seen.push({ key, sym }); s.setHeader('content-type', 'application/json');
    const err = (code, message) => { s.statusCode = 200; s.end(JSON.stringify({ code, message, status: 'error' })); };   // Twelve Data answers errors with HTTP 200 and a code in the body
    if (key.includes('bad')) return err(401, '**apikey** parameter is incorrect or not specified.');
    if (key.includes('limit')) return err(429, 'You have run out of API credits for the current minute.');
    if (key.includes('free') && sym !== 'EUR/USD') return err(403, `${sym} is available starting with the Grow plan.`);
    s.end(JSON.stringify({ meta: { symbol: sym }, values: [{ datetime: '2026-10-08 10:00:00', open: '1', high: '2', low: '0.5', close: `1.5${key.slice(-1)}`, volume: '0' }], status: 'ok' }));
  });
}
async function startServer(env) {
  const port = 20000 + Math.floor(Math.random() * 20000);
  const child = spawn(process.execPath, ['server/index.js'], { env: { ...process.env, NODE_ENV: 'test', SERVER_PORT: String(port), ...env }, stdio: ['ignore', 'pipe', 'pipe'] });
  let log = ''; child.stdout.on('data', (c) => (log += c)); child.stderr.on('data', (c) => (log += c));
  for (let i = 0; i < 60; i++) { try { await call(port, '/api/market/status'); break; } catch { await new Promise((r) => setTimeout(r, 100)); } }
  return { port, child, log: () => log };
}

test('classifyMarket maps Twelve Data errors', () => {
  assert.equal(classifyMarket(200, { code: 401, message: '**apikey** parameter is incorrect or not specified.' }), 'invalid_key');
  assert.equal(classifyMarket(200, { code: 429, message: 'You have run out of API credits for the current minute.' }), 'rate_limit');
  assert.equal(classifyMarket(200, { code: 403, message: 'XAU/USD is available starting with the Grow plan.' }), 'no_permission');
  assert.equal(classifyMarket(200, { code: 400, message: '**symbol** not found' }), 'symbol_unavailable');
  assert.equal(classifyMarket(500, {}), 'unknown');
});

test('testMarketKey reports which market classes the plan unlocks, and stops on a rejected key', async () => {
  const seen = []; const mock = twelveMock(seen); const mp = await listen(mock);
  try {
    const base = `http://127.0.0.1:${mp}`;
    const full = await testMarketKey('td-full-key-12345', { base });
    assert.deepStrictEqual([full.ok, full.markets.forex.ok, full.markets.gold.ok, full.markets.indices.ok], [true, true, true, true]);
    const free = await testMarketKey('td-free-key-12345', { base });
    assert.equal(free.ok, true); assert.equal(free.markets.gold.code, 'no_permission'); assert.equal(free.markets.indices.code, 'no_permission');
    seen.length = 0;
    const bad = await testMarketKey('td-bad-key-12345', { base });
    assert.deepStrictEqual([bad.ok, bad.code], [false, 'invalid_key']); assert.equal(seen.length, 1);
    assert.equal((await testMarketKey('td-limit-key-12345', { base })).code, 'rate_limit');
    assert.equal((await testMarketKey('td-full-key-12345', { base: 'http://127.0.0.1:1' })).code, 'network');
  } finally { mock.close(); }
});

test('market key end to end: owner only, checked before saving, encrypted, used by the proxy, replaced, deleted', async () => {
  const seen = []; const mock = twelveMock(seen); const mp = await listen(mock);
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'mkey-')); const certFile = path.join(dir, 'certs.json'); fs.writeFileSync(certFile, JSON.stringify(certs));
  const { port, child, log } = await startServer({ TWELVEDATA_TEST_BASE: `http://127.0.0.1:${mp}`, AI_TEST_CERTS_FILE: certFile, FIREBASE_PROJECT_ID: PROJECT, AI_KEY_SECRET: 'm'.repeat(48), SERVER_DATA_DIR: dir, TWELVEDATA_API_KEY: '', ANTHROPIC_API_KEY: '', AI_IP_PER_MINUTE: '1000', AI_DAILY_PER_IP: '1000', AI_DAILY_LIMIT: '1000' });
  const owner = token(); const user = token({ uid: 'u1', email: 'someone@example.com' });
  const K1 = 'td-full-key-ONE-1111'; const K2 = 'td-full-key-TWO-2222';
  const all = []; const c = async (...a) => { const r = await call(port, ...a); all.push(r.raw); return r; };
  const series = (tok) => c('/api/market/twelve', { method: 'POST', tok, body: { endpoint: 'time_series', symbol: 'EUR/USD', interval: '1h', outputsize: 5 } });
  try {
    assert.equal((await c('/api/market/status')).body.state, 'none');
    assert.equal((await series()).status, 503);                                                      // no key → the proxy says so, no fake data
    assert.equal((await c('/api/market/config', { method: 'PUT', body: { apiKey: K1 } })).status, 401);
    assert.equal((await c('/api/market/config', { method: 'PUT', tok: user, body: { apiKey: K1 } })).status, 403);
    for (const [k, code] of [['td-bad-key-12345', 'invalid_key'], ['td-limit-key-12345', 'rate_limit']]) {   // a failing key is explained and NOT saved
      const r = await c('/api/market/config', { method: 'PUT', tok: owner, body: { apiKey: k } });
      assert.equal(r.body.ok, false); assert.equal(r.body.code, code); assert.equal(r.body.status.state, 'none');
    }
    assert.equal((await series()).status, 503);
    const ok = await c('/api/market/config', { method: 'PUT', tok: owner, body: { apiKey: K1 } });
    assert.equal(ok.body.ok, true); assert.equal(ok.body.status.state, 'connected'); assert.equal(ok.body.status.last4, '1111'); assert.equal(ok.body.status.markets.gold.ok, true);
    assert.ok(!fs.readFileSync(path.join(dir, 'market-config.json'), 'utf8').includes('ONE'));        // encrypted at rest
    assert.equal((fs.statSync(path.join(dir, 'market-config.json')).mode & 0o777), 0o600);
    const pub = (await c('/api/market/status', { tok: user })).body;
    assert.equal(pub.state, 'connected'); assert.equal(pub.last4, undefined);                          // no details for anyone but the owner
    seen.length = 0;
    const r1 = await series(); assert.equal(r1.status, 200); assert.equal(r1.body.values[0].close, '1.51');
    assert.equal(seen.at(-1).key, K1);                                                                 // the proxy used the saved key, server side
    // replacing the key applies at once (the proxy cache is cleared); a failing replacement keeps the working key
    assert.equal((await c('/api/market/config', { method: 'PUT', tok: owner, body: { apiKey: 'td-bad-key-99999' } })).body.ok, false);
    assert.equal((await c('/api/market/status', { tok: owner })).body.last4, '1111');
    assert.equal((await c('/api/market/config', { method: 'PUT', tok: owner, body: { apiKey: K2 } })).body.ok, true);
    const r2 = await series(); assert.equal(r2.body.values[0].close, '1.52'); assert.equal(seen.at(-1).key, K2);
    assert.equal((await c('/api/market/config/test', { method: 'POST', tok: owner, body: {} })).body.ok, true);
    assert.equal((await c('/api/market/config', { method: 'DELETE', tok: user })).status, 403);
    assert.equal((await c('/api/market/config', { method: 'DELETE', tok: owner })).body.status.state, 'none');
    assert.equal((await series()).status, 503);                                                        // deleted → real data stops, even from the cache
    assert.ok(!all.join('\n').includes('TWO-2222') && !all.join('\n').includes('ONE-1111'), 'a key leaked into a response');
    assert.ok(!log().includes('ONE-1111') && !log().includes('TWO-2222'), 'a key leaked into the log');
  } finally { child.kill(); mock.close(); fs.rmSync(dir, { recursive: true, force: true }); }
});

test('market requests do not use the AI daily budget', async () => {
  const seen = []; const mock = twelveMock(seen); const mp = await listen(mock);
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'mkey2-'));
  const { port, child } = await startServer({ TWELVEDATA_TEST_BASE: `http://127.0.0.1:${mp}`, TWELVEDATA_API_KEY: 'td-env-key-12345', AI_KEY_SECRET: '', SERVER_DATA_DIR: dir, AI_DAILY_PER_IP: '2', AI_IP_PER_MINUTE: '2', AI_DAILY_LIMIT: '2' });
  try {
    const codes = [];
    for (let i = 0; i < 8; i++) codes.push((await call(port, '/api/market/twelve', { method: 'POST', body: { endpoint: 'quote', symbol: `EUR/USD`, interval: '1h', outputsize: 1 } })).status);
    assert.deepStrictEqual([...new Set(codes)], [200]);
    assert.equal((await call(port, '/api/market/status')).body.state, 'unchecked');   // a key set in the server environment is reported as not yet checked
  } finally { child.kill(); mock.close(); fs.rmSync(dir, { recursive: true, force: true }); }
});
