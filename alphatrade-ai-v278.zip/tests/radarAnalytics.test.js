import test from 'node:test';
import assert from 'node:assert/strict';
import { efficiencyRatio, volatilityState, liquidityScan, bookStats, riskAdjust, testRule, scoreCall } from '../src/services/radarAnalytics.js';

const mk = (f, n = 300) => Array.from({ length: n }, (_, i) => { const c = f(i); return { time: i * 60, open: c, high: c * 1.001, low: c * 0.999, close: c, volume: 10 }; });

test('efficiency ratio: straight line = 1, zig-zag ≈ 0', () => {
  assert.ok(efficiencyRatio(mk((i) => 100 + i)) > 0.99);
  assert.ok(efficiencyRatio(mk((i) => 100 + (i % 2))) < 0.05);
});

test('volatility: quiet then explosive last candle = spike', () => {
  const c = mk((i) => 100 + Math.sin(i / 5) * 0.2);
  c[c.length - 1] = { ...c.at(-1), high: 104, low: 99, close: 103.5 };
  assert.equal(volatilityState(c).state, 'spike');
});

test('liquidity: equal highs become one stronger pool', () => {
  const c = mk((i) => 100 + 5 * Math.sin(i / 6) * (i < 280 ? 1 : 0.2), 300);
  const s = liquidityScan(c);
  assert.ok(s.bsl.length >= 1);
  assert.ok(s.bsl.some((p) => p.count >= 2));
});

test('order book imbalance and walls', () => {
  const b = bookStats({ bids: [['99.5', '10'], ['99.2', '100']], asks: [['100.5', '5']] }, 100, 1);
  assert.ok(b.imbalance > 0);
  assert.equal(b.bidWall.price, 99.2);
});

test('auto risk scales down for spikes and news, never above daily limit', () => {
  const a = riskAdjust({ baseRiskPct: 1, vol: { state: 'spike' }, newsMins: 20, lossStreak: 0, sameDirCorrelated: 0, score: 60 });
  assert.equal(a.riskPct, 0.25);
  const b = riskAdjust({ baseRiskPct: 1, vol: null, newsMins: null, lossStreak: 0, sameDirCorrelated: 0, score: 80, dailyUsedPct: 2.9, dailyLimitPct: 3 });
  assert.ok(Math.abs(b.riskPct - 0.1) < 1e-9);
});

test('multi-condition rule AND / OR', () => {
  const m = { 'BTC|1h': { price: 100, rsi: 25, trend: 'up', chgPct: -2, atrRatio: 1, squeeze: false, volRatio: 1, ema50: 99, event: null } };
  const rule = { symbol: 'BTC', tf: '1h', logic: 'and', conds: [{ type: 'rsi', op: 'lt', value: 30 }, { type: 'trend', op: 'up' }] };
  assert.equal(testRule(rule, m).ok, true);
  assert.equal(testRule({ ...rule, conds: [...rule.conds, { type: 'vol', op: 'gte', value: 1.5 }] }, m).ok, false);
  assert.equal(testRule({ ...rule, logic: 'or', conds: [...rule.conds, { type: 'vol', op: 'gte', value: 1.5 }] }, m).ok, true);
});

test('radar call scoring: target first = win, stop first = loss', () => {
  const c = mk((i) => 100 + i * 0.1, 50);
  assert.equal(scoreCall({ direction: 'long', price: 100, atr: 1, time: 0 }, c), 'win');
  assert.equal(scoreCall({ direction: 'short', price: 100, atr: 1, time: 0 }, c), 'loss');
});
