// v276: hands-free voice conversation loop (services/voice.js conversation) with a fake microphone and speaker.
import test from 'node:test';
import assert from 'node:assert/strict';

function fakeBrowser(script) {
  // script: array of what each listening round hears: a string (final words), 'silence', or an error code
  let round = 0; const spoken = [];
  class Rec {
    start() {
      const what = script[round++] ?? 'silence';
      setTimeout(() => {
        if (what === 'silence') { this.onend?.(); return; }
        if (/^[a-z-]+$/.test(what) && what.includes('-') || what === 'audio-capture') { this.onerror?.({ error: what }); this.onend?.(); return; }
        this.onresult?.({ resultIndex: 0, results: [Object.assign([{ transcript: what }], { isFinal: true })] });
        this.onend?.();
      }, 1);
    }
    stop() { this.onend?.(); }
  }
  globalThis.window = { SpeechRecognition: Rec, speechSynthesis: {} };
  globalThis.speechSynthesis = { cancel() {}, getVoices: () => [], speak(u) { spoken.push(u.text); setTimeout(() => u.onend?.(), 1); } };
  globalThis.SpeechSynthesisUtterance = class { constructor(t) { this.text = t; } };
  return { spoken };
}
const wait = (ms) => new Promise((r) => setTimeout(r, ms));
const load = () => import(`../src/services/voice.js?${Math.random()}`);

test('listen → think → speak → listen again, and stop() hangs up', async () => {
  const { spoken } = fakeBrowser(['hello', 'silence', 'what is gold doing']);
  const { conversation } = await load();
  const states = []; const asked = [];
  const c = conversation(() => 'en', { onAsk: async (q) => { asked.push(q); return `answer to ${q}`; }, onState: (s) => states.push(s) });
  await wait(450);   // a silent round waits 250 ms before listening again
  assert.deepEqual(asked, ['hello', 'what is gold doing']);
  assert.deepEqual(spoken, ['answer to hello', 'answer to what is gold doing']);
  assert.deepEqual(states.slice(0, 4), ['listen', 'think', 'speak', 'listen']);
  c.stop(); assert.equal(states.at(-1), 'off'); assert.equal(c.on, false);
});

test('a refused microphone ends the conversation with the reason', async () => {
  fakeBrowser(['not-allowed']);
  const { conversation } = await load();
  let why = 'none';
  conversation(() => 'ar', { onAsk: async () => 'x', onState: (s, d) => { if (s === 'off') why = d; } });
  await wait(20);
  assert.equal(why, 'not-allowed');
});

test('no recogniser in the browser: says so instead of pretending', async () => {
  globalThis.window = {};
  const { conversation } = await load();
  let why = 'none'; conversation(() => 'en', { onAsk: async () => 'x', onState: (s, d) => { if (s === 'off') why = d; } });
  assert.equal(why, 'unsupported');
});

test('an empty reply (e.g. AI not configured) does not read anything and keeps listening', async () => {
  const { spoken } = fakeBrowser(['hi', 'hi again']);
  const { conversation } = await load();
  const asked = [];
  const c = conversation(() => 'en', { onAsk: async (q) => { asked.push(q); return ''; } });
  await wait(40); c.stop();
  assert.deepEqual(asked, ['hi', 'hi again']); assert.deepEqual(spoken, []);
});
