// SMC / ICT assistant rules: invariants on many random markets, sizing maths, bias conflicts, outcome tracking.
import test from 'node:test';
import assert from 'node:assert/strict';
import { analyzeSmcIct, cleanInputs, sizePosition, trackTrade, historyStats, htfBias, STYLES, MAX_RISK_PCT } from '../src/services/smcAssist.js';

function walk(seed, n = 500, step = 3600, drift = 0.02) {
  let p = 100; let s = seed; const rnd = () => { s = (s * 16807) % 2147483647; return s / 2147483647; };
  const out = [];
  for (let i = 0; i < n; i++) {
    const o = p; const c = o + (rnd() - 0.5 + drift) * 2; const h = Math.max(o, c) + rnd() * 0.8; const l = Math.min(o, c) - rnd() * 0.8;
    out.push({ time: 1_700_000_000 + i * step, open: o, high: h, low: l, close: c, volume: 100 });
    p = c;
  }
  return out;
}
const zig = (n, step, up) => {   // clean zig-zag trend for higher-frame structure
  const out = []; let base = 100;
  for (let i = 0; i < n; i++) {
    const leg = Math.floor(i / 3) % 2 === 0 ? 1 : -0.6;
    base += (up ? leg : -leg) * 1.5;
    out.push({ time: 1_690_000_000 + i * step, open: base, high: base + 0.8, low: base - 0.8, close: base + (up ? 0.3 : -0.3) });
  }
  return out;
};

test('every plan is internally consistent on 120 random markets (both styles, both executions, all accounts)', () => {
  let trades = 0; let waits = 0;
  for (let seed = 1; seed <= 30; seed++) {
    const cs = walk(seed * 7919, 500, seed % 2 ? 3600 : 300, seed % 3 ? 0.03 : -0.03);
    for (const style of ['swing', 'scalp']) for (const execution of ['limit', 'market']) {
      const account = ['spot', 'margin', 'prop', 'demo'][seed % 4];
      const r = analyzeSmcIct(cs, { style, execution, account, capital: 10000, asset: 'crypto', symbol: 'BTCUSDT' });
      assert.ok(['trade', 'wait', 'no_trade'].includes(r.verdict));
      if (r.verdict === 'trade') trades++; if (r.verdict === 'wait') waits++;
      if (!r.plan) continue;
      const p = r.plan; const long = p.direction === 'long'; const sg = long ? 1 : -1;
      assert.ok((p.entry - p.stop) * sg > 0, 'stop on the losing side');
      p.targets.forEach((tp, k) => {
        assert.ok((tp - p.entry) * sg > 0, 'targets on the winning side');
        if (k) assert.ok((tp - p.targets[k - 1]) * sg > 0, 'targets in order');
        assert.ok(Math.abs(p.rr[k] - Math.abs(tp - p.entry) / p.risk) < 0.01, 'R:R = reward / risk');
      });
      assert.ok(p.risk >= STYLES[style].minRiskAtr * r.atr - 1e-9, 'stop never tighter than the minimum');
      if (r.verdict === 'trade') {
        assert.ok(r.checks.filter((c) => c.mandatory).every((c) => c.ok), 'a trade passes every required check');
        if (p.execution === 'market') assert.ok(Math.abs(p.entry - cs.at(-1).close) < 1e-6, 'a market entry is the current price');
        if (account === 'spot') assert.equal(p.direction, 'long', 'a cash account cannot sell short');
        assert.ok(r.size.riskAmount <= 10000 * (r.inputs.riskPct / 100) + 0.01, 'never risks more than chosen');
      }
      if (r.verdict === 'wait') assert.equal(execution, 'market');
    }
  }
  assert.ok(trades > 0, `some markets give a trade (${trades})`); assert.ok(waits >= 0);
});

test('too little data, odd inputs and a higher-frame conflict never produce a trade', () => {
  assert.equal(analyzeSmcIct(walk(3, 40), {}).verdict, 'insufficient');
  const c = cleanInputs({ style: 'x', account: 'y', riskPct: 50, leverage: 9999, capital: -5, execution: 'z', asset: 'q' });
  assert.deepEqual(c, { style: 'swing', account: 'margin', riskPct: MAX_RISK_PCT, leverage: 500, execution: 'limit', asset: 'crypto', capital: 0, costPct: 0.1, maxDailyLossPct: 3, require: [], maxOpen: 3 });
  assert.equal(cleanInputs({ account: 'prop' }).maxDailyLossPct, 5); assert.equal(cleanInputs({ asset: 'forex' }).costPct, 0.01); assert.equal(cleanInputs({ costPct: 9 }).costPct, 2);
  assert.equal(cleanInputs({ account: 'spot', leverage: 50 }).leverage, 1);
  // Daily up, 4h down → mixed → no trade
  const cs = walk(11, 300, 3600);
  const b = htfBias(cs, 3600, 'swing', { d1: zig(120, 86400, true), h4: zig(300, 14400, false) });
  assert.equal(b.frames.d1, 'bull'); assert.equal(b.frames.h4, 'bear'); assert.equal(b.bias, 'mixed');
  const r = analyzeSmcIct(cs, { style: 'swing', htf: { d1: zig(120, 86400, true), h4: zig(300, 14400, false) } });
  assert.equal(r.verdict, 'no_trade'); assert.deepEqual(r.reasons, ['htf_conflict']);
  // aligned frames → bias follows them
  assert.equal(htfBias(cs, 3600, 'swing', { d1: zig(120, 86400, false), h4: zig(300, 14400, false) }).bias, 'bear');
});

test('position size: risk %, cash-account cap, leverage cap, lots where the contract size is standard', () => {
  const m = sizePosition({ capital: 10000, riskPct: 1, entry: 2000, stop: 1990, account: 'margin', leverage: 100, asset: 'metal', symbol: 'XAUUSD', targets: [2030] });
  assert.equal(m.riskAmount, 100); assert.equal(m.units, 10); assert.equal(m.notional, 20000); assert.equal(m.margin, 200); assert.equal(m.lots, 0.1); assert.equal(m.rewards[0], 300); assert.equal(m.capped, null);
  const s = sizePosition({ capital: 1000, riskPct: 2, entry: 100, stop: 99.9, account: 'spot', asset: 'crypto', symbol: 'SOLUSDT' });
  assert.equal(s.capped, 'capital'); assert.equal(s.notional, 1000); assert.ok(s.riskAmount < 20); assert.equal(s.lots, null);
  const l = sizePosition({ capital: 1000, riskPct: 2, entry: 100, stop: 99.99, account: 'margin', leverage: 5, asset: 'crypto', symbol: 'X' });
  assert.equal(l.capped, 'leverage'); assert.equal(l.notional, 5000); assert.equal(l.margin, 1000);
  const fx = sizePosition({ capital: 5000, riskPct: 1, entry: 1.1, stop: 1.095, account: 'margin', leverage: 30, asset: 'forex', symbol: 'EURUSD' });
  assert.equal(fx.units, 10000); assert.equal(fx.lots, 0.1);
  assert.equal(sizePosition({ capital: 0, riskPct: 1, entry: 1, stop: 0.9 }), null);
});

test('outcome tracking: fill, targets, stop to entry after TP1, expiry, missed, result in R', () => {
  const T0 = 1000; const bar = (i, low, high) => ({ time: T0 + i * 60, open: (low + high) / 2, high, low, close: (low + high) / 2 });
  const tr = { direction: 'long', execution: 'limit', entry: 100, stop: 98, targets: [104, 106, 108], rr: [2, 3, 4], createdAt: T0, validUntil: T0 + 10 * 60 };
  // fill, TP1, then back to entry → breakeven: 2/3 of nothing… = TP1 part only
  let r = trackTrade(tr, [bar(1, 101, 102), bar(2, 99.5, 101), bar(3, 101, 104.5), bar(4, 99.9, 102)]);
  assert.equal(r.status, 'breakeven'); assert.equal(r.hits, 1); assert.equal(r.resultR, 0.667);
  r = trackTrade(tr, [bar(1, 99.8, 101), bar(2, 97.5, 100)]); assert.equal(r.status, 'stopped'); assert.equal(r.resultR, -1);
  r = trackTrade(tr, [bar(1, 99.8, 101), bar(2, 101, 109)]); assert.equal(r.status, 'done'); assert.equal(r.resultR, 3);
  r = trackTrade(tr, [bar(1, 101, 103), bar(2, 102, 104.2)]); assert.equal(r.status, 'missed');
  r = trackTrade(tr, [bar(1, 101, 103), bar(12, 101, 102)]); assert.equal(r.status, 'expired');
  r = trackTrade({ ...tr, execution: 'market' }, [bar(1, 100.5, 101)]); assert.equal(r.status, 'active'); assert.equal(r.resultR, null);
  // short mirror; a candle touching stop and target together counts as the stop
  const sh = { direction: 'short', execution: 'market', entry: 100, stop: 102, targets: [96], rr: [2], createdAt: T0 };
  assert.equal(trackTrade(sh, [bar(1, 95, 103)]).status, 'stopped');
  assert.equal(trackTrade(sh, [bar(1, 95.5, 101)]).status, 'done');
  const st = historyStats([{ status: 'done', resultR: 3 }, { status: 'stopped', resultR: -1 }, { status: 'pending', resultR: null }]);
  assert.deepEqual(st, { n: 3, closed: 2, wins: 1, winRate: 0.5, totalR: 2, avgR: 1 });
});

import { ltfConfirm } from '../src/services/smcAssist.js';
test('costs lower every R, news blocks a market entry, the daily loss limit blocks everything, LTF confirmation', () => {
  let checked = 0;
  for (let seed = 1; seed <= 40; seed++) {
    const cs = walk(seed * 104729, 500, 3600, seed % 2 ? 0.03 : -0.03);
    const base = analyzeSmcIct(cs, { style: 'swing', asset: 'crypto', costPct: 0 });
    if (!base.plan) continue;
    const withCost = analyzeSmcIct(cs, { style: 'swing', asset: 'crypto', costPct: 0.5 });
    assert.ok(withCost.plan.costR > 0); withCost.plan.rrNet.forEach((v, k) => assert.ok(Math.abs(v - (withCost.plan.rr[k] - withCost.plan.costR)) < 0.011));
    const blocked = analyzeSmcIct(cs, { style: 'swing', todayLossPct: 3, maxDailyLossPct: 3 });
    assert.equal(blocked.verdict, 'no_trade'); assert.ok(blocked.reasons.includes('daily'));
    const news = analyzeSmcIct(cs, { style: 'swing', execution: 'market', news: { level: 'high', known: true } });
    if (news.plan?.execution === 'market') { assert.ok(news.reasons.includes('news')); }
    const lim = analyzeSmcIct(cs, { style: 'swing', execution: 'limit', news: { level: 'high', known: true } });
    if (lim.plan?.execution === 'limit') assert.ok(!lim.reasons.includes('news'), 'a limit order is only warned');
    checked++;
  }
  assert.ok(checked > 5);
  // LTF: tap the bullish zone 100–101, then a close above the high made before the tap → confirmed
  const m = (i, o, h, l, c) => ({ time: 1000 + i * 60, open: o, high: h, low: l, close: c });
  const poi = { top: 101, bottom: 100 };
  const ltf = [m(0, 103, 103.5, 102.5, 103), m(1, 103, 103.2, 101.8, 102), m(2, 102, 102.4, 100.6, 100.8), m(3, 100.8, 101.2, 100.2, 101), m(4, 101, 102.6, 100.9, 102.5)];
  const c = ltfConfirm(ltf, poi, 'bull', 0, 2000, 0.05);
  assert.equal(c.status, 'confirmed'); assert.equal(c.entry, 102.5); assert.equal(c.stop, 100.15);
  assert.equal(ltfConfirm(ltf.slice(0, 4), poi, 'bull', 0, 2000, 0.05).status, 'tapped');
  assert.equal(ltfConfirm(ltf, poi, 'bull', 0, 1000 + 4 * 60, 0.05).status, 'tapped', 'never uses candles after `to`');
  assert.equal(ltfConfirm([m(0, 103, 103.5, 102.5, 103), m(1, 103, 103, 101.5, 102), m(2, 102, 102, 101.5, 101.6), m(3, 101.6, 102, 101.5, 101.9)], poi, 'bull', 0, 2000, 0.05).status, 'waiting');
  assert.equal(ltfConfirm([...ltf.slice(0, 3), m(3, 100.8, 101, 99, 99.5), m(4, 99.5, 103, 99, 102.9)], poi, 'bull', 0, 2000, 0.05).status, 'invalid');
  // costs are taken from the tracked result
  const tr = { direction: 'long', execution: 'market', entry: 100, stop: 98, targets: [104], rr: [2], createdAt: 0, costR: 0.1 };
  assert.equal(trackTrade(tr, [m(1, 100, 105, 99.5, 104)]).resultR, 1.9);
  assert.equal(trackTrade(tr, [m(1, 100, 100.5, 97, 98)]).resultR, -1.1);
});

test('a condition the user makes required blocks the trade when it fails', () => {
  let seen = 0;
  for (let seed = 1; seed <= 60 && seen < 3; seed++) {
    const cs = walk(seed * 3571, 500, 3600, 0.03);
    const r = analyzeSmcIct(cs, { style: 'swing' });
    const failed = r.checks?.find((c) => !c.mandatory && !c.ok && ['sweep', 'mss', 'ote', 'structure'].includes(c.id));
    if (r.verdict !== 'trade' || !failed) continue;
    const strict = analyzeSmcIct(cs, { style: 'swing', require: [failed.id, 'nonsense'] });
    assert.equal(strict.verdict, 'no_trade'); assert.deepEqual(strict.reasons, [failed.id]); seen++;
  }
  assert.ok(seen > 0);
});

import { breakerBlocks, inverseFvgs, nyClock, nyMidnightOpen, silverBullet } from '../src/services/smcAssist.js';
import { findSwings, findStructure } from '../src/indicators/smc.js';
test('breaker blocks and inverse FVGs flip sides; NY clock; exposure limit', () => {
  // inverse FVG: bullish gap 101–102, then a close below 101 → bearish IFVG; a later close above 102 would cancel it
  const m = (i, o, h, l, c) => ({ time: 1_700_000_000 + i * 3600, open: o, high: h, low: l, close: c });
  const cs = [m(0, 100, 101, 99.5, 100.8), m(1, 100.8, 103, 100.7, 102.9), m(2, 103, 104, 102, 103.5), m(3, 103.5, 103.6, 100.5, 100.6), m(4, 100.6, 101.5, 100, 101)];
  const iv = inverseFvgs(cs, 0.5, 0.1);
  assert.equal(iv.length, 1); assert.equal(iv[0].dir, 'bear'); assert.equal(iv[0].bottom, 101); assert.equal(iv[0].top, 102);
  assert.equal(inverseFvgs([...cs, m(5, 101, 102.6, 100.9, 102.5)], 0.5, 0.1).filter((g) => g.dir === 'bear' && g.bottom === 101).length, 0, 'closing back above cancels it');
  // breakers on random markets: each is the opposite side of a failed order block, never closed back through
  for (let seed = 1; seed <= 10; seed++) {
    const w = walk(seed * 13, 500);
    const sw = findSwings(w, 3); const { events } = findStructure(w, sw, 3);
    for (const b of breakerBlocks(w, events, 1)) {
      const k = w.findIndex((c) => c.time === b.flipTime);
      for (let j = k + 1; j < w.length; j++) assert.ok(b.dir === 'bear' ? w[j].close <= b.top : w[j].close >= b.bottom);
    }
  }
  // 2026-10-28 04:00 UTC = 00:00 New York (EDT)
  assert.deepEqual(nyClock(Date.UTC(2026, 9, 28, 4) / 1000), { h: 0, m: 0 });
  assert.equal(silverBullet(Date.UTC(2026, 9, 28, 14, 30) / 1000), 'am');   // 10:30 New York
  assert.equal(silverBullet(Date.UTC(2026, 9, 28, 16) / 1000), null);
  const day = Array.from({ length: 30 }, (_, i) => ({ time: Date.UTC(2026, 9, 27, 20) / 1000 + i * 3600, open: 100 + i, high: 101 + i, low: 99 + i, close: 100.5 + i }));
  assert.deepEqual(nyMidnightOpen(day, 3600), { price: 108, time: Date.UTC(2026, 9, 28, 4) / 1000 });
  assert.equal(nyMidnightOpen(day, 14400), null);
  // exposure: with the maximum already open nothing new is allowed
  let blocked = 0;
  for (let seed = 1; seed <= 30; seed++) {
    const r = analyzeSmcIct(walk(seed * 7919, 500), { style: 'swing', exposure: { open: 3, sameDir: 0 }, maxOpen: 3 });
    if (r.checks?.length) { assert.ok(r.reasons.includes('exposure')); assert.notEqual(r.verdict, 'trade'); blocked++; }
  }
  assert.ok(blocked > 0);
});

import { displacementVolume } from '../src/services/smcAssist.js';
test('volume displacement: ratio to the 20-candle average, none without real volume', () => {
  const cs = Array.from({ length: 40 }, (_, i) => ({ time: i * 60, open: 100, high: 101, low: 99, close: 100.5, volume: i === 30 ? 300 : 100 }));
  assert.equal(displacementVolume(cs, { kind: 'FVG', index: 30 }), 3);
  assert.equal(displacementVolume(cs, { kind: 'FVG', index: 10 }), null, 'needs 20 candles before');
  assert.equal(displacementVolume(cs.map((c) => ({ ...c, volume: undefined })), { kind: 'FVG', index: 30 }), null);
  const ob = [...cs]; ob[30] = { ...ob[30], volume: 100 }; ob[31] = { ...ob[31], open: 100, close: 104, volume: 250 };
  assert.equal(displacementVolume(ob, { kind: 'OB', index: 29, breakIndex: 33 }), 2.5, 'OB: the biggest candle of the break');
});

import { sessionClock } from '../src/services/smcAssist.js';
test('session clock: open windows and the next one (New York time, DST-safe)', () => {
  // 2026-10-28 14:30 UTC = 10:30 New York (EDT): Silver Bullet AM open, ends in 30 min; next = PM Silver Bullet at 14:00 → 210 min
  const c = sessionClock(Date.UTC(2026, 9, 28, 14, 30) / 1000);
  assert.deepEqual(c.now, [{ id: 'sb_am', endsIn: 30 }]);
  assert.deepEqual(c.next, { id: 'sb_pm', in: 210 });
  // 2026-11-10 08:00 UTC = 03:00 New York (EST): London kill zone + London Silver Bullet
  assert.deepEqual(sessionClock(Date.UTC(2026, 10, 10, 8) / 1000).now.map((x) => x.id), ['kz_london', 'sb_london']);
});
