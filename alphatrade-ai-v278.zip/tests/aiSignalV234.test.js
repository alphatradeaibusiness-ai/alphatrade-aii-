// v234 «توصية AI»: unified rules, execution (market / limit), expiry, tiered SMC, paper strategies (no look-ahead), back-test.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { riskSettings, costModel, limitCheck, chaseCheck, orderExpiry, nextWeekendClose, STRATEGIES, statusOf, RISK } from '../src/config/aiSignalRules.js';
import { executionPlan, extraGlobals, isDuplicate, rrOf } from '../src/services/aiSignalEngine.js';
import { paperSeries, PAPER, runPaper, unavailableReason } from '../src/services/aiPaperStrategies.js';
import { simulate, tradeStats, wilson, evaluate, runSuite } from '../src/services/aiBacktest.js';
import { runAllStrategies, smcStrategyTiered, snapshot } from '../src/services/multiStrategy.js';
import { analyzeSmcIct, cleanInputs } from '../src/services/smcAssist.js';
import { check } from '../src/services/learning.js';
import { chatSystem, smcSystem, AI_SIGNAL_FACTS, PROMPT_VERSION } from '../src/services/ai/prompts.js';
import { cleanTrade } from '../server/userTrades.js';

// seeded random walk with real-looking volume, 15m candles
function series(n = 900, { seed = 3, step = 900, start = 1_790_000_100, drift = 0 } = {}) {
  let a = seed >>> 0; const rnd = () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  const out = []; let p = 100;
  for (let i = 0; i < n; i++) { const o = p; p = p * (1 + drift + (rnd() - 0.5) * 0.006 + Math.sin(i / 37) * 0.0015); const c = p; const hi = Math.max(o, c) * (1 + rnd() * 0.002); const lo = Math.min(o, c) * (1 - rnd() * 0.002); out.push({ time: start + i * step, open: o, high: hi, low: lo, close: c, volume: 50 + rnd() * 100 + (i % 97 === 0 ? 400 : 0) }); }
  return out;
}

test('one risk source: settings are clamped, costs include spread + commission + slippage', () => {
  assert.deepEqual(riskSettings({}), { dailyLossPct: RISK.dailyLossPct.def, pauseAfterLosses: RISK.pauseAfterLosses.def, maxOpen: RISK.maxOpen.def });
  assert.equal(riskSettings({ dailyLossPct: 99 }).dailyLossPct, RISK.dailyLossPct.max);
  assert.equal(riskSettings({ dailyLossPct: 'x' }).dailyLossPct, RISK.dailyLossPct.def);
  const est = costModel('crypto'); assert.equal(est.estimated, true); assert.ok(est.totalPct > est.spreadPct);
  const real = costModel('crypto', 0.01); assert.equal(real.estimated, false); assert.equal(real.spreadPct, 0.01);
});

test('limit distance, chase and expiry are bound to style, asset, timeframe and session', () => {
  assert.equal(limitCheck({ entry: 99, price: 100, atr: 1, style: 'scalp', asset: 'crypto', direction: 'long' }).ok, true);
  assert.equal(limitCheck({ entry: 101, price: 100, atr: 1, style: 'scalp', asset: 'crypto', direction: 'long' }).reason, 'wrong_side');
  assert.equal(limitCheck({ entry: 97, price: 100, atr: 1, style: 'scalp', asset: 'crypto', direction: 'long' }).reason, 'too_far_atr');
  assert.equal(limitCheck({ entry: 97, price: 100, atr: 1.2, style: 'swing', asset: 'forex', direction: 'long' }).reason, 'too_far_pct');
  assert.equal(chaseCheck({ planEntry: 100, live: 100.3, atr: 1, style: 'scalp' }).ok, true);
  assert.equal(chaseCheck({ planEntry: 100, live: 101, atr: 1, style: 'scalp' }).ok, false);
  const mon = Date.UTC(2026, 10, 2, 9) / 1000;   // Monday
  const d1 = orderExpiry({ tf: '1D', style: 'swing', distAtr: 3, createdAt: mon, session24: true });
  assert.ok(d1.bars <= 5, 'a daily order never stays 30 days');
  const m15 = orderExpiry({ tf: '15m', style: 'scalp', distAtr: 0.5, createdAt: mon, session24: true });
  assert.ok(m15.bars >= 3 && m15.bars <= 16);
  const fri = Date.UTC(2026, 10, 6, 19) / 1000;   // Friday 19:00 UTC
  const w = orderExpiry({ tf: '4h', style: 'swing', distAtr: 2, createdAt: fri, session24: false });
  assert.equal(w.validUntil, nextWeekendClose(fri)); assert.equal(w.why, 'weekend');
});

test('execution plan: limit at the strategy level, market only when valid, no chasing, never an artificially moved limit', () => {
  const S = { i: 0, e20: [99.4], bb: { lower: [98.9], upper: [101.2] } };
  const plan = { direction: 'long', entry: 100, stop: 98.5, targets: [102.25, 103, 104.5] };
  const base = { id: 'trend', plan, style: 'scalp', asset: 'crypto', tf: '15m', tfSec: 900, S, atr: 1, price: 100, minRR: 1.35, costPct: 0.1, createdAt: 1_790_000_000, session24: true, nowMs: 1_790_000_000_000 };
  const lim = executionPlan({ ...base, want: 'limit' });
  assert.equal(lim.state, 'trade'); assert.equal(lim.plan.execution, 'limit'); assert.equal(lim.plan.entry, 99.4, 'the EMA 20 level, not the price');
  assert.ok(lim.plan.rrNet[0] < lim.plan.rr[0], 'R:R after costs is below the gross R:R');
  const live = { price: 100.1, bid: 100.09, ask: 100.11, at: 1_790_000_000_000 };
  const mk = executionPlan({ ...base, want: 'market', live });
  assert.equal(mk.plan.execution, 'market'); assert.equal(mk.plan.entry, 100.11, 'a buy pays the ask');
  const chase = executionPlan({ ...base, style: 'swing', want: 'market', live: { price: 101, at: 1_790_000_000_000 } });
  assert.equal(chase.plan?.execution, 'limit', 'a chased market entry falls back to the strategy limit');
  const chaseFar = executionPlan({ ...base, want: 'market', live: { price: 100.8, at: 1_790_000_000_000 } });
  assert.equal(chaseFar.state, 'wait'); assert.equal(chaseFar.reason, 'chase');
  const stale = executionPlan({ ...base, want: 'market', live: { price: 100.1, at: 1_789_999_000_000 } });
  assert.equal(stale.state, 'no_trade'); assert.equal(stale.reason, 'no_price');
  const smcLimit = executionPlan({ ...base, id: 'smc', engineExec: 'limit', plan: { ...plan, entry: 99.2, sources: ['BSL', '2R', '3R'] }, want: 'market', live });
  assert.equal(smcLimit.plan.execution, 'limit', 'an SMC zone order is not turned into a market order because price is close');
  const far = executionPlan({ ...base, S: { i: 0, e20: [96], bb: {} }, want: 'limit', live });
  assert.equal(far.state, 'trade', 'too far → the still-valid market entry is offered instead'); assert.equal(far.plan.execution, 'market');
  const farNoQuote = executionPlan({ ...base, S: { i: 0, e20: [96], bb: {} }, want: 'limit', live: null });
  assert.equal(farNoQuote.state, 'wait');
  assert.equal(rrOf(100, 99, [101], 0).rr[0], 1);
});

test('extra filters, duplicates', () => {
  const g = extraGlobals({ validation: { gaps: 0, duplicates: 0, n: 600, state: 'live' }, open: [{ riskPct: 2, asset: 'crypto' }, { riskPct: 2, asset: 'crypto' }], riskPct: 1, asset: 'crypto' });
  assert.equal(g.find((x) => x.id === 'integrity').status, 'pass');
  assert.equal(g.find((x) => x.id === 'asset_risk').status, 'fail', '2 % + 2 % + 1 % in one asset class is above 3 %');
  assert.equal(extraGlobals({ validation: { gaps: 0, duplicates: 3, n: 600, state: 'live' } }).find((x) => x.id === 'integrity').status, 'fail');
  const items = [{ mode: 'live', status: 'pending', symbol: 'BTCUSDT', strategy: 'trend', direction: 'long', entry: 100 }];
  assert.equal(isDuplicate(items, { symbol: 'BTCUSDT', strategy: 'trend', direction: 'long', entry: 100.1, atr: 1 }), true);
  assert.equal(isDuplicate(items, { symbol: 'BTCUSDT', strategy: 'smc', direction: 'long', entry: 100.1, atr: 1 }), false);
});

test('paper strategies never use the future (same signal on the full series and on the series cut at that bar)', () => {
  const cs = series(700);
  const full = paperSeries(cs, { volumeKind: 'taker' });
  const ctx = { assetClass: 'crypto', tf: '15m', tfSec: 900 };
  let fired = 0;
  for (const id of Object.keys(PAPER)) {
    for (let i = 250; i < 700; i += 7) {
      const a = PAPER[id](full, i, ctx);
      const cut = paperSeries(cs.slice(0, i + 1), { volumeKind: 'taker' });
      const b = PAPER[id](cut, i, ctx);
      assert.deepEqual(a, b, `${id} at ${i}`);
      if (a) fired++;
    }
  }
  assert.ok(fired > 0, 'some strategies fire on the test data');
  assert.equal(unavailableReason('vwap', { volumeKind: 'estimated', assetClass: 'index', tf: '15m' }), 'no_real_volume');
  assert.equal(runPaper(cs.slice(0, 50)).every((x) => x.status === 'unavailable'), true);
});

test('back-test: next-open fills, stop first, costs, statistics and promotion', () => {
  const cs = [];
  for (let i = 0; i < 260; i++) cs.push({ time: 1_790_000_000 + i * 900, open: 100, high: 100.5, low: 99.5, close: 100 });
  cs[221] = { ...cs[221], open: 100, high: 103.5, low: 99.6, close: 103 };   // after a signal at 220 → all three targets
  const sig = (i) => (i === 220 ? { direction: 'long', stop: 99, targets: [101, 102, 103] } : null);
  const t = simulate(cs, sig, { costPct: 0 });
  assert.equal(t.length, 1); assert.equal(t[0].entry, 100, 'filled at the next open'); assert.equal(t[0].r, 2);
  cs[221] = { ...cs[221], low: 98.5 };   // the same bar also trades the stop → the stop counts
  assert.equal(simulate(cs, sig, { costPct: 0 })[0].r, -1);
  assert.ok(simulate(cs, sig, { costPct: 0.1 })[0].r < -1, 'costs make a loss bigger');
  const st = tradeStats([{ r: 1, bars: 3 }, { r: -1, bars: 2 }, { r: 2, bars: 5 }]);
  assert.equal(st.n, 3); assert.equal(st.profitFactor, 3); assert.equal(st.small, true);
  const [lo, hi] = wilson(6, 10); assert.ok(lo < 0.6 && hi > 0.6);
  const ev = evaluate([], 1000); assert.equal(ev.meetsLive, false); assert.ok(ev.fails.includes('test_sample'));
});

test('back-test suite runs every strategy on its own (no look-ahead, nothing tuned)', async () => {
  const cs = series(800, { drift: 0.0002 });
  const res = await runSuite(cs, { symbol: 'BTCUSDT', tf: '15m', tfSec: 900, assetClass: 'crypto', volumeKind: 'taker', costPct: 0.1, style: 'scalp' }, { ids: ['trend', 'mean_reversion', 'donchian', 'vwap', 'orb'] });
  assert.ok(res.strategies.trend && res.strategies.donchian); assert.ok(res.baseline);
  for (const id of ['trend', 'mean_reversion', 'donchian']) assert.equal(typeof res.strategies[id].meetsLive, 'boolean');
  assert.ok(Number.isFinite(res.buyHoldPct));
});

test('registry: three LIVE, new ones PAPER, LSTM disabled', () => {
  assert.deepEqual(STRATEGIES.filter((s) => s.status === 'live').map((s) => s.id), ['smc', 'trend', 'mean_reversion']);
  assert.equal(statusOf('lstm'), 'disabled'); assert.equal(statusOf('donchian'), 'paper');
  for (const id of Object.keys(PAPER)) assert.equal(statusOf(id), 'paper', id);
});

test('engine: the AI options are opt-in — the channel defaults are unchanged; tiered SMC needs two confirmations', () => {
  const cs = series(600);
  const input = { symbol: 'BTCUSDT', inst: { type: 'crypto', provider: 'binance' }, tf: '15m', tfSec: 900, candles: cs, mode: 'live', reading: null, calendar: null, nowMs: (cs.at(-1).time + 900) * 1000, account: {} };
  const a = runAllStrategies(input, {}); const b = runAllStrategies(input, { ai: true, costPct: 0.12 });
  assert.equal(a.strategies.find((s) => s.id === 'mean_reversion').checks.some((c) => c.id === 'no_displacement'), false);
  assert.equal(b.strategies.find((s) => s.id === 'mean_reversion').checks.some((c) => c.id === 'no_displacement'), true);
  const S = snapshot(cs);
  const reading = { verdict: 'trade', reasons: [], price: 100, plan: { direction: 'long', execution: 'limit', entry: 99, stop: 98, targets: [101, 102, 103], rr: [2, 3, 4], rrMain: 3, risk: 1, sources: ['BSL', '2R', '3R'], poi: { kind: 'OB', top: 99.2, bottom: 98.6, withFvg: false } },
    checks: [{ id: 'poi', ok: true }, { id: 'risk', ok: true }, { id: 'sweep', ok: true }, { id: 'mss', ok: false }, { id: 'ote', ok: false }, { id: 'structure', ok: false }] };
  const one = smcStrategyTiered(reading, S);   // sweep + liquidity target = 2 confirmations, one structural → qualifies
  assert.equal(one.status, 'qualified'); assert.ok(one.quality >= 40 && one.quality <= 100);
  const none = smcStrategyTiered({ ...reading, plan: { ...reading.plan, sources: ['1.5R', '2.5R', '3.5R'] }, checks: reading.checks.map((c) => (c.id === 'sweep' ? { ...c, ok: false } : c)) }, S);
  assert.equal(none.status, 'not_qualified', 'a zone touch without a sweep or break is not a trade');
  const r = analyzeSmcIct(cs, { ...cleanInputs({ style: 'scalp' }), symbol: 'BTCUSDT', tfSec: 900, htfMode: 'tiered' });
  assert.ok(['none', 'minor', 'strong'].includes(r.htfConflict ?? 'none'));
});

test('learning ignores small groups when asked (the AI page); prompts match the section; trade records keep history', () => {
  const state = { blocks: { 'trend|session=asia': { n: 9 } }, adj: {} };
  assert.equal(check(state, 'trend', { session: 'asia' }, 2, 1.5).ok, false, 'the channel keeps its rule');
  assert.equal(check(state, 'trend', { session: 'asia' }, 2, 1.5, { minGroupN: 20 }).ok, true, 'the AI page needs ≥ 20 results');
  const sys = chatSystem({ page: 'ai-trading-chat' }, 'ar');
  assert.ok(sys.includes(AI_SIGNAL_FACTS)); assert.ok(!/EDH/.test(sys.split('Dashboard snapshot')[0]));
  assert.match(chatSystem({ page: 'dashboard' }, 'ar'), /EDH/, 'other pages keep the site-wide facts');
  assert.match(smcSystem('ar'), /setup quality score/); assert.match(PROMPT_VERSION, /v234/);
  const base = { id: 'tr_abcdef12', symbol: 'BTCUSDT', tf: '15m', style: 'scalp', direction: 'long', execution: 'limit', account: 'margin', asset: 'crypto', status: 'cancelled', entry: 100, stop: 99, risk: 1, targets: [101, 102], rr: [1, 2], createdAt: 1_790_000_000, savedAt: 1_790_000_000_000, updatedAt: 1_790_000_000_000, validUntil: null, filledAt: null, closedAt: null, hits: 0, resultR: null, capital: null, riskPct: 1, riskAmount: null, units: null, mode: 'live' };
  const c = cleanTrade({ ...base, cancelReason: 'news', history: [{ at: 1_790_000_000_000, status: 'pending', reason: 'saved' }, { at: 1_790_000_100_000, status: 'cancelled', reason: 'news' }] });
  assert.equal(c.value.cancelReason, 'news'); assert.equal(c.value.history.length, 2);
  assert.equal(cleanTrade({ ...base, cancelReason: '<script>' }).value.cancelReason, null);
});
