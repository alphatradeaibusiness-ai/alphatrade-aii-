// v274: property-based tests (fast-check) for the Alpha Partner Club money maths. Hundreds of random configurations,
// payments, duplicates and refunds; every run must keep the same rules. Test-only — fast-check is vendored under tools/vendor.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import * as fc from '../tools/vendor/fast-check.mjs';
import { createPartners } from '../server/partners.js';
import { RANKS, PRICE_TIERS } from '../src/config/partnerRanks.js';

const CAT = Object.fromEntries(PRICE_TIERS.map((c) => [`p${c}`, { id: `p${c}`, kind: 'plan', cents: c }]));
const PRODUCTS = Object.keys(CAT);
const matrix = (newPct, renPct, fixed) => Object.fromEntries(RANKS.map((r) => [r.id, Object.fromEntries(PRICE_TIERS.map((t) => [t, { newPct, newFixedCents: fixed, renPct, renFixedCents: 0 }]))]));
function world(cfg) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'pcp-')); let t = Date.UTC(2026, 10, 9, 12);
  const p = createPartners({ dir, secret: 'p'.repeat(40), now: () => t, deliver: async () => {}, hasPaid: () => false, catalogue: CAT });
  assert.equal(p.setConfig({ enabled: true, ...cfg }).ok, true);
  return { p, dir, adv: (ms) => { t += ms; }, done: () => fs.rmSync(dir, { recursive: true, force: true }) };
}
const RUNS = { numRuns: 60 };
const cfgArb = fc.record({ newPct: fc.integer({ min: 1, max: 60 }), renPct: fc.integer({ min: 0, max: 30 }), fixed: fc.integer({ min: 0, max: 5000 }) })
  .filter((c) => c.renPct < c.newPct); // the config validator requires renewal < new

test('calc: never negative, rounding stays in whole cents, and the fee/tax split adds up', async () => {
  await fc.assert(fc.property(cfgArb, fc.constantFrom(...PRICE_TIERS), fc.integer({ min: 0, max: 300000 }), fc.constantFrom('new', 'renewal'), (c, tier, collected, kind) => {
    const w = world({ matrix: matrix(c.newPct, c.renPct, c.fixed) });
    try {
      const r = w.p.calc({ rid: 'core', tier, kind, collectedCents: collected });
      assert.ok(r.commissionCents >= 0 && Number.isInteger(r.commissionCents));
      assert.equal(r.netCents, collected - r.taxCents - r.feeCents - r.otherCents);
      assert.equal(r.appRemainCents, r.netCents - r.commissionCents);
      if (kind === 'renewal') assert.ok(r.pct <= c.newPct);
    } finally { w.done(); }
  }), RUNS);
});

test('onPayment: a commission that passes straight to "pending" never breaks the financial limits', async () => {
  await fc.assert(fc.property(cfgArb, fc.constantFrom(...PRODUCTS), fc.integer({ min: 50, max: 100 }), (c, product, paidPct) => {
    const w = world({ matrix: matrix(c.newPct, c.renPct, c.fixed) });
    try {
      const part = w.p.join({ uid: 'pa', email: 'pa@mail.test', name: 'pa' }).partner; w.p.attach({ uid: 'cu', email: 'cu@mail.test', name: 'cu' }, part.code);
      const list = CAT[product].cents; const collected = Math.round((list * paidPct) / 100);
      const res = w.p.onPayment({ paymentId: 'cs_1', uid: 'cu', product, listCents: list, collectedCents: collected });
      const k = w.p.adminView().commissions.find((x) => x.paymentId === 'cs_1');
      if (res === 'new:pending') {
        const f = w.p.adminConfig().finance;
        assert.ok(k.amountCents <= Math.round((collected * f.maxCommissionPct) / 100), 'max % of payment');
        assert.ok(k.marginPct >= f.minMarginPct, 'minimum app margin');
        assert.ok(k.appRemainCents >= 0, 'the app never pays out more than it keeps');
      } else assert.match(res, /^new:(review|none)$/);
    } finally { w.done(); }
  }), RUNS);
});

test('idempotent webhooks + refunds: replays never create money, every refund reverses exactly what it paid', async () => {
  const ev = fc.oneof(
    fc.record({ t: fc.constant('pay'), id: fc.integer({ min: 1, max: 6 }), product: fc.constantFrom(...PRODUCTS) }),
    fc.record({ t: fc.constant('refund'), id: fc.integer({ min: 1, max: 6 }) }),
  );
  await fc.assert(fc.property(fc.array(ev, { minLength: 1, maxLength: 25 }), (events) => {
    const w = world({ matrix: matrix(20, 10, 0) });
    try {
      const part = w.p.join({ uid: 'pa', email: 'pa@mail.test', name: 'pa' }).partner; w.p.attach({ uid: 'cu', email: 'cu@mail.test', name: 'cu' }, part.code);
      const firstSeen = new Map(); const refunded = new Set();
      for (const e of events) {
        if (e.t === 'pay') {
          const r = w.p.onPayment({ paymentId: `cs_${e.id}`, uid: 'cu', product: e.product, listCents: CAT[e.product].cents, collectedCents: CAT[e.product].cents });
          if (firstSeen.has(e.id)) assert.equal(r, 'duplicate'); else firstSeen.set(e.id, r);
        } else {
          const r = w.p.onRefund({ paymentId: `cs_${e.id}` });
          if (!firstSeen.has(e.id)) assert.equal(r, 'no_commission');
          else if (refunded.has(e.id)) assert.equal(r, 'duplicate'); else { assert.equal(r, 'reversed'); refunded.add(e.id); }
        }
      }
      const ks = w.p.adminView().commissions.filter((x) => x.paymentId);
      assert.equal(ks.length, firstSeen.size, 'one commission per payment id, whatever the replays');
      assert.equal(new Set(ks.map((x) => x.paymentId)).size, ks.length);
      for (const k of ks) assert.equal(k.status === 'reversed', refunded.has(Number(k.paymentId.slice(3))));
      assert.equal(w.p.verifyAudit().ok ?? w.p.verifyAudit(), true, 'hash-chained audit log stays intact');
    } finally { w.done(); }
  }), RUNS);
});
