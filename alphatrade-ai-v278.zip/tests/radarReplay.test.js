import test from 'node:test';
import assert from 'node:assert/strict';
import { createReplay, WARMUP } from '../src/services/radarReplay.js';

const T0 = 1_762_000_000;
const candles = Array.from({ length: 700 }, (_, i) => {
  const mid = 100 + i * 0.04 + Math.sin(i / 25 * Math.PI * 2) * 3 + Math.sin(i / 7) * 0.6; const o = mid - 0.15, c = mid + 0.15 * Math.sign(Math.cos(i / 4));
  return { time: T0 + i * 300, open: o, high: Math.max(o, c) + 0.3, low: Math.min(o, c) - 0.3, close: c, volume: 5 };
});

test('replay: the reading and the trades at a cursor never use later candles', () => {
  const full = createReplay(candles, { tf: '5m', symbol: 'BTCUSDT' });
  for (const cur of [WARMUP + 10, 400, 520, 650]) {
    const cut = createReplay(candles.slice(0, cur + 1), { tf: '5m', symbol: 'BTCUSDT' });
    assert.deepEqual(full.reading(cur), cut.reading(cur), `reading at ${cur}`);
    assert.deepEqual(full.state(cur), cut.state(cur), `signals and trades at ${cur}`);
  }
  assert.equal(full.reading(WARMUP - 1), null, 'no reading before the warm-up');
});

test('replay: going back shows exactly what was known then', () => {
  const r = createReplay(candles, { tf: '5m', symbol: 'BTCUSDT' });
  const late = r.state(690); const early = r.state(450);
  assert.ok(early.trades.every((t) => t.closedAt <= candles[450].time * 1000), 'no trade closed in the future of the cursor');
  assert.ok(late.trades.length >= early.trades.length);
  assert.ok(late.trades.every((t) => ['tp1', 'tp2', 'tp3', 'sl', 'expired'].includes(t.status)));
});
