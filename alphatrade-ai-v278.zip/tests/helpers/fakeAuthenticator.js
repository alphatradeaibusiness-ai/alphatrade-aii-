// A software passkey for tests: produces real WebAuthn registration and assertion responses (P-256 / ES256),
// exactly what a browser sends, so the server's checks are exercised end to end.
import crypto from 'node:crypto';

const b64u = (b) => Buffer.from(b).toString('base64url');
const sha = (x) => crypto.createHash('sha256').update(x).digest();

export function cbor(v) {
  const head = (mt, n) => {
    if (n < 24) return Buffer.from([(mt << 5) | n]);
    if (n < 256) return Buffer.from([(mt << 5) | 24, n]);
    if (n < 65536) { const b = Buffer.alloc(3); b[0] = (mt << 5) | 25; b.writeUInt16BE(n, 1); return b; }
    const b = Buffer.alloc(5); b[0] = (mt << 5) | 26; b.writeUInt32BE(n, 1); return b;
  };
  if (Buffer.isBuffer(v)) return Buffer.concat([head(2, v.length), v]);
  if (typeof v === 'string') { const s = Buffer.from(v); return Buffer.concat([head(3, s.length), s]); }
  if (typeof v === 'number') return v >= 0 ? head(0, v) : head(1, -1 - v);
  if (Array.isArray(v)) return Buffer.concat([head(4, v.length), ...v.map(cbor)]);
  const entries = v instanceof Map ? [...v.entries()] : Object.entries(v);
  return Buffer.concat([head(5, entries.length), ...entries.flatMap(([k, x]) => [cbor(k), cbor(x)])]);
}

export function makeAuthenticator({ rpId = 'localhost', origin = 'http://localhost' } = {}) {
  const { privateKey, publicKey } = crypto.generateKeyPairSync('ec', { namedCurve: 'prime256v1' });
  const jwk = publicKey.export({ format: 'jwk' });
  const credId = crypto.randomBytes(32); let counter = 0;
  const id = b64u(credId);
  return {
    id,
    register(options, { uv = true, originOverride, rp = rpId } = {}) {
      const cose = cbor(new Map([[1, 2], [3, -7], [-1, 1], [-2, Buffer.from(jwk.x, 'base64url')], [-3, Buffer.from(jwk.y, 'base64url')]]));
      const len = Buffer.alloc(2); len.writeUInt16BE(credId.length);
      const authData = Buffer.concat([sha(rp), Buffer.from([0x41 | (uv ? 4 : 0)]), Buffer.alloc(4), Buffer.alloc(16), len, credId, cose]);
      const clientDataJSON = Buffer.from(JSON.stringify({ type: 'webauthn.create', challenge: options.publicKey.challenge, origin: originOverride || origin }));
      return { id, rawId: id, type: 'public-key', response: { clientDataJSON: b64u(clientDataJSON), attestationObject: b64u(cbor({ fmt: 'none', attStmt: {}, authData })) } };
    },
    /** options = server's assertion options ({ challengeId, publicKey }) → the `passkey` object the API expects. */
    assert(options, { uv = true, originOverride, tamper = false, keepCounter = false, rp = rpId } = {}) {
      if (!keepCounter) counter += 1;
      const c = Buffer.alloc(4); c.writeUInt32BE(counter);
      const authData = Buffer.concat([sha(rp), Buffer.from([0x01 | (uv ? 4 : 0)]), c]);
      const clientDataJSON = Buffer.from(JSON.stringify({ type: 'webauthn.get', challenge: options.publicKey.challenge, origin: originOverride || origin }));
      let sig = crypto.sign('sha256', Buffer.concat([authData, sha(clientDataJSON)]), privateKey);
      if (tamper) { sig = Buffer.from(sig); sig[sig.length - 1] ^= 1; }
      return { challengeId: options.challengeId, id, type: 'public-key', response: { clientDataJSON: b64u(clientDataJSON), authenticatorData: b64u(authData), signature: b64u(sig) } };
    },
  };
}
