import test from 'node:test';
import assert from 'node:assert/strict';
import { readDerivs, derivCheck } from '../src/services/derivatives.js';
import { positionSize } from '../src/services/sizing.js';
import { guardCheck } from '../src/services/riskGuard.js';
import { backtestClassic } from '../src/services/backtest.js';
import { divergence } from '../src/services/zoneStrategy.js';

const base = { symbol: 'BTCUSDT', funding: 0.0001, oiChange1h: 0, oiChange4h: 0, priceChange1h: 0 };

test('balanced positioning lets both directions through', () => {
  const r = readDerivs(base);
  assert.equal(derivCheck(r, 'long').ok, true);
  assert.equal(derivCheck(r, 'short').ok, true);
});
test('crowded longs (funding high + OI building) block buying, not selling', () => {
  const r = readDerivs({ ...base, funding: 0.0004, oiChange4h: 5 });
  assert.equal(derivCheck(r, 'long').key, 'crowdedLongs');
  assert.equal(derivCheck(r, 'short').ok, true);
});
test('moderately high funding without growing OI is not enough to block', () => {
  assert.equal(derivCheck(readDerivs({ ...base, funding: 0.0004, oiChange4h: 0 }), 'long').ok, true);
});
test('extreme funding blocks buying whatever the OI does', () => {
  assert.equal(derivCheck(readDerivs({ ...base, funding: 0.0006, oiChange4h: -2 }), 'long').ok, false);
});
test('negative funding blocks selling', () => {
  assert.equal(derivCheck(readDerivs({ ...base, funding: -0.0003 }), 'short').key, 'crowdedShorts');
});
test('long flush: price down + OI collapse blocks selling the bottom, short squeeze blocks buying the top', () => {
  assert.equal(derivCheck(readDerivs({ ...base, oiChange1h: -2.5, priceChange1h: -1.2 }), 'short').key, 'longFlush');
  assert.equal(derivCheck(readDerivs({ ...base, oiChange1h: -2.5, priceChange1h: 1.2 }), 'long').key, 'shortSqueeze');
  assert.equal(derivCheck(readDerivs({ ...base, oiChange1h: -2.5, priceChange1h: -1.2 }), 'long').ok, true);
});
test('no data → no filter', () => { assert.equal(derivCheck(readDerivs(null), 'long').ok, true); });

test('the risk guard holds a signal back on a derivatives block, and only when the filter is on', () => {
  const deriv = { ok: false, key: 'crowdedLongs', params: { f: '0.040%' } };
  const on = guardCheck({ signals: [], candidate: { symbol: 'BTCUSDT', direction: 'long' }, cfg: { derivFilter: true }, deriv });
  assert.equal(on.ok, false); assert.equal(on.key, 'deriv');
  const off = guardCheck({ signals: [], candidate: { symbol: 'BTCUSDT', direction: 'long' }, cfg: { derivFilter: false }, deriv });
  assert.equal(off.ok, true);
});

test('position size: risk amount / stop distance, shrinks in high volatility, never above the chosen share', () => {
  const a = positionSize({ account: 10000, riskPct: 1, entry: 100, stop: 98, volRank: 0.5 });
  assert.equal(a.riskAmount, 100); assert.equal(a.units, 50);
  const b = positionSize({ account: 10000, riskPct: 1, entry: 100, stop: 98, volRank: 0.8 });
  assert.ok(b.units < a.units && Math.abs(b.riskAmount - 70) < 1e-9);
  const c = positionSize({ account: 10000, riskPct: 1, entry: 100, stop: 98, volRank: 0.1 });
  assert.equal(c.units, a.units);
  assert.equal(positionSize({ account: 0, riskPct: 1, entry: 100, stop: 98 }), null);
});

// a rising market where momentum crosses up → one long, so we can watch the stop move
function climb() {
  const c = []; let p = 100;
  for (let i = 0; i < 420; i++) { const d = i < 300 ? Math.sin(i / 6) * 0.6 + 0.02 : 0.45; const o = p; p += d; c.push({ time: 1_700_000_000 + i * 900, open: o, high: Math.max(o, p) + 0.3, low: Math.min(o, p) - 0.3, close: p, volume: 100 }); }
  return c;
}
test('breakeven at R: once price has gone beAtR x the risk, the stop sits at the entry', () => {
  const rules = { stopMode: 'atr', atrMult: 2, tpR: [3, 4, 5], pointSize: 1, feePct: 0, trendFilter: false, openOnLast: true };
  const run = backtestClassic(climb(), { ...rules, beAtR: 0.5 });
  const all = [...run.trades, run.open].filter(Boolean);
  assert.ok(all.length > 0);
  assert.ok(all.some((t) => t.beMoved), 'some trade had its stop moved');
  for (const t of all.filter((x) => x.beMoved)) assert.equal(t.stop, t.entry);
  const off = backtestClassic(climb(), { ...rules, beAtR: 0 });
  assert.ok([...off.trades, off.open].filter(Boolean).every((t) => !t.beMoved));
});

test('divergence: regular (reversal) and hidden (continuation) are told apart, for buys and sells', () => {
  const mk = (pts, rsiAt) => ({ sw: pts.map(([index, type, price]) => ({ index, type, price })), rsi: Object.fromEntries(rsiAt) });
  // buy side: two swing lows
  const regular = mk([[10, 'low', 100], [30, 'low', 98]], [[10, 30], [30, 38]]);   // lower low, RSI higher low
  const hidden = mk([[10, 'low', 100], [30, 'low', 102]], [[10, 38], [30, 30]]);   // higher low, RSI lower low
  const none = mk([[10, 'low', 100], [30, 'low', 98]], [[10, 38], [30, 30]]);      // both lower: no divergence
  assert.equal(divergence(regular, 40, 'long'), 'regular');
  assert.equal(divergence(hidden, 40, 'long'), 'hidden');
  assert.equal(divergence(none, 40, 'long'), null);
  // sell side: two swing highs
  const sReg = mk([[10, 'high', 100], [30, 'high', 102]], [[10, 70], [30, 62]]);
  const sHid = mk([[10, 'high', 100], [30, 'high', 98]], [[10, 62], [30, 70]]);
  assert.equal(divergence(sReg, 40, 'short'), 'regular');
  assert.equal(divergence(sHid, 40, 'short'), 'hidden');
});
