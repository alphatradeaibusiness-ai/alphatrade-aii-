import assert from 'node:assert';
import { guardCheck, guardState, signalR } from '../src/services/riskGuard.js';
const now = Date.parse('2026-10-03T12:00:00Z');
const mk = (o) => ({ symbol: 'BTCUSDT', direction: 'long', entry: 100, stop: 98, targets: [102, 104, 107], hits: 0, status: 'active', closedAt: null, ...o });
const loss = (o = {}) => mk({ status: 'sl', closedAt: now - 3600_000, ...o });
assert.strictEqual(signalR(loss()), -1);
assert.strictEqual(signalR(mk({ status: 'be', hits: 1, closedAt: now })).toFixed(3), (1 / 3).toFixed(3));
assert.strictEqual(signalR(mk({ status: 'tp3', hits: 3, closedAt: now })).toFixed(3), ((1 + 2 + 3.5) / 3).toFixed(3));
const cand = { symbol: 'ETHUSDT', direction: 'long' };
assert(guardCheck({ signals: [], candidate: cand, now }).ok);
// daily loss limit (3R)
let r = guardCheck({ signals: [loss(), loss(), loss({ closedAt: now - 7200_000 })], candidate: cand, now, cfg: { streakPause: 0 } });
assert(!r.ok && r.key === 'daily');
// losses from yesterday do not count
assert(guardCheck({ signals: [loss({ closedAt: now - 2 * 86400_000 }), loss({ closedAt: now - 2 * 86400_000 }), loss({ closedAt: now - 2 * 86400_000 })], candidate: cand, now }).ok);
// loss streak
r = guardCheck({ signals: [loss(), loss({ closedAt: now - 5000_000 })], candidate: cand, now, cfg: { streakPause: 2, dailyLossR: 0, dailyLossPct: 0 } });
assert(!r.ok && r.key === 'streak');
// a win in between breaks the streak
r = guardCheck({ signals: [loss(), mk({ status: 'tp3', hits: 3, closedAt: now - 1800_000 }), loss({ closedAt: now - 7000_000 })], candidate: cand, now, cfg: { streakPause: 2, dailyLossR: 0, dailyLossPct: 0 } });
assert(r.ok);
// max active / correlated
assert.strictEqual(guardCheck({ signals: ['BTCUSDT', 'XAUUSD', 'US30', 'US100', 'ETHUSDT', 'SOLUSDT'].map((symbol) => mk({ symbol })), candidate: cand, now, cfg: { maxActive: 6 } }).key, 'active');
assert.strictEqual(guardCheck({ signals: [mk(), mk({ symbol: 'SOLUSDT' })], candidate: cand, now }).key, 'corr');
assert(guardCheck({ signals: [mk(), mk({ symbol: 'SOLUSDT', direction: 'short' })], candidate: cand, now }).ok, 'opposite direction is not correlated');
// news
const ev = [{ title: 'FOMC', country: 'USD', time: now + 20 * 60_000, impact: 'High' }];
r = guardCheck({ signals: [], candidate: { symbol: 'XAUUSD', direction: 'long' }, now, events: ev, impact: { USD: ['XAUUSD'] } });
assert(!r.ok && r.key === 'news');
assert(guardCheck({ signals: [], candidate: { symbol: 'XAUUSD', direction: 'long' }, now: now - 3600_000, events: ev, impact: { USD: ['XAUUSD'] } }).ok, 'an hour before the news is fine');
assert(guardCheck({ signals: [loss(), loss(), loss()], candidate: cand, now, cfg: { enabled: false } }).ok);
console.log('risk guard ok');

// circuit breaker in account percent: 2% daily limit at 1% risk per trade = 2R → two stop-outs halt trading
r = guardCheck({ signals: [loss(), loss({ closedAt: now - 5000_000 })], candidate: cand, now, cfg: { dailyLossPct: 2, riskPct: 1, dailyLossR: 0, streakPause: 0 } });
assert(!r.ok && r.key === 'daily' && r.params.r === 2 && r.params.pct === 2);
r = guardCheck({ signals: [loss()], candidate: cand, now, cfg: { dailyLossPct: 2, riskPct: 1, dailyLossR: 0, streakPause: 0 } });
assert(r.ok && Math.abs(r.state.dailyPct + 1) < 1e-9); // -1% so far
// with 0.5% risk per trade the same 2% limit allows four losses
r = guardCheck({ signals: [loss(), loss({ closedAt: now - 5000_000 }), loss({ closedAt: now - 6000_000 })], candidate: cand, now, cfg: { dailyLossPct: 2, riskPct: 0.5, dailyLossR: 0, streakPause: 0 } });
assert(r.ok);
// statistical correlation block
r = guardCheck({ signals: [], candidate: cand, now, cfg: {}, corr: { symbol: 'ETHUSDT', r: 0.88 } });
assert(!r.ok && r.key === 'corrDyn');
console.log('guard breaker ok');
