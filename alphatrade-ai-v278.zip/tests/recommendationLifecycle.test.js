import test from 'node:test';import assert from 'node:assert/strict';import {pendingTransition} from '../src/services/recommendationLifecycle.js';
const now=1_800_000_000_000;
const long={status:'pending',order:'limit',direction:'long',entry:100,stop:90,createdAt:now-10000,priceAt:now-5000,expiresAt:now+10000};
test('buy and sell limits activate at the intended side and preserve their entry',()=>{
 assert.equal(pendingTransition(long,{price:101,at:now},now).status,'pending');
 const a=pendingTransition(long,{price:100,at:now},now);assert.equal(a.status,'active');assert.equal(a.entry,100);assert.equal(a.activatedAt,now);
 const short={...long,direction:'short',stop:110};assert.equal(pendingTransition(short,{price:99,at:now},now).status,'pending');assert.equal(pendingTransition(short,{price:100,at:now},now).status,'active');
});
test('invalidated limits cancel before activation; time expiry needs no live quote',()=>{
 const r=pendingTransition(long,{price:89,at:now},now);assert.equal(r.status,'cancelled');assert.equal(r.activatedAt,undefined);
 assert.equal(pendingTransition(long,null,now+10000).status,'expired');
});
test('stale, future, duplicate and malformed quotes cannot fill pending orders',()=>{
 for(const q of [{price:100,at:now-40000},{price:100,at:now+6000},{price:100,at:long.priceAt},{price:NaN,at:now},{price:100}])assert.equal(pendingTransition(long,q,now).status,'pending');
});
