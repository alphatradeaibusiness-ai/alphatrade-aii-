// Starts server/index.js on a free port against a local fake AI provider and checks the security fixes of v131.
import test from 'node:test';
import assert from 'node:assert';
import http from 'node:http';
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const listen = (srv) => new Promise((r) => srv.listen(0, '127.0.0.1', () => r(srv.address().port)));
const req = (port, p, { method = 'GET', headers = {}, body } = {}) => new Promise((resolve, reject) => {
  const r = http.request({ host: '127.0.0.1', port, path: p, method, headers }, (res) => { let d = ''; res.on('data', (c) => (d += c)); res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, body: d })); });
  r.on('error', reject); if (body) r.write(body); r.end();
});

test('AI proxy: no Origin → refused; same origin → allowed; provider errors are not echoed; FF proxy and static files get safe headers', async () => {
  const fake = http.createServer((q, s) => {
    if (q.url.startsWith('/v1/messages')) { s.writeHead(400, { 'content-type': 'application/json' }); s.end(JSON.stringify({ error: { type: 'x', message: 'SECRET INTERNAL DETAIL' } })); return; }
    s.writeHead(200, { 'content-type': 'text/html' }); s.end('<script>alert(1)</script>');
  });
  const fp = await listen(fake);
  const dist = fs.mkdtempSync(path.join(os.tmpdir(), 'dist-'));
  fs.writeFileSync(path.join(dist, 'index.html'), '<!doctype html><title>x</title>');
  const port = 20000 + Math.floor(Math.random() * 20000);
  const child = spawn(process.execPath, ['server/index.js', '--serve-dist'], {
    env: { ...process.env, SERVER_PORT: String(port), ANTHROPIC_API_KEY: 'test-key', ANTHROPIC_BASE_URL: `http://127.0.0.1:${fp}`, FF_NEWS_URL: `http://127.0.0.1:${fp}/news`, STATIC_DIR: dist, AI_ACCESS_TOKEN: '' },
    stdio: 'ignore',
  });
  try {
    for (let i = 0; i < 50; i++) { try { await req(port, '/api/ai/health'); break; } catch { await new Promise((r) => setTimeout(r, 100)); } }
    const body = JSON.stringify({ messages: [{ role: 'user', content: 'hi' }] });
    const noOrigin = await req(port, '/api/ai/chat', { method: 'POST', headers: { 'content-type': 'application/json' }, body });
    assert.equal(noOrigin.status, 403);
    const foreign = await req(port, '/api/ai/chat', { method: 'POST', headers: { 'content-type': 'application/json', origin: 'https://evil.example' }, body });
    assert.equal(foreign.status, 403);
    const same = await req(port, '/api/ai/chat', { method: 'POST', headers: { 'content-type': 'application/json', origin: `http://127.0.0.1:${port}`, host: `127.0.0.1:${port}` }, body });
    assert.equal(same.status, 503);   // passed the origin gate; v144: every AI call also needs a verified user (server sign-in not configured here)
    assert.equal(JSON.parse(same.body).code, 'auth_not_configured');
    assert.ok(!same.body.includes('SECRET INTERNAL DETAIL'));
    const ff = await req(port, '/ff/news');
    assert.match(ff.headers['content-security-policy'] || '', /sandbox/);
    assert.equal(ff.headers['x-content-type-options'], 'nosniff');
    const page = await req(port, '/');
    assert.match(page.headers['content-security-policy'] || '', /frame-ancestors 'none'/);
    assert.equal(page.headers['x-frame-options'], 'DENY');
  } finally { child.kill(); fake.close(); fs.rmSync(dist, { recursive: true, force: true }); }
});
