import test from 'node:test';
import assert from 'node:assert/strict';

const mem = () => { const m = new Map(); return { getItem: (k) => (m.has(k) ? m.get(k) : null), setItem: (k, v) => m.set(k, String(v)), removeItem: (k) => m.delete(k) }; };
globalThis.localStorage = mem();
globalThis.sessionStorage = mem();
const { localAuth } = await import('../src/services/auth/localAuth.js');
const { storage } = await import('../src/utils/storage.js');

test('new accounts use PBKDF2 and sign in', async () => {
  await localAuth.signUp('Ali', 'ali@example.com', 'secret123');
  const u = storage.get('demo-users', {})['ali@example.com'];
  assert.ok(u.hash.startsWith('p2$'));
  const me = await localAuth.signIn('ali@example.com', 'secret123', false);
  assert.equal(me.email, 'ali@example.com');
});

test('an old SHA-256 account still signs in and is upgraded', async () => {
  const salt = '1-2-3-4';
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(`${salt}:oldpass99`));
  const hex = [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, '0')).join('');
  const all = storage.get('demo-users', {});
  all['old@example.com'] = { name: 'Old', salt, hash: hex, created: 1 };
  storage.set('demo-users', all);
  await localAuth.signIn('old@example.com', 'oldpass99', false);
  assert.ok(storage.get('demo-users', {})['old@example.com'].hash.startsWith('p2$'));
});

test('wrong passwords lock the sign-in, and the lock survives a reload', async () => {
  for (let i = 0; i < 5; i++) await assert.rejects(localAuth.signIn('ali@example.com', 'bad', false));
  await assert.rejects(localAuth.signIn('ali@example.com', 'secret123', false), (e) => e.code === 'tooMany' || /tooMany/.test(String(e.code || e.message)));
  assert.ok(storage.get('demo-lock', null, 'local').until > Date.now());
});
