import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createUserTrades } from '../server/userTrades.js';
import { createTradeWatch, eventsFor } from '../server/tradeWatch.js';

const T0 = 1_760_000_000;   // seconds
const trade = (o = {}) => ({ id: 'tr_abc123', symbol: 'BTCUSDT', tf: '1h', style: 'swing', direction: 'long', execution: 'limit', account: 'spot', asset: 'crypto', status: 'pending',
  entry: 100, stop: 95, risk: 5, targets: [110, 120], rr: [2, 4], createdAt: T0, savedAt: T0 * 1000, updatedAt: T0 * 1000, validUntil: T0 + 48 * 3600, filledAt: null, closedAt: null,
  hits: 0, resultR: null, capital: null, riskPct: null, riskAmount: null, units: null, mode: 'live', costR: 0, tags: [], note: '', ...o });
const k = (i, o, h, l, c) => [(T0 + i * 3600) * 1000, String(o), String(h), String(l), String(c), '10'];

function setup(rows) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'tw-'));
  const ut = createUserTrades({ dir, secret: 's'.repeat(40) });
  const sent = []; const urls = [];
  let nowMs = (T0 + 10 * 3600) * 1000;
  const fetchFn = async (u) => { urls.push(u); const q = new URL(u); if (q.searchParams.get('symbol') === 'NOTAPAIR') return { ok: false, status: 400 }; return { ok: true, json: async () => rows() } };
  const w = createTradeWatch({ userTrades: ut, notify: (uid, kind, p) => sent.push({ uid, kind, ...p }), env: {}, fetchFn, base: 'http://x', now: () => nowMs, log: { error() {} } });
  return { ut, w, sent, urls, dir, setNow: (s) => { nowMs = s * 1000; } };
}

test('events: fill, target, end are reported once each', () => {
  assert.deepEqual(eventsFor({ status: 'pending', hits: 0 }, { status: 'active', hits: 1, filledAt: 1 }, 2).map((e) => e.kind), ['trade_filled', 'trade_target']);
  assert.deepEqual(eventsFor({ status: 'active', hits: 1 }, { status: 'done', hits: 2, resultR: 3 }, 2), [{ kind: 'trade_done', r: 3 }]);
  assert.deepEqual(eventsFor({ status: 'active', hits: 1 }, { status: 'breakeven', hits: 1, resultR: 1 }, 2), [{ kind: 'trade_breakeven', r: 1 }]);
});

test('watcher: judges open crypto trades on closed candles, saves the outcome, notifies, and stops watching closed trades', async () => {
  let rows = [k(0, 101, 102, 100.5, 101), k(1, 101, 101.5, 99.5, 100.5), k(2, 100.5, 111, 100, 110)];
  const s = setup(() => rows);
  assert.deepEqual(s.ut.openOwners(), []);
  s.ut.upsert('u1', trade());
  s.ut.upsert('u2', trade({ id: 'tr_fx0001', symbol: 'EURUSD', asset: 'forex' }));   // not crypto and no market key here: skipped
  s.ut.upsert('u3', trade({ id: 'tr_demo01', mode: 'demo' }));                       // demo prices: never judged
  assert.deepEqual(s.ut.openOwners().sort(), ['u1', 'u2', 'u3']);
  assert.equal(fs.readFileSync(path.join(s.dir, 'user-trades', 'open-index.json'), 'utf8').includes('u1'), false, 'index is encrypted');
  let r = await s.w.tick(); assert.equal(r.changes, 1);
  let x = s.ut.list('u1')[0]; assert.equal(x.status, 'active'); assert.equal(x.hits, 1); assert.equal(x.filledAt, T0 + 3600);
  assert.deepEqual(s.sent.map((e) => e.kind), ['trade_filled', 'trade_target']);
  assert.equal(s.sent[1].n, 1); assert.equal(s.sent[0].symbol, 'BTCUSDT'); assert.equal(s.sent[0].uid, 'u1');
  assert.ok(s.urls.every((u) => u.includes('symbol=BTCUSDT') && u.includes('interval=1h')));
  // nothing new → no notification
  r = await s.w.tick(); assert.equal(r.changes, 0); assert.equal(s.sent.length, 2);
  // a still-forming candle is not used
  rows = [...rows, k(3, 110, 125, 109, 121)];
  s.setNow(T0 + 3 * 3600 + 100); r = await s.w.tick(); assert.equal(r.changes, 0);
  s.setNow(T0 + 4 * 3600 + 1); r = await s.w.tick(); assert.equal(r.changes, 1);
  x = s.ut.list('u1')[0]; assert.equal(x.status, 'done'); assert.equal(x.resultR, 3);
  assert.deepEqual(s.sent.at(-1), { uid: 'u1', kind: 'trade_done', id: 'tr_abc123', symbol: 'BTCUSDT', r: 3, direction: 'long', entry: 100, stop: 95, hits: 2, price: 120 });
  assert.deepEqual(s.ut.openOwners().sort(), ['u2', 'u3'], 'u1 has no open trades left');
  // an older copy from another device cannot reopen the judged trade (that would notify twice), but its note is kept
  s.ut.upsert('u1', trade({ note: 'my note', updatedAt: Date.now() + 1000 }));
  x = s.ut.list('u1')[0]; assert.equal(x.status, 'done'); assert.equal(x.note, 'my note');
  assert.deepEqual(s.ut.openOwners().sort(), ['u2', 'u3']);
});

test('watcher: stop-out, not-a-Binance-pair and disabled', async () => {
  const s = setup(() => [k(1, 100, 100.5, 94, 95)]);
  s.ut.upsert('u1', trade({ execution: 'market', status: 'active', filledAt: T0 }));
  s.ut.upsert('u2', trade({ id: 'tr_bad001', symbol: 'NOTAPAIR' }));
  await s.w.tick();
  const x = s.ut.list('u1')[0]; assert.equal(x.status, 'stopped'); assert.equal(x.resultR, -1);
  assert.deepEqual(s.sent.map((e) => [e.kind, e.r]), [['trade_stopped', -1]]);
  assert.equal(s.ut.list('u2')[0].status, 'pending');
  const off = createTradeWatch({ userTrades: s.ut, env: { TRADE_WATCH_DISABLED: '1' }, fetchFn: async () => { throw new Error('no'); } });
  assert.equal((await off.tick()).skipped, true);
});

test('watcher: gold / forex trades are judged from the market-data key, at most every 10 minutes, and notify each target', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'tw-'));
  const ut = createUserTrades({ dir, secret: 's'.repeat(40) });
  const sent = []; let calls = 0; let nowMs = (T0 + 10 * 3600) * 1000;
  const c = (i, o, h, l, cl) => ({ time: T0 + i * 3600, open: o, high: h, low: l, close: cl });
  let rows = [c(0, 101, 102, 100.5, 101), c(1, 101, 101.5, 99.5, 100.5), c(2, 100.5, 111, 100, 110)];
  const w = createTradeWatch({ userTrades: ut, notify: (uid, kind, p) => sent.push({ uid, kind, ...p }), env: {}, fetchFn: async () => { throw new Error('binance not used'); }, now: () => nowMs, log: { error() {} },
    otherCandles: async (symbol, tf) => { calls++; assert.equal(symbol, 'XAUUSD'); assert.equal(tf, '1h'); return rows; } });
  ut.upsert('u1', trade({ id: 'tr_gold01', symbol: 'XAUUSD', asset: 'metal' }));
  await w.tick();
  assert.deepEqual(sent.map((e) => `${e.kind}${e.n ?? ''}`), ['trade_filled', 'trade_target1']);
  assert.equal(sent[1].price, 110); assert.equal(calls, 1);
  rows = [...rows, c(3, 110, 125, 109, 121)];
  nowMs += 5 * 60_000; await w.tick(); assert.equal(calls, 1, 'not again within 10 minutes');
  nowMs += 6 * 60_000; await w.tick(); assert.equal(calls, 2);
  assert.equal(sent.at(-1).kind, 'trade_done'); assert.equal(sent.at(-1).price, 120);
  assert.equal(w.status().other, true);
});
