// v262 Telegram channel gate: join requests checked against the site, removal on expiry / unlink, periodic sweep.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createTgGate } from '../server/tgGate.js';

function setup() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'tgg-')); let t = Date.UTC(2026, 10, 9, 12); const calls = [];
  const subs = { u1: { until: t + 5 * 86_400_000 }, u2: { until: t - 86_400_000 } }; const links = { 501: 'u1', 502: 'u2', 504: 'boss' };
  const fetchFn = async (url, o) => { const m = url.split('/').pop(); const body = JSON.parse(o.body); calls.push({ m, body });
    const res = { createChatInviteLink: { invite_link: 'https://t.me/+JoinReq123' }, getMe: { id: 9, username: 'alpha_bot' }, getChatMember: { status: 'administrator', can_invite_users: true, can_restrict_members: true } }[m] ?? true;
    return { status: 200, json: async () => ({ ok: true, result: res }) }; };
  const g = createTgGate({ dir, now: () => t, token: () => '1:TOKEN', defaultChannel: () => '-100777', fetchFn, publicUrl: () => 'https://alpha.example',
    entitlement: (uid) => (uid === 'boss' ? { owner: true } : subs[uid] || null), uidByTg: (id) => links[id] || null, langOf: () => 'ar' });
  return { g, calls, subs, links, adv: (ms) => { t += ms; } };
}
const req = (id) => ({ chat_join_request: { chat: { id: -100777 }, from: { id }, user_chat_id: id } });
const joined = (id) => ({ chat_member: { chat: { id: -100777 }, new_chat_member: { status: 'member', user: { id } } } });

test('off by default; join requests: subscriber approved, expired / unlinked declined with a guiding message', async () => {
  const { g, calls } = setup();
  assert.equal(await g.onUpdate(req(501)), false, 'disabled → not handled');
  g.setConfig({ enabled: true });
  await g.onUpdate(req(501)); assert.ok(calls.some((c) => c.m === 'approveChatJoinRequest' && c.body.user_id === 501));
  await g.onUpdate(req(502)); assert.ok(calls.some((c) => c.m === 'declineChatJoinRequest' && c.body.user_id === 502));
  assert.match(calls.filter((c) => c.m === 'sendMessage').at(-1).body.text, /اشتراك فعّال[\s\S]*https:\/\/alpha\.example\/#\/app\/pricing/);
  await g.onUpdate(req(503)); assert.match(calls.filter((c) => c.m === 'sendMessage').at(-1).body.text, /مش مربوط[\s\S]*#\/app\/connect/);
  await g.onUpdate(req(504)); assert.ok(calls.some((c) => c.m === 'approveChatJoinRequest' && c.body.user_id === 504), 'owners always');
  assert.equal(await g.onUpdate({ chat_join_request: { chat: { id: -100999 }, from: { id: 502 } } }), false, 'other chats ignored');
  assert.equal(g.status().members, 2);
});

test('people who get in another way are checked on chat_member and removed (ban + unban) when not entitled', async () => {
  const { g, calls } = setup(); g.setConfig({ enabled: true });
  await g.onUpdate(joined(502));
  const ban = calls.find((c) => c.m === 'banChatMember'); assert.equal(ban.body.user_id, 502);
  assert.ok(calls.some((c) => c.m === 'unbanChatMember' && c.body.only_if_banned), 'removed, not banned forever');
  await g.onUpdate(joined(501)); assert.equal(calls.filter((c) => c.m === 'banChatMember').length, 1); assert.equal(g.status().members, 1);
});

test('periodic sweep: expiry (with grace), unlinked account; interval respected; kickOnExpiry off keeps expired members', async () => {
  const { g, calls, subs, links, adv } = setup(); g.setConfig({ enabled: true, graceHours: 24, checkMinutes: 15 });
  await g.onUpdate(req(501)); assert.equal(g.status().members, 1);
  subs.u1.until -= 6 * 86_400_000;   // ended 1 day ago → still inside a 24 h grace? exactly at the edge → let 2 h more pass
  adv(2 * 3_600_000); let r = await g.sweep({ force: true }); assert.equal(r.removed, 1);
  assert.match(calls.filter((c) => c.m === 'sendMessage').at(-1).body.text, /انتهى اشتراكك/);
  // unlinked
  subs.u1.until = Date.now() * 2; await g.onUpdate(req(501)); delete links[501];
  r = await g.sweep(); assert.equal(r.skipped, true, 'not before checkMinutes'); adv(16 * 60_000); r = await g.sweep(); assert.equal(r.removed, 1);
  assert.match(calls.filter((c) => c.m === 'sendMessage').at(-1).body.text, /انفصل/);
  // kickOnExpiry off
  links[501] = 'u1'; await g.onUpdate(req(501)); subs.u1.until = 0; g.setConfig({ kickOnExpiry: false, graceHours: 0 }); adv(20 * 60_000);
  assert.equal((await g.sweep()).removed, 0);
});

test('invite link needs approval; bot rights check; channel id validated', async () => {
  const { g, calls } = setup();
  assert.equal(g.setConfig({ channelId: 'my channel' }).error, 'bad_channel');
  assert.equal(g.setConfig({ channelId: '-1001234567890' }).ok, true);
  const r = await g.createInvite(); assert.equal(r.inviteLink, 'https://t.me/+JoinReq123'); assert.equal(calls.find((c) => c.m === 'createChatInviteLink').body.creates_join_request, true);
  const b = await g.botRights(); assert.deepEqual([b.ok, b.canInvite, b.canRestrict, b.bot], [true, true, true, 'alpha_bot']);
  g.setConfig({ enabled: true }); assert.equal(g.userView('u1', 501).inviteLink, 'https://t.me/+JoinReq123'); assert.equal(g.userView('u2', 502).inviteLink, null); assert.equal(g.userView('u1', null).inviteLink, null, 'must link Telegram first');
});
