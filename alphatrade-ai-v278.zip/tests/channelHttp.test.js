import test from 'node:test';import assert from 'node:assert/strict';import crypto from 'node:crypto';import fs from 'node:fs';import path from 'node:path';import os from 'node:os';import {spawn} from 'node:child_process';import http from 'node:http';
test('channel HTTP feed requires verified identity; only owner grants access; separate accounts and quotas',async t=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'channel-http-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
 const {privateKey,publicKey}=crypto.generateKeyPairSync('rsa',{modulusLength:2048});const certFile=path.join(dir,'certs.json');fs.writeFileSync(certFile,JSON.stringify({test:publicKey.export({type:'spki',format:'pem'})}));
 const now=Date.now();fs.writeFileSync(path.join(dir,'state.json'),JSON.stringify({'ata:signals':JSON.stringify(Array.from({length:40},(_,i)=>({id:'sig'+i,createdAt:now-1000+i,status:'active',entry:100,stop:90,targets:[110,120,130]})))}));
 const listen=http.createServer();await new Promise(r=>listen.listen(0,'127.0.0.1',r));const port=listen.address().port;await new Promise(r=>listen.close(r));
 const child=spawn(process.execPath,['server/index.js'],{env:{...process.env,NODE_ENV:'test',SERVER_PORT:String(port),SERVER_DATA_DIR:dir,WORKER_DATA_DIR:dir,AI_TEST_CERTS_FILE:certFile,FIREBASE_PROJECT_ID:'channel-test',ADMIN_EMAILS:'owner@example.com',AI_IP_PER_MINUTE:'1000'},stdio:'ignore'});t.after(()=>child.kill());
 const jwt=(uid,email)=>{const h=Buffer.from(JSON.stringify({alg:'RS256',kid:'test'})).toString('base64url'),p=Buffer.from(JSON.stringify({sub:uid,email,email_verified:true,aud:'channel-test',iss:'https://securetoken.google.com/channel-test',iat:Math.floor(now/1000)-5,exp:Math.floor(now/1000)+3600})).toString('base64url');return `${h}.${p}.${crypto.sign('RSA-SHA256',Buffer.from(h+'.'+p),privateKey).toString('base64url')}`;};
 const req=async(route,token,body)=>{const r=await fetch(`http://127.0.0.1:${port}${route}`,{method:body?'POST':'GET',headers:{...(token?{Authorization:'Bearer '+token}:{}),...(body?{Origin:`http://127.0.0.1:${port}`,'Content-Type':'application/json'}:{})},body:body?JSON.stringify(body):undefined});return {status:r.status,data:await r.json()};};
 for(let i=0;i<40;i++){try{await req('/api/ai/health');break;}catch{await new Promise(r=>setTimeout(r,100));}}
 assert.equal((await req('/api/channel/feed')).status,401);
 const owner=jwt('owner','owner@example.com'),a=jwt('a','a@example.com'),b=jwt('b','b@example.com');
 assert.equal((await req('/api/channel/feed',a)).data.signals.length,0);
 const grant={uid:'a',product:'monthly',paymentId:'verified-payment',startsAt:now-2000,until:now+86400000};
 assert.equal((await req('/api/channel/grant',a,grant)).status,403);
 assert.equal((await req('/api/channel/grant',owner,grant)).data.ok,true);
 const result=await req('/api/channel/feed',a);assert.equal(result.status,200);assert.equal(result.data.signals.length,30);assert.equal(result.data.allowance.remaining,0);
 assert.equal((await req('/api/channel/feed',b)).data.signals.length,0);
 assert.equal((await req('/api/channel/feed',owner)).data.signals.length,40);
 assert.equal((await req('/api/channel/grant',owner,{uid:'b',product:'channel',paymentId:'channel-payment',startsAt:now-2000,until:now+86400000})).data.ok,true);
 assert.equal((await req('/api/ai/explain',b,{context:{}})).data.code,'platform_plan_required');
});
