import test from 'node:test';
import assert from 'node:assert/strict';
import { binanceGet, binanceBases } from '../src/services/market/binance.js';

test('binanceGet falls back to the next host when the first is blocked, and remembers the good one', async () => {
  const real = globalThis.fetch;
  const calls = [];
  globalThis.fetch = async (url) => {
    calls.push(String(url));
    if (!String(url).startsWith('https://api.binance.com')) throw new TypeError('blocked');
    return new Response(JSON.stringify([1]), { status: 200 });
  };
  try {
    assert.deepEqual(await binanceGet('/api/v3/x'), [1]);
    assert.ok(calls.length >= 3 && calls.at(-1).startsWith('https://api.binance.com'));
    assert.ok(binanceBases()[0].startsWith('https://api.binance.com'));   // remembered
    calls.length = 0;
    await binanceGet('/api/v3/x');
    assert.equal(calls.length, 1);
  } finally { globalThis.fetch = real; }
});

test('a real error answer (bad symbol) is not retried on other hosts', async () => {
  const real = globalThis.fetch; let n = 0;
  globalThis.fetch = async () => { n++; return new Response(JSON.stringify({ msg: 'Invalid symbol.' }), { status: 400 }); };
  try { await assert.rejects(() => binanceGet('/api/v3/x')); assert.equal(n, 1); } finally { globalThis.fetch = real; }
});
