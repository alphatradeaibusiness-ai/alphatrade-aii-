import test from 'node:test';
import assert from 'node:assert';

const mem = new Map();
globalThis.localStorage = { getItem: (k) => (mem.has(k) ? mem.get(k) : null), setItem: (k, v) => mem.set(k, String(v)), removeItem: (k) => mem.delete(k) };

test('plans only add, never remove, and quotas grow with the plan', async () => {
  const { TIERS, PLAN_ORDER, FEATURE_RANK } = await import('../src/config/entitlements.js');
  for (let i = 1; i < PLAN_ORDER.length; i++) {
    const a = TIERS[PLAN_ORDER[i - 1]]; const b = TIERS[PLAN_ORDER[i]];
    assert.ok(b.rank > a.rank && b.aiPerMonth > a.aiPerMonth && b.aiCarryMonths >= a.aiCarryMonths);
  }
  assert.deepEqual(PLAN_ORDER.map((p) => TIERS[p].aiPerMonth), [30, 60, 100, 150, 200, 300, 500]);   // v276: + prime, apex, max
  assert.ok(Object.values(FEATURE_RANK).every((r) => r >= 1 && r <= 4));
});

test('planFor returns the cheapest plan that unlocks a feature', async () => {
  const { planFor } = await import('../src/config/entitlements.js');
  assert.equal(planFor('frvp'), 'quarterly');
  assert.equal(planFor('quant'), 'semiannual');
  assert.equal(planFor('earlyAccess'), 'annual');
});

test('enforcement off: nothing is locked and AI is never blocked', async () => {
  const { ENFORCE, can, canTab, currentPlan, consumeAi, aiAllowance } = await import('../src/config/entitlements.js');
  assert.equal(ENFORCE, false);
  assert.equal(currentPlan(), 'max');   // v276: the top plan is now Max
  assert.ok(can('multiScreen') && canTab('radar-multi'));
  const before = aiAllowance().used;
  for (let i = 0; i < 600; i++) assert.equal(consumeAi(), true); // beyond the 500 quota
  assert.equal(aiAllowance().used, before + 600);
});

test('last month unused analyses carry over, capped by the plan', async () => {
  const { aiAllowance } = await import('../src/config/entitlements.js');
  const d = new Date(); d.setUTCMonth(d.getUTCMonth() - 1, 1);
  const prev = `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}`;
  mem.set('ai-usage', JSON.stringify({ [prev]: 100 })); // storage key may be namespaced; check below
  const a = aiAllowance();
  assert.ok(a.carry >= 0 && a.carry <= a.quota * 3 && a.total === a.quota + a.carry);
});

test('v276: side-menu pages map to the cheapest plan that opens them; Elite and EDH are untouched', async () => {
  const { navPlan, canNav, NAV_RANK, PLAN_ORDER, TIERS } = await import('../src/config/entitlements.js');
  assert.equal(navPlan('liquidity'), 'max');
  assert.equal(navPlan('council'), 'apex');
  assert.equal(navPlan('studio'), 'prime');
  assert.equal(navPlan('radar'), 'quarterly');
  for (const id of ['home', 'ai-signal', 'elite', 'signals', 'support', 'billing']) assert.equal(navPlan(id), null, id);
  assert.ok(Object.values(NAV_RANK).every((r) => r >= 1 && r <= TIERS[PLAN_ORDER.at(-1)].rank));
  assert.ok(Object.keys(NAV_RANK).every((id) => canNav(id)), 'not enforced: nothing locked');
});
test('v276: the three premium plans are priced 750 / 850 / 1000 and only show a real saving', async () => {
  const { PLANS, planMath } = await import('../src/config/billing.js');
  const by = Object.fromEntries(PLANS.map((p) => [p.id, p]));
  assert.deepEqual([by.prime.price, by.apex.price, by.max.price], [750, 850, 1000]);
  // saving is versus 12 × monthly ($960): real for Prime and Apex, none for Max (never a negative or invented saving)
  assert.deepEqual(['prime', 'apex', 'max'].map((id) => planMath(by[id]).saving), [210, 110, 0]);
  assert.ok(planMath(by.annual).saving > 0);
});
