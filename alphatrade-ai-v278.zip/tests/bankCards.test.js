// v151 virtual card details: unique 16-digit test numbers, derived CVV, encrypted storage, identity check on the request form, art, Apple Pay.
import test from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { openDb } from '../server/bank/db.js';
import { createVault } from '../server/bank/vault.js';
import { createBank } from '../server/bank/service.js';
import { decryptPayload } from '../server/bank/webpush.js';
import { makeAuthenticator } from './helpers/fakeAuthenticator.js';

const OWNER = { uid: 'owner' };
const DAY = 86400_000;
const GOOD_IBAN = 'DE89370400440532013000';
const GB_IBAN = 'GB82WEST12345698765432';
const ADDR = { country: 'DE', region: 'BE', city: 'Berlin', postal: '10115', line1: 'Invalidenstrasse 1' };
const RP = { rpId: 'localhost', origins: ['http://localhost'] };

function setup({ mode = 'sandbox', start = Date.UTC(2026, 9, 27, 12), ...extra } = {}) {
  let t = start; const db = openDb(':memory:'); const pushes = [];
  const bank = createBank({
    db, vault: createVault({ secret: 'z'.repeat(40) }), mode, now: () => t,
    priceFn: async () => ({ price: 50000, ts: t }),
    rateFn: async () => ({ usdPer: { USD: 1, EUR: 1.1, USDT: 1, BTC: 50000 }, ts: t, sources: {} }),
    pushSender: async (sub, payload) => { pushes.push({ sub, payload }); return { ok: true }; },
    config: { beneficiaryCooldown: 1000 }, ...extra,
  });
  return { db, bank, pushes, tick: (ms) => { t += ms; }, now: () => t };
}
const kyc = (b, uid, tier = 1) => {
  if (tier === 2 && b.kycStatus(uid).tier < 1) kyc(b, uid, 1);
  if (b.kycStatus(uid).tier >= tier) return;
  b.submitKyc(uid, { tier, fullName: 'Ada Lovelace', dob: '1990-05-05', nationality: 'DE', address: ADDR, idType: 'passport', idNumber: 'C' + Buffer.from(String(uid)).toString('hex').slice(0, 14), idExpiry: '2031-01-01', sourceOfFunds: 'salary', proofOfAddressRef: 'vend-123' });
  b.reviewKyc(OWNER, uid, 'approve');
};
let n = 0; const k = () => `key-${++n}-abcdef`;
const fund = (b, uid, cur, amt) => b.sandboxFund(uid, { currency: cur, amount: amt, idem: k() });
const bal = (b, uid, cur) => b.wallet(uid).find((w) => w.currency === cur);
const code = (fn) => { try { fn(); } catch (e) { return e.code; } return 'NO_ERROR'; };
const acode = async (fn) => { try { await fn(); } catch (e) { return e.code; } return 'NO_ERROR'; };
const ok = (bank) => assert.deepEqual(bank.ledger.verify(), { ok: true, problems: [] });

import { luhnOk } from '../server/bank/features/vcards.js';
const mk = (bank, extra = {}) => bank.vcards.create('u1', { holder: 'Ada Lovelace', dob: '1990-05-05', label: 'web', ...extra });

test('card details: unique Luhn-valid 16-digit test numbers; CVV derived (never stored); number only encrypted at rest', () => {
  const { bank, db } = setup(); kyc(bank, 'u1', 2);
  const a = mk(bank); const b = mk(bank, { label: 'two' });
  const ra = bank.vcards.reveal('u1', a.id); const rb = bank.vcards.reveal('u1', b.id);
  assert.match(ra.pan, /^400000\d{10}$/); assert.ok(luhnOk(ra.pan)); assert.match(ra.cvv, /^\d{3}$/);
  assert.notEqual(ra.pan, rb.pan); assert.equal(ra.pan.slice(-4), a.last4); assert.equal(ra.holder, 'ADA LOVELACE');
  assert.equal(bank.vcards.reveal('u1', a.id).cvv, ra.cvv);   // the same card always derives the same CVV
  const row = db.prepare('SELECT * FROM vcards WHERE id = ?').get(a.id);
  const dump = JSON.stringify(row);
  assert.ok(!dump.includes(ra.pan) && !dump.includes(ra.pan.slice(0, 12)), 'number is not stored in clear');
  assert.ok(!db.prepare("SELECT group_concat(detail) d FROM audit").get().d?.includes(ra.pan), 'number is not in the audit log');
  assert.equal(code(() => bank.vcards.reveal('u2', a.id)), 'card_not_found');
  ok(bank);
});
test('card request form: name and date of birth must match the verified KYC; repeated misses lock the form', () => {
  const { bank } = setup(); kyc(bank, 'u1', 2);
  assert.equal(code(() => mk(bank, { holder: 'Grace Hopper' })), 'verification_failed');
  assert.equal(code(() => mk(bank, { dob: '1991-05-05' })), 'verification_failed');
  assert.equal(code(() => mk(bank, { holder: 'Ada' })), 'verification_failed');   // a first name alone is not enough
  assert.equal(code(() => mk(bank, { holder: 'ada  LOVELACE' })), 'NO_ERROR');   // case and spacing do not matter
  for (let i = 0; i < 4; i++) code(() => mk(bank, { holder: 'Nobody Else' }));
  assert.equal(code(() => mk(bank)), 'too_many_attempts');
  assert.equal(code(() => bank.requestCard('u1', { product: 'virtual', nameOnCard: 'ADA LOVELACE', phone: '+49 30 1234567', dob: '1990-05-05', consents: { terms: true, fees: true, dataSharing: true }, idem: k() })), 'too_many_attempts');
});
test('card art: colour and pattern come from a fixed list and can be changed later', () => {
  const { bank } = setup(); kyc(bank, 'u1', 2);
  assert.equal(code(() => mk(bank, { art: 'neon:lines' })), 'bad_art');
  const c = mk(bank, { art: 'sage:waves' }); assert.equal(c.art, 'sage:waves');
  assert.equal(bank.vcards.update('u1', c.id, { art: 'plum:dots' }).art, 'plum:dots');
  assert.equal(code(() => bank.vcards.update('u1', c.id, { art: '<script>:x' })), 'bad_art');
});
test('card details are rate-limited and refused for closed cards; Apple Pay needs an issuer that supports it', () => {
  const { bank, tick } = setup(); kyc(bank, 'u1', 2); const c = mk(bank);
  for (let i = 0; i < 10; i++) bank.vcards.reveal('u1', c.id);
  assert.equal(code(() => bank.vcards.reveal('u1', c.id)), 'too_many_reveals');
  tick(3600_000 + 1); assert.ok(bank.vcards.reveal('u1', c.id).pan);
  assert.equal(code(() => bank.vcards.appleWallet('u1', c.id, {})), 'apple_pay_unavailable');
  bank.vcards.action('u1', c.id, 'close'); assert.equal(code(() => bank.vcards.reveal('u1', c.id)), 'card_not_found');
});
test('Apple Pay provisioning: with a supporting issuer the request is validated and the issuer payload returned', () => {
  const issuer = { name: 'fake', create: () => ({ ref: 'fk_1', last4: '1234', exp: '12/29' }), reveal: () => ({ token: 't' }), setStatus: () => true,
    provisionApplePay: (ref, req) => ({ encryptedPassData: `E:${ref}:${req.nonce}`, activationData: 'A', ephemeralPublicKey: 'K' }) };
  const { bank } = setup({ issuer }); kyc(bank, 'u1', 2); const c = mk(bank);
  assert.equal(bank.vcards.applePay(), true);
  assert.equal(code(() => bank.vcards.appleWallet('u1', c.id, { certificates: [], nonce: 'abcdefgh', nonceSignature: 'abcdefgh' })), 'bad_certificate');
  assert.equal(code(() => bank.vcards.appleWallet('u1', c.id, { certificates: ['<x>'], nonce: 'abcdefgh', nonceSignature: 'abcdefgh' })), 'bad_certificate');
  const r = bank.vcards.appleWallet('u1', c.id, { certificates: ['QUJDREVGR0g='], nonce: 'abcdefgh', nonceSignature: 'abcdefgh' });
  assert.equal(r.encryptedPassData, 'E:fk_1:abcdefgh');
  const rv = bank.vcards.reveal('u1', c.id); assert.equal(rv.pan, undefined); assert.equal(rv.issuerToken, 't');   // a real issuer's number never reaches us
});
