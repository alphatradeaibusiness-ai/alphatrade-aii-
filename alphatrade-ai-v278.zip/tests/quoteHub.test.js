// v243: the one-second price hub — many visitors, one upstream call per symbol per second; failures back off; the endpoint.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import http from 'node:http';
import { spawn } from 'node:child_process';
import { createQuoteHub, parseYahooQuote } from '../server/quoteHub.js';

const yahooBody = (price) => ({ chart: { result: [{ meta: { regularMarketPrice: price, regularMarketChangePercent: 0.5, regularMarketDayHigh: price + 1, regularMarketDayLow: price - 1, regularMarketTime: 1_793_000_000 }, indicators: { quote: [{ close: [price - 0.2, price] }] } }] } });

test('quote hub: 500 visitors at once → one upstream call per symbol; refreshed about once a second while watched', async () => {
  let t = 1_000_000; let calls = 0; let price = 4000;
  const fetchFn = async () => { calls += 1; return { ok: true, json: async () => yahooBody(price) }; };
  const hub = createQuoteHub({ symbolMap: { XAUUSD: 'GC=F', US30: '^DJI' }, fetchFn, now: () => t, ttlMs: 1000 });
  try {
    const all = await Promise.all(Array.from({ length: 500 }, () => hub.get(['XAUUSD', 'US30', 'NOPE'])));
    assert.equal(calls, 2, 'two symbols → two upstream calls, not 1000');
    assert.equal(all[499].XAUUSD.price, 4000); assert.equal(all[0].NOPE, undefined);
    price = 4001; t += 500; assert.equal((await hub.get(['XAUUSD'])).XAUUSD.price, 4000, 'within the second: the cached price');
    assert.equal(calls, 2);
  } finally { hub.stop(); }
});

test('quote hub: a failing upstream backs off instead of being hammered, and the last good price is kept', async () => {
  let t = 2_000_000; let calls = 0; let ok = true;
  const fetchFn = async () => { calls += 1; if (!ok) throw new Error('blocked'); return { ok: true, json: async () => yahooBody(10) }; };
  const hub = createQuoteHub({ symbolMap: { USOIL: 'CL=F' }, fetchFn, now: () => t, ttlMs: 1000, log: { warn() {} } });
  try {
    assert.equal((await hub.get(['USOIL'])).USOIL.price, 10);
    ok = false; t += 2000;
    // the background refresh is a timer; simulate its calls directly through get after expiry
    for (let i = 0; i < 20; i++) { t += 100; await hub.get(['USOIL']); }
    assert.ok(calls <= 2, `no storm of retries (${calls} calls)`);
    assert.equal(parseYahooQuote({ chart: { result: [{ meta: {}, indicators: { quote: [{ close: [null] }] } }] } }), null);
  } finally { hub.stop(); }
});

test('server: GET /api/market/quotes — shared live prices, symbols validated, per-IP limit', async () => {
  let up = 0;
  const yahoo = http.createServer((q, r) => { up += 1; r.writeHead(200, { 'content-type': 'application/json' }); r.end(JSON.stringify(yahooBody(q.url.includes('GC%3DF') ? 4065.25 : 47000))); });
  await new Promise((r) => yahoo.listen(0, '127.0.0.1', r));
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'qh-')); const port = 20000 + Math.floor(Math.random() * 20000);
  const child = spawn(process.execPath, ['--no-warnings', 'server/index.js'], { env: { ...process.env, NODE_ENV: 'test', SERVER_PORT: String(port), SERVER_DATA_DIR: dir, AI_KEY_SECRET: 'q'.repeat(40), MARKET_PROXY_TEST_BASE: `http://127.0.0.1:${yahoo.address().port}` }, stdio: 'ignore' });
  const get = (p) => new Promise((resolve) => http.get({ host: '127.0.0.1', port, path: p }, (res) => { let s = ''; res.on('data', (c) => (s += c)); res.on('end', () => resolve({ status: res.statusCode, body: (() => { try { return JSON.parse(s); } catch { return null; } })() })); }).on('error', (e) => resolve({ status: e.code })));
  try {
    for (let i = 0; i < 80; i++) { if ((await get('/api/health')).status === 200) break; await new Promise((r) => setTimeout(r, 100)); }
    const r = await get('/api/market/quotes?s=XAUUSD,US30,BTCUSDT,../etc');
    assert.equal(r.status, 200); assert.equal(r.body.quotes.XAUUSD.price, 4065.25); assert.equal(r.body.quotes.US30.price, 47000);
    assert.equal(r.body.quotes.BTCUSDT, undefined, 'crypto is not served here (Binance stream)');
    const before = up; await Promise.all(Array.from({ length: 50 }, () => get('/api/market/quotes?s=XAUUSD,US30')));
    assert.ok(up - before <= 2, `50 visitors → at most one more upstream call per symbol (${up - before})`);
    assert.equal((await get('/api/market/quotes?s=;rm')).status, 400);
    let limited = false; for (let i = 0; i < 320 && !limited; i++) if ((await get('/api/market/quotes?s=XAUUSD')).status === 429) limited = true;
    assert.ok(limited, 'one IP is limited (5 a second)');
  } finally { child.kill(); yahoo.close(); }
});
