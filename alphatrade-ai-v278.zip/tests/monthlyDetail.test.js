import test from 'node:test';
import assert from 'node:assert/strict';
import { monthlyDetail, openFloating, totalOf, monthOf } from '../src/services/monthlyDetail.js';
const T = (iso, points) => ({ closeTime: Date.parse(iso) / 1000, points, r: points / 100 });
test('each month stands alone: counts, gross win/loss, net, averages, streak, drawdown (in pips)', () => {
  const m = monthlyDetail([T('2026-01-05', 100), T('2026-01-06', -50), T('2026-01-07', -50), T('2026-01-08', 200), T('2026-02-03', -30)], 10);
  assert.deepEqual(m.map((x) => x.month), ['2026-01', '2026-02']);
  const j = m[0];
  assert.equal(j.trades, 4); assert.equal(j.wins, 2); assert.equal(j.losses, 2); assert.equal(j.winRate, 50);
  assert.equal(j.grossWinPips, 30); assert.equal(j.grossLossPips, 10); assert.equal(j.netPips, 20);
  assert.equal(j.avgWinPips, 15); assert.equal(j.avgLossPips, 5); assert.equal(j.maxLossStreak, 2); assert.equal(j.maxDrawdownPips, 10);
  assert.equal(m[1].netPips, -3);                       // February is not mixed with January
  const tot = totalOf(m); assert.equal(tot.netPips, 17); assert.equal(tot.trades, 5);
});
test('an open trade is floating, direction-aware, and never part of a month', () => {
  assert.equal(openFloating({ direction: 'long', entry: 100, hits: 0 }, 105, 1, 1).floatingPips, 5);
  assert.equal(openFloating({ direction: 'short', entry: 100, hits: 0 }, 105, 1, 1).floatingPips, -5);
  assert.equal(openFloating({ direction: 'long', entry: 100 }, NaN, 1, 1), null);
  assert.deepEqual(monthlyDetail([], 10), []);
  assert.equal(monthOf(Date.parse('2026-10-05T00:00:00Z') / 1000), '2026-10');
});
