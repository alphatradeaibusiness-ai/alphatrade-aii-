// Coalesced store writes (v229, from the load test). The members / community / channel stores rewrite their whole (encrypted)
// file on every change. Under load that meant one full re-encrypt + disk write per request — the cost grows with the number of
// members, and it blocks the server for every visitor. With write-behind, all changes inside a short window are written ONCE.
//  • delayMs = 0 → write at once (tests and tools keep the old synchronous behaviour)
//  • a write is never delayed more than maxWaitMs, and every pending write is flushed on shutdown (SIGTERM / SIGINT / exit)
//  • the data in memory is always the current state; only the disk copy lags by at most maxWaitMs
const all = new Set();
let hooked = false;
function hook() {
  if (hooked) return; hooked = true;
  const flushAll = () => { for (const w of all) { try { w.flush(); } catch (e) { console.error('[store] flush failed:', e?.message || e); } } };
  process.on('exit', flushAll);   // SIGTERM / SIGINT: server/index.js drains connections, then calls flushAllStores()
}
export function flushAllStores() { for (const w of all) { try { w.flush(); } catch { /* reported by the store */ } } }

// Adaptive: a big store (e.g. 20 000 members) takes longer to encrypt + write, so the window widens to 5× the last write's
// duration (writing then uses at most ~20 % of the server's time), capped at 4× the configured wait.
export function writeBehind(writeNow, { delayMs = 0, maxWaitMs = 1000 } = {}) {
  let timer = null; let first = 0; let dirty = false; let lastMs = 0;
  const flush = () => { if (timer) { clearTimeout(timer); timer = null; } if (!dirty) return; dirty = false; first = 0; const t = performance.now(); writeNow(); lastMs = performance.now() - t; };
  const w = {
    schedule() {
      if (!delayMs) { writeNow(); return; }
      dirty = true; const now = Date.now(); if (!first) first = now;
      const wait = Math.min(Math.max(delayMs, lastMs * 5), maxWaitMs * 4); const cap = Math.max(maxWaitMs, Math.min(lastMs * 10, maxWaitMs * 4));
      if (timer) clearTimeout(timer);
      timer = setTimeout(flush, Math.max(0, Math.min(wait, first + cap - now)));
      timer.unref?.();
    },
    flush,
    pending: () => dirty,
  };
  if (delayMs) { all.add(w); hook(); }
  return w;
}
