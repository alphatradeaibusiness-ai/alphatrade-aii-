// Daily rotating backups of everything the server keeps: the bank database (consistent snapshot with VACUUM INTO),
// the encrypted config files and the encrypted per-user trade files. Files stay encrypted exactly as they are on disk.
//   BACKUP_DIR        where backups go (default SERVER_DATA_DIR/backups). Best on a separate disk / mounted bucket.
//   BACKUP_KEEP_DAYS  how many daily backups to keep (default 14, 1–90)
//   BACKUP_DISABLED=1 turn it off
import fs from 'node:fs';
import path from 'node:path';

const DAY = 86_400_000;
const stamp = (ms) => new Date(ms).toISOString().slice(0, 10);

export function createBackups({ dataDir, env = process.env, snapshotBank = null, now = Date.now, log = console }) {
  const dir = path.resolve(env.BACKUP_DIR || path.join(dataDir, 'backups'));
  const keep = Math.max(1, Math.min(90, Number(env.BACKUP_KEEP_DAYS) || 14));
  const disabled = env.BACKUP_DISABLED === '1';
  let last = null; let lastError = null;

  const list = () => { try { return fs.readdirSync(dir).filter((n) => /^\d{4}-\d{2}-\d{2}$/.test(n)).sort(); } catch { return []; } };
  function copyTree(from, to) {
    if (!fs.existsSync(from)) return 0;
    let n = 0;
    for (const e of fs.readdirSync(from, { withFileTypes: true })) {
      const a = path.join(from, e.name);
      if (path.resolve(a) === dir || e.name === 'backups' || e.name === 'bank') continue;   // never back up the backups; bank.db goes via VACUUM
      if (e.isDirectory()) { n += copyTree(a, path.join(to, e.name)); continue; }
      if (!e.isFile() || !/\.(json|jsonl)$/.test(e.name)) continue;
      fs.mkdirSync(to, { recursive: true, mode: 0o700 }); fs.copyFileSync(a, path.join(to, e.name)); n++;
    }
    return n;
  }
  function prune() {
    const all = list(); const drop = all.slice(0, Math.max(0, all.length - keep));
    for (const d of drop) fs.rmSync(path.join(dir, d), { recursive: true, force: true });
    return drop.length;
  }
  /** Make today's backup if it does not exist yet (or always with force). */
  function run({ force = false } = {}) {
    if (disabled) return { skipped: 'disabled' };
    const day = stamp(now()); const out = path.join(dir, day);
    if (!force && fs.existsSync(path.join(out, 'DONE'))) return { skipped: 'exists', day };
    const tmp = `${out}.partial`;
    try {
      fs.rmSync(tmp, { recursive: true, force: true }); fs.mkdirSync(tmp, { recursive: true, mode: 0o700 });
      let bank = false;
      if (snapshotBank) { snapshotBank(path.join(tmp, 'bank.db')); bank = true; }
      const files = copyTree(dataDir, path.join(tmp, 'data'));
      const info = { at: now(), bank, files };
      fs.writeFileSync(path.join(tmp, 'DONE'), JSON.stringify(info));
      fs.rmSync(out, { recursive: true, force: true }); fs.renameSync(tmp, out);
      const pruned = prune(); last = info.at; lastError = null;
      return { ok: true, day, ...info, pruned };
    } catch (e) {
      fs.rmSync(tmp, { recursive: true, force: true }); lastError = String(e?.message || e).slice(0, 120);
      log.error?.('[backup] failed:', lastError); return { ok: false, error: lastError };
    }
  }
  function start() {
    if (disabled) return () => {};
    const first = setTimeout(() => run(), 60_000); first.unref?.();
    const timer = setInterval(() => run(), DAY / 24); timer.unref?.();   // hourly check; makes at most one per day
    return () => { clearTimeout(first); clearInterval(timer); };
  }
  const status = () => {
    const all = list();
    if (!last && all.length) { try { last = JSON.parse(fs.readFileSync(path.join(dir, all.at(-1), 'DONE'), 'utf8')).at; } catch { /* */ } }
    return { enabled: !disabled, count: all.length, keep, last, error: lastError, stale: !disabled && (!last || now() - last > 2 * DAY) };
  };
  return { run, start, status, dir };
}
