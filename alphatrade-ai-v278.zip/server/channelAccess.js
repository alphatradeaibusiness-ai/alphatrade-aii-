import fs from 'node:fs';
import path from 'node:path';
import { CHANNEL_PLANS, CHANNEL_PRODUCTS, channelPeriod } from '../src/config/channelPlans.js';
import { writeBehind } from './writeBehind.js';

// One server process, persistent disk. Never accepts an entitlement from browser storage.
// v229 (load test): the file was read + parsed on EVERY call (each feed poll, each plan check) and rewritten on every feed poll of
// a subscriber even when nothing changed. Now: the parsed copy is kept in memory and re-read only if the file changed on disk
// (stat check), feed() writes only when a grant / refund / snapshot really changed, and those writes are coalesced.
// Payments (grant / remove) are still written to disk at once.
export function createChannelAccess(dir, { writeDelayMs = 0 } = {}) {
  const file = path.join(dir, 'channel-accounts.json');
  let mem = null; let memStat = '';
  const statKey = () => { try { const s = fs.statSync(file); return `${s.mtimeMs}|${s.size}`; } catch { return 'none'; } };
  const writeNow = () => { fs.mkdirSync(dir, { recursive: true }); fs.writeFileSync(file + '.tmp', JSON.stringify(mem), { mode: 0o600 }); fs.renameSync(file + '.tmp', file); memStat = statKey(); };
  const writer = writeBehind(writeNow, { delayMs: writeDelayMs });
  const load = () => {
    if (mem && (writer.pending() || statKey() === memStat)) return mem;
    try { mem = JSON.parse(fs.readFileSync(file, 'utf8')); } catch (e) { if (e.code === 'ENOENT') mem = {}; else throw e; }
    memStat = statKey(); return mem;
  };
  const save = (db, { now = true } = {}) => { mem = db; writer.schedule(); if (now) writer.flush(); };
  return {
    subscription(uid, now = Date.now()) {
      const db=load(), a=Object.hasOwn(db,uid)?db[uid]:null, s=a?.subscription;
      return s && s.startsAt<=now && s.until>now ? s : null;
    },
    /** Account deletion: drop the plan and history, keep only the used payment references (so a replayed payment cannot be granted again). */
    remove(uid) { const db=load(); if(!Object.hasOwn(db,uid)) return false; db[uid]={ grants:{}, addons:[], purchases: db[uid].purchases||[], deleted:true }; save(db); return true; },
    account(uid, now = Date.now()) { const db=load(), a=Object.hasOwn(db,uid)?db[uid]:null; if(!a) return null; return { subscription: a.subscription||null, addons:(a.addons||[]).filter(x=>x.until>now).map(x=>({count:x.count,until:x.until})) }; },
    allAccounts() { return load(); },
    channelOnly(uid) { const db=load();return Object.hasOwn(db,uid)&&db[uid].subscription?.product==='channel'; },
    // Owner-only HTTP route calls this after checking payment. External payment systems can use the same route.
    grant(uid, input, now = Date.now()) {
      if (typeof uid !== 'string' || !uid || uid.length > 128 || ['__proto__','constructor','prototype'].includes(uid)) throw new Error('invalid_uid');
      const db = load(), account = Object.hasOwn(db, uid) ? db[uid] : { grants: {}, purchases: [], addons: [] };
      const { product, paymentId } = input;
      if (typeof paymentId !== 'string' || !paymentId.trim() || paymentId.length > 200) throw new Error('payment_reference_required');
      // A payment reference can only ever be used once, including across accounts.
      for (const a of Object.values(db)) if (a.purchases?.includes(paymentId)) return { duplicate: true };
      if (CHANNEL_PLANS[product]) {
        const startsAt = Number(input.startsAt ?? now), until = Number(input.until);
        if (!Number.isFinite(startsAt) || !Number.isFinite(until) || until <= startsAt || until <= now) throw new Error('invalid_dates');
        if (account.subscription && account.subscription.until > now && account.subscription.product !== product && input.replace !== true) throw new Error('explicit_replacement_required');
        account.subscription = { product, startsAt, until };
      } else {
        const addon = CHANNEL_PRODUCTS.find(p => p.id === product && p.kind === 'addon');
        const sub = account.subscription, period = sub && channelPeriod(sub.startsAt, now);
        if (!addon || !period || sub.until <= now) throw new Error('active_subscription_required');
        account.addons ||= [];
        account.addons.push({ paymentId, count: addon.count, startsAt: now, until: Math.min(sub.until, period.end) });
      }
      account.purchases ||= []; account.purchases.push(paymentId); db[uid] = account; save(db);
      return { ok: true };
    },
    feed(uid, signals, { now = Date.now(), owner = false, configured = true } = {}) {
      const db = load(), account = Object.hasOwn(db, uid) ? db[uid] : { grants: {}, addons: [] };
      account.grants ||= {};
      const sub = account.subscription;
      const period = sub && channelPeriod(sub.startsAt, now);
      const enabled = Boolean(period && now < sub.until && CHANNEL_PLANS[sub.product]);
      const plan = enabled ? sub.product : null, spec = CHANNEL_PLANS[plan];
      const extra = enabled ? (account.addons || []).filter(a => a.until > now && a.startsAt <= now).reduce((n,a)=>n+a.count,0) : 0;
      const total = (spec?.quota || 0) + extra;
      const rows = signals.filter(s => s && typeof s.id === 'string' && Number.isFinite(s.createdAt)).sort((a,b)=>a.createdAt-b.createdAt || a.id.localeCompare(b.id));
      // Unfilled cancelled/expired recommendations release their quota; original grants remain for history.
      let changed = false;
      for (const s of rows) if (account.grants[s.id] && ['cancelled','expired'].includes(s.status) && !s.activatedAt && s.order === 'limit' && !account.grants[s.id].refunded) { account.grants[s.id].refunded = true; changed = true; }
      const usedCount = () => period ? Object.values(account.grants).filter(g=>!g.refunded && g.at>=period.start && g.at<period.end).length : 0;
      let used = usedCount();
      for (const s of rows) {
        if (Object.hasOwn(account.grants,s.id) || !enabled || used >= total || s.createdAt < period.start || s.createdAt < sub.startsAt || s.createdAt >= sub.until || s.createdAt > now || !['active','pending'].includes(s.status)) continue;
        account.grants[s.id] = { at: now, refunded: false }; used++; changed = true;
      }
      for (const s of rows) if (Object.hasOwn(account.grants, s.id)) { const g = account.grants[s.id]; if (g.snapshot !== s && JSON.stringify(g.snapshot) !== JSON.stringify(s)) { g.snapshot = s; changed = true; } }
      if (changed && (Object.keys(account.grants).length || Object.hasOwn(db,uid))) { db[uid]=account; save(db, { now: false }); }
      const view=owner?'complete':spec?.view || 'essential';
      const visible=(owner?rows:Object.values(account.grants).map(g=>g.snapshot).filter(Boolean)).sort((a,b)=>b.createdAt-a.createdAt).map(s=>view==='essential'?{...s,confirm:null,score:null,accuracy:null,trades:null,evidence:s.evidence?{...s.evidence,zones:[]}:null}:s);
      return { configured, signals: visible, allowance: { plan, channelOnly: sub?.product==='channel', view, total: owner?null:total, used: owner?0:used, remaining: owner?null:Math.max(0,total-used), renewsAt: period ? Math.min(period.end,sub.until) : null, active: enabled || owner, owner } };
    },
  };
}
