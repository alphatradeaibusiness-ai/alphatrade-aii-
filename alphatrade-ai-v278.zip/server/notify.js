// Phone-alert channels (Telegram bot + ntfy topic) that the owner can set from the website instead of editing .env.
// The values live only on the server, encrypted (same AES-256-GCM store as the AI key, file notify-config.json) and are
// never sent back to the browser — the owner only sees "set" flags and the last characters. The worker reads the same file.
import { sendTelegram } from './telegram.js';

const TOKEN_RE = /^\d{5,}:[A-Za-z0-9_-]{30,}$/;      // 123456789:AAH… (from @BotFather)
const CHAT_RE = /^(-?\d{3,20}|@[A-Za-z][A-Za-z0-9_]{4,31})$/;
const TOPIC_RE = /^[A-Za-z0-9_-]{8,64}$/;           // ntfy topic: anyone who knows it can read it, so require a long, unguessable one

export const NTFY_BASE = 'https://ntfy.sh/';

/** Cleans the owner's input. Empty fields mean "leave as is". Returns { value:{telegramToken?,telegramChatId?,ntfyTopic?}, error? } */
export function cleanNotify(input) {
  const v = {}; const s = (x) => (typeof x === 'string' ? x.trim() : '');
  const token = s(input?.telegramToken); const chat = s(input?.telegramChatId); const topic = s(input?.ntfyTopic);
  if (token) { if (!TOKEN_RE.test(token)) return { error: 'telegram_token_format' }; v.telegramToken = token; }
  if (chat) { if (!CHAT_RE.test(chat)) return { error: 'telegram_chat_format' }; v.telegramChatId = chat; }
  if (topic) { if (!TOPIC_RE.test(topic)) return { error: 'ntfy_topic_format' }; v.ntfyTopic = topic; }
  return { value: v };
}

export async function sendNtfy({ topic, title, body, fetchImpl = fetch, base = NTFY_BASE, timeoutMs = 10_000 }) {
  if (!topic) return { ok: false, status: 'not-configured' };
  const ctrl = new AbortController(); const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetchImpl(base, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ topic, title: `AlphaTrade AI · ${String(title || '').slice(0, 200)}`, message: String(body || '').slice(0, 3500), priority: 4 }), signal: ctrl.signal });
    return { ok: Boolean(res.ok), status: res.status };
  } catch (err) {
    return { ok: false, status: String(err?.name === 'AbortError' ? 'timeout' : err?.message || 'error').split(topic).join('***') };
  } finally { clearTimeout(timer); }
}

/** Channels in force: what the owner saved on the site wins, the .env values are the fallback. */
export function effectiveNotify(stored, env = process.env) {
  return {
    telegramToken: stored?.telegramToken || env.TELEGRAM_BOT_TOKEN || '',
    telegramChatId: stored?.telegramChatId || env.TELEGRAM_CHAT_ID || '',
    ntfyTopic: stored?.ntfyTopic || env.ALERT_TOPIC || '',
  };
}
export const parseStored = (rec) => { try { const o = JSON.parse(rec?.apiKey || ''); return o && typeof o === 'object' ? o : null; } catch { return null; } };

/** Sends one message to every configured channel. { telegram:{ok,status}|null, ntfy:{...}|null } — never throws. */
export async function sendAll(cfg, { title, body }, { fetchImpl = fetch, ntfyBase = NTFY_BASE, telegramBase } = {}) {
  const out = { telegram: null, ntfy: null };
  if (cfg.telegramToken && cfg.telegramChatId) out.telegram = await sendTelegram({ token: cfg.telegramToken, chatId: cfg.telegramChatId, title, body, fetchImpl, base: telegramBase });
  if (cfg.ntfyTopic) out.ntfy = await sendNtfy({ topic: cfg.ntfyTopic, title, body, fetchImpl, base: ntfyBase });
  return out;
}

/** For the worker: reads the saved config (re-read at most every `ttl` ms so a change on the site applies without a restart). */
export function createNotifier({ store, env = process.env, ttl = 10_000, fetchImpl = fetch, now = Date.now } = {}) {
  let cache = null; let at = -Infinity;
  const config = () => { if (now() - at > ttl) { cache = effectiveNotify(parseStored(store?.load?.()), env); at = now(); } return cache; };
  return {
    config,
    configured: () => { const c = config(); return { telegram: Boolean(c.telegramToken && c.telegramChatId), ntfy: Boolean(c.ntfyTopic) }; },
    send: (msg) => sendAll(config(), msg, { fetchImpl }),
  };
}
