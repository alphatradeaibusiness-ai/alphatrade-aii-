// Community & owner features (v198):
//   • Feedback & reports — ratings, suggestions and bug reports with up to 3 images; status New → Under review → In progress →
//     Resolved; the owners reply and the customer is notified.
//   • Live support calls — WebRTC voice calls between a customer and the owners. This server only relays the call set-up
//     (offer / answer / ICE candidates, kept in memory for the call's life); the audio goes browser-to-browser, encrypted
//     by WebRTC (DTLS-SRTP). TURN_URL / TURN_USER / TURN_PASS add a relay for networks where direct calls fail.
//   • Live broadcasts — an owner goes live FROM THE SITE (camera / screen + mic over WebRTC, no external service) or with a
//     YouTube / Vimeo / Twitch / other https stream link (title, topic, host);
//     every member gets an in-app notice + phone push + Telegram; the owner ends it.
//   • Plans & coupons — owners change plan prices, durations and on/off; coupons (percent or fixed, dates, use limit, plans,
//     on/off) with usage and total discount; checkout applies a coupon on the server (the browser never sets a price).
//   • Business analytics — recommendations generated / saved by customers, closed results (wins, losses, R, points, money),
//     active customers; an automatic report for every finished month, sent to the owners (in-app, push, Telegram, e-mail
//     via Resend when RESEND_API_KEY is set) and kept for download. "Executed trades" are only those confirmed by a broker:
//     the app has no broker connection, so it reports 0 verified executions and never counts a recommendation as executed.
// Everything is kept in one file encrypted with AES-256-GCM (key from AI_KEY_SECRET); images in separate encrypted files.
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';

const DAY = 86_400_000;
const clip = (s, n) => String(s ?? '').replace(/[\u0000-\u0008\u000b-\u001f]/g, ' ').trim().slice(0, n);
const rid = (p) => `${p}${crypto.randomBytes(6).toString('hex')}`;
export const FEEDBACK_KINDS = ['rating', 'suggestion', 'bug'];
export const FEEDBACK_STATUS = ['new', 'review', 'progress', 'resolved'];
const IMG_RE = /^data:image\/(png|jpeg|webp);base64,([A-Za-z0-9+/=]+)$/;
const MAX_IMG = 1_500_000;   // bytes after decoding
const CODE_RE = /^[A-Z0-9]{4,20}$/;

/** A safe embeddable URL for a stream link, or null. YouTube watch/short links become embed links. */
export function embedUrl(raw, parent = 'localhost') {
  let u; try { u = new URL(String(raw || '').trim()); } catch { return null; }
  if (u.protocol !== 'https:') return null;
  const host = u.hostname.toLowerCase();
  if (host === 'youtu.be') return `https://www.youtube-nocookie.com/embed/${encodeURIComponent(u.pathname.slice(1, 40))}?autoplay=1`;
  if (host.endsWith('youtube.com')) {
    const id = u.searchParams.get('v') || (u.pathname.match(/\/(?:live|embed|shorts)\/([\w-]{6,20})/) || [])[1];
    return id ? `https://www.youtube-nocookie.com/embed/${encodeURIComponent(id)}?autoplay=1` : null;
  }
  if (host === 'vimeo.com') { const id = (u.pathname.match(/\/(\d{5,12})/) || [])[1]; return id ? `https://player.vimeo.com/video/${id}?autoplay=1` : null; }
  if (host === 'player.vimeo.com') return u.toString();
  if (host.endsWith('twitch.tv')) { const ch = u.pathname.split('/').filter(Boolean)[0]; return ch && /^\w{3,30}$/.test(ch) ? `https://player.twitch.tv/?channel=${ch}&parent=${encodeURIComponent(parent)}` : null; }
  return null;   // any other https page is offered as a link (opens in a new tab), not embedded
}

export function createCommunity({ dir, secret, now = Date.now, growth = null, userTrades = null, isOwnerEmail = () => false, pointSize = () => 1, env = process.env, log = console } = {}) {
  const key = secret && String(secret).length >= 32 ? crypto.scryptSync(String(secret), 'alphatrade-community-v1', 32) : null;
  const file = path.join(dir, 'community.json');
  const imgDir = path.join(dir, 'feedback-img');
  let db = null;
  const enc = (buf, aad) => { const iv = crypto.randomBytes(12); const c = crypto.createCipheriv('aes-256-gcm', key, iv); c.setAAD(Buffer.from(aad)); const d = Buffer.concat([c.update(buf), c.final()]); return Buffer.concat([iv, c.getAuthTag(), d]); };
  const dec = (buf, aad) => { const d = crypto.createDecipheriv('aes-256-gcm', key, buf.subarray(0, 12)); d.setAAD(Buffer.from(aad)); d.setAuthTag(buf.subarray(12, 28)); return Buffer.concat([d.update(buf.subarray(28)), d.final()]); };
  function load() {
    if (db) return db;
    db = { feedback: [], live: { current: null, history: [] }, plans: {}, coupons: [], recos: {}, reports: {} };
    if (!key) return db;
    try { db = { ...db, ...JSON.parse(dec(fs.readFileSync(file), 'community').toString('utf8')) }; } catch { /* first start or another secret */ }
    return db;
  }
  function save() {
    if (!key) return;
    fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
    const tmp = `${file}.${process.pid}.tmp`; fs.writeFileSync(tmp, enc(Buffer.from(JSON.stringify(db)), 'community'), { mode: 0o600 }); fs.renameSync(tmp, file);
  }
  const notifyUser = (uid, title, body, url, kind) => growth?.deliver?.(uid, { kind, title, body, url, push: true, tg: true, email: null })?.catch?.(() => null);
  const owners = () => (growth?.members?.() || []).filter((m) => isOwnerEmail(m.email));
  const notifyOwners = (title, body, url, kind) => { for (const o of owners()) notifyUser(o.uid, title, body, url, kind); };

  /* ───────── feedback & reports ───────── */
  function submitFeedback(u, b = {}) {
    if (!key) return { error: 'no_secret' };
    const kind = FEEDBACK_KINDS.includes(b.kind) ? b.kind : null; if (!kind) return { error: 'bad_kind' };
    const text = clip(b.text, 2000);
    const rating = b.rating == null ? null : Number(b.rating);
    if (kind === 'rating' && !(Number.isInteger(rating) && rating >= 1 && rating <= 5)) return { error: 'bad_rating' };
    if (kind !== 'rating' && text.length < 5) return { error: 'text_short' };
    const imgs = Array.isArray(b.images) ? b.images.slice(0, 3) : [];
    const d = load();
    if (d.feedback.filter((x) => x.uid === u.uid && now() - x.at < DAY).length >= 20) return { error: 'too_many' };
    const id = rid('f'); const images = [];
    for (const raw of imgs) {
      const m = IMG_RE.exec(String(raw || '')); if (!m) return { error: 'bad_image' };
      const buf = Buffer.from(m[2], 'base64'); if (!buf.length || buf.length > MAX_IMG) return { error: 'image_too_large' };
      const iid = rid('i'); fs.mkdirSync(imgDir, { recursive: true, mode: 0o700 });
      fs.writeFileSync(path.join(imgDir, `${iid}.bin`), enc(Buffer.concat([Buffer.from(`${m[1]}\n`), buf]), `img:${id}`), { mode: 0o600 });
      images.push(iid);
    }
    const item = { id, uid: u.uid, name: clip(u.name || String(u.email || '').split('@')[0], 60), kind, rating: kind === 'rating' ? rating : null, text, images, status: 'new', at: now(), updatedAt: now(), replies: [] };
    d.feedback.unshift(item); d.feedback.length = Math.min(d.feedback.length, 2000); save();
    notifyOwners(kind === 'bug' ? 'بلاغ مشكلة جديد / New bug report' : 'رأي جديد من عميل / New customer feedback', text.slice(0, 140) || `★ ${rating}`, '/#/app/feedback', 'feedback');
    return { item: view(item, false) };
  }
  const view = (x, owner) => ({ id: x.id, kind: x.kind, rating: x.rating, text: x.text, images: x.images, status: x.status, at: x.at, updatedAt: x.updatedAt, replies: x.replies, ...(owner ? { name: x.name, ref: x.uid.slice(0, 6) } : {}) });
  const listFeedback = (u, owner) => ({ items: load().feedback.filter((x) => owner || x.uid === u.uid).slice(0, 300).map((x) => view(x, owner)) });
  function updateFeedback(id, { status, reply } = {}) {
    const x = load().feedback.find((f) => f.id === id); if (!x) return { error: 'not_found' };
    if (status != null) { if (!FEEDBACK_STATUS.includes(status)) return { error: 'bad_status' }; x.status = status; }
    const r = clip(reply, 1000); if (r) x.replies.push({ at: now(), text: r, by: 'team' });
    x.updatedAt = now(); save();
    notifyUser(x.uid, 'رد على بلاغك / Update on your report', r || status, '/#/app/feedback', 'feedback');
    return { item: view(x, true) };
  }
  function feedbackImage(u, owner, iid) {
    if (!/^i[0-9a-f]{12}$/.test(iid)) return null;
    const x = load().feedback.find((f) => f.images.includes(iid)); if (!x || (!owner && x.uid !== u.uid)) return null;
    try { const buf = dec(fs.readFileSync(path.join(imgDir, `${iid}.bin`)), `img:${x.id}`); const nl = buf.indexOf(10); return { type: `image/${buf.subarray(0, nl).toString()}`, data: buf.subarray(nl + 1) }; } catch { return null; }
  }

  /* ───────── live support calls (signalling only, in memory) ───────── */
  const calls = new Map();
  const iceServers = () => {
    const out = [{ urls: ['stun:stun.l.google.com:19302', 'stun:stun1.l.google.com:19302'] }];
    if (env.TURN_URL) out.push({ urls: String(env.TURN_URL).split(',').map((x) => x.trim()).filter(Boolean), username: String(env.TURN_USER || ''), credential: String(env.TURN_PASS || '') });
    return out;
  };
  const sweep = () => { for (const [id, c] of calls) if ((c.status === 'ringing' && now() - c.at > 120_000) || now() - c.at > 3 * 3600_000 || (c.status === 'ended' && now() - c.endedAt > 60_000)) calls.delete(id); };
  const SDP = (s) => typeof s === 'string' && s.length > 20 && s.length < 20_000 && s.startsWith('v=0');
  function startCall(u, { offer } = {}) {
    sweep();
    if (!SDP(offer)) return { error: 'bad_offer' };
    if ([...calls.values()].some((c) => c.uid === u.uid && ['ringing', 'active'].includes(c.status))) return { error: 'call_open' };
    if (calls.size > 200) return { error: 'busy' };
    const c = { id: rid('c'), uid: u.uid, name: clip(u.name || String(u.email || '').split('@')[0], 60), status: 'ringing', at: now(), offer, answer: null, ice: { caller: [], agent: [] }, agent: null };
    calls.set(c.id, c);
    notifyOwners('📞 مكالمة دعم واردة / Incoming support call', c.name, '/#/app/support', 'call');
    return { id: c.id, iceServers: iceServers() };
  }
  function callState(u, owner, id, since = {}) {
    const c = calls.get(id); if (!c || (!owner && c.uid !== u.uid)) return null;
    const mine = owner && c.uid !== u.uid ? 'agent' : 'caller'; const other = mine === 'agent' ? 'caller' : 'agent';
    const from = Math.max(0, Number(since[other]) || 0);
    return { id: c.id, status: c.status, name: c.name, at: c.at, offer: mine === 'agent' ? c.offer : undefined, answer: mine === 'caller' ? c.answer : undefined, ice: c.ice[other].slice(from), iceTotal: c.ice[other].length };
  }
  const listCalls = () => { sweep(); return { items: [...calls.values()].filter((c) => c.status !== 'ended').map((c) => ({ id: c.id, name: c.name, status: c.status, at: c.at })) }; };
  function answerCall(u, id, { answer } = {}) {
    const c = calls.get(id); if (!c) return { error: 'not_found' };
    if (c.status !== 'ringing') return { error: 'not_ringing' };
    if (!SDP(answer)) return { error: 'bad_answer' };
    Object.assign(c, { answer, status: 'active', agent: u.uid, answeredAt: now() });
    return { ok: true, iceServers: iceServers() };
  }
  function addIce(u, owner, id, { candidate } = {}) {
    const c = calls.get(id); if (!c || (!owner && c.uid !== u.uid)) return { error: 'not_found' };
    const side = owner && c.uid !== u.uid ? 'agent' : 'caller';
    if (typeof candidate !== 'string' || candidate.length > 1000 || c.ice[side].length >= 60) return { error: 'bad_candidate' };
    c.ice[side].push(candidate); return { ok: true };
  }
  function endCall(u, owner, id) {
    const c = calls.get(id); if (!c || (!owner && c.uid !== u.uid)) return { error: 'not_found' };
    c.status = 'ended'; c.endedAt = now(); return { ok: true };
  }

  /* ───────── live broadcasts ───────── */
  async function startLive(u, { title, topic, url } = {}, parent) {
    const t = clip(title, 120); if (t.length < 3) return { error: 'bad_title' };
    let link = null; if (url) { try { const x = new URL(String(url)); if (x.protocol === 'https:') link = x.toString().slice(0, 500); } catch { /* */ } if (!link) return { error: 'bad_url' }; }
    const d = load();
    if (d.live.current) d.live.history.unshift({ ...d.live.current, endedAt: now() });
    d.live.current = { id: rid('l'), title: t, topic: clip(topic, 400), host: clip(u.name || String(u.email || '').split('@')[0], 60), url: link, embed: link ? embedUrl(link, parent) : null, mode: link ? 'link' : 'site', startedAt: now() };
    viewers.clear();
    d.live.history.length = Math.min(d.live.history.length, 20); save();
    let sent = 0;
    for (const m of growth?.members?.() || []) { notifyUser(m.uid, `🔴 ${d.live.current.host}: بث مباشر الآن / Live now`, t, '/#/app/live', 'live'); sent++; }
    return { live: d.live.current, sent };
  }
  function endLive() { viewers.clear(); const d = load(); if (!d.live.current) return { ok: true }; d.live.history.unshift({ ...d.live.current, endedAt: now() }); d.live.current = null; save(); return { ok: true }; }

  /* ───────── in-site broadcast (WebRTC from the owner's browser; this server only relays the set-up, in memory) ─────────
     A viewer sends an offer (receive-only, complete ICE inside the SDP); the owner's page answers it with its camera / screen.
     The video goes browser-to-browser, encrypted (DTLS-SRTP). One connection per viewer from the owner's browser, so it suits
     tens of viewers; a large audience needs a media server (SFU) or the stream-link mode. */
  const viewers = new Map();
  const MAX_VIEWERS = 50;
  const sweepViewers = () => { for (const [id, v] of viewers) if ((v.status === 'waiting' && now() - v.at > 60_000) || (v.status === 'left' && now() - v.leftAt > 30_000) || now() - v.seen > 90_000) viewers.delete(id); };
  function watchLive(u, { offer } = {}) {
    const cur = load().live.current;
    if (!cur || cur.mode !== 'site') return { error: 'not_live' };
    if (!SDP(offer)) return { error: 'bad_offer' };
    sweepViewers();
    for (const [id, v] of viewers) if (v.uid === u.uid) viewers.delete(id);   // one connection per customer (a reload replaces it)
    if (viewers.size >= MAX_VIEWERS) return { error: 'full' };
    const v = { id: rid('v'), uid: u.uid, name: clip(u.name || String(u.email || '').split('@')[0], 60), live: cur.id, offer, answer: null, status: 'waiting', at: now(), seen: now() };
    viewers.set(v.id, v);
    return { id: v.id, iceServers: iceServers() };
  }
  function watchState(u, id) {
    const v = viewers.get(id); if (!v || v.uid !== u.uid) return null;
    v.seen = now();
    return { id: v.id, status: v.status, answer: v.answer || undefined };
  }
  function leaveLive(u, owner, id) { const v = viewers.get(id); if (!v || (!owner && v.uid !== u.uid)) return { error: 'not_found' }; v.status = 'left'; v.leftAt = now(); return { ok: true }; }
  function liveViewers() {
    sweepViewers();
    const list = [...viewers.values()];
    return { waiting: list.filter((v) => v.status === 'waiting').map((v) => ({ id: v.id, name: v.name, offer: v.offer })), watching: list.filter((v) => v.status === 'watching').map((v) => ({ id: v.id, name: v.name })), left: list.filter((v) => v.status === 'left').map((v) => v.id), iceServers: iceServers() };
  }
  function answerViewer(id, { answer } = {}) {
    const v = viewers.get(id); if (!v) return { error: 'not_found' };
    if (v.status !== 'waiting') return { error: 'not_waiting' };
    if (!SDP(answer)) return { error: 'bad_answer' };
    Object.assign(v, { answer, status: 'watching', seen: now() }); return { ok: true };
  }
  const liveState = () => { const d = load(); return { current: d.live.current, history: d.live.history.slice(0, 10) }; };

  /* ───────── plans & coupons ───────── */
  function setPlan(id, { price, months, active } = {}, catalogue = {}) {
    if (!catalogue[id]) return { error: 'bad_product' };
    const d = load(); const o = { ...(d.plans[id] || {}) };
    if (price != null) { const c = Math.round(Number(price) * 100); if (!(c >= 100 && c <= 10_000_000)) return { error: 'bad_price' }; o.cents = c; }
    if (months != null) { const m = Number(months); if (!(Number.isInteger(m) && m >= 1 && m <= 36) || catalogue[id].kind !== 'plan') return { error: 'bad_months' }; o.months = m; }
    if (active != null) o.active = Boolean(active);
    d.plans[id] = o; save(); return { plan: { id, ...o } };
  }
  const planOverrides = () => load().plans;
  function upsertCoupon(b = {}) {
    const code = String(b.code || '').trim().toUpperCase(); if (!CODE_RE.test(code)) return { error: 'bad_code' };
    const type = b.type === 'fixed' ? 'fixed' : b.type === 'percent' ? 'percent' : null; if (!type) return { error: 'bad_type' };
    const value = Number(b.value);
    if (type === 'percent' ? !(value > 0 && value <= 90) : !(value > 0 && value <= 100000)) return { error: 'bad_value' };
    const startsAt = b.startsAt ? Number(new Date(b.startsAt)) : null; const endsAt = b.endsAt ? Number(new Date(b.endsAt)) : null;
    if ((startsAt != null && !Number.isFinite(startsAt)) || (endsAt != null && !Number.isFinite(endsAt)) || (startsAt && endsAt && endsAt <= startsAt)) return { error: 'bad_dates' };
    const maxUses = b.maxUses == null || b.maxUses === '' ? null : Number(b.maxUses); if (maxUses != null && !(Number.isInteger(maxUses) && maxUses >= 1 && maxUses <= 1e6)) return { error: 'bad_max' };
    const plans = Array.isArray(b.plans) ? b.plans.filter((x) => /^[a-z0-9]{2,20}$/.test(x)).slice(0, 20) : [];
    const d = load(); let c = d.coupons.find((x) => x.code === code);
    if (!c) { if (d.coupons.length >= 500) return { error: 'too_many' }; c = { code, used: 0, discountCents: 0, createdAt: now(), users: [] }; d.coupons.unshift(c); }
    Object.assign(c, { type, value, startsAt, endsAt, maxUses, plans, active: b.active !== false, updatedAt: now() }); save();
    return { coupon: couponView(c) };
  }
  const couponView = (c) => ({ code: c.code, type: c.type, value: c.value, startsAt: c.startsAt, endsAt: c.endsAt, maxUses: c.maxUses, plans: c.plans, active: c.active, used: c.used, discountCents: c.discountCents, createdAt: c.createdAt });
  function deleteCoupon(code) { const d = load(); const n = d.coupons.length; d.coupons = d.coupons.filter((x) => x.code !== String(code || '').toUpperCase()); save(); return { ok: d.coupons.length < n }; }
  const listCoupons = () => ({ items: load().coupons.map(couponView), totals: { used: load().coupons.reduce((a, c) => a + c.used, 0), discountCents: load().coupons.reduce((a, c) => a + c.discountCents, 0) } });
  /** Discount for a coupon on a product at a list price (cents), or { error }. Does not count a use. */
  function quote(codeRaw, product, listCents, uid = null) {
    const code = String(codeRaw || '').trim().toUpperCase(); if (!CODE_RE.test(code)) return { error: 'bad_code' };
    const c = load().coupons.find((x) => x.code === code);
    if (!c || !c.active) return { error: 'invalid_coupon' };
    const t = now();
    if (c.startsAt && t < c.startsAt) return { error: 'not_started' };
    if (c.endsAt && t > c.endsAt) return { error: 'expired' };
    if (c.maxUses != null && c.used >= c.maxUses) return { error: 'used_up' };
    if (c.plans.length && !c.plans.includes(product)) return { error: 'not_for_plan' };
    if (uid && c.users.includes(crypto.createHash('sha256').update(uid).digest('hex').slice(0, 16))) return { error: 'already_used' };
    const off = c.type === 'percent' ? Math.round((listCents * c.value) / 100) : Math.round(c.value * 100);
    const discount = Math.min(off, listCents - 50);   // Stripe's minimum charge is $0.50
    if (!(discount > 0)) return { error: 'no_discount' };
    return { code, discountCents: discount, finalCents: listCents - discount };
  }
  function redeem(codeRaw, discountCents, uid) {
    const c = load().coupons.find((x) => x.code === String(codeRaw || '').toUpperCase()); if (!c) return false;
    c.used += 1; c.discountCents += Math.max(0, Math.round(discountCents) || 0);
    if (uid) { c.users.push(crypto.createHash('sha256').update(uid).digest('hex').slice(0, 16)); c.users = c.users.slice(-5000); }
    save(); return true;
  }

  /* ───────── analytics & monthly reports ───────── */
  const monthKey = (ms) => new Date(ms).toISOString().slice(0, 7);
  function countReco(uid, { final, strategy } = {}) {
    const d = load(); const k = monthKey(now());
    const m = d.recos[k] ||= { total: 0, buy: 0, sell: 0, no_trade: 0, users: [] };
    m.total += 1; if (['buy', 'sell', 'no_trade'].includes(final)) m[final] += 1;
    const h = crypto.createHash('sha256').update(uid).digest('hex').slice(0, 12); if (!m.users.includes(h)) m.users.push(h);
    if (strategy) { m.by ||= {}; m.by[strategy] = (m.by[strategy] || 0) + 1; }
    save(); return { ok: true };
  }
  /** Statistics for one calendar month (UTC) from every member's saved AI trades. */
  function monthStats(key) {
    const [y, mo] = key.split('-').map(Number); const from = Date.UTC(y, mo - 1, 1); const to = Date.UTC(y, mo, 1);
    const members = growth?.members?.() || [];
    const trades = [];
    for (const m of members) {
      for (const x of userTrades?.list?.(m.uid) || []) {
        if (x.mode !== 'live') continue;
        const saved = x.savedAt; const closed = x.closedAt ? x.closedAt * 1000 : null;
        trades.push({ ...x, ref: m.uid.slice(0, 6), savedMs: saved, closedMs: closed });
      }
    }
    const savedIn = trades.filter((x) => x.savedMs >= from && x.savedMs < to);
    const closedIn = trades.filter((x) => x.closedMs && x.closedMs >= from && x.closedMs < to && Number.isFinite(x.resultR));
    const wins = closedIn.filter((x) => x.resultR > 0); const losses = closedIn.filter((x) => x.resultR < 0);
    const points = (x) => (x.resultR * x.risk) / (pointSize(x.symbol) || 1);
    const money = (x) => (Number.isFinite(x.riskAmount) ? x.resultR * x.riskAmount : null);
    const sum = (a, f) => a.reduce((s, x) => s + (f(x) || 0), 0);
    const r = load().recos[key] || { total: 0, buy: 0, sell: 0, no_trade: 0, users: [] };
    const active = members.filter((m) => m.lastLogin >= from && m.lastLogin < Math.max(to, from + 1)).length;
    return {
      month: key, generatedAt: now(),
      recommendations: { generated: r.total, buy: r.buy, sell: r.sell, noTrade: r.no_trade, byStrategy: r.by || {}, uniqueUsers: r.users.length },
      followed: savedIn.length,
      executedVerified: 0, executedNote: 'no broker connection: executions cannot be verified',
      closed: closedIn.length, wins: wins.length, losses: losses.length, breakeven: closedIn.length - wins.length - losses.length,
      successRate: closedIn.length ? Math.round((1000 * wins.length) / closedIn.length) / 10 : null,
      totalR: Math.round(sum(closedIn, (x) => x.resultR) * 100) / 100,
      avgR: closedIn.length ? Math.round((sum(closedIn, (x) => x.resultR) / closedIn.length) * 100) / 100 : null,
      points: Math.round(sum(closedIn, points)),
      profitUsd: Math.round(sum(closedIn.filter((x) => x.resultR > 0), money) * 100) / 100,
      lossUsd: Math.round(sum(closedIn.filter((x) => x.resultR < 0), money) * 100) / 100,
      customers: { total: members.length, active, newThisMonth: members.filter((m) => m.createdAt >= from && m.createdAt < to).length },
      trades: closedIn.sort((a, b) => a.closedMs - b.closedMs).slice(0, 2000).map((x) => ({ ref: x.ref, symbol: x.symbol, direction: x.direction, tf: x.tf, strategy: x.strategy || 'smc', entry: x.entry, stop: x.stop, status: x.status, hits: x.hits, resultR: x.resultR, points: Math.round(points(x)), usd: money(x) == null ? null : Math.round(money(x) * 100) / 100, savedAt: x.savedMs, closedAt: x.closedMs })),
    };
  }
  function analytics(t = now()) {
    const cur = monthKey(t); const d = new Date(t); const prev = monthKey(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() - 1, 1));
    const a = monthStats(cur); const b = load().reports[prev] || monthStats(prev);
    const { trades, ...curNoTrades } = a; const { trades: _t, ...prevNoTrades } = b;
    return { current: curNoTrades, previous: prevNoTrades, reports: Object.keys(load().reports).sort().reverse() };
  }
  const report = (key) => (/^\d{4}-\d{2}$/.test(key) ? load().reports[key] || monthStats(key) : null);
  /** Runs hourly: the first run in a new month builds last month's report and sends it to the owners. */
  async function runMonthly(t = now()) {
    const d = new Date(t); const prev = monthKey(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() - 1, 1));
    const db_ = load(); if (db_.reports[prev]) return null;
    const rep = monthStats(prev); const before = monthStats(monthKey(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() - 2, 1)));
    rep.compare = { closed: rep.closed - before.closed, successRate: rep.successRate != null && before.successRate != null ? Math.round((rep.successRate - before.successRate) * 10) / 10 : null, totalR: Math.round((rep.totalR - before.totalR) * 100) / 100, points: rep.points - before.points, generated: rep.recommendations.generated - before.recommendations.generated };
    db_.reports[prev] = rep; save();
    const line = `${prev}: ${rep.recommendations.generated} recommendations · ${rep.closed} closed · ${rep.successRate ?? '—'}% · ${rep.totalR}R · ${rep.points} pts`;
    for (const o of owners()) {
      notifyUser(o.uid, `📊 التقرير الشهري / Monthly report ${prev}`, line, '/#/app/admin-stats', 'report');
      try { await growth?.sendMail?.(o.email, `AlphaTrade AI — monthly report ${prev}`, `${line}\n\nOpen the dashboard to download the full report (Excel / PDF): /#/app/admin-stats`); } catch { /* optional */ }
    }
    log.log?.(`[community] monthly report ${prev} built`);
    return rep;
  }

  // v235: account deletion — the customer's own reports (with their screenshots), open support calls and live-viewer seats go.
  function forgetUser(uid) {
    const d = load(); const mineF = d.feedback.filter((x) => x.uid === uid);
    for (const x of mineF) for (const iid of x.images || []) { try { fs.unlinkSync(path.join(imgDir, `${iid}.bin`)); } catch { /* already gone */ } }
    if (mineF.length) { d.feedback = d.feedback.filter((x) => x.uid !== uid); save(); }
    for (const [id, c] of calls) if (c.uid === uid) calls.delete(id);
    for (const [id, v] of viewers) if (v.uid === uid) viewers.delete(id);
    return { feedback: mineF.length };
  }
  return {
    forgetUser,
    canSave: () => Boolean(key), submitFeedback, listFeedback, updateFeedback, feedbackImage,
    startCall, callState, listCalls, answerCall, addIce, endCall, iceServers,
    startLive, endLive, liveState, watchLive, watchState, leaveLive, liveViewers, answerViewer, setPlan, planOverrides, upsertCoupon, deleteCoupon, listCoupons, quote, redeem,
    countReco, monthStats, analytics, report, runMonthly,
  };
}
