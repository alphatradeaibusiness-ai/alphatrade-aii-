// Server-side watcher for saved assistant / AI-signal trades: checks open trades every few minutes, stores the outcome and
// notifies (Web Push, in-app message, Telegram) at every event — order filled, each target, stop, closed at entry — even
// when the user's browser is closed. Crypto pairs use Binance candles; gold / forex / indices use the site's market-data
// key (Twelve Data) when one is saved, every 10 minutes to spare its credits.
//   TRADE_WATCH_DISABLED=1   switch it off
//   TRADE_WATCH_MINUTES      check interval (default 3, 1–30)
import { trackTrade } from '../src/services/smcAssist.js';

const IV = { '1m': '1m', '5m': '5m', '15m': '15m', '1h': '1h', '4h': '4h', '1D': '1d' };
const SEC = { '1m': 60, '5m': 300, '15m': 900, '1h': 3600, '4h': 14400, '1D': 86400 };
const MAX_PAGES = 5;

export function eventsFor(before, after, n) {
  const ev = [];
  if (before.status === 'pending' && after.status !== 'pending' && after.filledAt) ev.push({ kind: 'trade_filled' });
  if (after.hits > before.hits && after.status !== 'done') ev.push({ kind: 'trade_target', n: after.hits });
  const end = { done: 'trade_done', stopped: 'trade_stopped', breakeven: 'trade_breakeven', expired: 'trade_expired', missed: 'trade_missed' }[after.status];
  if (end && end !== before.status) ev.push({ kind: end, r: after.resultR });
  return n ? ev : [];
}

// Prices for the short phone alert (tradeMessages.js): the level that was hit and the entry / stop.
export function alertParams(x, saved, ev) {
  const price = ev.kind === 'trade_target' ? x.targets[ev.n - 1] : ev.kind === 'trade_done' ? x.targets.at(-1) : null;
  return { direction: x.direction, entry: x.entry, stop: x.stop, hits: saved.hits, ...(Number.isFinite(price) ? { price } : {}) };
}

// otherCandles(symbol, tf, fromSec) → candles | null: prices for non-crypto trades (gold, forex, indices…) from the site's
// market-data key (Twelve Data). Checked less often (otherEveryMs) because those requests use the key's daily credits.
export function createTradeWatch({ userTrades, notify = null, allowed = () => true, env = process.env, fetchFn = fetch, base = 'https://api.binance.com', now = Date.now, log = console, otherCandles = null, otherEveryMs = 10 * 60_000 }) {
  const disabled = env.TRADE_WATCH_DISABLED === '1';
  const everyMs = (env.TRADE_WATCH_MS ? Number(env.TRADE_WATCH_MS) : Math.max(1, Math.min(30, Number(env.TRADE_WATCH_MINUTES) || 3)) * 60_000);
  let running = false; let lastRun = null; let lastError = null; let checked = 0; const otherAt = new Map();

  async function candles(symbol, tf, fromSec) {
    const out = []; let start = (fromSec - SEC[tf]) * 1000;
    for (let p = 0; p < MAX_PAGES; p++) {
      const r = await fetchFn(`${base}/api/v3/klines?symbol=${encodeURIComponent(symbol)}&interval=${IV[tf]}&startTime=${start}&limit=1000`, { signal: AbortSignal.timeout(10_000) });
      if (!r.ok) { if (r.status === 400) return null; throw new Error(`binance ${r.status}`); }   // 400 = not a Binance pair
      const rows = await r.json(); if (!Array.isArray(rows) || !rows.length) break;
      for (const k of rows) out.push({ time: Math.floor(k[0] / 1000), open: +k[1], high: +k[2], low: +k[3], close: +k[4], volume: +k[5] });
      if (rows.length < 1000) break;
      start = rows.at(-1)[0] + SEC[tf] * 1000;
    }
    return out;
  }

  async function tick() {
    if (running || disabled || !userTrades.canSave()) return { skipped: true };
    running = true; const cache = new Map(); let changes = 0;
    try {
      for (const uid of userTrades.openOwners()) {
        for (const x of userTrades.openTrades(uid)) {
          if (x.mode !== 'live' || !IV[x.tf]) continue;
          const crypto = x.asset === 'crypto';
          if (!crypto && !otherCandles) continue;
          const key = `${x.symbol}|${x.tf}|${x.createdAt}`;
          if (!crypto && !cache.has(key) && now() - (otherAt.get(key) || 0) < otherEveryMs) continue;
          let cs = cache.get(key);
          if (cs === undefined) {
            if (!crypto) otherAt.set(key, now());
            cs = await (crypto ? candles(x.symbol, x.tf, x.createdAt) : otherCandles(x.symbol, x.tf, x.createdAt)).catch((e) => { lastError = String(e?.message || e).slice(0, 80); return undefined; });
            if (cs !== undefined) cache.set(key, cs);
          }
          if (!cs?.length) continue;
          // the last candle is still forming: judge only on closed candles, like the browser does with a live chart
          const closed = cs.filter((c) => c.time + SEC[x.tf] <= now() / 1000);
          const r = trackTrade(x, closed); checked++;
          if (r.status === x.status && r.hits === x.hits && r.resultR === x.resultR) continue;
          const saved = userTrades.setOutcome(uid, x.id, r); if (!saved) continue;
          changes++;
          if (allowed(uid)) for (const ev of eventsFor(x, saved, x.targets.length)) notify?.(uid, ev.kind, { id: x.id, symbol: x.symbol, ...(ev.n ? { n: ev.n } : {}), ...(ev.r != null ? { r: ev.r } : {}), ...alertParams(x, saved, ev) });
        }
      }
      lastRun = now(); return { ok: true, changes };
    } catch (e) { lastError = String(e?.message || e).slice(0, 80); log.error?.('[trades] watch failed:', lastError); return { ok: false };
    } finally { running = false; }
  }
  function start() {
    if (disabled) return () => {};
    const t = setInterval(() => { tick(); }, everyMs); t.unref?.();
    return () => clearInterval(t);
  }
  return { tick, start, status: () => ({ enabled: !disabled, lastRun, lastError, checked, other: Boolean(otherCandles) }) };
}
