// Verifies Firebase Authentication ID tokens on the server (no dependencies).
// A token is accepted only when: RS256 signature by one of Google's current securetoken keys (kid), aud = project id,
// iss = https://securetoken.google.com/<project>, not expired, issued in the past, and a non-empty subject (uid).
import crypto from 'node:crypto';

const GOOGLE_CERTS = 'https://www.googleapis.com/robot/v1/metadata/x509/securetoken@system.gserviceaccount.com';
let cache = { certs: null, until: 0 };

const b64url = (s) => Buffer.from(String(s).replace(/-/g, '+').replace(/_/g, '/'), 'base64');

/** Google's current public certificates { kid: PEM }, cached for the time Google allows (Cache-Control max-age). */
export async function googleCerts(fetchImpl = fetch, now = Date.now()) {
  if (cache.certs && now < cache.until) return cache.certs;
  const r = await fetchImpl(GOOGLE_CERTS);
  if (!r.ok) throw new Error(`certs ${r.status}`);
  const certs = await r.json();
  const m = /max-age=(\d+)/.exec(r.headers.get('cache-control') || '');
  cache = { certs, until: now + (m ? Number(m[1]) * 1000 : 3600_000) };
  return certs;
}

/**
 * @returns { uid, email, emailVerified, provider } — throws Error('auth:<reason>') when the token is not valid.
 * `certs` = { kid: PEM } (Google's in production).
 */
export function verifyIdToken(token, { projectId, certs, now = Date.now(), skewSec = 300 }) {
  if (!projectId) throw new Error('auth:not-configured');
  const parts = String(token || '').split('.');
  if (parts.length !== 3) throw new Error('auth:malformed');
  let header; let payload;
  try { header = JSON.parse(b64url(parts[0]).toString('utf8')); payload = JSON.parse(b64url(parts[1]).toString('utf8')); } catch { throw new Error('auth:malformed'); }
  if (header.alg !== 'RS256' || !header.kid || !certs?.[header.kid]) throw new Error('auth:unknown-key');
  let key;
  try { key = crypto.createPublicKey(certs[header.kid]); } catch { throw new Error('auth:unknown-key'); }
  const ok = crypto.verify('RSA-SHA256', Buffer.from(`${parts[0]}.${parts[1]}`), key, b64url(parts[2]));
  if (!ok) throw new Error('auth:bad-signature');
  const t = Math.floor(now / 1000);
  if (payload.aud !== projectId) throw new Error('auth:wrong-audience');
  if (payload.iss !== `https://securetoken.google.com/${projectId}`) throw new Error('auth:wrong-issuer');
  if (!(payload.exp > t - skewSec)) throw new Error('auth:expired');
  if (!(payload.iat <= t + skewSec)) throw new Error('auth:not-yet-valid');
  if (payload.auth_time != null && !(payload.auth_time <= t + skewSec)) throw new Error('auth:not-yet-valid');
  if (typeof payload.sub !== 'string' || !payload.sub || payload.sub.length > 128) throw new Error('auth:no-subject');
  return {
    uid: payload.sub,
    email: String(payload.email || '').toLowerCase(),
    name: String(payload.name || '').replace(/[\u0000-\u001f<>]/g, '').slice(0, 60),   // v251: display name (rooms)
    emailVerified: payload.email_verified === true,
    provider: payload.firebase?.sign_in_provider || '',
    authTime: Number(payload.auth_time) || 0,                       // seconds: when the user last really signed in
    mfa: Boolean(payload.firebase?.sign_in_second_factor),          // signed in with a second factor (Firebase MFA)
  };
}
