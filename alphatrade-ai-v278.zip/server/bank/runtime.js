// Builds the bank (database + vault + rules + HTTP handler + plan scheduler) from the environment.
//   BANK_MASTER_KEY        32+ chars, required (encrypts personal data). Separate from AI_KEY_SECRET.
//   BANK_MASTER_KEY_PREV   optional, previous master key(s) comma-separated, while rotating
//   BANK_MODE              sandbox (default: test funds only) | live (the owner confirms real transfers made outside)
//   BANK_DATA_DIR          where bank.db lives (default SERVER_DATA_DIR/bank) — persistent disk, backed up, NOT shared with the worker
//   BANK_REAUTH_MINUTES    step-up window for money/personal-data actions (live default 15, sandbox 0 = off)
//   BANK_REQUIRE_MFA       1 = those actions need a Firebase second factor (live default 1)
//   BANK_RP_ID / BANK_ORIGINS   passkeys: relying-party id (your domain) and allowed origins, when not derived from the request
//   BANK_VAPID_SUBJECT     contact for push services (mailto:… or https://…)
//   BANK_ISSUER_WEBHOOK_SECRET  32+ chars: enables the signed card-issuer webhook (/api/bank/issuer/webhook)
//   BANK_REWARDS_CASHBACK  1 = allow points → cashback in live mode (fund the platform rewards account first)
import path from 'node:path';
import { openDb } from './db.js';
import { createVault } from './vault.js';
import { createBank, DEFAULTS } from './service.js';
import { createBankHttp } from './http.js';
import { sendPush } from './webpush.js';

const SYMBOL = { BTC: 'BTCUSDT', ETH: 'ETHUSDT', SOL: 'SOLUSDT', BNB: 'BNBUSDT' };

export function createBankRuntime({ env = process.env, deps, dataDir, isTest = false, now = Date.now }) {
  const secret = env.BANK_MASTER_KEY || '';
  if (secret.length < 32) return { enabled: false, reason: secret ? 'master_key_too_short' : 'no_master_key', handle: null };
  const mode = env.BANK_MODE === 'live' ? 'live' : 'sandbox';
  const vault = createVault({ secret, previous: String(env.BANK_MASTER_KEY_PREV || '').split(',').map((x) => x.trim()).filter(Boolean) });
  const db = openDb(env.BANK_DATA_DIR ? path.resolve(env.BANK_DATA_DIR) : path.join(dataDir, 'bank'));
  const base = isTest && env.BANK_TEST_PRICE_BASE ? env.BANK_TEST_PRICE_BASE : 'https://data-api.binance.vision';
  const priceFn = async (asset) => {
    const r = await fetch(`${base}/api/v3/ticker/price?symbol=${SYMBOL[asset]}`, { signal: AbortSignal.timeout(5000) });
    const j = await r.json(); return { price: Number(j.price), ts: Date.now() };
  };
  // Reference rates: EUR from the ECB daily file, BTC from Binance, USDT taken as 1 USD (stated on the page).
  const ecbBase = isTest && env.BANK_TEST_RATES_BASE ? env.BANK_TEST_RATES_BASE : 'https://www.ecb.europa.eu';
  const rateFn = async () => {
    const r = await fetch(`${ecbBase}/stats/eurofxref/eurofxref-daily.xml`, { signal: AbortSignal.timeout(6000) });
    const xml = await r.text(); const usdPerEur = Number((/currency=['"]USD['"]\s+rate=['"]([\d.]+)['"]/.exec(xml) || [])[1]);
    const btc = await priceFn('BTC');
    if (!(usdPerEur > 0) || !(btc?.price > 0)) throw new Error('rates');
    return { usdPer: { USD: 1, EUR: usdPerEur, USDT: 1, BTC: btc.price }, ts: Math.min(Date.now(), btc.ts), sources: { EUR: 'ECB', BTC: 'Binance BTCUSDT', USDT: 'assumed 1 USD' } };
  };
  const pushSender = (sub, payload, vapid) => sendPush(sub, payload, { vapid, subject: env.BANK_VAPID_SUBJECT || 'mailto:admin@localhost' });
  const config = env.BANK_REWARDS_CASHBACK === '1' ? { rewards: { ...DEFAULTS.rewards, cashbackLive: true } } : {};
  const bank = createBank({ db, vault, mode, now, priceFn, rateFn, pushSender, pushTestBase: isTest ? env.BANK_TEST_PUSH_BASE || '' : '', config });
  const handle = createBankHttp({ bank, env, now, ...deps });
  const timer = setInterval(() => { bank.runDue().catch((e) => console.error('[bank] scheduler:', String(e?.message || e).slice(0, 100))); }, isTest ? 500 : 60_000);
  timer.unref?.();
  const chain = bank.audit.verify(); const led = bank.ledger.verify();
  if (!chain.ok || !led.ok) console.error('[bank] INTEGRITY PROBLEM at start: audit', JSON.stringify(chain), 'ledger', JSON.stringify(led.problems.slice(0, 3)));
  return { enabled: true, mode, handle, bank, snapshot: (file) => db.exec(`VACUUM INTO '${String(file).replace(/'/g, "''")}'`), close: () => { clearInterval(timer); db.close(); } };
}
