// The bank's business rules. Everything that changes money runs inside one database transaction together with its audit
// row. Real-money rails (bank transfers, crypto custody, card issuing, brokerage) are NOT connected: in "live" mode the
// owner confirms what really happened outside (a received transfer, a sent payout) and the ledger records it; in "sandbox"
// mode users can only play with test funds. Nothing here pretends otherwise.
import crypto from 'node:crypto';
import { EventEmitter } from 'node:events';
import { createLedger, LedgerError } from './ledger.js';
import { createAudit } from './audit.js';
import { CURRENCIES, toMinor } from './money.js';
import { BankError, bad, str, oneOf, idem as idemOk, validIban, validCryptoAddress, iso2, adult, address } from './validate.js';
import { createNotify } from './features/notify.js';
import { createSecurity } from './features/security.js';
import { createPockets } from './features/pockets.js';
import { createPlanning } from './features/planning.js';
import { createVcards, sandboxIssuer } from './features/vcards.js';
import { createRewards } from './features/rewards.js';
import { createFx } from './features/fx.js';
import { createOpenBanking, demoProvider } from './features/openbanking.js';
import { createInsights } from './features/insights.js';
import { createSupport } from './features/support.js';
import { createTotp } from './features/totp.js';
import { createRisk } from './features/risk.js';
import { createCompliance } from './features/compliance.js';

const DAY = 86400_000; const HOUR = 3600_000;
const m = (n, c) => Math.round(n * 10 ** CURRENCIES[c].decimals);
const rid = (p) => `${p}_${crypto.randomBytes(9).toString('base64url')}`;
const REF_ALPHA = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const newRef = () => `ATB-${Array.from(crypto.randomBytes(8), (b) => REF_ALPHA[b % REF_ALPHA.length]).join('')}`;

export const DEFAULTS = {
  // per rolling 24 h, by KYC tier (minor units). Tier 0 cannot move money.
  dailyWithdraw: { 1: { USD: m(1000, 'USD'), EUR: m(1000, 'EUR'), USDT: m(1000, 'USDT'), BTC: m(0.02, 'BTC') }, 2: { USD: m(25000, 'USD'), EUR: m(25000, 'EUR'), USDT: m(25000, 'USDT'), BTC: m(0.5, 'BTC') } },
  minWithdraw: { USD: m(10, 'USD'), EUR: m(10, 'EUR'), USDT: m(10, 'USDT'), BTC: m(0.0002, 'BTC') },
  fee: { USD: m(1, 'USD'), EUR: m(1, 'EUR'), USDT: m(1, 'USDT'), BTC: m(0.0001, 'BTC') },
  cardFee: { virtual: 0, standard: m(15, 'USD'), express: m(35, 'USD') },
  maxWithdrawalsPerHour: 5, maxOpenDeposits: 5, depositTtl: 7 * DAY, beneficiaryCooldown: 24 * HOUR, newBeneficiaryFlag: 7 * DAY,
  sandboxFundMax: m(10000, 'USD'), sandboxFundTotal: m(100000, 'USD'),
  blockedCountries: ['KP', 'IR', 'SY', 'CU'],   // illustrative: compliance must set the real list for your licence
  plans: { assets: ['BTC', 'ETH', 'SOL', 'BNB'], minAmount: m(10, 'USDT'), maxPerUser: 10, dailyCapDefault: m(500, 'USDT'), maxStaleMs: 60_000 },
  // v150
  maxPockets: 10, vaultDelay: 24 * HOUR, approvalTtl: 48 * HOUR,
  vcard: { tx: m(1000, 'USD'), day: m(2000, 'USD'), month: m(5000, 'USD'), maxTx: m(5000, 'USD'), maxDay: m(10000, 'USD'), maxMonth: m(25000, 'USD'), maxCards: 5 },
  saveRules: { dailyCap: { USD: m(500, 'USD'), EUR: m(500, 'EUR'), USDT: m(500, 'USDT'), BTC: m(0.01, 'BTC') } },
  rewards: { perUsd: 1, kyc1: 100, kyc2: 200, passkey: 50, redeemUnit: 1000, redeemUsd: m(5, 'USD'), ttl: 365 * DAY, cashbackLive: false },
  fx: { spreadBp: 50, cacheMs: 60_000, maxStaleMs: 10 * 60_000 },
  intl: { fee: { USD: m(2, 'USD'), EUR: m(2, 'EUR'), USDT: m(2, 'USDT'), BTC: m(0.00005, 'BTC') }, quoteTtl: 60_000 },
  openBanking: { consentDays: 90 },
};

export function createBank({ db, vault, mode = 'sandbox', now = Date.now, config = {}, priceFn = null, broker = null, rateFn = null, issuer = undefined, obProvider = undefined, fxProvider = null, pushSender = null, pushTestBase = '' }) {
  if (!vault?.available) throw new Error('bank:no-vault');
  const cfg = { ...DEFAULTS, ...config };
  const L = createLedger(db, now); const A = createAudit(db, now);
  const events = new EventEmitter();
  const ping = (uid, type = 'balance') => events.emit(`u:${uid}`, { type, at: now() });
  const sandbox = mode !== 'live';
  const seal = (v, aad) => vault.seal(v, aad); const open = (b, aad) => vault.open(b, aad);

  const tier = (uid) => db.prepare('SELECT tier FROM kyc WHERE uid = ?').get(uid)?.tier || 0;
  const needTier = (uid, n) => { if (tier(uid) < n) bad('kyc_required', 403); };
  /** One database transaction (money + audit together), ledger errors mapped to API errors, then live-update pings. */
  const commit = (fn, ...uids) => {
    let r;
    try { r = db.tx(fn); } catch (e) { if (e instanceof LedgerError) throw new BankError(e.code, e.code === 'insufficient_funds' ? 409 : e.code === 'idempotency_conflict' ? 409 : 400); throw e; }
    for (const u of uids.flat()) if (u) ping(u);
    return r;
  };
  const notSelf = (actor, uid) => { if (actor.uid === uid) bad('self_action_not_allowed', 403); };

  /* ─────────── v150 features share one context ─────────── */
  const handlers = {};
  const ctx = {
    db, L, A, audit: A, vault, cfg, now, sandbox, rid, commit, ping, seal, open, tier, needTier, priceFn, broker, rateFn, fxProvider, pushSender, pushTestBase,
    issuer: issuer === undefined ? (sandbox ? sandboxIssuer : null) : issuer,
    obProvider: obProvider === undefined ? (sandbox ? demoProvider : null) : obProvider,
    approvalTargets: {},
    on: (ev, fn) => { (handlers[ev] ||= []).push(fn); },
    /** After-commit domain events (rules, rewards, alerts). A failing handler is logged and never undoes the money change. */
    emit: (ev, data) => { for (const fn of handlers[ev] || []) { try { fn(data); } catch (e) { console.error('[bank] hook', ev, e?.code || e?.name, String(e?.message || '').slice(0, 80)); } } },
  };
  const notifications = createNotify(ctx); ctx.notify = notifications.notify;
  ctx.security = createSecurity(ctx);
  ctx.totp = createTotp(ctx);
  ctx.risk = createRisk(ctx);
  ctx.pockets = createPockets(ctx);
  ctx.planning = createPlanning(ctx);
  ctx.vcards = createVcards(ctx);
  ctx.rewards = createRewards(ctx);
  ctx.fx = createFx(ctx);
  ctx.ob = createOpenBanking(ctx);
  ctx.insights = createInsights(ctx);
  ctx.support = createSupport(ctx);
  ctx.compliance = createCompliance(ctx);

  /* ─────────── wallet ─────────── */
  function wallet(uid) {
    return Object.keys(CURRENCIES).map((c) => {
      const b = L.balance(uid, c);
      const pend = db.prepare("SELECT COALESCE(SUM(amount),0) s FROM deposits WHERE uid = ? AND currency = ? AND status = 'requested' AND expires_at > ?").get(uid, c, now()).s;
      const pockets = db.prepare("SELECT COALESCE(SUM(balance),0) s FROM accounts WHERE owner = ? AND currency = ? AND kind = 'pocket'").get(uid, c).s;
      return { currency: c, available: b.available, held: b.held, pendingDeposits: pend, pockets, vault: L.account(uid, c, 'vault').balance };
    });
  }
  function history(uid, opts) {
    const h = L.history(uid, opts);
    return { ...h, items: h.items.map((x) => (x.label ? { ...x, label: { category: x.label.category, tags: x.label.tags, note: ctx.pockets.openNote(uid, x.label.noteSealed) } } : x)) };
  }

  /* ─────────── deposits ─────────── */
  const depositView = (d) => ({ id: d.id, currency: d.currency, amount: d.amount, method: d.method, reference: d.reference, status: d.status, createdAt: d.created_at, expiresAt: d.expires_at,
    instructions: sandbox ? 'sandbox' : (process.env[`BANK_DEPOSIT_INSTRUCTIONS_${d.currency}`] || 'not_configured') });
  function requestDeposit(uid, i) {
    const currency = oneOf(i.currency, Object.keys(CURRENCIES), 'bad_currency'); const key = idemOk(i.idem);
    const method = CURRENCIES[currency].kind === 'crypto' ? 'crypto' : 'bank';
    const network = method === 'crypto' ? oneOf(i.network, CURRENCIES[currency].networks, 'bad_network') : null;
    const amount = toMinor(i.amount, currency) ?? bad('bad_amount');
    if (!sandbox) needTier(uid, 1);
    return commit(() => {
      const prev = db.prepare('SELECT * FROM deposits WHERE uid = ? AND idem = ?').get(uid, key);
      if (prev) { if (prev.amount !== amount || prev.currency !== currency) bad('idempotency_conflict', 409); return depositView(prev); }
      const n = db.prepare("SELECT COUNT(*) c FROM deposits WHERE uid = ? AND status = 'requested' AND expires_at > ?").get(uid, now()).c;
      if (n >= cfg.maxOpenDeposits) bad('too_many_open_deposits', 429);
      const id = rid('dep'); const t = now();
      db.prepare('INSERT INTO deposits (id, uid, currency, amount, method, reference, status, idem, created_at, updated_at, expires_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)')
        .run(id, uid, currency, amount, method + (network ? `:${network}` : ''), newRef(), 'requested', key, t, t, t + cfg.depositTtl);
      A.log(uid, 'deposit.request', id, { currency, amount, method });
      return depositView(db.prepare('SELECT * FROM deposits WHERE id = ?').get(id));
    });
  }
  const listDeposits = (uid) => db.prepare('SELECT * FROM deposits WHERE uid = ? ORDER BY created_at DESC LIMIT 50').all(uid).map(depositView);

  /** Owner, after checking with the bank / custodian that the money really arrived (one external reference = one credit, ever). */
  function confirmDeposit(actor, id, { extRef, received } = {}) {
    const ref = str(extRef, { min: 4, max: 100, re: /^[A-Za-z0-9._:/-]+$/, code: 'bad_reference' });
    let uid;
    const r = commit(() => {
      const d = db.prepare('SELECT * FROM deposits WHERE id = ?').get(id) ?? bad('not_found', 404);
      uid = d.uid; notSelf(actor, d.uid);
      if (d.status !== 'requested') bad('bad_state', 409);
      if (d.expires_at < now()) bad('expired', 409);
      const amount = received == null ? d.amount : (toMinor(received, d.currency) ?? bad('bad_amount'));
      if (amount !== d.amount) bad('amount_mismatch', 409);   // partial / over payments are settled outside; nothing is guessed here
      const tx = L.post({ type: 'deposit', uid: d.uid, currency: d.currency, amount, extRef: ref, meta: { depositId: id, method: d.method, reference: d.reference },
        legs: [{ acc: L.sys('external', d.currency), delta: -amount }, { acc: L.account(d.uid, d.currency, 'wallet'), delta: amount }] });
      db.prepare("UPDATE deposits SET status = 'confirmed', ext_ref = ?, updated_at = ? WHERE id = ?").run(ref, now(), id);
      A.log(actor.uid, 'deposit.confirm', id, { uid: d.uid, amount, currency: d.currency, txn: tx.id });
      return { ok: true, txn: tx.id, currency: d.currency, amount };
    });
    ping(uid);
    ctx.notify(uid, 'deposit_confirmed', { amount: r.amount, currency: r.currency });
    ctx.emit('deposit.credited', { uid, currency: r.currency, amount: r.amount, txn: r.txn });
    return { ok: true, txn: r.txn };
  }
  function rejectDeposit(actor, id, reason) {
    const why = str(reason ?? 'rejected', { max: 200, code: 'bad_reason' }); let uid;
    commit(() => {
      const d = db.prepare('SELECT * FROM deposits WHERE id = ?').get(id) ?? bad('not_found', 404);
      if (d.status !== 'requested') bad('bad_state', 409);
      uid = d.uid;
      db.prepare("UPDATE deposits SET status = 'rejected', updated_at = ? WHERE id = ?").run(now(), id);
      A.log(actor.uid, 'deposit.reject', id, { uid: d.uid, why });
    });
    ctx.notify(uid, 'deposit_rejected');
    return { ok: true };
  }
  /** Test funds. Exists only in sandbox mode and is capped per request and per user. */
  function sandboxFund(uid, i) {
    if (!sandbox) bad('not_available', 403);
    const currency = oneOf(i.currency, Object.keys(CURRENCIES), 'bad_currency'); const key = idemOk(i.idem);
    const amount = toMinor(i.amount, currency) ?? bad('bad_amount');
    if (currency === 'USD' || currency === 'EUR' || currency === 'USDT') { if (amount > cfg.sandboxFundMax * 10 ** (CURRENCIES[currency].decimals - 2)) bad('limit_exceeded', 403); }
    else if (amount > m(0.5, 'BTC')) bad('limit_exceeded', 403);
    return commit(() => {
      const total = db.prepare("SELECT COALESCE(SUM(amount),0) s FROM txns WHERE uid = ? AND type = 'sandbox_credit' AND currency = ?").get(uid, currency).s;
      const cap = currency === 'BTC' ? m(2, 'BTC') : cfg.sandboxFundTotal * 10 ** (CURRENCIES[currency].decimals - 2);
      if (total + amount > cap) bad('limit_exceeded', 403);
      const tx = L.post({ type: 'sandbox_credit', uid, currency, amount, idem: key, meta: { sandbox: true },
        legs: [{ acc: L.sys('sandbox', currency), delta: -amount }, { acc: L.account(uid, currency, 'wallet'), delta: amount }] });
      if (!tx.replay) A.log(uid, 'sandbox.fund', tx.id, { currency, amount });
      return { txn: tx.id, replay: tx.replay };
    }, uid);
  }
  function sandboxFundAndHooks(uid, i) {
    const r = sandboxFund(uid, i);
    if (!r.replay) { const t = db.prepare('SELECT currency, amount FROM txns WHERE id = ?').get(r.txn); ctx.emit('deposit.credited', { uid, currency: t.currency, amount: t.amount, txn: r.txn }); }
    return r;
  }

  /* ─────────── beneficiaries ─────────── */
  const benView = (b) => ({ id: b.id, kind: b.kind, currency: b.currency, label: b.label, last4: b.last4, status: b.status, usableAfter: b.usable_after, createdAt: b.created_at });
  function addBeneficiary(uid, i) {
    needTier(uid, 1);
    const currency = oneOf(i.currency, Object.keys(CURRENCIES), 'bad_currency'); const crypto_ = CURRENCIES[currency].kind === 'crypto';
    const label = str(i.label, { max: 40, code: 'bad_label' });
    let details; let id_;
    if (!crypto_) {
      const iban = validIban(i.iban) ?? bad('bad_iban');
      details = { iban, holder: str(i.holder, { max: 70, code: 'bad_holder' }) }; id_ = iban;
    } else {
      const network = oneOf(i.network, CURRENCIES[currency].networks, 'bad_network');
      const addr = validCryptoAddress(network, i.address) ?? bad('bad_address');
      details = { network, address: addr, memo: i.memo ? str(i.memo, { max: 40, code: 'bad_memo' }) : '' }; id_ = `${network}:${addr}`;
    }
    const blind = vault.blind(id_); const id = rid('ben'); const t = now();
    return commit(() => {
      if (db.prepare('SELECT COUNT(*) c FROM beneficiaries WHERE uid = ? AND status = ?').get(uid, 'active').c >= 10) bad('too_many_beneficiaries', 429);
      if (db.prepare('SELECT 1 FROM beneficiaries WHERE uid = ? AND blind = ? AND status = ?').get(uid, blind, 'active')) bad('already_exists', 409);
      db.prepare("DELETE FROM beneficiaries WHERE uid = ? AND blind = ? AND status = 'removed'").run(uid, blind);
      db.prepare('INSERT INTO beneficiaries (id, uid, kind, currency, label, last4, details, blind, status, created_at, usable_after) VALUES (?,?,?,?,?,?,?,?,?,?,?)')
        .run(id, uid, crypto_ ? 'crypto' : 'bank', currency, label, id_.slice(-4), seal(details, `ben:${uid}`), blind, 'active', t, t + cfg.beneficiaryCooldown);
      A.log(uid, 'beneficiary.add', id, { currency, kind: crypto_ ? 'crypto' : 'bank' });
      return benView(db.prepare('SELECT * FROM beneficiaries WHERE id = ?').get(id));
    }, uid);
  }
  function addBeneficiaryAndNotify(uid, i) { const b = addBeneficiary(uid, i); ctx.notify(uid, 'beneficiary_added'); return b; }
  const listBeneficiaries = (uid) => db.prepare("SELECT * FROM beneficiaries WHERE uid = ? AND status = 'active' ORDER BY created_at DESC").all(uid).map(benView);
  function removeBeneficiary(uid, id) {
    return commit(() => {
      const r = db.prepare("UPDATE beneficiaries SET status = 'removed' WHERE id = ? AND uid = ? AND status = 'active'").run(id, uid);
      if (!r.changes) bad('not_found', 404);
      A.log(uid, 'beneficiary.remove', id, {}); return { ok: true };
    });
  }

  /* ─────────── withdrawals ─────────── */
  const wdView = (w) => ({ id: w.id, currency: w.currency, amount: w.amount, fee: w.fee, status: w.status, flags: JSON.parse(w.flags || '[]'), beneficiaryId: w.beneficiary_id, createdAt: w.created_at, updatedAt: w.updated_at, note: w.status === 'rejected' ? w.note : null, intl: ctx.fx.intlFor(w.id) });
  /** Public: a normal withdrawal. Internal callers (cross-border) pass `fee` and `crossBorder` through createWithdrawal. */
  const requestWithdrawal = (uid, i) => createWithdrawal(uid, { currency: i.currency, amount: i.amount, beneficiaryId: i.beneficiaryId, idem: i.idem });
  function createWithdrawal(uid, i) {
    const key = idemOk(i.idem); const currency = oneOf(i.currency, Object.keys(CURRENCIES), 'bad_currency');
    const amount = typeof i.amount === 'number' && Number.isSafeInteger(i.amount) && i.crossBorder ? i.amount : (toMinor(i.amount, currency) ?? bad('bad_amount'));
    if (amount < cfg.minWithdraw[currency]) bad('below_minimum');
    const tr = tier(uid); if (tr < 1) bad('kyc_required', 403);
    ctx.security.assertNotFrozen(uid);
    let needed = 0; let riskBlock = null;
    const out = commit(() => {
      const prev = db.prepare('SELECT * FROM withdrawals WHERE uid = ? AND idem = ?').get(uid, key);
      if (prev) { if (prev.amount !== amount || prev.currency !== currency || prev.beneficiary_id !== i.beneficiaryId) bad('idempotency_conflict', 409); return wdView(prev); }
      const ben = db.prepare("SELECT * FROM beneficiaries WHERE id = ? AND uid = ? AND status = 'active'").get(String(i.beneficiaryId || ''), uid) ?? bad('beneficiary_not_found', 404);
      if (ben.currency !== currency && !i.crossBorder) bad('beneficiary_currency_mismatch');
      if (ben.usable_after > now()) bad('beneficiary_cooling_off', 403);
      const t = now();
      if (db.prepare("SELECT COUNT(*) c FROM withdrawals WHERE uid = ? AND created_at > ?").get(uid, t - HOUR).c >= cfg.maxWithdrawalsPerHour) bad('velocity_limit', 429);
      const used = db.prepare("SELECT COALESCE(SUM(amount),0) s FROM withdrawals WHERE uid = ? AND currency = ? AND created_at > ? AND status NOT IN ('rejected','cancelled')").get(uid, currency, t - DAY).s;
      const limit = cfg.dailyWithdraw[Math.min(tr, 2)][currency];
      if (used + amount > limit) bad('daily_limit_exceeded', 403);
      const fee = i.crossBorder ? i.fee : cfg.fee[currency];
      const flags = i.crossBorder ? ['cross_border'] : [];
      if (!db.prepare("SELECT 1 FROM withdrawals WHERE uid = ? AND status = 'completed' LIMIT 1").get(uid)) flags.push('first_withdrawal');
      if (t - ben.created_at < cfg.newBeneficiaryFlag) flags.push('new_beneficiary');
      if (amount >= limit / 2) flags.push('large');
      const dep = db.prepare("SELECT COALESCE(SUM(amount),0) s FROM txns WHERE uid = ? AND currency = ? AND type = 'deposit' AND created_at > ?").get(uid, currency, t - 2 * HOUR).s;
      if (dep && amount >= dep * 0.8) flags.push('fresh_deposit');
      const id = rid('wd');
      const rk = ctx.risk.checkWithdrawal(uid, id, { currency, amount, flags, limit });
      if (rk.blocked) { riskBlock = rk; return null; }
      flags.push(...rk.flags);
      const hold = L.post({ type: 'withdrawal_hold', uid, currency, amount: amount + fee, idem: `h:${key}`, meta: { withdrawalId: id, crossBorder: Boolean(i.crossBorder) },
        legs: [{ acc: L.account(uid, currency, 'wallet'), delta: -(amount + fee) }, { acc: L.account(uid, currency, 'hold'), delta: amount + fee }] });
      needed = ctx.security.needsApproval(uid, currency, amount);
      db.prepare('INSERT INTO withdrawals (id, uid, currency, amount, fee, beneficiary_id, status, flags, hold_txn, idem, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)')
        .run(id, uid, currency, amount, fee, ben.id, needed ? 'awaiting_approvals' : 'requested', JSON.stringify(flags), hold.id, key, t, t);
      if (needed) ctx.security.openApproval(uid, 'withdrawal', id, currency, amount, needed);
      if (i.crossBorder) ctx.fx.recordIntl(uid, id, i.crossBorder);
      A.log(uid, 'withdrawal.request', id, { currency, amount, fee, flags, needed });
      return wdView(db.prepare('SELECT * FROM withdrawals WHERE id = ?').get(id));
    }, uid);
    if (riskBlock) { ctx.notify(uid, 'fraud_alert'); bad('risk_blocked', 403); }
    if (needed) for (const a of ctx.security.approverUids(uid)) ctx.notify(a, 'approval_needed');
    return out;
  }
  ctx.withdrawals = { create: createWithdrawal };
  ctx.approvalTargets.withdrawal = {
    approved: (a) => db.prepare("UPDATE withdrawals SET status = 'requested', updated_at = ? WHERE id = ? AND status = 'awaiting_approvals'").run(now(), a.target_id),
    rejected: (a) => {
      const w = db.prepare("SELECT * FROM withdrawals WHERE id = ? AND status = 'awaiting_approvals'").get(a.target_id); if (!w) return;
      db.prepare("UPDATE withdrawals SET status = 'rejected', note = 'co_signers', updated_at = ? WHERE id = ?").run(now(), w.id);
      releaseHold(w, 'withdrawal_release', 'co_signers', 'system');
    },
  };
  const listWithdrawals = (uid) => db.prepare('SELECT * FROM withdrawals WHERE uid = ? ORDER BY created_at DESC LIMIT 50').all(uid).map(wdView);
  function releaseHold(w, type, why, actor) {
    const total = w.amount + w.fee;
    L.post({ type, uid: w.uid, currency: w.currency, amount: total, idem: `r:${w.id}`, meta: { withdrawalId: w.id, why },
      legs: [{ acc: L.account(w.uid, w.currency, 'hold'), delta: -total }, { acc: L.account(w.uid, w.currency, 'wallet'), delta: total }] });
    A.log(actor, `withdrawal.${type === 'withdrawal_release' ? 'release' : 'refund'}`, w.id, { why });
  }
  function cancelWithdrawal(uid, id) {
    return commit(() => {
      const w = db.prepare('SELECT * FROM withdrawals WHERE id = ? AND uid = ?').get(id, uid) ?? bad('not_found', 404);
      if (w.status !== 'requested' && w.status !== 'awaiting_approvals') bad('bad_state', 409);
      db.prepare("UPDATE withdrawals SET status = 'cancelled', updated_at = ? WHERE id = ?").run(now(), id);
      ctx.security.cancelApprovalFor('withdrawal', id);
      releaseHold(w, 'withdrawal_release', 'user_cancelled', uid); return { ok: true };
    }, uid);
  }
  /** Owner: approve (money may now be sent outside) or reject (hold returned). Never the owner's own withdrawal. */
  function reviewWithdrawal(actor, id, decision, note) {
    oneOf(decision, ['approve', 'reject'], 'bad_decision'); const why = note ? str(note, { max: 200, code: 'bad_reason' }) : '';
    let uid;
    const r = commit(() => {
      const w = db.prepare('SELECT * FROM withdrawals WHERE id = ?').get(id) ?? bad('not_found', 404);
      uid = w.uid; notSelf(actor, w.uid);
      if (w.status !== 'requested') bad('bad_state', 409);
      if (decision === 'approve') { db.prepare("UPDATE withdrawals SET status = 'approved', reviewer = ?, note = ?, updated_at = ? WHERE id = ?").run(actor.uid, why, now(), id); A.log(actor.uid, 'withdrawal.approve', id, { uid: w.uid }); }
      else { db.prepare("UPDATE withdrawals SET status = 'rejected', reviewer = ?, note = ?, updated_at = ? WHERE id = ?").run(actor.uid, why || 'rejected', now(), id); releaseHold(w, 'withdrawal_release', 'rejected', actor.uid); }
      return { ok: true, amount: w.amount, currency: w.currency };
    });
    ping(uid); ctx.notify(uid, decision === 'approve' ? 'withdrawal_approved' : 'withdrawal_rejected', { amount: r.amount, currency: r.currency });
    return { ok: true };
  }
  /** Owner, after really sending the money outside: the hold leaves the ledger (payout + fee). One external reference = one payout. */
  function completeWithdrawal(actor, id, { extRef } = {}) {
    const ref = str(extRef, { min: 4, max: 100, re: /^[A-Za-z0-9._:/-]+$/, code: 'bad_reference' });
    let uid;
    const r = commit(() => {
      const w = db.prepare('SELECT * FROM withdrawals WHERE id = ?').get(id) ?? bad('not_found', 404);
      uid = w.uid; notSelf(actor, w.uid);
      if (w.status !== 'approved') bad('bad_state', 409);
      L.post({ type: 'withdrawal', uid: w.uid, currency: w.currency, amount: w.amount + w.fee, extRef: ref, meta: { withdrawalId: id, fee: w.fee },
        legs: [{ acc: L.account(w.uid, w.currency, 'hold'), delta: -(w.amount + w.fee) }, { acc: L.sys('external', w.currency), delta: w.amount }, { acc: L.sys('fees', w.currency), delta: w.fee }] });
      db.prepare("UPDATE withdrawals SET status = 'completed', ext_ref = ?, updated_at = ? WHERE id = ?").run(ref, now(), id);
      A.log(actor.uid, 'withdrawal.complete', id, { uid: w.uid });
      return { ok: true, amount: w.amount, currency: w.currency };
    });
    ping(uid); ctx.notify(uid, 'withdrawal_completed', { amount: r.amount, currency: r.currency });
    return { ok: true };
  }
  /** Owner only, audited: the destination of a withdrawal, so the payout can be made. */
  function withdrawalDestination(actor, id) {
    const w = db.prepare('SELECT * FROM withdrawals WHERE id = ?').get(id) ?? bad('not_found', 404); notSelf(actor, w.uid);
    const b = db.prepare('SELECT * FROM beneficiaries WHERE id = ?').get(w.beneficiary_id) ?? bad('not_found', 404);
    const details = open(b.details, `ben:${w.uid}`);
    db.tx(() => A.log(actor.uid, 'withdrawal.view_destination', id, {}));
    return { withdrawalId: id, currency: w.currency, amount: w.amount, details, intl: ctx.fx.intlFor(id) };
  }

  /* ─────────── KYC ─────────── */
  const kycView = (uid) => {
    const r = db.prepare('SELECT tier, status, requested_tier, submitted_at, reviewed_at, reason FROM kyc WHERE uid = ?').get(uid);
    return r ? { tier: r.tier, status: r.status, requestedTier: r.requested_tier, submittedAt: r.submitted_at, reviewedAt: r.reviewed_at, reason: r.status === 'rejected' ? r.reason : null } : { tier: 0, status: 'none', requestedTier: null };
  };
  function submitKyc(uid, i) {
    const wanted = oneOf(i.tier, [1, 2], 'bad_tier');
    const data = {
      fullName: str(i.fullName, { min: 3, max: 80, re: /^[\p{L}\p{M} '.-]+$/u, code: 'bad_name' }), dob: adult(i.dob, now()),
      nationality: iso2(i.nationality), residence: address(i.address), idType: oneOf(i.idType, ['passport', 'national_id', 'driver_license'], 'bad_id_type'),
      idNumber: str(i.idNumber, { min: 4, max: 30, re: /^[A-Za-z0-9 -]+$/, code: 'bad_id_number' }), idExpiry: str(i.idExpiry, { max: 10, re: /^\d{4}-\d{2}-\d{2}$/, code: 'bad_id_expiry' }),
      vendorRef: i.vendorRef ? str(i.vendorRef, { max: 80, re: /^[A-Za-z0-9._:-]+$/, code: 'bad_vendor_ref' }) : '',
    };
    if (new Date(`${data.idExpiry}T00:00:00Z`).getTime() < now()) bad('id_expired');
    if (cfg.blockedCountries.includes(data.nationality) || cfg.blockedCountries.includes(data.residence.country)) bad('not_available_in_region', 403);
    if (wanted === 2) {
      if (tier(uid) < 1) bad('kyc_tier1_first', 403);
      data.sourceOfFunds = oneOf(i.sourceOfFunds, ['salary', 'business', 'savings', 'investments', 'other'], 'bad_source_of_funds');
      data.proofOfAddressRef = str(i.proofOfAddressRef, { min: 4, max: 80, re: /^[A-Za-z0-9._:-]+$/, code: 'bad_proof_ref' });
    }
    const soon = new Date(`${data.idExpiry}T00:00:00Z`).getTime() - now();
    if (soon < 30 * DAY) bad('id_expiring');   // a document about to lapse would break re-verification within weeks
    const idHash = vault.blind(`${data.idType}|${data.nationality}|${data.idNumber}`);   // keyed hash: the number itself is never stored in the clear
    // Raw document images are NOT stored here: the verification vendor keeps them; we store its reference and our decision.
    let dup = false;
    const out = commit(() => {
      const cur = db.prepare('SELECT status FROM kyc WHERE uid = ?').get(uid);
      if (cur?.status === 'pending') bad('already_pending', 409);
      const t = now();
      const holder = db.prepare('SELECT uid FROM kyc_ids WHERE hash = ?').get(idHash);
      if (holder && holder.uid !== uid) { A.log(uid, 'kyc.duplicate_id', uid, {}); ctx.risk.record(uid, 'kyc', null, 70, 'review', [{ why: 'duplicate_id_document', pts: 70 }]); dup = true; return null; }   // recorded, then refused after commit
      if (!holder) db.prepare('INSERT INTO kyc_ids (hash, uid, created_at) VALUES (?,?,?)').run(idHash, uid, t);
      db.prepare(`INSERT INTO kyc (uid, tier, status, data, requested_tier, submitted_at) VALUES (?,0,'pending',?,?,?)
        ON CONFLICT(uid) DO UPDATE SET status='pending', data=excluded.data, requested_tier=excluded.requested_tier, submitted_at=excluded.submitted_at, reason=NULL`)
        .run(uid, seal(data, `kyc:${uid}`), wanted, t);
      A.log(uid, 'kyc.submit', uid, { tier: wanted });
      return kycView(uid);
    });
    if (dup) bad('verification_failed', 409);
    return out;
  }
  function reviewKyc(actor, uid, decision, reason) {
    oneOf(decision, ['approve', 'reject'], 'bad_decision'); const why = reason ? str(reason, { max: 200, code: 'bad_reason' }) : '';
    notSelf(actor, uid);
    return commit(() => {
      const k = db.prepare('SELECT * FROM kyc WHERE uid = ?').get(uid) ?? bad('not_found', 404);
      if (k.status !== 'pending') bad('bad_state', 409);
      if (decision === 'approve') db.prepare("UPDATE kyc SET status = 'approved', tier = ?, reviewed_by = ?, reviewed_at = ?, reason = NULL WHERE uid = ?").run(k.requested_tier, actor.uid, now(), uid);
      else db.prepare("UPDATE kyc SET status = 'rejected', reviewed_by = ?, reviewed_at = ?, reason = ? WHERE uid = ?").run(actor.uid, now(), why || 'rejected', uid);
      A.log(actor.uid, `kyc.${decision}`, uid, { tier: k.requested_tier });
      return kycView(uid);
    }, uid);
  }
  function reviewKycAndHooks(actor, uid, decision, reason) {
    const v = reviewKyc(actor, uid, decision, reason);
    if (decision === 'approve') { ctx.notify(uid, 'kyc_approved', { tier: v.tier }); ctx.emit('kyc.approved', { uid, tier: v.tier }); } else ctx.notify(uid, 'kyc_rejected');
    return v;
  }
  /** Owner only: the submitted data, decrypted. Every view is audited. */
  function kycDetail(actor, uid) {
    notSelf(actor, uid);
    const k = db.prepare('SELECT data FROM kyc WHERE uid = ?').get(uid); if (!k?.data) bad('not_found', 404);
    const data = open(k.data, `kyc:${uid}`);
    db.tx(() => A.log(actor.uid, 'kyc.view', uid, {}));
    return data;
  }

  /* ─────────── Visa card request ─────────── */
  const cardView = (c) => ({ id: c.id, product: c.product, status: c.status, city: c.city, country: c.country, fee: c.fee, currency: c.currency, tracking: c.tracking, createdAt: c.created_at, updatedAt: c.updated_at });
  const CARD_FLOW = { requested: ['review', 'rejected'], review: ['sent_to_issuer', 'rejected'], sent_to_issuer: ['produced'], produced: ['shipped'], shipped: ['delivered'], delivered: ['active'] };
  const CARD_OPEN = ['requested', 'review', 'sent_to_issuer', 'produced', 'shipped', 'delivered', 'active', 'frozen'];
  function requestCard(uid, i) {
    const key = idemOk(i.idem); needTier(uid, 2);
    const product = oneOf(i.product, ['physical', 'virtual'], 'bad_product');
    const shipping = product === 'physical' ? oneOf(i.shipping, ['standard', 'express'], 'bad_shipping') : 'virtual';
    const form = {
      nameOnCard: str(String(i.nameOnCard ?? '').toUpperCase(), { min: 3, max: 26, re: /^[A-Z][A-Z .'-]*[A-Z]$/, code: 'bad_card_name' }),
      phone: str(i.phone, { min: 7, max: 20, re: /^\+?[0-9 ()-]{7,20}$/, code: 'bad_phone' }), shipping,
      address: product === 'physical' ? address(i.address) : null,
      consents: i.consents && i.consents.terms === true && i.consents.fees === true && i.consents.dataSharing === true ? { terms: true, fees: true, dataSharing: true } : bad('consent_required'),
    };
    ctx.vcards.verifyHolder(uid, { holder: form.nameOnCard, dob: i.dob });
    if (form.address && (cfg.blockedCountries.includes(form.address.country))) bad('not_available_in_region', 403);
    const fee = cfg.cardFee[shipping]; const id = rid('card');
    return commit(() => {
      const prev = db.prepare('SELECT * FROM cards WHERE uid = ? AND idem = ?').get(uid, key);
      if (prev) return cardView(prev);
      if (db.prepare(`SELECT 1 FROM cards WHERE uid = ? AND status IN (${CARD_OPEN.map(() => '?').join(',')}) AND product = ?`).get(uid, ...CARD_OPEN, product)) bad('card_already_requested', 409);
      let feeTxn = null;
      if (fee > 0) feeTxn = L.post({ type: 'card_fee', uid, currency: 'USD', amount: fee, idem: `c:${key}`, meta: { cardId: id },
        legs: [{ acc: L.account(uid, 'USD', 'wallet'), delta: -fee }, { acc: L.sys('fees', 'USD'), delta: fee }] }).id;
      const t = now();
      db.prepare('INSERT INTO cards (id, uid, product, status, form, city, country, fee_txn, fee, currency, idem, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)')
        .run(id, uid, product, 'requested', seal(form, `card:${uid}`), form.address?.city ?? null, form.address?.country ?? null, feeTxn, fee, 'USD', key, t, t);
      A.log(uid, 'card.request', id, { product, shipping, fee });
      return cardView(db.prepare('SELECT * FROM cards WHERE id = ?').get(id));
    }, uid);
  }
  const listCards = (uid) => db.prepare('SELECT * FROM cards WHERE uid = ? ORDER BY created_at DESC LIMIT 20').all(uid).map(cardView);
  function refundCardFee(c, why, actor) {
    if (!c.fee || !c.fee_txn) return;
    L.post({ type: 'card_fee_refund', uid: c.uid, currency: c.currency, amount: c.fee, idem: `cr:${c.id}`, meta: { cardId: c.id, why },
      legs: [{ acc: L.sys('fees', c.currency), delta: -c.fee }, { acc: L.account(c.uid, c.currency, 'wallet'), delta: c.fee }] });
    A.log(actor, 'card.refund', c.id, { why });
  }
  function cancelCard(uid, id) {
    return commit(() => {
      const c = db.prepare('SELECT * FROM cards WHERE id = ? AND uid = ?').get(id, uid) ?? bad('not_found', 404);
      if (c.status !== 'requested') bad('bad_state', 409);
      db.prepare("UPDATE cards SET status = 'cancelled', updated_at = ? WHERE id = ?").run(now(), id); refundCardFee(c, 'user_cancelled', uid); return { ok: true };
    }, uid);
  }
  /** Owner mirrors what the issuer / courier reported; no PAN/CVV ever enters this system. */
  function updateCard(actor, id, { status, tracking } = {}) {
    let uid;
    const r = commit(() => {
      const c = db.prepare('SELECT * FROM cards WHERE id = ?').get(id) ?? bad('not_found', 404); uid = c.uid; notSelf(actor, c.uid);
      if (!(CARD_FLOW[c.status] || []).includes(status)) bad('bad_transition', 409);
      const trk = tracking ? str(tracking, { max: 40, re: /^[A-Za-z0-9-]+$/, code: 'bad_tracking' }) : c.tracking;
      db.prepare('UPDATE cards SET status = ?, tracking = ?, updated_at = ? WHERE id = ?').run(status, trk, now(), id);
      if (status === 'rejected') refundCardFee(c, 'issuer_rejected', actor.uid);
      A.log(actor.uid, 'card.update', id, { status }); return { ok: true };
    });
    ping(uid); ctx.notify(uid, 'card_status'); return r;
  }
  function cardAction(uid, id, action) {
    oneOf(action, ['activate', 'freeze', 'unfreeze'], 'bad_action');
    return commit(() => {
      const c = db.prepare('SELECT * FROM cards WHERE id = ? AND uid = ?').get(id, uid) ?? bad('not_found', 404);
      const to = { activate: ['delivered', 'active'], freeze: ['active', 'frozen'], unfreeze: ['frozen', 'active'] }[action];
      if (c.status !== to[0]) bad('bad_state', 409);
      db.prepare('UPDATE cards SET status = ?, updated_at = ? WHERE id = ?').run(to[1], now(), id);
      A.log(uid, `card.${action}`, id, {}); return cardView(db.prepare('SELECT * FROM cards WHERE id = ?').get(id));
    });
  }
  function cardDetail(actor, id) {
    const c = db.prepare('SELECT * FROM cards WHERE id = ?').get(id) ?? bad('not_found', 404); notSelf(actor, c.uid);
    const form = open(c.form, `card:${c.uid}`); db.tx(() => A.log(actor.uid, 'card.view', id, {}));
    return { id, ...cardView(c), form };
  }

  /* ─────────── automated investment (user-defined recurring buys) ─────────── */
  const EVERY = { daily: DAY, weekly: 7 * DAY, monthly: 30 * DAY };
  const planView = (p) => ({ id: p.id, asset: p.asset, currency: p.currency, amount: p.amount, every: p.every, status: p.status, mode: p.mode, nextRun: p.next_run, dailyCap: p.daily_cap, maxSlipBp: p.max_slip_bp, fails: p.fails });
  function createPlan(uid, i) {
    const asset = oneOf(i.asset, cfg.plans.assets, 'bad_asset'); const every = oneOf(i.every, Object.keys(EVERY), 'bad_interval');
    const amount = toMinor(i.amount, 'USDT') ?? bad('bad_amount'); if (amount < cfg.plans.minAmount) bad('below_minimum');
    const cap = i.dailyCap == null ? cfg.plans.dailyCapDefault : (toMinor(i.dailyCap, 'USDT') ?? bad('bad_amount'));
    const slip = i.maxSlipBp == null ? 100 : Number(i.maxSlipBp); if (!Number.isInteger(slip) || slip < 10 || slip > 500) bad('bad_slippage');
    return commit(() => {
      if (db.prepare("SELECT COUNT(*) c FROM plans WHERE uid = ? AND status != 'deleted'").get(uid).c >= cfg.plans.maxPerUser) bad('too_many_plans', 429);
      const id = rid('plan'); const t = now();
      db.prepare('INSERT INTO plans (id, uid, asset, currency, amount, every, status, mode, next_run, max_slip_bp, daily_cap, created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)')
        .run(id, uid, asset, 'USDT', amount, every, 'active', sandbox ? 'paper' : 'broker', t + EVERY[every], slip, cap, t);
      A.log(uid, 'plan.create', id, { asset, amount, every });
      return planView(db.prepare('SELECT * FROM plans WHERE id = ?').get(id));
    });
  }
  const listPlans = (uid) => db.prepare("SELECT * FROM plans WHERE uid = ? AND status != 'deleted' ORDER BY created_at DESC").all(uid).map(planView);
  function setPlan(uid, id, action) {
    oneOf(action, ['pause', 'resume', 'delete'], 'bad_action');
    return commit(() => {
      const p = db.prepare("SELECT * FROM plans WHERE id = ? AND uid = ? AND status != 'deleted'").get(id, uid) ?? bad('not_found', 404);
      const st = { pause: 'paused', resume: 'active', delete: 'deleted' }[action];
      db.prepare('UPDATE plans SET status = ?, fails = 0, next_run = ? WHERE id = ?').run(st, action === 'resume' ? now() + EVERY[p.every] : p.next_run, id);
      A.log(uid, `plan.${action}`, id, {}); return { ok: true };
    });
  }
  const listOrders = (uid) => db.prepare('SELECT id, plan_id, asset, status, mode, amount, price, qty, reason, created_at FROM orders WHERE uid = ? ORDER BY created_at DESC LIMIT 50').all(uid);
  /** Key rotation: after setting BANK_MASTER_KEY (new) and BANK_MASTER_KEY_PREV (old), re-wrap every sealed record under the new key. Idempotent. */
  function rewrapAll(actor) {
    const targets = [['kyc', 'uid', 'data', (r) => `kyc:${r.uid}`], ['cards', 'id', 'form', (r) => `card:${r.uid}`, 'uid'], ['vcards', 'id', 'pan_enc', (r) => `vcpan:${r.id}`],
      ['totp', 'uid', 'secret_enc', (r) => `totp:${r.uid}`], ['beneficiaries', 'id', 'details', (r) => `ben:${r.uid}`, 'uid']];
    let done = 0; let skipped = 0;
    commit(() => {
      for (const [tbl, pk, col, aadOf, extra] of targets) {
        const cols = [...new Set([pk, col, extra, tbl === 'vcards' ? null : 'uid'].filter(Boolean))];
        for (const r of db.prepare(`SELECT ${cols.join(',')} FROM ${tbl} WHERE ${col} IS NOT NULL`).all()) {
          try { const nb = vault.rewrap(r[col], aadOf(r)); if (nb !== r[col]) { db.prepare(`UPDATE ${tbl} SET ${col} = ? WHERE ${pk} = ?`).run(nb, r[pk]); done++; } } catch { skipped++; }
        }
      }
      A.log(actor, 'vault.rewrap_all', 'all', { done, skipped });
    });
    return { rewrapped: done, skipped, kid: vault.kid };
  }
  const holdings = (uid) => db.prepare('SELECT asset, qty, cost FROM holdings WHERE uid = ? AND qty > 0').all(uid).map((h) => ({ ...h, mode: sandbox ? 'paper' : 'broker' }));
  /**
   * Runs every due plan once (no catch-up for missed runs). sandbox: paper fill at a fresh real price against sandbox funds.
   * live: needs a broker adapter (`broker.buy`); without one the order is recorded as blocked and NO money moves.
   */
  async function runDue() {
    const due = db.prepare("SELECT * FROM plans WHERE status = 'active' AND next_run <= ? ORDER BY next_run LIMIT 50").all(now());
    const out = [];
    for (const p of due) {
      let quote = null; let reason = ctx.security.isFrozen(p.uid) ? 'frozen' : null;
      if (!reason) try {
        if (sandbox) { quote = priceFn ? await priceFn(p.asset) : null; if (!quote || !(quote.price > 0) || now() - quote.ts > cfg.plans.maxStaleMs) { quote = null; reason = 'no_fresh_price'; } }
        else if (!broker) reason = 'no_broker';
      } catch { reason = 'price_error'; }
      const done = commit(() => {
        const cur = db.prepare("SELECT * FROM plans WHERE id = ? AND status = 'active' AND next_run <= ?").get(p.id, now()); if (!cur) return null;
        const t = now(); let next = cur.next_run; while (next <= t) next += EVERY[cur.every];
        const oid = rid('ord'); let status = 'skipped'; let qty = null; let txnId = null;
        if (!reason) {
          const spent = db.prepare("SELECT COALESCE(SUM(amount),0) s FROM orders WHERE uid = ? AND status = 'filled' AND created_at > ?").get(cur.uid, t - DAY).s;
          if (spent + cur.amount > cur.daily_cap) reason = 'daily_cap';
          else if (L.balance(cur.uid, 'USDT').available < cur.amount) reason = 'insufficient_funds';
          else {
            qty = Math.floor((cur.amount / 1e6 / quote.price) * 1e8);
            if (qty <= 0) reason = 'amount_too_small';
            else {
              const tx = L.post({ type: 'invest_buy', uid: cur.uid, currency: 'USDT', amount: cur.amount, meta: { planId: cur.id, asset: cur.asset, price: quote.price, qty, paper: true },
                legs: [{ acc: L.account(cur.uid, 'USDT', 'wallet'), delta: -cur.amount }, { acc: L.sys('invest', 'USDT'), delta: cur.amount }] });
              txnId = tx.id; status = 'filled';
              db.prepare('INSERT INTO holdings (uid, asset, qty, cost) VALUES (?,?,?,?) ON CONFLICT(uid, asset) DO UPDATE SET qty = qty + excluded.qty, cost = cost + excluded.cost').run(cur.uid, cur.asset, qty, cur.amount);
            }
          }
        }
        const fails = status === 'filled' ? 0 : cur.fails + 1;
        const pause = fails >= 3 && reason !== 'no_broker';
        db.prepare('INSERT INTO orders (id, plan_id, uid, asset, status, mode, amount, price, qty, reason, txn_id, created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)')
          .run(oid, cur.id, cur.uid, cur.asset, status, cur.mode, cur.amount, quote?.price ?? null, qty, reason, txnId, t);
        db.prepare('UPDATE plans SET next_run = ?, fails = ?, status = ? WHERE id = ?').run(next, fails, pause ? 'paused' : 'active', cur.id);
        A.log('system', `plan.${status}`, cur.id, { reason, orderId: oid });
        return { plan: cur.id, status, reason, uid: cur.uid };
      });
      if (done) { out.push(done); ping(done.uid); if (done.status !== 'filled') ctx.notify(done.uid, 'plan_skipped'); }
    }
    for (const job of [ctx.security.expireApprovals, ctx.pockets.runVault, ctx.planning.runRules, ctx.vcards.runSubs, ctx.rewards.runExpiry, ctx.ob.runExpiry]) {
      try { job(); } catch (e) { console.error('[bank] job failed:', e?.code || e?.name, String(e?.message || '').slice(0, 80)); }
    }
    try { await ctx.compliance.runDue(); } catch (e) { console.error('[bank] compliance failed:', e?.code || e?.name, String(e?.message || '').slice(0, 80)); }
    return out;
  }

  /* ─────────── owner overview ─────────── */
  function adminQueue() {
    return {
      mode: sandbox ? 'sandbox' : 'live',
      deposits: db.prepare("SELECT id, uid, currency, amount, method, reference, created_at, expires_at FROM deposits WHERE status = 'requested' AND expires_at > ? ORDER BY created_at LIMIT 100").all(now()),
      withdrawals: db.prepare("SELECT id, uid, currency, amount, fee, status, flags, created_at FROM withdrawals WHERE status IN ('requested','approved') ORDER BY created_at LIMIT 100").all().map((w) => ({ ...w, flags: JSON.parse(w.flags) })),
      kyc: db.prepare("SELECT uid, requested_tier, submitted_at FROM kyc WHERE status = 'pending' ORDER BY submitted_at LIMIT 100").all(),
      cards: db.prepare("SELECT id, uid, product, status, city, country, created_at FROM cards WHERE status IN ('requested','review','sent_to_issuer','produced','shipped','delivered') ORDER BY created_at LIMIT 100").all(),
      ledger: L.verify(), audit: A.verify(),
    };
  }

  return {
    mode: sandbox ? 'sandbox' : 'live', events, ledger: L, audit: A, config: cfg, kycStatus: kycView,
    wallet, history, requestDeposit, listDeposits, confirmDeposit, rejectDeposit, sandboxFund: sandboxFundAndHooks,
    addBeneficiary: addBeneficiaryAndNotify, listBeneficiaries, removeBeneficiary, requestWithdrawal, listWithdrawals, cancelWithdrawal, reviewWithdrawal, completeWithdrawal, withdrawalDestination,
    submitKyc, reviewKyc: reviewKycAndHooks, kycDetail, requestCard, listCards, cancelCard, updateCard, cardAction, cardDetail,
    createPlan, listPlans, setPlan, listOrders, holdings, runDue, adminQueue, rewrapAll,
    notifications, security: ctx.security, pockets: ctx.pockets, planning: ctx.planning, vcards: ctx.vcards, rewards: ctx.rewards, fx: ctx.fx, ob: ctx.ob, insights: ctx.insights, support: ctx.support, totp: ctx.totp, risk: ctx.risk, compliance: ctx.compliance,
    issuerName: () => ctx.issuer?.name || null,
  };
}
export { BankError };
