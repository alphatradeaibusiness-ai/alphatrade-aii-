// Web Push without dependencies: VAPID (RFC 8292, ES256 JWT) + message encryption "aes128gcm" (RFC 8291 / RFC 8188).
// The push service (Google, Mozilla, Apple, Microsoft) only sees an encrypted blob; only the user's browser can read it.
// Endpoints are restricted to the known push services, so a stored subscription can never make the server call an arbitrary URL.
import crypto from 'node:crypto';

const b64u = (b) => Buffer.from(b).toString('base64url');
const PUSH_HOSTS = [/^fcm\.googleapis\.com$/, /^updates\.push\.services\.mozilla\.com$/, /^web\.push\.apple\.com$/, /\.notify\.windows\.com$/, /^android\.googleapis\.com$/];

/** New VAPID key pair: { publicKey: base64url(uncompressed P-256 point, 65 bytes), privateJwk } */
export function generateVapid() {
  const { publicKey, privateKey } = crypto.generateKeyPairSync('ec', { namedCurve: 'prime256v1' });
  const jwk = privateKey.export({ format: 'jwk' });
  const pub = publicKey.export({ format: 'jwk' });
  return { publicKey: b64u(Buffer.concat([Buffer.from([4]), Buffer.from(pub.x, 'base64url'), Buffer.from(pub.y, 'base64url')])), privateJwk: jwk };
}

/** Validates a browser PushSubscription JSON. testBase (tests only) allows one local endpoint origin. */
export function cleanSubscription(s, { testBase = '' } = {}) {
  if (!s || typeof s !== 'object' || typeof s.endpoint !== 'string' || s.endpoint.length > 1000) return null;
  let u; try { u = new URL(s.endpoint); } catch { return null; }
  const isTest = testBase && s.endpoint.startsWith(testBase);
  if (!isTest && (u.protocol !== 'https:' || !PUSH_HOSTS.some((re) => re.test(u.hostname)))) return null;
  const p256dh = s.keys?.p256dh; const auth = s.keys?.auth;
  if (typeof p256dh !== 'string' || typeof auth !== 'string') return null;
  let k; let a; try { k = Buffer.from(p256dh, 'base64url'); a = Buffer.from(auth, 'base64url'); } catch { return null; }
  if (k.length !== 65 || k[0] !== 4 || a.length !== 16) return null;
  return { endpoint: s.endpoint, keys: { p256dh: b64u(k), auth: b64u(a) } };
}

function vapidJwt(endpoint, vapid, subject, nowSec) {
  const aud = new URL(endpoint).origin;
  const h = b64u(JSON.stringify({ typ: 'JWT', alg: 'ES256' }));
  const p = b64u(JSON.stringify({ aud, exp: nowSec + 12 * 3600, sub: subject }));
  const key = crypto.createPrivateKey({ key: vapid.privateJwk, format: 'jwk' });
  const sig = crypto.sign('sha256', Buffer.from(`${h}.${p}`), { key, dsaEncoding: 'ieee-p1363' });
  return `${h}.${p}.${b64u(sig)}`;
}

const hmac = (key, data) => crypto.createHmac('sha256', key).update(data).digest();

/** RFC 8291 encryption of one record. Returns the full request body (header + ciphertext). */
export function encryptPayload(plaintext, sub) {
  const uaPub = Buffer.from(sub.keys.p256dh, 'base64url'); const authSecret = Buffer.from(sub.keys.auth, 'base64url');
  const ecdh = crypto.createECDH('prime256v1'); ecdh.generateKeys(); const asPub = ecdh.getPublicKey();
  const shared = ecdh.computeSecret(uaPub);
  const prkKey = hmac(authSecret, shared);
  const ikm = hmac(prkKey, Buffer.concat([Buffer.from('WebPush: info\0'), uaPub, asPub, Buffer.from([1])]));
  const salt = crypto.randomBytes(16);
  const prk = hmac(salt, ikm);
  const cek = hmac(prk, Buffer.from('Content-Encoding: aes128gcm\0\x01', 'binary')).subarray(0, 16);
  const nonce = hmac(prk, Buffer.from('Content-Encoding: nonce\0\x01', 'binary')).subarray(0, 12);
  const c = crypto.createCipheriv('aes-128-gcm', cek, nonce);
  const body = Buffer.concat([c.update(Buffer.concat([Buffer.from(plaintext), Buffer.from([2])])), c.final(), c.getAuthTag()]);
  const header = Buffer.alloc(21); salt.copy(header, 0); header.writeUInt32BE(4096, 16); header[20] = asPub.length;
  return Buffer.concat([header, asPub, body]);
}

/** Decrypts a body made by encryptPayload — used by tests acting as the browser. */
export function decryptPayload(body, uaPrivate, uaPub, authSecret) {
  const salt = body.subarray(0, 16); const idlen = body[20]; const asPub = body.subarray(21, 21 + idlen); const ct = body.subarray(21 + idlen);
  const ecdh = crypto.createECDH('prime256v1'); ecdh.setPrivateKey(uaPrivate);
  const shared = ecdh.computeSecret(asPub);
  const ikm = hmac(hmac(authSecret, shared), Buffer.concat([Buffer.from('WebPush: info\0'), uaPub, asPub, Buffer.from([1])]));
  const prk = hmac(salt, ikm);
  const cek = hmac(prk, Buffer.from('Content-Encoding: aes128gcm\0\x01', 'binary')).subarray(0, 16);
  const nonce = hmac(prk, Buffer.from('Content-Encoding: nonce\0\x01', 'binary')).subarray(0, 12);
  const d = crypto.createDecipheriv('aes-128-gcm', cek, nonce); d.setAuthTag(ct.subarray(ct.length - 16));
  const pt = Buffer.concat([d.update(ct.subarray(0, ct.length - 16)), d.final()]);
  return pt.subarray(0, pt.lastIndexOf(2)).toString('utf8');
}

/** Sends one message. Resolves { ok, gone } — gone=true means the subscription no longer exists and should be deleted. */
export async function sendPush(sub, payload, { vapid, subject = 'mailto:admin@localhost', ttl = 86400, now = Date.now } = {}) {
  const body = encryptPayload(JSON.stringify(payload), sub);
  const jwt = vapidJwt(sub.endpoint, vapid, subject, Math.floor(now() / 1000));
  const r = await fetch(sub.endpoint, {
    method: 'POST', redirect: 'error', signal: AbortSignal.timeout(8000), body,
    headers: { TTL: String(ttl), 'Content-Encoding': 'aes128gcm', 'Content-Type': 'application/octet-stream', Urgency: 'normal', Authorization: `vapid t=${jwt}, k=${vapid.publicKey}` },
  });
  return { ok: r.status >= 200 && r.status < 300, gone: r.status === 404 || r.status === 410, status: r.status };
}
