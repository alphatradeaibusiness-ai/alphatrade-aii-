// Double-entry ledger. A transaction is a set of entries whose deltas sum to zero; user balances can never go negative
// (enforced by a CHECK in the database as well). Entries are never edited: a correction is a new, reversing transaction.
// Accounts: wallet (spendable), hold (reserved for a pending withdrawal/fee), system (platform:external, platform:fees, platform:sandbox, platform:invest).
import crypto from 'node:crypto';
import { isUnit } from './money.js';

const rid = (p) => `${p}_${crypto.randomBytes(9).toString('base64url')}`;

export class LedgerError extends Error { constructor(code) { super(code); this.code = code; } }

export function createLedger(db, now = Date.now) {
  const getAcc = db.prepare('SELECT id, balance FROM accounts WHERE owner = ? AND currency = ? AND kind = ? AND sub = ?');
  const insAcc = db.prepare('INSERT INTO accounts (id, owner, currency, kind, sub, balance, created_at) VALUES (?,?,?,?,?,0,?)');
  const addBal = db.prepare('UPDATE accounts SET balance = balance + ? WHERE id = ?');
  const insTxn = db.prepare('INSERT INTO txns (id, type, status, uid, currency, amount, idem, ext_ref, meta, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)');
  const insEntry = db.prepare('INSERT INTO entries (txn_id, account_id, delta) VALUES (?,?,?)');

  /** kind: wallet | hold | system | pocket (sub = pocket id) | vault (time-locked savings) | points (PTS only). */
  function account(owner, currency, kind, sub = '') {
    if (!isUnit(currency)) throw new LedgerError('bad_currency');
    let a = getAcc.get(owner, currency, kind, sub);
    if (!a) { const id = rid('acc'); insAcc.run(id, owner, currency, kind, sub, now()); a = { id, balance: 0 }; }
    return a;
  }
  const sys = (name, currency) => account(`platform:${name}`, currency, 'system');

  return {
    account, sys,
    balance(uid, currency) { return { available: account(uid, currency, 'wallet').balance, held: account(uid, currency, 'hold').balance }; },
    /**
     * legs: [{ acc: {id}, delta }] with Σdelta = 0. Must be called inside db.tx(). Idempotent per (uid, idem).
     * Returns { id, replay } — replay=true when the same idempotency key was already applied.
     */
    post({ type, uid = null, currency, amount, legs, idem = null, extRef = null, meta = {}, status = 'completed', at = null }) {
      if (legs.reduce((s, l) => s + l.delta, 0) !== 0) throw new LedgerError('unbalanced');
      if (legs.some((l) => !Number.isSafeInteger(l.delta) || l.delta === 0)) throw new LedgerError('bad_leg');
      if (idem && uid) {
        const prev = db.prepare('SELECT id, type, amount, currency FROM txns WHERE uid = ? AND idem = ?').get(uid, idem);
        if (prev) { if (prev.type !== type || prev.amount !== amount || prev.currency !== currency) throw new LedgerError('idempotency_conflict'); return { id: prev.id, replay: true }; }
      }
      const id = rid('txn'); const t = at ?? now();   // `at` only for sandbox simulations that back-date a purchase
      try { insTxn.run(id, type, status, uid, currency, amount, idem, extRef, JSON.stringify(meta), t, t); }
      catch (e) { if (/UNIQUE/.test(String(e.message)) && extRef) throw new LedgerError('duplicate_reference'); throw e; }
      for (const l of legs) {
        try { addBal.run(l.delta, l.acc.id); } catch (e) { if (/CHECK/.test(String(e.message))) throw new LedgerError('insufficient_funds'); throw e; }
        insEntry.run(id, l.acc.id, l.delta);
      }
      return { id, replay: false };
    },
    /** Σ of all entry deltas per currency must be 0, and each account's stored balance must equal its entries. */
    verify() {
      const bad = [];
      for (const r of db.prepare('SELECT a.currency c, SUM(e.delta) s FROM entries e JOIN accounts a ON a.id = e.account_id GROUP BY a.currency').all()) if (r.s !== 0) bad.push({ kind: 'currency_not_zero', currency: r.c, sum: r.s });
      for (const r of db.prepare('SELECT a.id, a.balance b, COALESCE((SELECT SUM(delta) FROM entries WHERE account_id = a.id), 0) s FROM accounts a').all()) if (r.b !== r.s) bad.push({ kind: 'balance_mismatch', account: r.id, stored: r.b, entries: r.s });
      for (const r of db.prepare('SELECT txn_id, SUM(delta) s FROM entries GROUP BY txn_id HAVING s != 0').all()) bad.push({ kind: 'txn_unbalanced', txn: r.txn_id });
      return { ok: bad.length === 0, problems: bad };
    },
    history(uid, { limit = 30, before = null, type = null, currency = null, category = null, tag = null } = {}) {
      const lim = Math.max(1, Math.min(100, limit | 0));
      const where = ['t.uid = ?']; const args = [uid, uid];
      if (type) { where.push('t.type = ?'); args.push(String(type).slice(0, 40)); }
      if (currency) { where.push('t.currency = ?'); args.push(String(currency).slice(0, 8)); } else where.push("t.currency != 'PTS'");   // points have their own history
      if (category) { where.push("COALESCE(l.category, json_extract(t.meta, '$.category'), '') = ?"); args.push(String(category).slice(0, 30)); }
      if (tag) { where.push("EXISTS (SELECT 1 FROM json_each(COALESCE(l.tags, '[]')) j WHERE j.value = ?)"); args.push(String(tag).slice(0, 24)); }
      if (before) { const [c, i] = String(before).split('|'); where.push('(t.created_at < ? OR (t.created_at = ? AND t.id < ?))'); args.push(Number(c) || 0, Number(c) || 0, String(i || '')); }
      // effect = signed change of THIS user's spendable wallet caused by the transaction (+ in, − out); 0 for hold moves of the same money
      const rows = db.prepare(`SELECT t.id, t.type, t.status, t.currency, t.amount, t.meta, t.created_at, t.updated_at, l.category AS label_category, l.tags AS label_tags, l.note AS label_note,
        (SELECT COALESCE(SUM(e.delta), 0) FROM entries e JOIN accounts a ON a.id = e.account_id WHERE e.txn_id = t.id AND a.owner = ? AND a.kind = 'wallet') AS effect
        FROM txns t LEFT JOIN txn_labels l ON l.txn_id = t.id AND l.uid = t.uid WHERE ${where.join(' AND ')} ORDER BY t.created_at DESC, t.id DESC LIMIT ?`).all(...args, lim + 1);
      const more = rows.length > lim; const page = rows.slice(0, lim);
      return { items: page.map(({ label_category: lc, label_tags: lt, label_note: ln, ...r }) => ({ ...r, meta: safeMeta(r.meta), label: lc || lt || ln ? { category: lc || null, tags: safeArr(lt), noteSealed: ln || null } : null })), next: more ? `${page.at(-1).created_at}|${page.at(-1).id}` : null };
    },
  };
}
function safeArr(s) { try { const a = JSON.parse(s || '[]'); return Array.isArray(a) ? a : []; } catch { return []; } }
function safeMeta(s) { try { const m = JSON.parse(s || '{}'); return m && typeof m === 'object' ? m : {}; } catch { return {}; } }
