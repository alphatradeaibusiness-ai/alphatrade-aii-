// SQLite (node:sqlite, built into Node 22) with real transactions: the only place money state lives.
// Entries are append-only (triggers refuse UPDATE/DELETE) and user balances can never go negative (CHECK).
import { DatabaseSync } from 'node:sqlite';
import fs from 'node:fs';
import path from 'node:path';

const SCHEMA = `
CREATE TABLE IF NOT EXISTS accounts (
  id TEXT PRIMARY KEY, owner TEXT NOT NULL, currency TEXT NOT NULL, kind TEXT NOT NULL CHECK (kind IN ('wallet','hold','system','pocket','vault','points')),
  sub TEXT NOT NULL DEFAULT '', balance INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL,
  UNIQUE (owner, currency, kind, sub),
  CHECK (kind = 'system' OR balance >= 0)
);
CREATE TABLE IF NOT EXISTS txns (
  id TEXT PRIMARY KEY, type TEXT NOT NULL, status TEXT NOT NULL, uid TEXT, currency TEXT NOT NULL, amount INTEGER NOT NULL,
  idem TEXT, ext_ref TEXT, meta TEXT, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS txns_idem ON txns (uid, idem) WHERE idem IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS txns_ext ON txns (ext_ref) WHERE ext_ref IS NOT NULL;
CREATE INDEX IF NOT EXISTS txns_uid ON txns (uid, created_at DESC, id);
CREATE TABLE IF NOT EXISTS entries (
  id INTEGER PRIMARY KEY AUTOINCREMENT, txn_id TEXT NOT NULL REFERENCES txns(id), account_id TEXT NOT NULL REFERENCES accounts(id), delta INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS entries_txn ON entries (txn_id);
CREATE TRIGGER IF NOT EXISTS entries_no_update BEFORE UPDATE ON entries BEGIN SELECT RAISE(ABORT, 'entries are append-only'); END;
CREATE TRIGGER IF NOT EXISTS entries_no_delete BEFORE DELETE ON entries BEGIN SELECT RAISE(ABORT, 'entries are append-only'); END;
CREATE TABLE IF NOT EXISTS deposits (
  id TEXT PRIMARY KEY, uid TEXT NOT NULL, currency TEXT NOT NULL, amount INTEGER NOT NULL, method TEXT NOT NULL, reference TEXT NOT NULL UNIQUE,
  status TEXT NOT NULL, ext_ref TEXT UNIQUE, idem TEXT, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL, expires_at INTEGER NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS deposits_idem ON deposits (uid, idem) WHERE idem IS NOT NULL;
CREATE TABLE IF NOT EXISTS beneficiaries (
  id TEXT PRIMARY KEY, uid TEXT NOT NULL, kind TEXT NOT NULL, currency TEXT NOT NULL, label TEXT NOT NULL, last4 TEXT NOT NULL,
  details TEXT NOT NULL, blind TEXT NOT NULL, status TEXT NOT NULL, created_at INTEGER NOT NULL, usable_after INTEGER NOT NULL,
  UNIQUE (uid, blind)
);
CREATE TABLE IF NOT EXISTS withdrawals (
  id TEXT PRIMARY KEY, uid TEXT NOT NULL, currency TEXT NOT NULL, amount INTEGER NOT NULL, fee INTEGER NOT NULL, beneficiary_id TEXT NOT NULL,
  status TEXT NOT NULL, flags TEXT NOT NULL DEFAULT '[]', hold_txn TEXT, ext_ref TEXT UNIQUE, idem TEXT, reviewer TEXT, note TEXT,
  created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS withdrawals_idem ON withdrawals (uid, idem) WHERE idem IS NOT NULL;
CREATE TABLE IF NOT EXISTS kyc (
  uid TEXT PRIMARY KEY, tier INTEGER NOT NULL DEFAULT 0, status TEXT NOT NULL DEFAULT 'none', data TEXT, requested_tier INTEGER,
  submitted_at INTEGER, reviewed_by TEXT, reviewed_at INTEGER, reason TEXT
);
CREATE TABLE IF NOT EXISTS cards (
  id TEXT PRIMARY KEY, uid TEXT NOT NULL, product TEXT NOT NULL, status TEXT NOT NULL, form TEXT NOT NULL, city TEXT, country TEXT,
  fee_txn TEXT, fee INTEGER NOT NULL, currency TEXT NOT NULL, tracking TEXT, idem TEXT, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS cards_idem ON cards (uid, idem) WHERE idem IS NOT NULL;
CREATE TABLE IF NOT EXISTS plans (
  id TEXT PRIMARY KEY, uid TEXT NOT NULL, asset TEXT NOT NULL, currency TEXT NOT NULL, amount INTEGER NOT NULL, every TEXT NOT NULL,
  status TEXT NOT NULL, mode TEXT NOT NULL, next_run INTEGER NOT NULL, max_slip_bp INTEGER NOT NULL, daily_cap INTEGER NOT NULL,
  fails INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS holdings (uid TEXT NOT NULL, asset TEXT NOT NULL, qty INTEGER NOT NULL, cost INTEGER NOT NULL, PRIMARY KEY (uid, asset));
CREATE TABLE IF NOT EXISTS orders (
  id TEXT PRIMARY KEY, plan_id TEXT NOT NULL, uid TEXT NOT NULL, asset TEXT NOT NULL, status TEXT NOT NULL, mode TEXT NOT NULL,
  amount INTEGER NOT NULL, price REAL, qty INTEGER, reason TEXT, txn_id TEXT, created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS audit (
  seq INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER NOT NULL, actor TEXT NOT NULL, action TEXT NOT NULL, target TEXT, detail TEXT,
  prev TEXT NOT NULL, hash TEXT NOT NULL
);
CREATE TRIGGER IF NOT EXISTS audit_no_update BEFORE UPDATE ON audit BEGIN SELECT RAISE(ABORT, 'audit is append-only'); END;
CREATE TRIGGER IF NOT EXISTS audit_no_delete BEFORE DELETE ON audit BEGIN SELECT RAISE(ABORT, 'audit is append-only'); END;

-- v150 ---------------------------------------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS meta (k TEXT PRIMARY KEY, v TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS txn_labels (txn_id TEXT PRIMARY KEY REFERENCES txns(id), uid TEXT NOT NULL, category TEXT, tags TEXT, note TEXT, updated_at INTEGER NOT NULL);
CREATE INDEX IF NOT EXISTS txn_labels_uid ON txn_labels (uid, category);
CREATE TABLE IF NOT EXISTS pockets (
  id TEXT PRIMARY KEY, uid TEXT NOT NULL, currency TEXT NOT NULL, name TEXT NOT NULL, goal INTEGER, color TEXT NOT NULL, status TEXT NOT NULL, created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS pockets_uid ON pockets (uid, status);
CREATE TABLE IF NOT EXISTS vault_releases (
  id TEXT PRIMARY KEY, uid TEXT NOT NULL, currency TEXT NOT NULL, amount INTEGER NOT NULL, status TEXT NOT NULL, unlock_at INTEGER NOT NULL,
  approval_id TEXT, txn_id TEXT, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS user_flags (uid TEXT PRIMARY KEY, frozen INTEGER NOT NULL DEFAULT 0, frozen_at INTEGER, policy TEXT, prefs TEXT);
CREATE TABLE IF NOT EXISTS approvers (owner_uid TEXT NOT NULL, approver_uid TEXT NOT NULL, label TEXT NOT NULL, created_at INTEGER NOT NULL, PRIMARY KEY (owner_uid, approver_uid));
CREATE TABLE IF NOT EXISTS approver_invites (code_hash TEXT PRIMARY KEY, owner_uid TEXT NOT NULL, label TEXT NOT NULL, expires_at INTEGER NOT NULL, used INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS approvals (
  id TEXT PRIMARY KEY, owner_uid TEXT NOT NULL, kind TEXT NOT NULL, target_id TEXT NOT NULL, currency TEXT NOT NULL, amount INTEGER NOT NULL,
  needed INTEGER NOT NULL, status TEXT NOT NULL, expires_at INTEGER NOT NULL, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS approval_votes (approval_id TEXT NOT NULL, approver_uid TEXT NOT NULL, decision TEXT NOT NULL, passkey INTEGER NOT NULL, at INTEGER NOT NULL, PRIMARY KEY (approval_id, approver_uid));
CREATE TABLE IF NOT EXISTS passkeys (
  id TEXT PRIMARY KEY, uid TEXT NOT NULL, jwk TEXT NOT NULL, alg INTEGER NOT NULL, sign_count INTEGER NOT NULL DEFAULT 0, name TEXT NOT NULL,
  created_at INTEGER NOT NULL, last_used INTEGER
);
CREATE INDEX IF NOT EXISTS passkeys_uid ON passkeys (uid);
CREATE TABLE IF NOT EXISTS webauthn_challenges (
  id TEXT PRIMARY KEY, uid TEXT NOT NULL, challenge TEXT NOT NULL, purpose TEXT NOT NULL, binding TEXT NOT NULL, expires_at INTEGER NOT NULL, used INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS vcards (
  id TEXT PRIMARY KEY, uid TEXT NOT NULL, issuer TEXT NOT NULL, issuer_ref TEXT NOT NULL UNIQUE, last4 TEXT NOT NULL, exp TEXT NOT NULL, kind TEXT NOT NULL,
  merchant_lock TEXT, label TEXT NOT NULL, status TEXT NOT NULL, limit_tx INTEGER NOT NULL, limit_day INTEGER NOT NULL, limit_month INTEGER NOT NULL,
  pocket_id TEXT, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL,
  art TEXT NOT NULL DEFAULT 'graphite:lines', holder TEXT, pan_enc TEXT, pan_hash TEXT
);
CREATE INDEX IF NOT EXISTS vcards_uid ON vcards (uid, status);
CREATE UNIQUE INDEX IF NOT EXISTS vcards_pan ON vcards (pan_hash) WHERE pan_hash IS NOT NULL;
CREATE TABLE IF NOT EXISTS card_auths (
  id TEXT PRIMARY KEY, uid TEXT NOT NULL, card_id TEXT NOT NULL, issuer_event TEXT UNIQUE, merchant TEXT NOT NULL, merchant_key TEXT NOT NULL, category TEXT NOT NULL,
  amount INTEGER NOT NULL, currency TEXT NOT NULL, status TEXT NOT NULL, reason TEXT, hold_txn TEXT, settle_txn TEXT, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS card_auths_uid ON card_auths (uid, created_at DESC);
CREATE TABLE IF NOT EXISTS blocked_merchants (uid TEXT NOT NULL, merchant_key TEXT NOT NULL, created_at INTEGER NOT NULL, PRIMARY KEY (uid, merchant_key));
CREATE TABLE IF NOT EXISTS budgets (uid TEXT NOT NULL, category TEXT NOT NULL, amount INTEGER NOT NULL, block INTEGER NOT NULL DEFAULT 0, alerted TEXT, PRIMARY KEY (uid, category));
CREATE TABLE IF NOT EXISTS subscriptions (
  id TEXT PRIMARY KEY, uid TEXT NOT NULL, merchant TEXT NOT NULL, merchant_key TEXT NOT NULL, amount INTEGER NOT NULL, currency TEXT NOT NULL, every TEXT NOT NULL,
  next_due INTEGER, source TEXT NOT NULL, status TEXT NOT NULL, reminded_for INTEGER, last_amount INTEGER, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL,
  UNIQUE (uid, merchant_key)
);
CREATE TABLE IF NOT EXISTS save_rules (
  id TEXT PRIMARY KEY, uid TEXT NOT NULL, kind TEXT NOT NULL, pocket_id TEXT NOT NULL, currency TEXT NOT NULL, amount INTEGER, pct_bp INTEGER, round_to INTEGER,
  every TEXT, next_run INTEGER, daily_cap INTEGER NOT NULL, floor INTEGER NOT NULL, status TEXT NOT NULL, created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS points_lots (id TEXT PRIMARY KEY, uid TEXT NOT NULL, amount INTEGER NOT NULL, remaining INTEGER NOT NULL, reason TEXT NOT NULL, ref TEXT, earned_at INTEGER NOT NULL, UNIQUE (uid, reason, ref));
CREATE TABLE IF NOT EXISTS quotes (
  id TEXT PRIMARY KEY, uid TEXT NOT NULL, kind TEXT NOT NULL, from_cur TEXT NOT NULL, to_cur TEXT NOT NULL, amount INTEGER NOT NULL, rate REAL NOT NULL, fee INTEGER NOT NULL,
  receive INTEGER NOT NULL, beneficiary_id TEXT, expires_at INTEGER NOT NULL, used INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS intl_transfers (id TEXT PRIMARY KEY, uid TEXT NOT NULL, quote_id TEXT NOT NULL UNIQUE, withdrawal_id TEXT NOT NULL, to_cur TEXT NOT NULL, receive INTEGER NOT NULL, rate REAL NOT NULL, created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS sells (id TEXT PRIMARY KEY, uid TEXT NOT NULL, asset TEXT NOT NULL, qty INTEGER NOT NULL, price REAL NOT NULL, proceeds INTEGER NOT NULL, mode TEXT NOT NULL, txn_id TEXT, created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS ob_links (id TEXT PRIMARY KEY, uid TEXT NOT NULL, provider TEXT NOT NULL, institution TEXT NOT NULL, status TEXT NOT NULL, consent_expires INTEGER NOT NULL, token TEXT, created_at INTEGER NOT NULL, refreshed_at INTEGER);
CREATE TABLE IF NOT EXISTS ob_accounts (id TEXT PRIMARY KEY, link_id TEXT NOT NULL, uid TEXT NOT NULL, name TEXT NOT NULL, last4 TEXT NOT NULL, currency TEXT NOT NULL, balance INTEGER NOT NULL, demo INTEGER NOT NULL, updated_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS ob_txns (id TEXT PRIMARY KEY, account_id TEXT NOT NULL, uid TEXT NOT NULL, at INTEGER NOT NULL, amount INTEGER NOT NULL, currency TEXT NOT NULL, description TEXT NOT NULL, category TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS ob_txns_uid ON ob_txns (uid, at DESC);
CREATE TABLE IF NOT EXISTS tickets (id TEXT PRIMARY KEY, uid TEXT NOT NULL, subject TEXT NOT NULL, topic TEXT NOT NULL, txn_ref TEXT, status TEXT NOT NULL, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS ticket_msgs (id TEXT PRIMARY KEY, ticket_id TEXT NOT NULL, author TEXT NOT NULL, body TEXT NOT NULL, created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS notifications (id TEXT PRIMARY KEY, uid TEXT NOT NULL, kind TEXT NOT NULL, params TEXT NOT NULL, read INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL);
CREATE INDEX IF NOT EXISTS notifications_uid ON notifications (uid, created_at DESC);
CREATE TABLE IF NOT EXISTS push_subs (id TEXT PRIMARY KEY, uid TEXT NOT NULL, endpoint_hash TEXT NOT NULL UNIQUE, sub TEXT NOT NULL, created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS totp (uid TEXT PRIMARY KEY, secret_enc TEXT NOT NULL, confirmed_at INTEGER, last_step INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS totp_backup (uid TEXT NOT NULL, hash TEXT NOT NULL, used_at INTEGER, PRIMARY KEY (uid, hash));
CREATE TABLE IF NOT EXISTS risk_events (id TEXT PRIMARY KEY, uid TEXT NOT NULL, kind TEXT NOT NULL, ref TEXT, score INTEGER NOT NULL, level TEXT NOT NULL, reasons TEXT NOT NULL, created_at INTEGER NOT NULL, reviewed_by TEXT, reviewed_at INTEGER);
CREATE INDEX IF NOT EXISTS risk_uid ON risk_events (uid, created_at DESC);
CREATE INDEX IF NOT EXISTS risk_level ON risk_events (level, created_at DESC);
CREATE TABLE IF NOT EXISTS compliance_reports (id TEXT PRIMARY KEY, period TEXT NOT NULL UNIQUE, kind TEXT NOT NULL, from_ts INTEGER NOT NULL, to_ts INTEGER NOT NULL, data TEXT NOT NULL, created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS kyc_ids (hash TEXT PRIMARY KEY, uid TEXT NOT NULL, created_at INTEGER NOT NULL);
`;

const VERSION = 4;
/**
 * v1 (v149) → v2: the accounts table gains `sub` (pocket id) and new kinds (pocket, vault, points). SQLite cannot change a CHECK,
 * so the table is rebuilt in one transaction with every row and balance copied as is; the ledger check afterwards proves nothing moved.
 */
function migrate(db) {
  // v2 → v3: virtual cards gain art, cardholder name and the encrypted number (added in place; nothing is rewritten).
  if (db.prepare("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = 'vcards'").get() && !db.prepare('PRAGMA table_info(vcards)').all().some((c) => c.name === 'art')) {
    db.exec("ALTER TABLE vcards ADD COLUMN art TEXT NOT NULL DEFAULT 'graphite:lines'; ALTER TABLE vcards ADD COLUMN holder TEXT; ALTER TABLE vcards ADD COLUMN pan_enc TEXT; ALTER TABLE vcards ADD COLUMN pan_hash TEXT;");
  }
  const has = db.prepare("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = 'accounts'").get();
  const ver = db.prepare('PRAGMA user_version').get().user_version;
  if (!has || ver >= 2) return;
  const cols = db.prepare('PRAGMA table_info(accounts)').all().map((c) => c.name);
  if (cols.includes('sub')) return;
  db.exec('PRAGMA foreign_keys = OFF');
  db.exec('BEGIN IMMEDIATE');
  try {
    db.exec(`CREATE TABLE accounts_v2 (
      id TEXT PRIMARY KEY, owner TEXT NOT NULL, currency TEXT NOT NULL, kind TEXT NOT NULL CHECK (kind IN ('wallet','hold','system','pocket','vault','points')),
      sub TEXT NOT NULL DEFAULT '', balance INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL, UNIQUE (owner, currency, kind, sub), CHECK (kind = 'system' OR balance >= 0));
      INSERT INTO accounts_v2 (id, owner, currency, kind, sub, balance, created_at) SELECT id, owner, currency, kind, '', balance, created_at FROM accounts;
      DROP TABLE accounts; ALTER TABLE accounts_v2 RENAME TO accounts;`);
    db.exec('COMMIT');
  } catch (e) { try { db.exec('ROLLBACK'); } catch { /* */ } throw e; }
}

export function openDb(dir, name = 'bank.db') {
  if (dir !== ':memory:') fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
  const file = dir === ':memory:' ? ':memory:' : path.join(dir, name);
  const db = new DatabaseSync(file);
  db.exec('PRAGMA journal_mode = WAL; PRAGMA synchronous = FULL; PRAGMA busy_timeout = 5000;');
  migrate(db);
  db.exec('PRAGMA foreign_keys = ON;');
  db.exec(SCHEMA);
  db.exec(`PRAGMA user_version = ${VERSION}`);
  if (file !== ':memory:') { try { fs.chmodSync(file, 0o600); } catch { /* best effort */ } }
  /** Runs fn inside BEGIN IMMEDIATE … COMMIT; any throw rolls everything back. Never nest. */
  db.tx = (fn) => {
    db.exec('BEGIN IMMEDIATE');
    try { const r = fn(); db.exec('COMMIT'); return r; } catch (e) { try { db.exec('ROLLBACK'); } catch { /* already rolled back */ } throw e; }
  };
  return db;
}
