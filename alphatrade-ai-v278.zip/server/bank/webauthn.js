// Passkeys (WebAuthn) without dependencies: a small CBOR reader, COSE → JWK, and the two checks the server must do —
// registration (store the public key) and assertion (the device signed OUR challenge, for THIS site, with user verification).
// The fingerprint / face never leaves the device; the server only ever sees a public key and signatures.
// Attestation statements are not verified (passkeys from synced providers usually send "none"); the security comes from the
// challenge, origin, RP id, user-verification flag and the signature, which are all checked.
import crypto from 'node:crypto';

export class WebAuthnError extends Error { constructor(code) { super(code); this.code = code; } }
const fail = (c) => { throw new WebAuthnError(c); };
export const b64u = (buf) => Buffer.from(buf).toString('base64url');
export const fromB64u = (s) => { if (typeof s !== 'string' || !/^[A-Za-z0-9_-]*={0,2}$/.test(s) || s.length > 4096) fail('bad_encoding'); return Buffer.from(s, 'base64url'); };

/** Minimal CBOR decoder (RFC 8949): unsigned/negative ints, byte/text strings, arrays, maps, simple values. Enough for WebAuthn. */
export function cborDecode(buf) {
  let i = 0; let depth = 0;
  const need = (n) => { if (i + n > buf.length) fail('cbor_truncated'); };
  const len = (ai) => {
    if (ai < 24) return ai;
    if (ai === 24) { need(1); return buf[i++]; }
    if (ai === 25) { need(2); const v = buf.readUInt16BE(i); i += 2; return v; }
    if (ai === 26) { need(4); const v = buf.readUInt32BE(i); i += 4; return v; }
    if (ai === 27) { need(8); const v = Number(buf.readBigUInt64BE(i)); i += 8; if (!Number.isSafeInteger(v)) fail('cbor_big'); return v; }
    return fail('cbor_indefinite');
  };
  const item = () => {
    if (++depth > 16) fail('cbor_deep');
    need(1); const b = buf[i++]; const mt = b >> 5; const ai = b & 31; let v;
    if (mt === 0) v = len(ai);
    else if (mt === 1) v = -1 - len(ai);
    else if (mt === 2) { const n = len(ai); need(n); v = buf.subarray(i, i + n); i += n; }
    else if (mt === 3) { const n = len(ai); need(n); v = buf.subarray(i, i + n).toString('utf8'); i += n; }
    else if (mt === 4) { const n = len(ai); if (n > 64) fail('cbor_big'); v = []; for (let k = 0; k < n; k++) v.push(item()); }
    else if (mt === 5) { const n = len(ai); if (n > 64) fail('cbor_big'); v = new Map(); for (let k = 0; k < n; k++) { const key = item(); v.set(key, item()); } }
    else if (mt === 7) { v = ai === 20 ? false : ai === 21 ? true : ai === 22 ? null : fail('cbor_simple'); }
    else fail('cbor_type');
    depth--; return v;
  };
  const out = item();
  return { value: out, rest: buf.subarray(i) };
}

/** COSE_Key map → JWK (ES256 on P-256, or RS256). */
export function coseToJwk(m) {
  if (!(m instanceof Map)) fail('bad_cose');
  const kty = m.get(1); const alg = m.get(3);
  if (kty === 2 && alg === -7 && m.get(-1) === 1) {
    const x = m.get(-2); const y = m.get(-3); if (!Buffer.isBuffer(x) || !Buffer.isBuffer(y) || x.length !== 32 || y.length !== 32) fail('bad_cose');
    return { jwk: { kty: 'EC', crv: 'P-256', x: b64u(x), y: b64u(y) }, alg: -7 };
  }
  if (kty === 3 && alg === -257) {
    const n = m.get(-1); const e = m.get(-2); if (!Buffer.isBuffer(n) || !Buffer.isBuffer(e) || n.length < 256) fail('bad_cose');
    return { jwk: { kty: 'RSA', n: b64u(n), e: b64u(e) }, alg: -257 };
  }
  return fail('unsupported_algorithm');
}

/** authenticatorData: rpIdHash(32) flags(1) signCount(4) [attestedCredentialData] */
export function parseAuthData(ad) {
  if (!Buffer.isBuffer(ad) || ad.length < 37) fail('bad_auth_data');
  const flags = ad[32];
  const out = { rpIdHash: ad.subarray(0, 32), up: Boolean(flags & 1), uv: Boolean(flags & 4), at: Boolean(flags & 64), signCount: ad.readUInt32BE(33) };
  if (out.at) {
    if (ad.length < 55) fail('bad_auth_data');
    const idLen = ad.readUInt16BE(53); if (idLen < 16 || idLen > 1023 || ad.length < 55 + idLen) fail('bad_auth_data');
    out.credId = ad.subarray(55, 55 + idLen);
    out.cose = cborDecode(ad.subarray(55 + idLen)).value;
  }
  return out;
}

function checkClient(clientDataJSON, type, challenge, origins) {
  let c; try { c = JSON.parse(clientDataJSON.toString('utf8')); } catch { fail('bad_client_data'); }
  if (c.type !== type) fail('bad_client_data');
  if (typeof c.challenge !== 'string' || Buffer.byteLength(c.challenge) !== Buffer.byteLength(challenge) || !crypto.timingSafeEqual(Buffer.from(c.challenge), Buffer.from(challenge))) fail('challenge_mismatch');
  if (!origins.includes(c.origin)) fail('origin_mismatch');
  if (c.crossOrigin === true) fail('origin_mismatch');
  return c;
}
const rpHashOk = (h, rpId) => crypto.timingSafeEqual(h, crypto.createHash('sha256').update(rpId).digest());

/**
 * @param cred  { id, rawId, type:'public-key', response:{ clientDataJSON, attestationObject } } (base64url strings)
 * @returns { id, jwk, alg, signCount }
 */
export function verifyRegistration(cred, { challenge, origins, rpId }) {
  if (!cred || cred.type !== 'public-key' || !cred.response) fail('bad_credential');
  const cdj = fromB64u(cred.response.clientDataJSON); const ao = fromB64u(cred.response.attestationObject);
  if (ao.length > 4096 || cdj.length > 2048) fail('too_large');
  checkClient(cdj, 'webauthn.create', challenge, origins);
  const att = cborDecode(ao).value; if (!(att instanceof Map)) fail('bad_attestation');
  const ad = parseAuthData(att.get('authData'));
  if (!rpHashOk(ad.rpIdHash, rpId)) fail('rp_mismatch');
  if (!ad.up || !ad.uv) fail('user_verification_required');
  if (!ad.at || !ad.credId) fail('bad_attestation');
  if (b64u(ad.credId) !== cred.id) fail('credential_id_mismatch');
  const { jwk, alg } = coseToJwk(ad.cose);
  crypto.createPublicKey({ key: jwk, format: 'jwk' });   // throws on an invalid point / key
  return { id: cred.id, jwk, alg, signCount: ad.signCount };
}

/**
 * @param cred   { id, response:{ clientDataJSON, authenticatorData, signature } }
 * @param stored { jwk, alg, signCount }
 * @returns { signCount }
 */
export function verifyAssertion(cred, stored, { challenge, origins, rpId }) {
  if (!cred || !cred.response) fail('bad_credential');
  const cdj = fromB64u(cred.response.clientDataJSON); const adb = fromB64u(cred.response.authenticatorData); const sig = fromB64u(cred.response.signature);
  if (cdj.length > 2048 || adb.length > 1024 || sig.length > 1024) fail('too_large');
  checkClient(cdj, 'webauthn.get', challenge, origins);
  const ad = parseAuthData(adb);
  if (!rpHashOk(ad.rpIdHash, rpId)) fail('rp_mismatch');
  if (!ad.up || !ad.uv) fail('user_verification_required');
  const data = Buffer.concat([adb, crypto.createHash('sha256').update(cdj).digest()]);
  const key = crypto.createPublicKey({ key: stored.jwk, format: 'jwk' });
  const ok = stored.alg === -7 ? crypto.verify('sha256', data, { key, dsaEncoding: 'der' }, sig) : crypto.verify('sha256', data, key, sig);
  if (!ok) fail('bad_signature');
  // A counter that does not grow means a cloned authenticator — but synced passkeys always send 0, which is allowed.
  if ((ad.signCount !== 0 || stored.signCount !== 0) && ad.signCount <= stored.signCount) fail('counter_replay');
  return { signCount: ad.signCount };
}
