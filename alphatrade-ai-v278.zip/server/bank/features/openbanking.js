// Open Banking (read-only account information). A provider adapter (Tink, TrueLayer, Plaid… under its AISP licence) returns
// accounts and transactions after the user consents at their own bank; we keep a copy for budgets, insights and net worth,
// for at most the consent period (90 days), and delete it when the user unlinks. In sandbox mode a built-in DEMO provider
// returns invented accounts, clearly flagged demo=true — they are never mixed with real money and never move anything.
import crypto from 'node:crypto';
import { bad, str, oneOf } from '../validate.js';

const DAY = 86400_000;
export const DEMO_INSTITUTIONS = ['Demo Bank A', 'Demo Bank B'];
const DEMO_SHOPS = [['Supermarket', 'groceries', 4200], ['Coffee shop', 'dining', 450], ['Metro ticket', 'transport', 280], ['Electricity', 'bills', 6800], ['Streaming', 'subscriptions', 1199], ['Pharmacy', 'health', 1650], ['Bookshop', 'education', 2300], ['Restaurant', 'dining', 3800]];

/** Deterministic demo data (same link → same accounts), so the screens can be tried. */
export const demoProvider = {
  name: 'demo', demo: true,
  institutions: () => DEMO_INSTITUTIONS,
  fetch(linkId, now) {
    const seed = crypto.createHash('sha256').update(linkId).digest();
    const day = Math.floor(now / DAY);
    const accounts = [
      { ext: `${linkId}:cur`, name: 'Current account', last4: String(seed.readUInt16BE(0) % 10000).padStart(4, '0'), currency: 'EUR', balance: 150000 + (seed[2] * 1000) + ((day * 37) % 9000) },
      { ext: `${linkId}:sav`, name: 'Savings', last4: String(seed.readUInt16BE(4) % 10000).padStart(4, '0'), currency: 'EUR', balance: 500000 + seed[6] * 5000 },
    ];
    const txns = [];
    for (let k = 0; k < 30; k++) {
      const s = DEMO_SHOPS[(seed[k % 32] + k) % DEMO_SHOPS.length];
      txns.push({ ext: `${linkId}:t${k}`, account: accounts[0].ext, at: now - ((k * 2 + (seed[(k + 7) % 32] % 2)) * DAY), amount: -(s[2] + (seed[(k + 3) % 32] % 300)), currency: 'EUR', description: s[0], category: s[1] });
    }
    txns.push({ ext: `${linkId}:sal`, account: accounts[0].ext, at: now - 12 * DAY, amount: 320000, currency: 'EUR', description: 'Salary', category: 'income' });
    return { accounts, txns };
  },
};

export function createOpenBanking(ctx) {
  const { db, A, now, rid, commit, cfg } = ctx;
  const provider = () => ctx.obProvider ?? bad('no_open_banking_provider', 503);
  const linkView = (l) => ({
    id: l.id, institution: l.institution, provider: l.provider, status: l.status, consentExpires: l.consent_expires, refreshedAt: l.refreshed_at,
    accounts: db.prepare('SELECT id, name, last4, currency, balance, demo, updated_at FROM ob_accounts WHERE link_id = ?').all(l.id).map((a) => ({ ...a, demo: Boolean(a.demo) })),
  });
  const links = (uid) => db.prepare("SELECT * FROM ob_links WHERE uid = ? AND status = 'active' ORDER BY created_at").all(uid).map(linkView);
  function store(uid, l, data, demo) {
    db.prepare('DELETE FROM ob_txns WHERE account_id IN (SELECT id FROM ob_accounts WHERE link_id = ?)').run(l.id);
    db.prepare('DELETE FROM ob_accounts WHERE link_id = ?').run(l.id);
    const ids = {};
    for (const a of data.accounts.slice(0, 10)) {
      const id = `oba_${crypto.createHash('sha256').update(a.ext).digest('base64url').slice(0, 16)}`; ids[a.ext] = id;
      db.prepare('INSERT INTO ob_accounts (id, link_id, uid, name, last4, currency, balance, demo, updated_at) VALUES (?,?,?,?,?,?,?,?,?)')
        .run(id, l.id, uid, String(a.name).slice(0, 40), String(a.last4).slice(-4), a.currency, Math.trunc(a.balance), demo ? 1 : 0, now());
    }
    for (const t of data.txns.slice(0, 500)) if (ids[t.account]) db.prepare('INSERT INTO ob_txns (id, account_id, uid, at, amount, currency, description, category) VALUES (?,?,?,?,?,?,?,?)')
      .run(`obt_${crypto.createHash('sha256').update(t.ext).digest('base64url').slice(0, 16)}`, ids[t.account], uid, t.at, Math.trunc(t.amount), t.currency, String(t.description).slice(0, 60), String(t.category || 'other').slice(0, 24));
    db.prepare('UPDATE ob_links SET refreshed_at = ? WHERE id = ?').run(now(), l.id);
  }
  function link(uid, i) {
    const p = provider();
    const institution = oneOf(str(i.institution, { max: 60, code: 'bad_institution' }), p.institutions(), 'bad_institution');
    const out = commit(() => {
      if (db.prepare("SELECT COUNT(*) c FROM ob_links WHERE uid = ? AND status = 'active'").get(uid).c >= 5) bad('too_many_links', 429);
      const id = rid('obl'); const t = now();
      db.prepare('INSERT INTO ob_links (id, uid, provider, institution, status, consent_expires, created_at) VALUES (?,?,?,?,?,?,?)').run(id, uid, p.name, institution, 'active', t + cfg.openBanking.consentDays * DAY, t);
      const l = db.prepare('SELECT * FROM ob_links WHERE id = ?').get(id);
      store(uid, l, p.fetch(id, t), p.demo);
      A.log(uid, 'ob.link', id, { provider: p.name });
      return linkView(l);
    });
    ctx.notify(uid, 'ob_linked');
    return out;
  }
  function refresh(uid, id) {
    const p = provider();
    return commit(() => {
      const l = db.prepare("SELECT * FROM ob_links WHERE id = ? AND uid = ? AND status = 'active'").get(String(id || ''), uid) ?? bad('not_found', 404);
      store(uid, l, p.fetch(l.id, now()), p.demo); return linkView(db.prepare('SELECT * FROM ob_links WHERE id = ?').get(l.id));
    });
  }
  function revoke(uid, id) {
    return commit(() => {
      const l = db.prepare("SELECT * FROM ob_links WHERE id = ? AND uid = ? AND status = 'active'").get(String(id || ''), uid) ?? bad('not_found', 404);
      db.prepare('DELETE FROM ob_txns WHERE account_id IN (SELECT id FROM ob_accounts WHERE link_id = ?)').run(l.id);
      db.prepare('DELETE FROM ob_accounts WHERE link_id = ?').run(l.id);
      db.prepare("UPDATE ob_links SET status = 'revoked', token = NULL WHERE id = ?").run(l.id);
      A.log(uid, 'ob.revoke', l.id, {}); return { ok: true };
    });
  }
  const txns = (uid, accountId) => db.prepare('SELECT id, at, amount, currency, description, category FROM ob_txns WHERE uid = ? AND account_id = ? ORDER BY at DESC LIMIT 60').all(uid, String(accountId || ''));
  function runExpiry() {
    for (const l of db.prepare("SELECT * FROM ob_links WHERE status = 'active' AND consent_expires < ?").all(now())) {
      commit(() => {
        db.prepare('DELETE FROM ob_txns WHERE account_id IN (SELECT id FROM ob_accounts WHERE link_id = ?)').run(l.id);
        db.prepare('DELETE FROM ob_accounts WHERE link_id = ?').run(l.id);
        db.prepare("UPDATE ob_links SET status = 'expired', token = NULL WHERE id = ?").run(l.id);
        A.log('system', 'ob.expire', l.id, {});
      });
    }
  }
  const institutions = () => ({ provider: ctx.obProvider?.name || null, demo: Boolean(ctx.obProvider?.demo), institutions: ctx.obProvider ? ctx.obProvider.institutions() : [] });
  return { institutions, links, link, refresh, revoke, txns, runExpiry };
}
