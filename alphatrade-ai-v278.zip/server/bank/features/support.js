// Support tickets. Subject and messages are encrypted (they often contain personal details); the owner's desk lists tickets
// without their text and opens one at a time (audited). Support never asks for a password, a code or a card number — the
// page says so next to the form.
import { bad, str, oneOf } from '../validate.js';

export const TOPICS = ['card', 'transfer', 'deposit', 'withdrawal', 'kyc', 'security', 'invest', 'other'];

export function createSupport(ctx) {
  const { db, A, now, rid, commit, seal, open } = ctx;
  const aad = (uid) => `ticket:${uid}`;
  const tView = (t, withSubject) => ({ id: t.id, topic: t.topic, status: t.status, txnRef: t.txn_ref, createdAt: t.created_at, updatedAt: t.updated_at, ...(withSubject ? { subject: safeOpen(t.subject, t.uid) } : {}) });
  const safeOpen = (b, uid) => { try { return open(b, aad(uid)); } catch { return null; } };
  const msgs = (t) => db.prepare('SELECT author, body, created_at FROM ticket_msgs WHERE ticket_id = ? ORDER BY created_at').all(t.id).map((m) => ({ author: m.author, body: safeOpen(m.body, t.uid), at: m.created_at }));
  const body = (v) => str(v, { min: 2, max: 2000, code: 'bad_message' });

  function create(uid, i) {
    const topic = oneOf(i.topic, TOPICS, 'bad_topic'); const subject = str(i.subject, { min: 3, max: 80, code: 'bad_subject' }); const text = body(i.body);
    const txnRef = i.txnRef ? str(i.txnRef, { max: 40, re: /^[A-Za-z0-9_-]+$/, code: 'bad_reference' }) : null;
    if (txnRef && !db.prepare('SELECT 1 FROM txns WHERE id = ? AND uid = ?').get(txnRef, uid)) bad('not_found', 404);
    return commit(() => {
      if (db.prepare("SELECT COUNT(*) c FROM tickets WHERE uid = ? AND status != 'closed'").get(uid).c >= 5) bad('too_many_open_tickets', 429);
      const id = rid('tkt'); const t = now();
      db.prepare('INSERT INTO tickets (id, uid, subject, topic, txn_ref, status, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?)').run(id, uid, seal(subject, aad(uid)), topic, txnRef, 'open', t, t);
      db.prepare('INSERT INTO ticket_msgs (id, ticket_id, author, body, created_at) VALUES (?,?,?,?,?)').run(rid('msg'), id, 'user', seal(text, aad(uid)), t);
      A.log(uid, 'ticket.create', id, { topic });
      return tView(db.prepare('SELECT * FROM tickets WHERE id = ?').get(id), true);
    });
  }
  const list = (uid) => db.prepare('SELECT * FROM tickets WHERE uid = ? ORDER BY updated_at DESC LIMIT 30').all(uid).map((t) => tView(t, true));
  function view(uid, id) { const t = db.prepare('SELECT * FROM tickets WHERE id = ? AND uid = ?').get(String(id || ''), uid) ?? bad('not_found', 404); return { ...tView(t, true), messages: msgs(t) }; }
  function reply(uid, id, i) {
    const text = body(i.body);
    return commit(() => {
      const t = db.prepare('SELECT * FROM tickets WHERE id = ? AND uid = ?').get(String(id || ''), uid) ?? bad('not_found', 404);
      if (t.status === 'closed') bad('bad_state', 409);
      if (db.prepare('SELECT COUNT(*) c FROM ticket_msgs WHERE ticket_id = ?').get(t.id).c >= 50) bad('too_many', 429);
      db.prepare('INSERT INTO ticket_msgs (id, ticket_id, author, body, created_at) VALUES (?,?,?,?,?)').run(rid('msg'), t.id, 'user', seal(text, aad(uid)), now());
      db.prepare("UPDATE tickets SET status = 'open', updated_at = ? WHERE id = ?").run(now(), t.id);
      return { ok: true };
    });
  }
  function close(uid, id) {
    const r = db.prepare("UPDATE tickets SET status = 'closed', updated_at = ? WHERE id = ? AND uid = ? AND status != 'closed'").run(now(), String(id || ''), uid);
    if (!r.changes) bad('not_found', 404); return { ok: true };
  }
  /* owner desk */
  const adminList = () => db.prepare("SELECT * FROM tickets WHERE status != 'closed' ORDER BY CASE status WHEN 'open' THEN 0 ELSE 1 END, updated_at LIMIT 100").all().map((t) => ({ ...tView(t, false), user: String(t.uid).slice(0, 10) }));
  function adminView(actor, id) {
    const t = db.prepare('SELECT * FROM tickets WHERE id = ?').get(String(id || '')) ?? bad('not_found', 404);
    if (t.uid === actor.uid) bad('self_action_not_allowed', 403);
    db.tx(() => A.log(actor.uid, 'ticket.view', t.id, {}));
    return { ...tView(t, true), user: String(t.uid).slice(0, 10), messages: msgs(t) };
  }
  function adminReply(actor, id, i) {
    const text = body(i.body); let uid;
    commit(() => {
      const t = db.prepare('SELECT * FROM tickets WHERE id = ?').get(String(id || '')) ?? bad('not_found', 404);
      if (t.uid === actor.uid) bad('self_action_not_allowed', 403);
      if (t.status === 'closed') bad('bad_state', 409);
      uid = t.uid;
      db.prepare('INSERT INTO ticket_msgs (id, ticket_id, author, body, created_at) VALUES (?,?,?,?,?)').run(rid('msg'), t.id, 'support', seal(text, aad(t.uid)), now());
      db.prepare("UPDATE tickets SET status = ?, updated_at = ? WHERE id = ?").run(i.close === true ? 'closed' : 'answered', now(), t.id);
      A.log(actor.uid, 'ticket.reply', t.id, {});
    });
    ctx.notify(uid, 'ticket_reply');
    return { ok: true };
  }
  return { create, list, view, reply, close, adminList, adminView, adminReply };
}
