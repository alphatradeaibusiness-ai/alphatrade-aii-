// Read-only views over the ledger: personal insights (plain rules anyone can check, no black box), the user's dashboard
// (net worth, cash flow, spending by category), the owner's platform dashboard (no personal data), and the yearly tax
// report (FIFO cost basis for investment sales, fees paid, cashback). Also the "sell" side of the investment plans.
// Totals in USD use today's reference rates for every month — an approximation, labelled as such on the page.
import { bad, oneOf, idem as idemOk } from '../validate.js';
import { CURRENCIES, fromMinor } from '../money.js';
import { monthStart } from './planning.js';

const DAY = 86400_000;
const MONEY = Object.keys(CURRENCIES);
const INTERNAL = new Set(['pocket_in', 'pocket_out', 'vault_in', 'vault_out', 'auto_save', 'withdrawal_hold', 'withdrawal_release', 'card_hold', 'card_release', 'fx_out', 'fx_in']);

export function createInsights(ctx) {
  const { db, L, A, now, rid, commit, sandbox } = ctx;

  async function usdRates() { try { return (await ctx.fx.rates()).usdPer; } catch { return null; } }
  const toUsd = (minor, c, r) => (r ? (minor / 10 ** CURRENCIES[c].decimals) * r[c] : null);

  async function dashboard(uid) {
    const r = await usdRates();
    const parts = [];
    for (const c of MONEY) {
      const w = L.balance(uid, c);
      const pockets = db.prepare("SELECT COALESCE(SUM(a.balance),0) s FROM accounts a WHERE a.owner = ? AND a.currency = ? AND a.kind = 'pocket'").get(uid, c).s;
      const vault = L.account(uid, c, 'vault').balance;
      parts.push({ currency: c, wallet: w.available, held: w.held, pockets, vault });
    }
    const hold = db.prepare('SELECT asset, qty, cost FROM holdings WHERE uid = ? AND qty > 0').all(uid);
    const invest = [];
    for (const h of hold) { let price = null; try { price = (await ctx.priceFn?.(h.asset))?.price ?? null; } catch { price = null; } invest.push({ asset: h.asset, qty: h.qty, cost: h.cost, valueUsdt: price ? Math.floor((h.qty / 1e8) * price * 1e6) : null }); }
    const external = db.prepare('SELECT currency, SUM(balance) s, MAX(demo) demo FROM ob_accounts WHERE uid = ? GROUP BY currency').all(uid);
    let total = 0; let complete = Boolean(r);
    if (r) {
      for (const p of parts) total += toUsd(p.wallet + p.held + p.pockets + p.vault, p.currency, r);
      for (const i of invest) { if (i.valueUsdt == null) complete = false; else total += toUsd(i.valueUsdt, 'USDT', r); }
      for (const e of external) if (MONEY.includes(e.currency) && !e.demo) total += toUsd(e.s, e.currency, r);   // demo accounts are never counted as wealth
    }
    // cash flow: last 6 calendar months, money in / out of the user's spendable wallets (internal moves excluded)
    const flow = [];
    for (let k = 5; k >= 0; k--) {
      const d = new Date(now()); const from = Date.UTC(d.getUTCFullYear(), d.getUTCMonth() - k, 1); const to = Date.UTC(d.getUTCFullYear(), d.getUTCMonth() - k + 1, 1);
      const rows = db.prepare(`SELECT t.type, t.currency, (SELECT COALESCE(SUM(e.delta),0) FROM entries e JOIN accounts a ON a.id = e.account_id WHERE e.txn_id = t.id AND a.owner = t.uid AND a.kind IN ('wallet','pocket')) eff
        FROM txns t WHERE t.uid = ? AND t.currency != 'PTS' AND t.created_at >= ? AND t.created_at < ?`).all(uid, from, to);
      let inn = 0; let out = 0;
      for (const x of rows) { if (INTERNAL.has(x.type) || !r) continue; const v = toUsd(x.eff, x.currency, r); if (v > 0) inn += v; else out -= v; }
      for (const c of db.prepare("SELECT SUM(amount) s FROM card_auths WHERE uid = ? AND status IN ('approved','settled') AND created_at >= ? AND created_at < ?").all(uid, from, to)) if (r && c.s) out += toUsd(c.s, 'USD', r);
      flow.push({ month: new Date(from).toISOString().slice(0, 7), inUsd: Math.round(inn * 100) / 100, outUsd: Math.round(out * 100) / 100 });
    }
    const spent = ctx.planning.spentByCategory(uid);
    return { netWorthUsd: r ? Math.round(total * 100) / 100 : null, complete, parts, invest, external: external.map((e) => ({ currency: e.currency, balance: e.s, demo: Boolean(e.demo) })),
      cashflow: flow, spendByCategory: Object.entries(spent).map(([category, amount]) => ({ category, amount })).sort((a, b) => b.amount - a.amount), ratesTs: null, approx: true };
  }

  function insights(uid) {
    const out = []; const t = now(); const ms = monthStart(t);
    const b = ctx.planning.budgets(uid);
    for (const x of b.items) { if (x.pct >= 100) out.push({ kind: 'budget_over', severity: 'warn', params: { category: x.category, pct: x.pct } }); else if (x.pct >= 80) out.push({ kind: 'budget_near', severity: 'warn', params: { category: x.category, pct: x.pct } }); }
    const now3 = ctx.planning.spentByCategory(uid, ms, t + 1);
    const d = new Date(t); const prevFrom = Date.UTC(d.getUTCFullYear(), d.getUTCMonth() - 3, 1);
    const prev = ctx.planning.spentByCategory(uid, prevFrom, ms);
    for (const [cat, v] of Object.entries(now3)) { const avg = (prev[cat] || 0) / 3; if (avg > 0 && v > avg * 1.3 && v - avg > 2000) out.push({ kind: 'category_up', severity: 'info', params: { category: cat, amount: v, avg: Math.round(avg), currency: 'USD' } }); }
    for (const s of ctx.vcards.listSubs(uid)) {
      if (s.status === 'active' && s.nextDue && s.nextDue - t < 7 * DAY && s.nextDue > t) out.push({ kind: 'sub_upcoming', severity: 'info', params: { merchant: s.merchant, amount: s.amount, currency: s.currency, at: s.nextDue } });
      if (s.priceUp) out.push({ kind: 'sub_price_up', severity: 'warn', params: { merchant: s.merchant, amount: s.amount, before: s.lastAmount, currency: s.currency } });
    }
    const fees = db.prepare("SELECT currency, SUM(json_extract(meta,'$.fee')) s FROM txns WHERE uid = ? AND type = 'withdrawal' AND created_at >= ? GROUP BY currency").all(uid, ms)
      .concat(db.prepare("SELECT currency, SUM(amount) s FROM txns WHERE uid = ? AND type = 'card_fee' AND created_at >= ? GROUP BY currency").all(uid, ms)).filter((f) => f.s > 0);
    for (const f of fees) out.push({ kind: 'fees_paid', severity: 'info', params: { amount: f.s, currency: f.currency } });
    for (const p of ctx.pockets.listPockets(uid)) if (p.goal) out.push(p.balance >= p.goal ? { kind: 'goal_reached', severity: 'good', params: { name: p.name } } : { kind: 'goal_progress', severity: 'info', params: { name: p.name, pct: Math.floor((p.balance / p.goal) * 100) } });
    const rs = ctx.rewards.summary(uid); if (rs.expiringIn30Days > 0) out.push({ kind: 'points_expiring', severity: 'info', params: { pts: rs.expiringIn30Days } });
    if (ctx.security.isFrozen(uid)) out.push({ kind: 'frozen', severity: 'warn', params: {} });
    if (!ctx.security.passkeys.count(uid)) out.push({ kind: 'add_passkey', severity: 'info', params: {} });
    return { items: out, rules: true };
  }

  function ownerDashboard() {
    const t = now(); const since = t - 30 * DAY;
    const vol = (type) => db.prepare('SELECT currency, COUNT(*) n, SUM(amount) s FROM txns WHERE type = ? AND created_at > ? GROUP BY currency').all(type, since);
    return {
      users: db.prepare("SELECT COUNT(DISTINCT owner) c FROM accounts WHERE kind = 'wallet' AND owner NOT LIKE 'platform:%'").get().c,
      kyc: db.prepare('SELECT tier, COUNT(*) c FROM kyc GROUP BY tier').all(),
      last30: { deposits: vol('deposit'), withdrawals: vol('withdrawal'), cards: vol('card_purchase'), conversions: vol('fx_out'), sandboxCredits: vol('sandbox_credit') },
      pending: {
        deposits: db.prepare("SELECT COUNT(*) c FROM deposits WHERE status = 'requested' AND expires_at > ?").get(t).c,
        withdrawals: db.prepare("SELECT COUNT(*) c FROM withdrawals WHERE status IN ('requested','approved')").get().c,
        awaitingCosigners: db.prepare("SELECT COUNT(*) c FROM withdrawals WHERE status = 'awaiting_approvals'").get().c,
        kyc: db.prepare("SELECT COUNT(*) c FROM kyc WHERE status = 'pending'").get().c,
        tickets: db.prepare("SELECT COUNT(*) c FROM tickets WHERE status = 'open'").get().c,
      },
      flags: db.prepare("SELECT j.value flag, COUNT(*) c FROM withdrawals, json_each(withdrawals.flags) j WHERE created_at > ? GROUP BY j.value").all(since),
      declines: db.prepare("SELECT reason, COUNT(*) c FROM card_auths WHERE status = 'declined' AND created_at > ? GROUP BY reason").all(since),
      feesCollected: MONEY.map((c) => ({ currency: c, amount: L.sys('fees', c).balance })),
      ledger: L.verify().ok, audit: ctx.audit.verify().ok,
    };
  }

  /* ── investment sales (paper in sandbox) ── */
  async function sell(uid, i) {
    const asset = oneOf(i.asset, ctx.cfg.plans.assets, 'bad_asset'); const key = idemOk(i.idem);
    if (!sandbox && !ctx.broker) bad('no_broker', 503);
    ctx.security.assertNotFrozen(uid);
    const h = db.prepare('SELECT * FROM holdings WHERE uid = ? AND asset = ?').get(uid, asset); if (!h || h.qty <= 0) bad('nothing_to_sell', 409);
    const qty = i.all === true ? h.qty : Math.floor(Number(i.qty) * 1e8);
    if (!Number.isSafeInteger(qty) || qty <= 0 || qty > h.qty) bad('bad_quantity');
    const q = await ctx.priceFn?.(asset).catch(() => null);
    if (!q || !(q.price > 0) || now() - q.ts > ctx.cfg.plans.maxStaleMs) bad('no_fresh_price', 503);
    const proceeds = Math.floor((qty / 1e8) * q.price * 1e6); if (proceeds <= 0) bad('amount_too_small');
    return commit(() => {
      const prev = db.prepare('SELECT id FROM txns WHERE uid = ? AND idem = ?').get(uid, key); if (prev) return { replay: true };
      const cur = db.prepare('SELECT * FROM holdings WHERE uid = ? AND asset = ?').get(uid, asset); if (!cur || cur.qty < qty) bad('nothing_to_sell', 409);
      const tx = L.post({ type: 'invest_sell', uid, currency: 'USDT', amount: proceeds, idem: key, meta: { asset, qty, price: q.price, paper: sandbox },
        legs: [{ acc: L.sys('invest', 'USDT'), delta: -proceeds }, { acc: L.account(uid, 'USDT', 'wallet'), delta: proceeds }] });
      const costOut = Math.floor((cur.cost * qty) / cur.qty);
      db.prepare('UPDATE holdings SET qty = qty - ?, cost = cost - ? WHERE uid = ? AND asset = ?').run(qty, costOut, uid, asset);
      db.prepare('INSERT INTO sells (id, uid, asset, qty, price, proceeds, mode, txn_id, created_at) VALUES (?,?,?,?,?,?,?,?,?)').run(rid('sel'), uid, asset, qty, q.price, proceeds, sandbox ? 'paper' : 'broker', tx.id, now());
      A.log(uid, 'invest.sell', tx.id, { asset, qty, proceeds });
      return { ok: true, proceeds, qty, price: q.price };
    }, uid);
  }

  /* ── tax report ── */
  function taxReport(uid, year) {
    const y = Number(year); if (!Number.isInteger(y) || y < 2000 || y > 2100) bad('bad_year');
    const from = Date.UTC(y, 0, 1); const to = Date.UTC(y + 1, 0, 1);
    const events = [
      ...db.prepare("SELECT asset, qty, amount cost, created_at at, 'buy' k FROM orders WHERE uid = ? AND status = 'filled' AND qty > 0").all(uid),
      ...db.prepare("SELECT asset, qty, proceeds, price, created_at at, 'sell' k, id FROM sells WHERE uid = ?").all(uid),
    ].sort((a, b) => a.at - b.at || (a.k === 'buy' ? -1 : 1));
    const lots = {}; const sales = [];
    for (const e of events) {
      const q = (lots[e.asset] ||= []);
      if (e.k === 'buy') { q.push({ qty: e.qty, cost: e.cost, at: e.at }); continue; }
      let left = e.qty; let basis = 0; let earliest = null;
      while (left > 0 && q.length) {
        const l = q[0]; const take = Math.min(left, l.qty); const c = Math.floor((l.cost * take) / l.qty);
        basis += c; l.cost -= c; l.qty -= take; left -= take; earliest ??= l.at; if (l.qty === 0) q.shift();
      }
      if (e.at >= from && e.at < to) sales.push({ asset: e.asset, qty: e.qty, soldAt: e.at, acquiredFrom: earliest, proceeds: e.proceeds, costBasis: basis, gain: e.proceeds - basis, unmatchedQty: left, currency: 'USDT' });
    }
    const fees = db.prepare(`SELECT currency, SUM(CASE WHEN type = 'withdrawal' THEN json_extract(meta,'$.fee') ELSE amount END) s FROM txns
      WHERE uid = ? AND type IN ('withdrawal','card_fee') AND created_at >= ? AND created_at < ? GROUP BY currency`).all(uid, from, to).filter((f) => f.s > 0);
    const refunds = db.prepare("SELECT currency, SUM(amount) s FROM txns WHERE uid = ? AND type = 'card_fee_refund' AND created_at >= ? AND created_at < ? GROUP BY currency").all(uid, from, to);
    const cashback = db.prepare("SELECT SUM(amount) s FROM txns WHERE uid = ? AND type = 'cashback' AND created_at >= ? AND created_at < ?").get(uid, from, to).s || 0;
    const fx = db.prepare("SELECT COUNT(*) n FROM txns WHERE uid = ? AND type = 'fx_out' AND created_at >= ? AND created_at < ?").get(uid, from, to).n;
    const total = sales.reduce((s, x) => s + x.gain, 0);
    return { year: y, method: 'FIFO', mode: sandbox ? 'sandbox' : 'live', sales, realizedGainUsdt: total, fees: fees.map((f) => ({ currency: f.currency, amount: f.s - (refunds.find((r) => r.currency === f.currency)?.s || 0) })),
      cashbackUsd: cashback, conversions: fx, disclaimer: 'draft_for_accountant' };
  }
  function taxCsv(uid, year) {
    const r = taxReport(uid, year);
    const rows = [['type', 'asset', 'quantity', 'acquired_from', 'sold_at', 'proceeds_usdt', 'cost_basis_usdt', 'gain_usdt', 'note']];
    const iso = (t) => (t ? new Date(t).toISOString().slice(0, 10) : '');
    for (const s of r.sales) rows.push(['sale', s.asset, (s.qty / 1e8).toFixed(8), iso(s.acquiredFrom), iso(s.soldAt), fromMinor(s.proceeds, 'USDT'), fromMinor(s.costBasis, 'USDT'), fromMinor(s.gain, 'USDT'), s.unmatchedQty ? 'missing_buy_records' : '']);
    for (const f of r.fees) rows.push(['fees', '', '', '', '', '', '', fromMinor(-f.amount, f.currency), f.currency]);
    if (r.cashbackUsd) rows.push(['cashback', '', '', '', '', fromMinor(r.cashbackUsd, 'USD'), '', '', 'USD']);
    rows.push(['total_realized_gain', '', '', '', '', '', '', fromMinor(r.realizedGainUsdt, 'USDT'), `FIFO ${r.mode}`]);
    rows.push(['note', '', '', '', '', '', '', '', 'Draft for your accountant - not a tax return']);
    const cell = (v) => { const s = String(v ?? ''); return /^[=+\-@\t\r]/.test(s) && !/^-?\d/.test(s) ? `'${s}` : /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };
    return rows.map((x) => x.map(cell).join(',')).join('\r\n') + '\r\n';
  }
  return { dashboard, insights, ownerDashboard, sell, taxReport, taxCsv };
}
