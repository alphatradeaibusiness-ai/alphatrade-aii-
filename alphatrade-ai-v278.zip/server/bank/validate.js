// Strict input validation: whitelist characters and lengths, reject everything else. Nothing here trusts the client.
export class BankError extends Error { constructor(code, status = 400) { super(code); this.code = code; this.status = status; } }
export const bad = (code, status) => { throw new BankError(code, status); };

export const str = (v, { min = 1, max = 100, re = null, code = 'bad_input' } = {}) => {
  if (typeof v !== 'string') bad(code);
  const s = v.normalize('NFC').trim().replace(/\s+/g, ' ');
  if (s.length < min || s.length > max || /[\u0000-\u001f\u007f<>]/.test(s) || (re && !re.test(s))) bad(code);
  return s;
};
export const oneOf = (v, list, code = 'bad_input') => (list.includes(v) ? v : bad(code));
export const idem = (v) => (typeof v === 'string' && /^[A-Za-z0-9_-]{8,64}$/.test(v) ? v : bad('idempotency_key_required'));

/** IBAN checksum (mod 97) + shape. */
export function validIban(raw) {
  const s = String(raw).replace(/\s+/g, '').toUpperCase();
  if (!/^[A-Z]{2}\d{2}[A-Z0-9]{11,30}$/.test(s)) return null;
  const r = s.slice(4) + s.slice(0, 4);
  let rem = 0;
  for (const ch of r) { const v = ch >= 'A' ? ch.charCodeAt(0) - 55 : Number(ch); rem = Number(String(rem) + String(v)) % 97; }
  return rem === 1 ? s : null;
}
const ADDR = {
  TRC20: /^T[1-9A-HJ-NP-Za-km-z]{33}$/, ERC20: /^0x[0-9a-fA-F]{40}$/, BEP20: /^0x[0-9a-fA-F]{40}$/,
  BTC: /^(bc1[a-z0-9]{25,60}|[13][a-km-zA-HJ-NP-Z1-9]{25,34})$/,
};
export const validCryptoAddress = (network, a) => (ADDR[network] && ADDR[network].test(String(a).trim()) ? String(a).trim() : null);

export const iso2 = (v) => str(v, { min: 2, max: 2, re: /^[A-Za-z]{2}$/, code: 'bad_country' }).toUpperCase();
export function adult(dob, now = Date.now()) {
  if (typeof dob !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(dob)) bad('bad_dob');
  const d = new Date(`${dob}T00:00:00Z`); if (Number.isNaN(d.getTime()) || d.toISOString().slice(0, 10) !== dob) bad('bad_dob');
  const n = new Date(now); let age = n.getUTCFullYear() - d.getUTCFullYear();
  if (n.getUTCMonth() < d.getUTCMonth() || (n.getUTCMonth() === d.getUTCMonth() && n.getUTCDate() < d.getUTCDate())) age--;
  if (age < 18) bad('under_age'); if (age > 120) bad('bad_dob');
  return dob;
}
export function address(a) {
  if (!a || typeof a !== 'object') bad('bad_address');
  return {
    country: iso2(a.country), region: str(a.region ?? '-', { max: 60, code: 'bad_address' }), city: str(a.city, { max: 60, code: 'bad_address' }),
    postal: str(a.postal, { max: 12, re: /^[A-Za-z0-9][A-Za-z0-9 -]{1,11}$/, code: 'bad_address' }),
    line1: str(a.line1, { max: 80, code: 'bad_address' }), line2: a.line2 ? str(a.line2, { max: 80, code: 'bad_address' }) : '',
  };
}
