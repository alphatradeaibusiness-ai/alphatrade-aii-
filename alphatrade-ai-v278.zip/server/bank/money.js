// Currencies, integer minor units and decimal parsing. No floating point ever touches a balance.
export const CURRENCIES = {
  USD: { decimals: 2, kind: 'fiat' }, EUR: { decimals: 2, kind: 'fiat' },
  USDT: { decimals: 6, kind: 'crypto', networks: ['TRC20', 'ERC20', 'BEP20'] }, BTC: { decimals: 8, kind: 'crypto', networks: ['BTC'] },
};
export const MAX_MINOR = 1e15;   // far below 2^53, far above any real balance
export const isCurrency = (c) => Object.prototype.hasOwnProperty.call(CURRENCIES, c);
/** Units the ledger can hold: the money currencies + loyalty points (PTS, whole numbers, never money, never shown as a balance). */
export const UNITS = { ...CURRENCIES, PTS: { decimals: 0, kind: 'points' } };
export const isUnit = (c) => Object.prototype.hasOwnProperty.call(UNITS, c);

/** "12.5" → minor units, or null if malformed / too many decimals / not positive / too large. Accepts strings and finite numbers. */
export function toMinor(v, currency) {
  if (!isCurrency(currency)) return null;
  const d = CURRENCIES[currency].decimals;
  const s = typeof v === 'number' && Number.isFinite(v) ? String(v) : typeof v === 'string' ? v.trim() : '';
  if (!/^\d{1,15}(\.\d{1,12})?$/.test(s) || /e/i.test(s)) return null;
  const [i, f = ''] = s.split('.');
  if (f.length > d) return null;
  const n = Number(i) * 10 ** d + Number((f + '0'.repeat(d)).slice(0, d));
  return Number.isSafeInteger(n) && n > 0 && n <= MAX_MINOR ? n : null;
}
export function fromMinor(n, currency) {
  const d = UNITS[currency].decimals; const neg = n < 0; const a = Math.abs(n);
  const i = Math.floor(a / 10 ** d); const f = String(a % 10 ** d).padStart(d, '0');
  return `${neg ? '-' : ''}${i}${d ? `.${f}` : ''}`;
}
