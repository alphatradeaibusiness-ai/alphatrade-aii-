// Owner dashboard (v230): online / offline members, sign-in activity, subscribers and revenue per plan.
// Owners only — the route checks a verified owner e-mail (ADMIN_EMAILS) before this runs. Everything returned is an aggregate;
// the only list (recent sign-ins) carries masked e-mails and no ids, IPs or tokens.
//  • online = a signed-in request reached the server in the last ONLINE_MS (the app polls every 30–60 s while open)
//  • subscribers = channel-store subscriptions active right now, per product
//  • revenue = the payments ledger (live payments only; Stripe test payments are counted separately)

export const ONLINE_MS = 3 * 60_000;
const DAY = 86_400_000;

/** Last-seen time per signed-in account, kept in memory only (bounded). */
export function createPresence({ max = 50_000 } = {}) {
  const seen = new Map();
  return {
    touch(uid, t = Date.now()) {
      if (typeof uid !== 'string' || !uid) return;
      if (seen.has(uid)) seen.delete(uid);           // re-insert: the Map stays ordered oldest → newest
      seen.set(uid, t);
      if (seen.size > max) seen.delete(seen.keys().next().value);
    },
    counts(t = Date.now(), isMember = () => true) {
      let online = 0, h1 = 0, d1 = 0;
      for (const [uid, at] of seen) {
        const age = t - at;
        if (age > DAY) { seen.delete(uid); continue; }
        if (!isMember(uid)) continue;                 // only real members (a token that never signed in here is not one)
        if (age <= ONLINE_MS) online++; if (age <= 3600_000) h1++; d1++;
      }
      return { online, lastHour: h1, lastDay: d1 };
    },
  };
}

/**
 * The dashboard snapshot.
 * plans: [{ id, kind, cents, months, active }] (owner prices, overrides applied) · accounts: channel store · ledger rows.
 */
export function dashboardSnapshot({ t = Date.now(), presence, activity, accounts, ledgerRows, plans, sinceStart = 0, isMember }) {
  const pres = presence.counts(t, isMember);
  const members = activity.members;
  const online = pres.online;
  const monthStart = Date.UTC(new Date(t).getUTCFullYear(), new Date(t).getUTCMonth(), 1);

  // subscribers per plan, right now
  const subs = {};
  for (const a of Object.values(accounts || {})) {
    const s = a?.subscription; if (!s || !(s.startsAt <= t && s.until > t)) continue;
    subs[s.product] = (subs[s.product] || 0) + 1;
  }
  // revenue per product from the ledger (cents)
  const rev = {}; let testCount = 0; let testCents = 0;
  for (const r of ledgerRows || []) {
    if (!r || !Number.isFinite(r.cents)) continue;
    if (!r.live) { testCount++; testCents += r.cents; continue; }
    const x = (rev[r.product] ||= { total: 0, month: 0, payments: 0 });
    x.total += r.cents; x.payments++; if (r.at >= monthStart) x.month += r.cents;
  }
  const planRows = plans.filter((p) => p.kind === 'plan')
    .sort((a, b) => a.cents - b.cents || a.months - b.months)                 // the cheapest plan first, the highest last
    .map((p) => {
      const n = subs[p.id] || 0; const r = rev[p.id] || { total: 0, month: 0, payments: 0 };
      const mrr = p.months > 0 ? Math.round((n * p.cents) / p.months) : 0;   // monthly-equivalent of the active subscriptions
      return { id: p.id, priceCents: p.cents, months: p.months, onSale: p.active !== false, subscribers: n, mrrCents: mrr, revenueCents: r.total, monthCents: r.month, payments: r.payments };
    });
  const addons = plans.filter((p) => p.kind === 'addon').map((p) => ({ id: p.id, priceCents: p.cents, revenueCents: rev[p.id]?.total || 0, monthCents: rev[p.id]?.month || 0, payments: rev[p.id]?.payments || 0 }));
  const known = new Set(plans.map((p) => p.id));
  const other = Object.entries(rev).filter(([id]) => !known.has(id)).reduce((a, [, r]) => a + r.total, 0);
  const sum = (rows, k) => rows.reduce((a, r) => a + r[k], 0);
  const subscribers = sum(planRows, 'subscribers');

  return {
    at: t, onlineWindowMin: ONLINE_MS / 60_000,
    users: { members, online, offline: Math.max(0, members - online), lastHour: pres.lastHour, lastDay: pres.lastDay,
      trackingSinceMin: Math.round((t - sinceStart) / 60_000) },
    logins: { ...activity.logins, active: activity.active, signups: activity.signups, series: activity.series, devices: activity.devices, langs: activity.langs, recent: activity.recent },
    subscriptions: { plans: planRows, addons, subscribers, conversionPct: members ? Math.round((subscribers / members) * 1000) / 10 : 0,
      totals: { mrrCents: sum(planRows, 'mrrCents'), revenueCents: sum(planRows, 'revenueCents') + sum(addons, 'revenueCents') + other, monthCents: sum(planRows, 'monthCents') + sum(addons, 'monthCents') },
      test: { payments: testCount, cents: testCents }, currency: 'usd' },
  };
}
