// Payments record: one line per confirmed Stripe payment (what was bought, amount, when). Kept for accounting —
// deleting an account removes the link to the person (uid and e-mail are replaced) but keeps the amounts.
import fs from 'node:fs';
import path from 'node:path';

export function createLedger({ dir }) {
  const file = path.join(dir, 'payments-ledger.json');
  const load = () => { try { const j = JSON.parse(fs.readFileSync(file, 'utf8')); return Array.isArray(j) ? j : []; } catch { return []; } };
  const save = (rows) => { fs.mkdirSync(dir, { recursive: true, mode: 0o700 }); const tmp = `${file}.${process.pid}.tmp`; fs.writeFileSync(tmp, JSON.stringify(rows), { mode: 0o600 }); fs.renameSync(tmp, file); };
  const mask = (e) => { const [a, d] = String(e || '').split('@'); return a && d ? `${a.slice(0, 2)}***@${d}` : ''; };
  return {
    add({ id, uid, product, cents, currency = 'usd', email = '', at = Date.now(), until = null, live = false }) {
      const rows = load(); if (rows.some((r) => r.id === id)) return false;
      rows.push({ id, uid, product, cents, currency, email: mask(email), at, until, live }); save(rows); return true;
    },
    forUser: (uid) => load().filter((r) => r.uid === uid).sort((a, b) => b.at - a.at).map(({ uid: _u, ...r }) => r),
    all: load,
    anonymise(uid) { const rows = load(); let n = 0; for (const r of rows) if (r.uid === uid) { r.uid = 'deleted'; r.email = ''; n++; } if (n) save(rows); return n; },
  };
}
