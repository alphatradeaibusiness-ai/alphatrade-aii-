// v243 live-price hub: gold, silver, oil, indices and forex refreshed every second on the SERVER, then handed to every visitor
// in one small request (GET /api/market/quotes?s=XAUUSD,US30,…). However many people watch, the upstream (Yahoo Finance) sees at
// most one request per symbol per second — and only as often as someone actually asks (a price on screen: every second; one
// asked every 10 s: refreshed every 10 s). A stale price is answered at once and refreshed behind it (stale-while-revalidate).
// A symbol that keeps failing backs off (15 s → 2 min) so a blocked upstream is never hammered. Crypto is not here: the browser
// gets it directly from Binance's WebSocket (pushed every second, free).
const HOT_MS = 2500;   // kept fresh every second only while someone asks for it every second (a visible price)

export function parseYahooQuote(body) {
  const r = body?.chart?.result?.[0]; if (!r) return null;
  const meta = r.meta || {}; const closes = r.indicators?.quote?.[0]?.close || [];
  let price = Number(meta.regularMarketPrice);
  for (let i = closes.length - 1; i >= 0; i--) if (Number.isFinite(closes[i])) { price = closes[i]; break; }
  if (!Number.isFinite(price)) return null;
  return { price, changePct: Number(meta.regularMarketChangePercent) || 0, high: Number(meta.regularMarketDayHigh) || price, low: Number(meta.regularMarketDayLow) || price,
    at: (Number(meta.regularMarketTime) || Math.floor(Date.now() / 1000)) * 1000 };
}

/**
 * symbolMap: { OUR: 'YAHOO' } · fetchFn(url) → Response · base: upstream origin
 * → { get(symbols) → Promise<{ [sym]: quote }>, stats(), stop() }
 */
export function createQuoteHub({ symbolMap, fetchFn = fetch, base = 'https://query1.finance.yahoo.com', ttlMs = 800, concurrency = 8, now = Date.now, log = console } = {}) {
  const cache = new Map();      // sym → { q, at }
  const wanted = new Map();     // sym → last time someone asked
  const fail = new Map();       // sym → { until, n }
  const inflight = new Map();   // sym → Promise
  let upstream = 0;

  const fetchOne = (sym) => {
    if (inflight.has(sym)) return inflight.get(sym);
    const y = symbolMap[sym]; if (!y) return Promise.resolve(null);
    const p = (async () => {
      upstream += 1;
      try {
        const r = await fetchFn(`${base}/v8/finance/chart/${encodeURIComponent(y)}?interval=1m&range=1d`, { headers: { 'user-agent': 'Mozilla/5.0 (compatible; AlphaTradeAI/1.0)', accept: 'application/json' }, signal: AbortSignal.timeout(4000) });
        if (!r.ok) throw new Error(`http ${r.status}`);
        const q = parseYahooQuote(await r.json()); if (!q) throw new Error('no price');
        cache.set(sym, { q, at: now() }); fail.delete(sym); return q;
      } catch (e) {
        const f = fail.get(sym) || { n: 0 }; f.n += 1; f.until = now() + Math.min(120_000, 15_000 * 2 ** (f.n - 1)); fail.set(sym, f);
        if (f.n === 3) log.warn?.(`[quotes] ${sym} failing: ${String(e?.message || e).slice(0, 60)}`);
        return cache.get(sym)?.q || null;
      } finally { inflight.delete(sym); }
    })();
    inflight.set(sym, p); return p;
  };
  const due = (sym) => { const c = cache.get(sym); const f = fail.get(sym); return (!c || now() - c.at >= ttlMs) && !(f && f.until > now()); };

  // the one-second refresh of the hot symbols, a few at a time
  async function refresh() {
    const t = now(); const list = [...wanted].filter(([, w]) => t - w < HOT_MS).map(([s]) => s).filter(due);
    for (const [s, w] of wanted) if (t - w >= HOT_MS * 4) wanted.delete(s);
    for (let i = 0; i < list.length; i += concurrency) await Promise.all(list.slice(i, i + concurrency).map(fetchOne));
  }
  let busy = false;
  const timer = setInterval(() => { if (busy) return; busy = true; refresh().catch(() => {}).finally(() => { busy = false; }); }, Math.max(250, ttlMs / 2));
  timer.unref?.();

  async function get(symbols) {
    const t = now(); const out = {}; const first = [];
    for (const s of symbols) { if (!symbolMap[s]) continue; wanted.set(s, t); const c = cache.get(s); if (c) { out[s] = { ...c.q, age: t - c.at }; if (due(s)) fetchOne(s); } else if (!(fail.get(s)?.until > t)) first.push(s); }
    if (first.length) {   // never seen yet: fetch now so the first answer already has prices
      const got = await Promise.all(first.slice(0, 16).map(fetchOne));
      first.slice(0, 16).forEach((s, i) => { if (got[i]) out[s] = { ...got[i], age: 0 }; });
    }
    return out;
  }
  return { get, stats: () => ({ symbols: cache.size, hot: [...wanted.values()].filter((w) => now() - w < HOT_MS).length, upstream, failing: fail.size }), stop: () => clearInterval(timer) };
}
