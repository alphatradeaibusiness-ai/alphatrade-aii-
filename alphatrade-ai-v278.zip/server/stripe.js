// Stripe Checkout: the server makes the checkout page (price and plan come from our own catalogue, never from the browser),
// and access is granted ONLY when Stripe's signed webhook says the payment is paid. One-time payments for a fixed period:
// nothing renews by itself, so there is nothing to cancel. Buying the same plan again adds its months on top.
//   STRIPE_SECRET_KEY      sk_live_… / sk_test_… (or a restricted key rk_… with Checkout Sessions: write)
//   STRIPE_WEBHOOK_SECRET  whsec_… from Stripe → Developers → Webhooks → endpoint https://<site>/api/billing/webhook
//   PUBLIC_URL             optional, e.g. https://alphatrade-ai.onrender.com (where Stripe sends the buyer back)
import crypto from 'node:crypto';
import { PLANS } from '../src/config/billing.js';
import { CHANNEL_PRODUCTS } from '../src/config/channelPlans.js';

const MONTH_MS = 30.4375 * 86_400_000;
export const CATALOGUE = Object.freeze(Object.fromEntries([
  ...PLANS.map((p) => [p.id, { id: p.id, kind: 'plan', months: p.months, cents: Math.round(p.price * 100), name: `AlphaTrade AI — ${p.months === 12 ? '12 months' : p.months === 1 ? '1 month' : `${p.months} months`}` }]),
  ...CHANNEL_PRODUCTS.map((p) => [p.id, { id: p.id, kind: p.kind === 'subscription' ? 'plan' : 'addon', months: p.kind === 'subscription' ? 1 : 0, cents: Math.round(p.price * 100), name: p.kind === 'subscription' ? 'AlphaTrade AI — signals channel, 1 month' : `AlphaTrade AI — ${p.count} extra signals` }]),
]));

/** Stripe-Signature check: `t=<unix>,v1=<hex HMAC-SHA256(secret, "<t>.<raw body>")>`, within `tolerance` seconds. */
export function verifySignature(raw, header, secret, nowSec = Math.floor(Date.now() / 1000), tolerance = 300) {
  if (!secret || typeof header !== 'string') return false;
  const parts = header.split(',').map((x) => x.trim().split('='));
  const t = Number(parts.find(([k]) => k === 't')?.[1]);
  const sigs = parts.filter(([k]) => k === 'v1').map(([, v]) => v).filter((v) => /^[0-9a-f]{64}$/.test(v || ''));
  if (!Number.isFinite(t) || !sigs.length || Math.abs(nowSec - t) > tolerance) return false;
  const want = crypto.createHmac('sha256', secret).update(`${t}.`).update(raw).digest();
  return sigs.some((s) => crypto.timingSafeEqual(Buffer.from(s, 'hex'), want));
}

const form = (obj, prefix = '', out = []) => {
  for (const [k, v] of Object.entries(obj)) {
    const key = prefix ? `${prefix}[${k}]` : k;
    if (v == null) continue;
    if (typeof v === 'object') form(v, key, out); else out.push(`${encodeURIComponent(key)}=${encodeURIComponent(String(v))}`);
  }
  return out.join('&');
};

export const KEY_RE = /^(sk|rk)_(live|test)_[A-Za-z0-9]{10,200}$/;
const WH_RE = /^whsec_[A-Za-z0-9+/=]{10,200}$/;

/** Creates the webhook endpoint in the owner's Stripe account with their secret key, so only one key has to be pasted. */
export async function createWebhook({ key, url, fetchFn = fetch, api = 'https://api.stripe.com' }) {
  const body = form({ url, description: 'AlphaTrade AI — grants plans after payment', enabled_events: { 0: 'checkout.session.completed', 1: 'checkout.session.async_payment_succeeded', 2: 'charge.refunded', 3: 'charge.dispute.created' } });
  const r = await fetchFn(`${api}/v1/webhook_endpoints`, { method: 'POST', headers: { authorization: `Bearer ${key}`, 'content-type': 'application/x-www-form-urlencoded' }, body, signal: AbortSignal.timeout(15_000) });
  const j = await r.json().catch(() => ({}));
  if (r.status === 401) return { error: 'invalid_key' };
  if (r.status === 403) return { error: 'no_permission' };
  if (!r.ok || !WH_RE.test(String(j.secret || '')) || typeof j.id !== 'string') return { error: String(j?.error?.code || j?.error?.type || 'stripe_error').slice(0, 40), message: String(j?.error?.message || '').slice(0, 160) };
  return { id: j.id, secret: j.secret };
}
export async function deleteWebhook({ key, id, fetchFn = fetch, api = 'https://api.stripe.com' }) {
  if (!/^we_[A-Za-z0-9]+$/.test(String(id || ''))) return;
  try { await fetchFn(`${api}/v1/webhook_endpoints/${id}`, { method: 'DELETE', headers: { authorization: `Bearer ${key}` }, signal: AbortSignal.timeout(10_000) }); } catch { /* best effort */ }
}

// pricing (optional): { item(id) → { …catalogue item, cents, months, active } with the owners' price changes,
//   quote(code, product, cents, uid) → { code, discountCents, finalCents } | { error }, redeem(code, discountCents, uid), secret }
// A coupon is checked on the server at checkout; the charged amount, the list price and the discount travel in the session's
// metadata with an HMAC, so the paid webhook can check the exact amount even if the owner changes the price meanwhile.
export function createStripeBilling({ env = process.env, access, keys = null, ledger = null, onPaid = null, partners = null, pricing = null, fetchFn = fetch, api = 'https://api.stripe.com', now = Date.now, log = console }) {
  const itemOf = (id) => (pricing?.item ? pricing.item(id) : CATALOGUE[id] ? { ...CATALOGUE[id], active: true } : null);
  const sign = (parts) => crypto.createHmac('sha256', String(pricing?.secret || env.AI_KEY_SECRET || 'x')).update(parts.join('|')).digest('hex').slice(0, 32);
  // keys(): { key, whsec } — Render env first, else what the owner saved on the site (encrypted)
  const cur = () => {
    const e = { key: String(env.STRIPE_SECRET_KEY || ''), whsec: String(env.STRIPE_WEBHOOK_SECRET || ''), source: 'env' };
    if (KEY_RE.test(e.key) && WH_RE.test(e.whsec)) return e;
    const k = keys?.(); return k && KEY_RE.test(k.key) && WH_RE.test(k.whsec) ? { ...k, source: 'site' } : null;
  };

  async function checkout({ uid, email, product, origin, coupon = '' }) {
    const c = cur(); const key = c?.key;
    if (!c) return { status: 503, body: { code: 'billing_not_configured' } };
    const item = itemOf(product);
    if (!item) return { status: 400, body: { code: 'bad_product' } };
    if (item.active === false) return { status: 409, body: { code: 'plan_inactive' } };
    let q = null;
    if (coupon) { q = pricing?.quote ? pricing.quote(coupon, item.id, item.cents, uid) : { error: 'invalid_coupon' }; if (q.error) return { status: 409, body: { code: q.error } }; }
    const charge = q ? q.finalCents : item.cents;
    const meta = { uid, product: item.id, list: String(item.cents), months: String(item.months), cdisc: String(q?.discountCents || 0), coupon: q?.code || '' };
    meta.sig = sign([meta.uid, meta.product, meta.list, meta.months, meta.cdisc, meta.coupon]);
    if (item.kind === 'addon' && !access.subscription(uid, now())) return { status: 409, body: { code: 'active_subscription_required' } };
    const base = String(env.PUBLIC_URL || origin || '').replace(/\/+$/, '');
    if (!/^https?:\/\/[^/]+$/.test(base)) return { status: 400, body: { code: 'bad_origin' } };
    const body = form({
      mode: 'payment', client_reference_id: uid, allow_promotion_codes: q ? undefined : 'true', customer_email: email || undefined,
      success_url: `${base}/#/app/pricing?paid=1`, cancel_url: `${base}/#/app/pricing?paid=0`,
      line_items: { 0: { quantity: 1, price_data: { currency: 'usd', unit_amount: charge, product_data: { name: q ? `${item.name} (coupon ${q.code})` : item.name } } } },
      metadata: meta,
      payment_intent_data: { metadata: { uid, product: item.id }, description: item.name },
    });
    const r = await fetchFn(`${api}/v1/checkout/sessions`, { method: 'POST', headers: { authorization: `Bearer ${key}`, 'content-type': 'application/x-www-form-urlencoded', 'idempotency-key': crypto.randomUUID() }, body, signal: AbortSignal.timeout(15_000) });
    const j = await r.json().catch(() => ({}));
    if (!r.ok || typeof j.url !== 'string' || !j.url.startsWith('https://')) { log.error?.('[billing] checkout failed:', r.status, String(j?.error?.code || j?.error?.type || '').slice(0, 60)); return { status: 502, body: { code: 'stripe_error' } }; }
    return { status: 200, body: { url: j.url } };
  }

  /** Apply one paid Checkout Session. Returns a short result code (also for logs/tests). */
  function apply(s, live = false) {
    if (!s || s.object !== 'checkout.session' || s.mode !== 'payment') return 'ignored';
    if (s.payment_status !== 'paid') return 'unpaid';
    const uid = s.client_reference_id; const md = s.metadata || {}; const base = CATALOGUE[md.product];
    if (typeof uid !== 'string' || !uid || uid !== md.uid || !base) return 'bad_session';
    // The price we asked for: the signed list price minus the signed coupon discount (sessions made before v198 carry no
    // signature: they must match the catalogue price). Any other amount is refused; a Stripe promotion code is still allowed.
    const signed = md.sig && md.sig === sign([md.uid, md.product, md.list, md.months, md.cdisc, md.coupon || '']);
    if (md.sig && !signed) return 'bad_session';
    const list = signed ? Number(md.list) : base.cents; const cdisc = signed ? Number(md.cdisc) || 0 : 0;
    const item = { ...base, cents: list, months: signed && Number(md.months) > 0 ? Number(md.months) : base.months };
    const subtotal = Number.isInteger(s.amount_subtotal) ? s.amount_subtotal : s.amount_total;
    const discount = Number(s.total_details?.amount_discount) || 0;
    if (s.currency !== 'usd' || subtotal !== list - cdisc || s.amount_total !== subtotal - discount || s.amount_total < 0) return 'amount_mismatch';
    const t = now();
    try {
      let r;
      if (item.kind === 'addon') r = access.grant(uid, { product: item.id, paymentId: s.id }, t);
      else {
        const cur = access.subscription(uid, t);
        const same = cur && cur.product === item.id;
        r = access.grant(uid, { product: item.id, paymentId: s.id, startsAt: same ? cur.startsAt : t, until: (same ? cur.until : t) + Math.round(item.months * MONTH_MS), replace: true }, t);
      }
      if (!r.duplicate) ledger?.add({ id: s.id, uid, product: item.id, cents: s.amount_total, list: item.cents, currency: 'usd', email: s.customer_details?.email || s.customer_email || '', at: t, until: access.subscription(uid, t)?.until || null, live });
      if (!r.duplicate) Promise.resolve(onPaid?.(uid)).catch(() => {});   // referral reward / banked days
      if (!r.duplicate && signed && md.coupon) { try { pricing?.redeem?.(md.coupon, cdisc, uid); } catch { /* counting only */ } }
      // v255 Alpha Partner Club: commissions only from payments confirmed here (idempotent on the session id)
      if (!r.duplicate) { try { partners?.onPayment?.({ paymentId: s.id, pi: typeof s.payment_intent === 'string' ? s.payment_intent : null, uid, product: item.id, listCents: item.cents, collectedCents: s.amount_total }); } catch (e) { log.error?.('[partners] payment failed:', String(e?.message || e).slice(0, 60)); } }
      return r.duplicate ? 'duplicate' : 'granted';
    } catch (e) { log.error?.('[billing] grant failed:', String(e?.message || e).slice(0, 60)); return `error:${String(e?.message || e).slice(0, 40)}`; }
  }

  async function webhook(raw, header) {
    const c = cur();
    if (!c) return { status: 503, body: { code: 'billing_not_configured' } };
    const live = c.key.includes('_live_');
    if (!verifySignature(raw, header, c.whsec, Math.floor(now() / 1000))) return { status: 400, body: { code: 'bad_signature' } };
    let ev; try { ev = JSON.parse(raw.toString('utf8')); } catch { return { status: 400, body: { code: 'bad_json' } }; }
    if (ev.livemode !== live) return { status: 200, body: { result: 'wrong_mode' } };   // a test event never unlocks a live site
    let result = 'ignored';
    if (ev.type === 'checkout.session.completed' || ev.type === 'checkout.session.async_payment_succeeded') result = apply(ev.data?.object, live);
    // v255: refunds and chargebacks reverse (or claw back) partner commissions; access itself is unchanged here
    else if ((ev.type === 'charge.refunded' || ev.type === 'charge.dispute.created') && partners?.onRefund) {
      const o = ev.data?.object || {}; const pi = typeof o.payment_intent === 'string' ? o.payment_intent : null;
      if (pi && (ev.type === 'charge.dispute.created' || o.refunded === true || Number(o.amount_refunded) > 0)) result = `partners:${partners.onRefund({ pi, kind: ev.type === 'charge.refunded' ? 'refund' : 'chargeback' })}`;
    }
    if (result.startsWith('error:')) return { status: 500, body: { result } };   // Stripe retries later
    return { status: 200, body: { result } };
  }

  const status = () => { const c = cur(); return { configured: Boolean(c), mode: c ? (c.key.includes('_live_') ? 'live' : 'test') : null, products: Object.keys(CATALOGUE) }; };
  return { get configured() { return Boolean(cur()); }, get live() { return Boolean(cur()?.key.includes('_live_')); }, source: () => cur()?.source || null, checkout, webhook, apply, status };
}
