// AlphaTrade AI — offline security scan: secrets (Gitleaks-style rules) + risky code patterns (Semgrep-style rules).
// Runs with Node only (no network, no extra packages), so it works in CI and on a laptop. CI also runs the official Gitleaks,
// Semgrep and Trivy (see .github/workflows/security.yml); this scanner is the always-available first line.
// Usage: node security/scan.mjs [dir…]   default: the project + dist/ when it exists. Exit 1 on any HIGH/CRITICAL finding.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const SKIP = /(^|\/)(node_modules|\.git|loadtest\/results|results|docs\/backtests|coverage)(\/|$)/;
const TEXT = /\.(m?js|cjs|ts|json|html|css|md|ya?ml|toml|env|sh|txt|svg|webmanifest|pine|mq5|conf)$|(^|\/)(Dockerfile[^/]*|\.env[^/]*|\.npmrc)$/;

// Secret rules (high signal; values seen in tests are allowed by ALLOW below).
export const SECRET_RULES = [
  ['anthropic-key', /sk-ant-(api|admin)\d{2}-[A-Za-z0-9_-]{30,}/],
  ['openai-key', /\bsk-(proj-)?[A-Za-z0-9_-]{40,}\b/],
  ['stripe-live-secret', /\b(sk|rk)_live_[A-Za-z0-9]{20,}\b/],
  ['stripe-webhook-secret', /\bwhsec_[A-Za-z0-9]{24,}\b/],
  ['aws-access-key', /\b(AKIA|ASIA)[0-9A-Z]{16}\b/],
  ['google-api-key', /\bAIza[0-9A-Za-z_-]{35}\b/],
  ['github-token', /\b(ghp|gho|ghu|ghs|ghr)_[A-Za-z0-9]{36}\b|github_pat_[A-Za-z0-9_]{60,}/],
  ['slack-token', /\bxox[abpors]-[A-Za-z0-9-]{10,}/],
  ['telegram-bot-token', /\b\d{8,10}:AA[A-Za-z0-9_-]{33}\b/],
  ['private-key', /-----BEGIN (RSA |EC |OPENSSH |DSA |ENCRYPTED )?PRIVATE KEY-----/],
  ['jwt', /\beyJ[A-Za-z0-9_-]{10,}\.eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{20,}/],
  ['twelvedata-key-assignment', /TWELVEDATA_API_KEY\s*[=:]\s*['"]?[a-f0-9]{32}\b/i],
  ['generic-secret-assignment', /\b(password|passwd|secret|api[_-]?key|access[_-]?token)\s*[:=]\s*['"](?=[^'"]*\d)(?=[^'"]*[A-Za-z])[A-Za-z0-9_\-+/=]{20,}['"]/],
];
// Known non-secrets: the public Firebase web config is meant for browsers; test fixtures use obvious fake values.
const ALLOW = [/(^|\/)tests\//, /security\/(scan|pentest)\.mjs$/, /'[a-z]'\.repeat\(/];

// Risky code rules: [id, severity, regex, files regex, why]
export const CODE_RULES = [
  ['eval', 'high', /\beval\s*\(|\bnew Function\s*\(/, /\.(m?js)$/, 'dynamic code execution'],
  ['child-process', 'high', /require\(['"]child_process['"]\)|from ['"]node:child_process['"]|from ['"]child_process['"]/, /^(server|src)\//, 'shell / process execution in app code'],
  ['weak-hash', 'medium', /createHash\(['"](md5|sha1)['"]\)/, /\.(m?js)$/, 'MD5 / SHA-1 used'],
  ['insecure-random-token', 'high', /(token|secret|nonce|salt|password)[A-Za-z_]*\s*=\s*[^;\n]*Math\.random\(/i, /\.(m?js)$/, 'Math.random() used for a secret'],
  ['tls-off', 'critical', /rejectUnauthorized\s*:\s*false|NODE_TLS_REJECT_UNAUTHORIZED\s*=\s*['"]?0/, /\.(m?js|ya?ml|sh|toml)$|Dockerfile/, 'TLS certificate checks disabled'],
  ['document-write', 'medium', /document\.write\s*\(/, /^src\//, 'document.write'],
  ['postmessage-star', 'medium', /postMessage\([^)]*,\s*['"]\*['"]\)/, /^src\//, 'postMessage to any origin'],
  ['message-no-origin', 'medium', /addEventListener\(\s*['"]message['"](?![\s\S]{0,400}origin)/, /^src\/(?!services\/(aiWorker|scanWorker))/, 'message listener without an origin check'],
  ['blank-target', 'low', /target=["']_blank["'](?![^>]{0,120}noopener)/, /^src\/|\.html$/, 'target=_blank without rel=noopener'],
  ['cors-star', 'high', /Access-Control-Allow-Origin['"]?\s*[:,]\s*['"]\*['"]/, /^server\//, 'CORS open to every origin'],
  ['token-in-localstorage', 'medium', /localStorage\.setItem\([^)]*(id_?token|access_?token|refresh_?token|apiKey|secret)/i, /^src\//, 'credential kept in localStorage'],
  ['vite-secret', 'critical', /VITE_[A-Z_]*(SECRET|PRIVATE|ANTHROPIC|OPENAI|TWELVEDATA_API_KEY|STRIPE_SK|BOT_TOKEN)/, /\.(m?js|json|toml|ya?ml)$|Dockerfile|\.env/, 'secret in a VITE_ variable (shipped to every browser)'],
  ['http-url', 'low', /['"`]http:\/\/(?!localhost|127\.0\.0\.1|0\.0\.0\.0|\[::1\]|www\.w3\.org)[a-z0-9.-]+/i, /^(src|server)\//, 'plain-http URL'],
];

function walk(dir, out = []) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name); const rel = path.relative(ROOT, p).split(path.sep).join('/');
    if (SKIP.test(rel)) continue;
    if (e.isDirectory()) walk(p, out); else if (TEXT.test(rel) && fs.statSync(p).size < 3_000_000) out.push({ p, rel });
  }
  return out;
}

export function scan(dirs = [ROOT, path.join(ROOT, 'dist')].filter((d) => fs.existsSync(d))) {
  const findings = []; const seen = new Set();
  for (const d of dirs) for (const { p, rel } of walk(d)) {
    if (seen.has(p)) continue; seen.add(p);
    const text = fs.readFileSync(p, 'utf8'); const lines = text.split('\n');
    const allowed = ALLOW.some((a) => a.test(rel));
    lines.forEach((line, i) => {
      if (line.length > 4000) line = line.slice(0, 4000);
      if (!allowed) for (const [id, re] of SECRET_RULES) if (re.test(line) && !/example|placeholder|xxxx|your[_-]?key|<|\.\.\.|process\.env|test_?\$\{|'k'\.repeat/i.test(line)) findings.push({ kind: 'secret', id, severity: 'critical', file: rel, line: i + 1, text: line.trim().replace(re, (m) => `${m.slice(0, 6)}…[redacted]`).slice(0, 140) });
      for (const [id, sev, re, files, why] of CODE_RULES) if (files.test(rel) && !/security\/scan\.mjs$|^tests\//.test(rel) && re.test(line) && !/scan-ignore/.test(line)) findings.push({ kind: 'code', id, severity: sev, file: rel, line: i + 1, why, text: line.trim().slice(0, 140) });
    });
  }
  return findings;
}

if (process.argv[1] && fileURLToPath(import.meta.url) === path.resolve(process.argv[1])) {
  const dirs = process.argv.slice(2).filter((x) => !x.startsWith('--')).map((d) => path.resolve(d));
  const f = scan(dirs.length ? dirs : undefined);
  const order = { critical: 0, high: 1, medium: 2, low: 3 };
  f.sort((a, b) => order[a.severity] - order[b.severity]);
  for (const x of f) console.log(`${x.severity.toUpperCase().padEnd(8)} ${x.kind}:${x.id}  ${x.file}:${x.line}  ${x.why || ''}\n         ${x.text}`);
  const bad = f.filter((x) => x.severity === 'critical' || x.severity === 'high');
  console.log(`\n${f.length} finding(s), ${bad.length} high/critical`);
  const j = process.argv.indexOf('--json'); if (j > 0) fs.writeFileSync(process.argv[j + 1], JSON.stringify(f, null, 1));
  process.exit(bad.length ? 1 : 0);
}
