// v236 — rotation of AI_KEY_SECRET (the secret that encrypts the AI / market / notify / Stripe keys, the members, community,
// passkey, MT5-bridge and per-user trade files). Before this tool, changing AI_KEY_SECRET made all of them unreadable.
//
// Safe by design: it NEVER changes the live data folder. It copies it to --out, re-encrypts every known file there with the new
// secret, then re-opens each one with the new secret and compares it with the original (a failed check stops with exit 1).
// Switch over only after it says OK: stop the server, move --out in place of the data folder, set AI_KEY_SECRET to the new
// value, start. Keep the old folder until you are sure.
//
//   OLD_AI_KEY_SECRET=… NEW_AI_KEY_SECRET=… node security/rotate-ai-key.mjs --data <SERVER_DATA_DIR> --out <new folder> [--notify <SERVER_NOTIFY_DIR> --notify-out <folder>]
//
// What changes for people after a rotation (the values are derived from the secret on purpose, so a leaked secret stops working):
//   • MT5: every terminal must be paired again (the pairing tokens are checked with a key derived from the secret);
//   • passkey (face) sign-in: each customer registers the passkey again; • referral codes change (old links stop counting).
// Secrets are read from the environment only, never from the command line (so they do not end up in shell history).
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const SALT = { store: 'alphatrade-ai-key-v1', growth: 'alphatrade-growth-v1', community: 'alphatrade-community-v1', face: 'alphatrade-face-login-v1', mt5: 'alphatrade-mt5-bridge-v1', trades: 'alphatrade-user-trades-v1' };
const derive = (secret, salt) => crypto.scryptSync(String(secret), salt, 32);
const STORE_FILES = ['ai-config.json', 'billing-config.json', 'market-config.json', 'notify-config.json'];

function decJson(e, key, aad) {
  const d = crypto.createDecipheriv('aes-256-gcm', key, Buffer.from(e.iv, 'base64')); if (aad) d.setAAD(Buffer.from(aad)); d.setAuthTag(Buffer.from(e.tag, 'base64'));
  return Buffer.concat([d.update(Buffer.from(e.data, 'base64')), d.final()]);
}
function encJson(plain, key, aad) {
  const iv = crypto.randomBytes(12); const c = crypto.createCipheriv('aes-256-gcm', key, iv); if (aad) c.setAAD(Buffer.from(aad));
  const data = Buffer.concat([c.update(plain), c.final()]);
  return { iv: iv.toString('base64'), tag: c.getAuthTag().toString('base64'), data: data.toString('base64') };
}
const decBin = (buf, key, aad) => { const d = crypto.createDecipheriv('aes-256-gcm', key, buf.subarray(0, 12)); d.setAAD(Buffer.from(aad)); d.setAuthTag(buf.subarray(12, 28)); return Buffer.concat([d.update(buf.subarray(28)), d.final()]); };
const encBin = (buf, key, aad) => { const iv = crypto.randomBytes(12); const c = crypto.createCipheriv('aes-256-gcm', key, iv); c.setAAD(Buffer.from(aad)); const d = Buffer.concat([c.update(buf), c.final()]); return Buffer.concat([iv, c.getAuthTag(), d]); };
const writeSecure = (file, data) => { const tmp = `${file}.rot.tmp`; fs.writeFileSync(tmp, data, { mode: 0o600 }); fs.renameSync(tmp, file); };

/** Re-encrypts a copy of `data` into `out`. → { done: [...], skipped: [...], unmapped: n } — throws when a check fails. */
export function rotate({ data, out, oldSecret, newSecret, notify = null, notifyOut = null }) {
  if (!oldSecret || String(oldSecret).length < 32 || !newSecret || String(newSecret).length < 32) throw new Error('both secrets must be at least 32 characters');
  if (oldSecret === newSecret) throw new Error('the new secret equals the old one');
  if (!fs.existsSync(data)) throw new Error(`no data folder: ${data}`);
  if (fs.existsSync(out) && fs.readdirSync(out).length) throw new Error(`--out must be empty or missing: ${out}`);
  const rel = path.relative(path.resolve(data), path.resolve(out)); if (!rel || !rel.startsWith('..')) throw new Error('--out must be outside the data folder (and not empty or missing the same folder)');
  fs.cpSync(data, out, { recursive: true });
  const K = (s, k) => derive(s, SALT[k]);
  const done = []; const skipped = [];
  const ok = (cond, what) => { if (!cond) throw new Error(`verification failed: ${what}`); };

  // 1. owner key stores (AI provider, Stripe, Twelve Data, notifications): { …meta, keyEnc: {iv,tag,data} }
  const storeDirs = [[out, data]]; if (notify && notifyOut) { fs.cpSync(notify, notifyOut, { recursive: true }); storeDirs.push([notifyOut, notify]); }
  for (const [dir, src] of storeDirs) for (const name of STORE_FILES) {
    const f = path.join(dir, name); if (!fs.existsSync(f)) continue;
    const r = JSON.parse(fs.readFileSync(f, 'utf8')); if (!r.keyEnc) { skipped.push(name); continue; }
    const plain = decJson(r.keyEnc, K(oldSecret, 'store'));
    writeSecure(f, JSON.stringify({ ...r, keyEnc: encJson(plain, K(newSecret, 'store')) }));
    ok(decJson(JSON.parse(fs.readFileSync(f, 'utf8')).keyEnc, K(newSecret, 'store')).equals(plain), name);
    done.push(path.relative(dir, f) || name); void src;
  }
  // 2. single JSON stores with an AAD (members/growth, passkeys) and without (MT5 bridge)
  let growthDb = null;
  for (const [name, k, aad] of [['growth.json', 'growth', 'growth'], ['face-login.json', 'face', 'face'], ['mt5-bridge.json', 'mt5', null]]) {
    const f = path.join(out, name); if (!fs.existsSync(f)) continue;
    const e = JSON.parse(fs.readFileSync(f, 'utf8')); const plain = decJson(e, K(oldSecret, k), aad);
    if (name === 'growth.json') growthDb = JSON.parse(plain.toString('utf8'));
    writeSecure(f, JSON.stringify({ ...(e.v ? { v: e.v } : {}), ...encJson(plain, K(newSecret, k), aad) }));
    ok(decJson(JSON.parse(fs.readFileSync(f, 'utf8')), K(newSecret, k), aad).equals(plain), name); done.push(name);
  }
  // 3. community (binary) + its feedback screenshots (AAD img:<feedback id>)
  const cf = path.join(out, 'community.json');
  if (fs.existsSync(cf)) {
    const plain = decBin(fs.readFileSync(cf), K(oldSecret, 'community'), 'community'); const db = JSON.parse(plain.toString('utf8'));
    writeSecure(cf, encBin(plain, K(newSecret, 'community'), 'community')); ok(decBin(fs.readFileSync(cf), K(newSecret, 'community'), 'community').equals(plain), 'community.json'); done.push('community.json');
    for (const fb of db.feedback || []) for (const iid of fb.images || []) {
      const f = path.join(out, 'feedback-img', `${iid}.bin`); if (!fs.existsSync(f)) continue;
      const p = decBin(fs.readFileSync(f), K(oldSecret, 'community'), `img:${fb.id}`); writeSecure(f, encBin(p, K(newSecret, 'community'), `img:${fb.id}`));
      ok(decBin(fs.readFileSync(f), K(newSecret, 'community'), `img:${fb.id}`).equals(p), `feedback-img/${iid}`); done.push(`feedback-img/${iid}.bin`);
    }
  }
  // 4. per-customer trade files: the file NAME is an HMAC of the uid under a key derived from the secret, the AAD is the uid
  let unmapped = 0; const tdir = path.join(out, 'user-trades');
  if (fs.existsSync(tdir)) {
    const oldK = K(oldSecret, 'trades'), newK = K(newSecret, 'trades');
    const nameOf = (k, uid) => `${crypto.createHmac('sha256', crypto.createHash('sha256').update(k).update('names').digest()).update(String(uid)).digest('hex').slice(0, 40)}.json`;
    const idxF = path.join(tdir, 'open-index.json'); let idx = [];
    if (fs.existsSync(idxF)) { idx = JSON.parse(decJson(JSON.parse(fs.readFileSync(idxF, 'utf8')), oldK, 'trades:index').toString('utf8')); }
    const uids = new Set([...idx, ...Object.keys(growthDb?.users || {})]);
    const left = new Set(fs.readdirSync(tdir).filter((f) => f.endsWith('.json') && f !== 'open-index.json'));
    for (const uid of uids) {
      const from = nameOf(oldK, uid); if (!left.has(from)) continue;
      const e = JSON.parse(fs.readFileSync(path.join(tdir, from), 'utf8')); const plain = decJson(e, oldK, `trades:${uid}`);
      const to = path.join(tdir, nameOf(newK, uid)); writeSecure(to, JSON.stringify({ v: 1, ...encJson(plain, newK, `trades:${uid}`) }));
      ok(decJson(JSON.parse(fs.readFileSync(to, 'utf8')), newK, `trades:${uid}`).equals(plain), `user-trades for ${uid.slice(0, 6)}`);
      fs.rmSync(path.join(tdir, from)); left.delete(from); done.push(`user-trades/${uid.slice(0, 6)}…`);
    }
    if (fs.existsSync(idxF)) { writeSecure(idxF, JSON.stringify({ v: 1, ...encJson(Buffer.from(JSON.stringify(idx)), newK, 'trades:index') })); done.push('user-trades/open-index.json'); }
    unmapped = left.size;   // files whose owner is unknown (no member record): kept as they are, still readable with the OLD secret
  }
  return { done, skipped, unmapped };
}

if (process.argv[1] && fileURLToPath(import.meta.url) === path.resolve(process.argv[1])) {
  const arg = (k) => { const i = process.argv.indexOf(k); return i > 0 ? process.argv[i + 1] : null; };
  try {
    const r = rotate({ data: path.resolve(arg('--data') || ''), out: path.resolve(arg('--out') || ''), oldSecret: process.env.OLD_AI_KEY_SECRET, newSecret: process.env.NEW_AI_KEY_SECRET,
      notify: arg('--notify') && path.resolve(arg('--notify')), notifyOut: arg('--notify-out') && path.resolve(arg('--notify-out')) });
    console.log(`OK — ${r.done.length} file(s) re-encrypted and verified with the new secret.${r.unmapped ? ` ${r.unmapped} trade file(s) of unknown accounts kept unchanged.` : ''}`);
    console.log('Next: stop the server, put the --out folder in place of the data folder, set AI_KEY_SECRET to the new value, start. Customers re-pair MT5 and re-register passkeys.');
  } catch (e) { console.error(`STOPPED — nothing in the live folder was changed: ${e.message}`); process.exit(1); }
}
