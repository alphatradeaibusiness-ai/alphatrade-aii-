#!/usr/bin/env node
// Multi-asset backtest + monthly-loss-cap report using the app's own engine.
//
//   node tools/research.mjs                                  # BTC, ETH, SOL · 15m,30m,1h,4h · from 2022-01-01 · downloads from Binance
//   node tools/research.mjs --tfs 1m,5m,15m,30m --from 2023-01-01 --cap 1000 --fee 0.04
//   node tools/research.mjs --offline                        # only use ./data/*.json already downloaded
//
// Options: --symbols BTCUSDT,ETHUSDT,SOLUSDT  --tfs 15m,30m,1h,4h  --from YYYY-MM-DD  --fee <% round trip, default 0.1>
//          --cap <monthly loss cap in points, default 1000>  --data ./data  --out ./results  --base https://data-api.binance.vision
// Output: results/report.md and results/summary.json. Nothing here is a promise of profit: read the verdict column.
import fs from 'node:fs';
import path from 'node:path';
import { runStrategy, rulesFrom, summarize } from '../src/services/backtest.js';
import { getInstrument } from '../src/config/instruments.js';

const arg = (k, d) => { const i = process.argv.indexOf(`--${k}`); return i > -1 ? (process.argv[i + 1] && !process.argv[i + 1].startsWith('--') ? process.argv[i + 1] : true) : d; };
const SYMBOLS = String(arg('symbols', 'BTCUSDT,ETHUSDT,SOLUSDT')).split(',');
const TFS = String(arg('tfs', '15m,30m,1h,4h')).split(',');
const FROM = Date.parse(`${arg('from', '2022-01-01')}T00:00:00Z`);
const FEE = Number(arg('fee', 0.1));
const CAP = Number(arg('cap', 1000));
const DATA = path.resolve(String(arg('data', './data')));
const OUT = path.resolve(String(arg('out', './results')));
const BASE = String(arg('base', 'https://data-api.binance.vision'));
const OFFLINE = arg('offline', false) === true;
const STRATS = ['classic', 'smc'];
const TF_SEC = { '1m': 60, '5m': 300, '15m': 900, '30m': 1800, '1h': 3600, '4h': 14400 };
fs.mkdirSync(DATA, { recursive: true }); fs.mkdirSync(OUT, { recursive: true });

/* ───────── data ───────── */
async function download(symbol, tf) {
  const file = path.join(DATA, `${symbol}_${tf}.json`);
  let have = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
  if (OFFLINE) return have;
  let start = have.length ? (have.at(-1).time + TF_SEC[tf]) * 1000 : FROM;
  if (have.length && have[0].time * 1000 > FROM + 7 * 864e5) { have = []; start = FROM; } // cache starts too late: refetch
  const now = Date.now();
  while (start < now - TF_SEC[tf] * 1000) {
    const url = `${BASE}/api/v3/klines?symbol=${symbol}&interval=${tf}&startTime=${start}&limit=1000`;
    let rows;
    for (let a = 0; a < 4; a++) { try { const r = await fetch(url); if (!r.ok) throw new Error(`HTTP ${r.status}`); rows = await r.json(); break; } catch (e) { if (a === 3) throw new Error(`${symbol} ${tf}: ${e.message} (use --base or --offline)`); await new Promise((r) => setTimeout(r, 800 * (a + 1))); } }
    if (!rows.length) break;
    for (const k of rows) have.push({ time: Math.floor(k[0] / 1000), open: +k[1], high: +k[2], low: +k[3], close: +k[4], volume: +k[5], buyVolume: +k[9] });
    start = rows.at(-1)[0] + TF_SEC[tf] * 1000;
    if (rows.length < 1000) break;
    await new Promise((r) => setTimeout(r, 120));
  }
  have = have.filter((c, i, a) => i === 0 || c.time > a[i - 1].time);
  fs.writeFileSync(file, JSON.stringify(have));
  return have;
}

/* ───────── stats ───────── */
const monthKey = (t) => new Date(t * 1000).toISOString().slice(0, 7);
function stats(trades, cap) {
  const n = trades.length;
  if (!n) return { n: 0 };
  const wins = trades.filter((t) => t.points > 0).length;
  const pts = trades.reduce((a, t) => a + t.points, 0);
  const R = trades.reduce((a, t) => a + (t.r || 0), 0);
  const gw = trades.filter((t) => t.points > 0).reduce((a, t) => a + t.points, 0);
  const gl = -trades.filter((t) => t.points <= 0).reduce((a, t) => a + t.points, 0);
  const sorted = [...trades].sort((a, b) => a.closeTime - b.closeTime);
  let eq = 0; let pk = 0; let dd = 0;
  const months = new Map();
  for (const t of sorted) { eq += t.points; pk = Math.max(pk, eq); dd = Math.max(dd, pk - eq); months.set(monthKey(t.closeTime), (months.get(monthKey(t.closeTime)) || 0) + t.points); }
  const mv = [...months.values()];
  const worst = Math.min(0, ...mv);
  return { n, winRate: wins / n * 100, points: pts, expectancy: R / n, pf: gl > 0 ? gw / gl : (gw > 0 ? Infinity : 0), maxDD: dd, months: mv.length, worstMonth: worst, monthsOverCap: cap ? mv.filter((v) => -v > cap).length : 0, avgMonth: pts / Math.max(1, mv.length) };
}
const f0 = (x) => (Number.isFinite(x) ? Math.round(x).toLocaleString('en') : '∞');
const f2 = (x) => (Number.isFinite(x) ? x.toFixed(2) : '∞');
const verdict = (s) => (s.n < 30 ? 'too few trades' : s.expectancy > 0 && s.pf > 1 ? 'positive (verify out-of-sample)' : 'negative');

function rulesFor(symbol, over = {}, risk = {}) {
  const inst = getInstrument(symbol === 'GOLD_FUTURES' ? 'XAUUSD' : symbol === 'NDX' ? 'US100' : symbol);
  const plan = { feePct: symbol.endsWith('USDT') ? FEE : 0.03, ...(over.plan || {}) };
  return { ...rulesFrom({ plan, smc2: over.smc2 || {}, zone: over.zone || {}, risk }, inst), forced: null, slipPct: 0.02, pointSize: symbol === 'EURUSD' ? 0.00001 : inst.pointSize, volumeKind: 'estimated', openOnLast: false, ...(over.rules || {}) };
}
const splitIS = (trades, t0) => ({ is: trades.filter((t) => t.openTime < t0 && t.closeTime < t0), oos: trades.filter((t) => t.openTime >= t0) });

/* ───────── run ───────── */
const results = []; const lines = [];
const grids = {};
const GRID = [
  ['default (ATR×3, targets 1/2/3.5R)', {}],
  ['stop ATR×2', { plan: { atrMult: 2 } }],
  ['targets 1.5/3/5R', { plan: { tpR: [1.5, 3, 5] } }],
  ['min stop 10× fee', { rules: { minRiskPct: FEE * 10 } }],
];
for (const symbol of SYMBOLS) {
  for (const tf of TFS) {
    let candles;
    try { candles = await download(symbol, tf); } catch (e) { console.error(`skip ${symbol} ${tf}: ${e.message}`); continue; }
    candles = candles.filter((c) => c.time * 1000 >= FROM);
    if (candles.length < 500) { console.error(`skip ${symbol} ${tf}: only ${candles.length} candles`); continue; }
    const t0 = candles[Math.floor(candles.length * 0.6)].time;
    for (const strat of STRATS) {
      const free = runStrategy(strat, candles, rulesFor(symbol)).trades;
      const capped = runStrategy(strat, candles, rulesFor(symbol, {}, { monthlyLossPts: CAP })).trades;
      const row = { symbol, tf, strategy: strat, from: new Date(candles[0].time * 1000).toISOString().slice(0, 10), to: new Date(candles.at(-1).time * 1000).toISOString().slice(0, 10), free: stats(free, CAP), capped: stats(capped, CAP) };
      row.verdict = verdict(row.capped);
      results.push(row);
      if (strat === 'classic') for (const [name, over] of GRID) {
        const tr = runStrategy(strat, candles, rulesFor(symbol, over)).trades; const { is, oos } = splitIS(tr, t0);
        const g = (grids[name] ||= { is: [], oos: [] }); g.is.push(...is); g.oos.push(...oos);
      }
    }
    process.stderr.write(`${symbol} ${tf} done\n`);
  }
}

/* ───────── report ───────── */
const md = [];
md.push(`# Backtest report — ${new Date().toISOString().slice(0, 10)}`);
md.push(`Engine: the app's own (services/backtest.js). Crypto fee ${FEE}% round trip; non-crypto cost proxy 0.03%; additional slippage 0.02% for all. GOLD_FUTURES is futures, not spot XAUUSD; NDX/SPX are indices, not broker CFDs. Points are the app's unit (1 point = pointSize: BTC $1, ETH $0.1, SOL $0.01). Monthly cap = ${CAP} points, enforced as "no new trade if this month's realised loss + the trade's full stop + fee could pass the cap". First 60% of each history = in-sample, last 40% = out-of-sample.\n`);
md.push('## Per asset (all timeframes, classic and SMC combined, cap ON)');
md.push('| Asset | Trades | Win % | Net points | Avg R / trade | Worst month | Months over cap |\n|---|---:|---:|---:|---:|---:|---:|');
for (const sym of SYMBOLS) {
  const rows = results.filter((r) => r.symbol === sym && r.capped.n);
  if (!rows.length) { md.push(`| ${sym} | no data | | | | | |`); continue; }
  const n = rows.reduce((a, r) => a + r.capped.n, 0);
  const w = rows.reduce((a, r) => a + r.capped.n * r.capped.winRate / 100, 0);
  const pts = rows.reduce((a, r) => a + r.capped.points, 0);
  const R = rows.reduce((a, r) => a + r.capped.n * r.capped.expectancy, 0);
  md.push(`| ${sym} | ${n} | ${f2(w / n * 100)} | ${f0(pts)} | ${f2(R / n)} | ${f0(Math.min(...rows.map((r) => r.capped.worstMonth)))} | ${rows.reduce((a, r) => a + r.capped.monthsOverCap, 0)} |`);
}
md.push('\n## Detail (cap OFF → cap ON)');
md.push('| Asset | TF | Strategy | Period | Trades (no cap → cap) | Win % (cap) | Net pts (no cap) | Net pts (cap) | Avg R | PF | Max DD | Worst month (no cap → cap) | Verdict |\n|---|---|---|---|---:|---:|---:|---:|---:|---:|---:|---|---|');
for (const r of results) {
  const a = r.free; const b = r.capped;
  if (!a.n && !b.n) continue;
  md.push(`| ${r.symbol} | ${r.tf} | ${r.strategy} | ${r.from} → ${r.to} | ${a.n || 0} → ${b.n || 0} | ${b.n ? f2(b.winRate) : '–'} | ${a.n ? f0(a.points) : '–'} | ${b.n ? f0(b.points) : '–'} | ${b.n ? f2(b.expectancy) : '–'} | ${b.n ? f2(b.pf) : '–'} | ${b.n ? f0(b.maxDD) : '–'} | ${a.n ? f0(a.worstMonth) : '–'} → ${b.n ? f0(b.worstMonth) : '–'} | ${r.verdict} |`);
}
md.push('\n## Parameter grid — classic strategy, all assets and timeframes pooled (chronological split; exploratory comparison)');
md.push('| Setting | In-sample trades | In-sample avg R | Out-of-sample trades | Out-of-sample avg R |\n|---|---:|---:|---:|---:|');
const avgR = (l) => (l.length ? l.reduce((a, t) => a + (t.r || 0), 0) / l.length : NaN);
for (const [name] of GRID) { const g = grids[name]; if (g) md.push(`| ${name} | ${g.is.length} | ${f2(avgR(g.is))} | ${g.oos.length} | ${f2(avgR(g.oos))} |`); }
const good = GRID.filter(([n]) => grids[n] && avgR(grids[n].is) > 0 && avgR(grids[n].oos) > 0 && grids[n].oos.length >= 100).map(([n]) => n);
md.push(good.length ? `\nSettings positive in BOTH halves with ≥100 out-of-sample trades: ${good.join('; ')}.` : '\nNo setting was positive in both halves with ≥100 out-of-sample trades: do not adopt any of them as an "optimised" setting.');
md.push('\n## How to read this\n- A monthly cap bounds the realised loss only if fills happen at the stop; gaps and slippage can exceed it.\n- If "Trades" collapses when the cap is on, the cap is smaller than one normal stop on that asset/timeframe: raise the cap or use a smaller timeframe-stop, do not widen the cap silently.\n- "negative" verdicts mean the strategy loses money net of fees on that data; the cap only limits how much.');
fs.writeFileSync(path.join(OUT, 'report.md'), md.join('\n'));
fs.writeFileSync(path.join(OUT, 'summary.json'), JSON.stringify({ fee: FEE, cap: CAP, results, grid: Object.fromEntries(Object.entries(grids).map(([k, g]) => [k, { isN: g.is.length, isR: avgR(g.is), oosN: g.oos.length, oosR: avgR(g.oos) }])) }, null, 1));
console.log(md.join('\n'));
