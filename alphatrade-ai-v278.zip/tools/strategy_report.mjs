#!/usr/bin/env node
// Strategy comparison + month-by-month results with the app's own engine (EDH is the reference, never modified).
//   node tools/strategy_report.mjs --data ./data --symbol BTCUSDT --fee 0.1 --slip 0.02 --out ./results
// Needs <data>/<SYMBOL>_<tf>.json for 5m (EDH's frame), 15m, 1h, 4h. First 60% of each series = development, last 40% = out of sample.
// Costs: round-trip fee + slippage (percent of price). No spread data exists for these candles. Pips = points / (10 on crypto & gold, 1 on indices).
import fs from 'node:fs';
import path from 'node:path';
import { runStrategy, rulesFrom, summarize } from '../src/services/backtest.js';
import { aggregate } from '../src/services/smc2.js';
import { getInstrument } from '../src/config/instruments.js';
import { pipPoints } from '../src/services/pips.js';
import { monthlyDetail, totalOf } from '../src/services/monthlyDetail.js';

const arg = (k, d) => { const i = process.argv.indexOf(`--${k}`); return i > -1 ? process.argv[i + 1] : d; };
const DATA = path.resolve(arg('data', './data')), SYMBOL = arg('symbol', 'BTCUSDT'), OUT = path.resolve(arg('out', './results'));
const FEE = Number(arg('fee', 0.1)), SLIP = Number(arg('slip', 0.02));
const inst = getInstrument(SYMBOL), pipPts = pipPoints(inst);
const load = (tf) => JSON.parse(fs.readFileSync(path.join(DATA, `${SYMBOL}_${tf}.json`), 'utf8'));
const h4 = load('4h'), d1 = aggregate(load('1h'), 86400).filter((_, i, a) => i < a.length - 1);
const date = (t) => new Date(t * 1000).toISOString().slice(0, 10);
const f = (x, d = 1) => (Number.isFinite(x) ? x.toFixed(d) : '∞');

function fig(trades, months) {
  const n = trades.length; if (!n) return { n: 0, perMonth: 0 };
  const w = trades.filter((t) => t.points > 0), l = trades.filter((t) => t.points <= 0);
  const gw = w.reduce((a, t) => a + t.r, 0), gl = -l.reduce((a, t) => a + t.r, 0);
  let eq = 0, pk = 0, dd = 0, run = 0, st = 0;
  for (const t of [...trades].sort((a, b) => a.closeTime - b.closeTime)) { eq += t.r; pk = Math.max(pk, eq); dd = Math.max(dd, pk - eq); if (t.points <= 0) { run++; st = Math.max(st, run); } else run = 0; }
  return { n, perMonth: n / months, wins: w.length, losses: l.length, win: 100 * w.length / n, exp: eq / n, pf: gl > 0 ? gw / gl : Infinity, ddR: dd, streak: st, netPips: trades.reduce((a, t) => a + t.points, 0) / pipPts, avgW: w.length ? gw / w.length : 0, avgL: l.length ? gl / l.length : 0 };
}
const lines = [`# Strategy report — ${SYMBOL}`, `Costs: fee ${FEE}% + slippage ${SLIP}% round trip; no spread data. Win = net result > 0 after costs. R = result in units of the risk taken. Pips = points / ${pipPts}. EDH is the reference and is run exactly as the app runs it.`, '',
  '## Comparison (development = first 60% of each series, out of sample = last 40%)', '', '| Strategy | Frame | Period | Dev trades (/mo) | Dev win | Dev PF | Dev R/trade | OOS trades (/mo) | OOS win (W/L) | OOS PF | OOS R/trade | OOS net pips | OOS max DD (R) | OOS loss streak |', '|---|---|---|---|---|---|---|---|---|---|---|---|---|---|'];
const monthly = [];
const RUNS = [['edh', '5m'], ['classic', '5m'], ['classic', '15m'], ['classic', '1h'], ['classic', '4h'], ['smc', '15m'], ['smc', '1h'], ['smc', '4h'], ['zone', '15m'], ['zone', '1h'], ['zone', '4h']];
for (const [strat, tf] of RUNS) {
  const c = load(tf); const cut = c[Math.floor(c.length * 0.6)].time;
  const mDev = (cut - c[0].time) / 2592000, mOos = (c.at(-1).time - cut) / 2592000;
  const rules = { ...rulesFrom({ plan: { feePct: FEE }, smc2: {}, zone: {}, risk: {} }, inst), forced: null, maxPerDay: 0, openOnLast: false, pointSize: inst.pointSize, volumeKind: 'taker', htfCandles: { h4, d1 }, slipPct: SLIP };
  const run = runStrategy(strat, c, rules); const a = fig(run.trades.filter((t) => t.openTime < cut), mDev), b = fig(run.trades.filter((t) => t.openTime >= cut), mOos);
  lines.push(`| ${strat} | ${tf} | ${date(c[0].time)} → ${date(c.at(-1).time)} (cut ${date(cut)}) | ${a.n} (${f(a.perMonth)}) | ${a.n ? f(a.win, 0) + '%' : '—'} | ${a.n ? f(a.pf, 2) : '—'} | ${a.n ? f(a.exp, 2) : '—'} | ${b.n} (${f(b.perMonth)}) | ${b.n ? `${f(b.win, 0)}% (${b.wins}/${b.losses})` : '—'} | ${b.n ? f(b.pf, 2) : '—'} | ${b.n ? f(b.exp, 2) : '—'} | ${b.n ? f(b.netPips, 0) : '—'} | ${b.n ? f(b.ddR, 1) : '—'} | ${b.n ? b.streak : '—'} |`);
  monthly.push({ strat, tf, months: monthlyDetail(run.trades, pipPts), open: run.open });
  process.stderr.write(`${strat} ${tf}: ${run.trades.length}\n`);
}
lines.push('', '## Month by month (closed trades only; an open trade is listed under its table, never inside a month)', '');
for (const { strat, tf, months, open } of monthly) {
  if (!months.length) { lines.push(`### ${strat} ${tf}`, 'No closed trades.', ''); continue; }
  const T = totalOf(months);
  lines.push(`### ${strat} ${tf}`, '', '| Month | Trades | W / L | Win % | Gross win (pips) | Gross loss (pips) | Net (pips) | Avg win | Avg loss | Loss streak | Max DD (pips) |', '|---|---|---|---|---|---|---|---|---|---|---|');
  for (const m of months) lines.push(`| ${m.month} | ${m.trades} | ${m.wins} / ${m.losses} | ${f(m.winRate, 0)}% | ${f(m.grossWinPips, 0)} | ${f(m.grossLossPips, 0)} | ${f(m.netPips, 0)} | ${f(m.avgWinPips, 0)} | ${f(m.avgLossPips, 0)} | ${m.maxLossStreak} | ${f(m.maxDrawdownPips, 0)} |`);
  lines.push(`| **Total** | ${T.trades} | ${T.wins} / ${T.losses} | ${f(T.winRate, 0)}% | ${f(T.grossWinPips, 0)} | ${f(T.grossLossPips, 0)} | ${f(T.netPips, 0)} | | | ${T.maxLossStreak} | |`, '', open ? `Open now (not counted above): ${open.direction} @ ${open.entry}` : 'Open now: none', '');
}
fs.mkdirSync(OUT, { recursive: true }); fs.writeFileSync(path.join(OUT, 'strategy_report.md'), lines.join('\n'));
console.log(lines.slice(0, 20).join('\n'));
