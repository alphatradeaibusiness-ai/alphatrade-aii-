
import fs from 'node:fs';
import path from 'node:path';
import { backtestEdh } from '../src/services/backtest.js';
import { getInstrument } from '../src/config/instruments.js';
import { rsi, ema } from '../src/indicators/index.js';

const DATA = '/mnt/agents/output/data';
const SYMBOLS = ['BTCUSDT','ETHUSDT','SOLUSDT','BNBUSDT','XRPUSDT','DOGEUSDT','ADAUSDT','LINKUSDT','LTCUSDT','TRXUSDT','DOTUSDT','ATOMUSDT','NEARUSDT','SUIUSDT','PEPEUSDT','PAXGUSDT'];
const FEE = 0.1, SLIP = 0.02;

const load = (s, tf) => JSON.parse(fs.readFileSync(path.join(DATA, `${s}_${tf}.json`), 'utf8'));
const fig = (trades) => {
  const n = trades.length; if (!n) return { n: 0, win: 0, pf: 0, netR: 0 };
  const w = trades.filter(t => t.points > 0), l = trades.filter(t => t.points <= 0);
  const gw = w.reduce((a,t) => a+t.r, 0), gl = -l.reduce((a,t) => a+t.r, 0);
  return { n, win: 100*w.length/n, pf: gl>0 ? gw/gl : Infinity, netR: trades.reduce((a,t)=>a+t.r,0) };
};

// Kill zone filter: London 07-10 UTC, NY 12-15 UTC
const inKillZone = (time) => {
  const h = new Date(time * 1000).getUTCHours();
  return (h >= 7 && h <= 10) || (h >= 12 && h <= 15);
};

// Wrap backtestEdh with filters by monkey-patching candle array
function edhFiltered(candles, opts, filters) {
  // We filter by pre-processing: mark non-kill-zone candles as non-breakout
  // Simplest: run backtestEdh on full data, then filter trades by entry time
  const res = backtestEdh(candles, opts);
  let trades = res.trades;
  if (filters.killZone) trades = trades.filter(t => inKillZone(t.openTime));
  return { trades };
}

const results = [];
for (const sym of SYMBOLS) {
  const inst = getInstrument(sym);
  for (const tf of ['1h','4h']) {
    let candles, d1;
    try { candles = load(sym, tf); } catch { continue; }
    try { d1 = load(sym, '1d'); } catch { d1 = []; }
    if (candles.length < 300) continue;
    const opts = { pointSize: inst.pointSize, volumeKind: 'taker', feePct: FEE, slipPct: SLIP, htfCandles: { d1 }, edhDaily: d1 };

    const base = fig(backtestEdh(candles, opts).trades);
    const v2 = fig(edhFiltered(candles, opts, { killZone: true }).trades);

    // V3: RSI filter - reimplement with RSI check
    const closes = candles.map(c => c.close);
    const rsiAll = rsi(closes, 14);
    const v3trades = [];
    {
      // Run EDH but skip entries with bad RSI by filtering candles? No - we need trade-level filter.
      // Approximation: filter trades where RSI at entry was extreme
      const res = backtestEdh(candles, opts);
      for (const t of res.trades) {
        // find entry index
        const idx = candles.findIndex(c => c.time === t.openTime);
        if (idx < 0) { v3trades.push(t); continue; }
        const r = rsiAll[idx];
        if (t.direction === 'long' && r > 68) continue;
        if (t.direction === 'short' && r < 32) continue;
        v3trades.push(t);
      }
    }
    const v3 = fig(v3trades);

    // V4: Volume filter
    const v4trades = [];
    {
      const res = backtestEdh(candles, opts);
      for (const t of res.trades) {
        const idx = candles.findIndex(c => c.time === t.openTime);
        if (idx < 20) { v4trades.push(t); continue; }
        const avgVol = candles.slice(idx-20, idx).reduce((a,c) => a+c.volume, 0) / 20;
        const c = candles[idx];
        if (c.volume < avgVol * 1.2) continue;
        v4trades.push(t);
      }
    }
    const v4 = fig(v4trades);

    // V5: All filters combined
    const v5trades = [];
    {
      const res = backtestEdh(candles, opts);
      for (const t of res.trades) {
        if (!inKillZone(t.openTime)) continue;
        const idx = candles.findIndex(c => c.time === t.openTime);
        if (idx < 0) continue;
        const r = rsiAll[idx];
        if (t.direction === 'long' && r > 68) continue;
        if (t.direction === 'short' && r < 32) continue;
        if (idx >= 20) {
          const avgVol = candles.slice(idx-20, idx).reduce((a,c) => a+c.volume, 0) / 20;
          if (candles[idx].volume < avgVol * 1.2) continue;
        }
        v5trades.push(t);
      }
    }
    const v5 = fig(v5trades);

    results.push({ sym, tf, base, v2, v3, v4, v5 });
    console.log(sym, tf, 'base:', base.win?.toFixed(1)+'%', 'V2:', v2.win?.toFixed(1)+'%', 'V3:', v3.win?.toFixed(1)+'%', 'V4:', v4.win?.toFixed(1)+'%', 'V5:', v5.win?.toFixed(1)+'%');
  }
}
fs.writeFileSync('/mnt/agents/output/edh_variants.json', JSON.stringify(results, null, 2));
console.log('DONE');
