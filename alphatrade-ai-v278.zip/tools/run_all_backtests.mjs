
import fs from 'node:fs';
import path from 'node:path';
import { backtestClassic, backtestSmc, backtestZone, backtestEdh, backtestLbr, summarize, rulesFrom } from '../src/services/backtest.js';
import { getInstrument } from '../src/config/instruments.js';
import { pipPoints } from '../src/services/pips.js';

const DATA = '/mnt/agents/output/data';
const SYMBOLS = ['BTCUSDT','ETHUSDT','SOLUSDT','BNBUSDT','XRPUSDT','DOGEUSDT','ADAUSDT','AVAXUSDT','LINKUSDT','LTCUSDT','TRXUSDT','DOTUSDT','ATOMUSDT','NEARUSDT','SUIUSDT','PEPEUSDT','PAXGUSDT'];
const FEE = 0.1, SLIP = 0.02;

const load = (s, tf) => JSON.parse(fs.readFileSync(path.join(DATA, `${s}_${tf}.json`), 'utf8'));
const fig = (trades) => {
  const n = trades.length; if (!n) return { n: 0, win: 0, pf: 0, netR: 0 };
  const w = trades.filter(t => t.points > 0), l = trades.filter(t => t.points <= 0);
  const gw = w.reduce((a,t) => a+t.r, 0), gl = -l.reduce((a,t) => a+t.r, 0);
  return { n, win: 100*w.length/n, pf: gl>0 ? gw/gl : Infinity, netR: trades.reduce((a,t)=>a+t.r,0) };
};

const results = [];
for (const sym of SYMBOLS) {
  const inst = getInstrument(sym);
  const pip = pipPoints(inst);
  for (const tf of ['5m','1h','4h']) {
    let candles;
    try { candles = load(sym, tf); } catch { continue; }
    if (candles.length < 300) continue;
    let d1; try { d1 = load(sym, '1d'); } catch { d1 = []; }
    const opts = { pointSize: inst.pointSize, volumeKind: 'taker', feePct: FEE, slipPct: SLIP, htfCandles: { d1 } };
    const r = {};
    try { r.edh = fig(backtestEdh(candles, { ...opts, edhDaily: d1 }).trades); } catch(e) { r.edh = { error: e.message }; }
    try { r.classic = fig(backtestClassic(candles, opts).trades); } catch(e) { r.classic = { error: e.message }; }
    try { r.smc = fig(backtestSmc(candles, opts).trades); } catch(e) { r.smc = { error: e.message }; }
    try { r.zone = fig(backtestZone(candles, opts).trades); } catch(e) { r.zone = { error: e.message }; }
    try { r.lbr = fig(backtestLbr(candles, opts).trades); } catch(e) { r.lbr = { error: e.message }; }
    results.push({ sym, tf, ...r });
    console.log(sym, tf, JSON.stringify(r.edh), JSON.stringify(r.classic));
  }
}
fs.writeFileSync('/mnt/agents/output/backtest_results.json', JSON.stringify(results, null, 2));
console.log('DONE');
