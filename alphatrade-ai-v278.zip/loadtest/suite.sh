#!/bin/bash
# usage: suite.sh <projectdir> <outdir>
PROJ=$1; OUT=$2; mkdir -p $OUT; cd $PROJ
S="--static ${STATIC_DIR:-dist} --quiet --endpoints"
for k in page asset asset304 health notices feed syncPut signin klines phone; do
  echo "== only:$k" ; timeout 90 node loadtest/local.mjs only:$k $S --rotate --json $OUT/only-$k.json | grep -v "^  "
done
echo "== only:feed (1000 subscribers)"; timeout 120 node loadtest/local.mjs only:feed $S --rotate --subs 1000 --json $OUT/only-feedSubs.json | grep -v "^  "
echo "== writes"; timeout 200 node loadtest/local.mjs writes $S --rotate --users 20000 --json $OUT/writes.json
echo "== load"; timeout 300 node loadtest/local.mjs load $S --json $OUT/load.json
echo "== grown (load, 1000 subscribers)"; timeout 300 node loadtest/local.mjs load $S --subs 1000 --json $OUT/grown.json
echo "== stress"; timeout 300 node loadtest/local.mjs stress $S --json $OUT/stress.json
echo "== spike"; timeout 300 node loadtest/local.mjs spike $S --json $OUT/spike.json
echo "== soak"; timeout 400 node loadtest/local.mjs soak $S --soak 180 --json $OUT/soak.json
echo SUITE_DONE
