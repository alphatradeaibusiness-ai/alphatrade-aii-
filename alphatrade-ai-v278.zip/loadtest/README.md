# Load & stress testing — AlphaTrade AI

Two tools, no dependencies to install for the first one.

## 1. Local, against the real production server (safe, repeatable)

```bash
npm run build                         # the suite serves ./dist like production
node loadtest/local.mjs smoke         # 15 s sanity check
node loadtest/local.mjs load --json loadtest/results/load.json
```

The harness starts `server/index.js --serve-dist` on a random port with:
- **test sign-in keys:** real RS256 tokens, verified exactly like Firebase ID tokens;
- **seeded data:** 150 channel recommendations, plus optional paying subscribers (`--subs 1000`);
- **a mock market upstream:** 120 ms latency, which counts every call that reaches it;
- **distinct client IPs** per virtual user (`X-Forwarded-For`, `TRUST_PROXY=1`), like real visitors behind a proxy.

It never touches the live site, Stripe, AI providers or e-mail.

### Scenarios

| Scenario | Model | What it answers |
|---|---|---|
| `smoke` | 10 users | Does everything answer? |
| `load` | 200 → 500 → 1 000 users, 1 s think time | Normal peak: latency and errors at expected traffic |
| `stress` | open model, 250 → 4 000 req/s in 15 s steps | Where does it break, and how (slow? errors? crash?) |
| `spike` | 50 → 2 000 users in 1 s, hold 30 s, back to 50 | Survives a sudden wave, and recovers after |
| `soak` | 400 users for `--soak` seconds | Memory leaks, slow degradation |
| `writes` | sign-in, settings sync, phone save | Cost of the encrypted member store under write load |
| `only:<endpoint>` | 100 users on one endpoint | Capacity of one endpoint: `page`, `asset`, `asset304`, `health`, `notices`, `feed`, `syncPut`, `signin`, `klines`, `phone`… |

### Useful flags

- `--rotate`: a new client IP on every request. This measures raw capacity rather than the per-IP limiter (20/min for the API).
- `--subs N`: N paying channel subscribers, each with 20 granted recommendations.
- `--users N`: number of distinct signed-in accounts.
- `--endpoints`: per-endpoint breakdown.
- `--json file`: full results, including a per-second timeline, server CPU/RSS, and the responsiveness probe.

The full before/after suite used for the report is `bash loadtest/suite.sh <project> <outdir>`.

## 2. Against staging or the live site — k6

```bash
k6 run -e BASE=https://staging.example.com -e PROFILE=load loadtest/k6-live.js
k6 run -e BASE=https://staging.example.com -e PROFILE=stress -e TOKEN=<ID token of a TEST account> loadtest/k6-live.js
```

Profiles are `smoke`, `load`, `stress`, `spike` and `soak` (2 h). The script aborts by itself if more than 1 % of requests fail. It only sends what a visitor's browser sends. It never calls AI, payment, bank or owner endpoints.

Rules:
- Run against **staging first**.
- Production only in a quiet window, with the hosting provider's terms checked (load tests can look like an attack) and the team told.
- From one machine every request shares one IP, so you will mostly measure the 429 limiter. Use several load generators (or k6 Cloud) to measure capacity.
- Watch `/api/health` while it runs: `load.overloaded`, `load.shed`, `load.loopP99Ms` and `load.proxy` (cache hit/miss/upstream calls).

## Reading the results

- **p95 / p99:** 95 % / 99 % of requests were faster than this.
- **probe:** latency of `/api/health`, measured 5× per second from outside the load. When it climbs, the whole server is stalling (event loop blocked), not only one endpoint.
- **upstreamHits:** calls that reached the market upstream. In production this is what counts against Binance's limits for the server's IP.
