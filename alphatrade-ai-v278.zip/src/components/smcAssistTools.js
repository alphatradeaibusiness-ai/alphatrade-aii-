// SMC / ICT assistant tools in dialogs: back-test of the rules on real history, market scanner, and the breakdown of the
// user's own saved trades (with an optional AI review of those statistics).
import { esc, fmtNum } from '../utils/dom.js';
import { t, getLang } from '../i18n/index.js';
import { icons } from './icons.js';
import { storage } from '../utils/storage.js';
import { getHistory } from '../services/market/index.js';
import { getInstrument } from '../config/instruments.js';
import { TIMEFRAMES } from '../config/market.js';
import { LTF, OPTIONAL, frameSummary, weekly } from '../services/smcAssist.js';
import { htfCandles } from '../services/htfData.js';
import { backtestSmcIct, compareSettings, riskAdvice, drift, robustness } from '../services/smcBacktest.js';
import { INSTRUMENTS } from '../config/instruments.js';
import { scanMarkets } from '../services/smcScanner.js';
import { breakdown, listTrades } from '../services/assistTrades.js';
import { reviewTrades } from '../services/ai/client.js';
import { aiErrorText } from './aiKeyCard.js';
import { lineSvg } from '../pages/tools/common.js';

const T = (k, p) => t(`sa.${k}`, p);
const tfName = (id) => t(`perf.tfShort.${id}`) || id;
const pct = (v) => (v == null ? '—' : `${Math.round(v * 100)}%`);
const rv = (v) => (v == null ? '—' : `${v > 0 ? '+' : ''}${fmtNum(v, 2)}R`);
const secOf = (tf) => TIMEFRAMES.find((x) => x.id === tf)?.seconds || 3600;

/* ───────── saved back-test results (shown as a badge in the panel) ───────── */
export const btKey = (symbol, tf, p) => `${symbol}|${tf}|${p.style}|${p.execution}|${[...(p.require || [])].sort().join('+')}`;
export const lastBacktest = (key) => (storage.get('assist-bt', {}) || {})[key] || null;
function keepBacktest(key, res) {
  const all = storage.get('assist-bt', {}) || {};
  all[key] = { at: Date.now(), verdict: res.verdict, n: res.all.n, avgR: res.all.avgR, winRate: res.all.winRate, oosAvgR: res.outOfSample.avgR, oosN: res.outOfSample.n, bars: res.bars };
  const keys = Object.keys(all).sort((a, b) => all[b].at - all[a].at).slice(0, 40);
  storage.set('assist-bt', Object.fromEntries(keys.map((k) => [k, all[k]])));
}

/* ───────── back-test dialog ───────── */
export function renderBacktest(body, { symbol, tf, inputs, onRequire, onDone, onApply, onApplyRisk }) {
  const inst = getInstrument(symbol);
  const ltf = LTF[tf];
  body.innerHTML = `<div class="sa-bt">
    <p class="sa-note">${esc(T('bt.intro', { sym: symbol, tf: tfName(tf), style: T(`style.${inputs.style}`), exec: T(`exec.${inputs.execution}`) }))}</p>
    <div class="sa-bt-ctl"><label class="sa-field"><span>${esc(T('bt.bars'))}</span><select class="select" data-bars>${[1000, 2000, 3000, 5000].map((n) => `<option value="${n}" ${n === 2000 ? 'selected' : ''}>${n}</option>`).join('')}</select></label>
      <button type="button" class="btn btn-primary btn-sm" data-run>${icons.flask || ''}<span>${esc(T('bt.run'))}</span></button><button type="button" class="btn btn-sm" data-stop hidden>${esc(T('bt.stop'))}</button></div>
    <div class="sa-progress" data-prog hidden><span></span></div>
    <div data-out></div></div>`;
  let cancelled = false;
  const out = body.querySelector('[data-out]');
  const prog = body.querySelector('[data-prog]');
  body.querySelector('[data-stop]').addEventListener('click', () => { cancelled = true; });
  body.querySelector('[data-run]').addEventListener('click', async (e) => {
    const btn = e.currentTarget; const bars = Number(body.querySelector('[data-bars]').value);
    cancelled = false; btn.disabled = true; body.querySelector('[data-stop]').hidden = false; prog.hidden = false; prog.firstElementChild.style.width = '2%';
    out.innerHTML = `<p class="muted sa-note">${esc(T('bt.loading'))}</p>`;
    try {
      const tfSec = secOf(tf);
      const ds = await getHistory(symbol, tf, bars + 500);
      if (ds.mode !== 'live') { out.innerHTML = `<p class="sa-note down">${esc(T('bt.demo'))}</p>`; return; }
      const span = ds.candles.at(-1).time - ds.candles[0].time;
      const want = (sec) => Math.min(5000, Math.ceil(span / sec) + 120);
      const [h4, d1] = await Promise.all([tfSec < 14400 ? getHistory(symbol, '4h', want(14400)) : null, tfSec < 86400 ? getHistory(symbol, '1D', want(86400)) : null]);
      const htf = { h4: h4?.mode === 'live' ? h4.candles : null, d1: d1?.mode === 'live' ? d1.candles : null };
      let ltfCandles = null; let ltfNote = '';
      if (inputs.execution === 'confirm') {
        const need = ltf ? Math.ceil(span / secOf(ltf)) + 50 : Infinity;
        if (!ltf) ltfNote = T('bt.noLtf');
        else if (inst?.provider !== 'binance' || need > 30000) ltfNote = T('bt.ltfLimit', { tf: tfName(ltf) });
        else { const l = await getHistory(symbol, ltf, need); if (l.mode === 'live') ltfCandles = l.candles; else ltfNote = T('bt.noLtf'); }
        if (!ltfCandles) { out.innerHTML = `<p class="sa-note down">${esc(ltfNote)}</p>`; return; }
      }
      const res = await backtestSmcIct(ds.candles, { ...inputs, symbol, tf, tfSec }, { htf, ltf: ltfCandles, onProgress: (f) => { prog.firstElementChild.style.width = `${Math.max(2, Math.round(f * 100))}%`; }, isCancelled: () => cancelled || !body.isConnected });
      if (res.error) { out.innerHTML = `<p class="sa-note down">${esc(T(`bt.err.${res.error}`))}</p>`; return; }
      keepBacktest(btKey(symbol, tf, inputs), res); onDone?.();
      paintResult(out, res, { inst, onRequire, inputs, htfNote: !htf.h4 && !htf.d1, onApplyRisk });
      // Compare a few settings on the same data (already loaded).
      const cmpBox = document.createElement('div'); cmpBox.className = 'sa-cmp';
      cmpBox.innerHTML = `<h4 class="sa-h">${esc(T('cmp.title'))}</h4><p class="sa-note muted">${esc(T('cmp.note'))}</p><button type="button" class="btn btn-sm" data-cmp>${esc(T('cmp.run'))}</button><div data-cmp-out></div>`;
      out.append(cmpBox);
      // The same settings on other markets (crypto: long real history from Binance).
      const mmBox = document.createElement('div'); mmBox.className = 'sa-cmp';
      mmBox.innerHTML = `<h4 class="sa-h">${esc(T('mm.title'))}</h4><p class="sa-note muted">${esc(T('mm.note'))}</p><button type="button" class="btn btn-sm" data-mm>${esc(T('mm.run'))}</button><div data-mm-out></div>`;
      out.append(mmBox);
      mmBox.querySelector('[data-mm]').addEventListener('click', async (ev) => {
        const b3 = ev.currentTarget; b3.disabled = true; prog.hidden = false; cancelled = false;
        const box = mmBox.querySelector('[data-mm-out]'); const rows = [];
        const list = INSTRUMENTS.filter((i) => i.provider === 'binance').map((i) => i.symbol).slice(0, 12);
        const draw = () => {
          const rb = robustness(rows);
          box.innerHTML = `${rows.length === list.length ? `<p class="sa-verdict ${rb.robust ? 'sa-bt-positive' : 'sa-bt-negative'}"><b>${esc(T(rb.robust ? 'mm.robust' : 'mm.notRobust', { p: rb.positive, t: rb.tested, m: rb.markets }))}</b></p>` : `<p class="muted sa-note">${esc(T('scan.count', { d: rows.length, t: list.length }))}</p>`}
            <div class="sa-table-wrap"><table class="kv-table sa-table"><thead><tr><th>${esc(T('history.cols.symbol'))}</th><th>${esc(T('bt.trades'))}</th><th>${esc(T('bt.winRate'))}</th><th>${esc(T('bt.avgR'))}</th><th>${esc(T('bt.outSample'))}</th><th></th></tr></thead><tbody>
            ${rows.map((x) => `<tr><td class="mono">${esc(x.symbol)}</td>${x.error ? `<td colspan="5" class="muted">${esc(T('scan.noData'))}</td>` : `<td class="mono">${x.n}</td><td class="mono">${pct(x.winRate)}</td><td class="mono ${x.avgR > 0 ? 'up' : 'down'}">${rv(x.avgR)}</td><td class="mono">${x.oosN} · ${rv(x.oosAvgR)}</td><td><small>${esc(T(`bt.verdict.${x.verdict}`))}</small></td>`}</tr>`).join('')}
            </tbody></table></div>`;
        };
        try {
          for (let k = 0; k < list.length && !cancelled && body.isConnected; k++) {
            const sym = list[k];
            try {
              const d2 = await getHistory(sym, tf, Math.min(bars, 2000) + 500);
              if (d2.mode !== 'live') { rows.push({ symbol: sym, error: true }); draw(); continue; }
              const span2 = d2.candles.at(-1).time - d2.candles[0].time; const w2 = (sec) => Math.min(5000, Math.ceil(span2 / sec) + 120);
              const [a4, a1] = await Promise.all([tfSec < 14400 ? getHistory(sym, '4h', w2(14400)) : null, tfSec < 86400 ? getHistory(sym, '1D', w2(86400)) : null]);
              const res2 = await backtestSmcIct(d2.candles, { ...inputs, execution: inputs.execution === 'confirm' ? 'limit' : inputs.execution, symbol: sym, tf, tfSec }, { htf: { h4: a4?.mode === 'live' ? a4.candles : null, d1: a1?.mode === 'live' ? a1.candles : null }, isCancelled: () => cancelled || !body.isConnected, onProgress: (f) => { prog.firstElementChild.style.width = `${Math.max(2, Math.round(((k + f) / list.length) * 100))}%`; } });
              rows.push(res2.error ? { symbol: sym, error: true } : { symbol: sym, n: res2.all.n, winRate: res2.all.winRate, avgR: res2.all.avgR, oosN: res2.outOfSample.n, oosAvgR: res2.outOfSample.avgR, verdict: res2.verdict });
            } catch { rows.push({ symbol: sym, error: true }); }
            draw();
          }
        } finally { b3.disabled = false; prog.hidden = true; }
      });
      cmpBox.querySelector('[data-cmp]').addEventListener('click', async (ev) => {
        const b2 = ev.currentTarget; b2.disabled = true; prog.hidden = false; cancelled = false;
        const box = cmpBox.querySelector('[data-cmp-out]'); box.innerHTML = `<p class="muted sa-note">${esc(T('cmp.running'))}</p>`;
        try {
          const c = await compareSettings(ds.candles, { ...inputs, symbol, tf, tfSec }, { htf, ltf: ltfCandles, onProgress: (f) => { prog.firstElementChild.style.width = `${Math.max(2, Math.round(f * 100))}%`; }, isCancelled: () => cancelled || !body.isConnected });
          if (c.error) { box.innerHTML = `<p class="sa-note down">${esc(T(`bt.err.${c.error}`))}</p>`; return; }
          box.innerHTML = `<div class="sa-table-wrap"><table class="kv-table sa-table"><thead><tr><th>${esc(T('exec.label'))}</th><th>${esc(T('cmp.req'))}</th><th>${esc(T('bt.trades'))}</th><th>${esc(T('bt.avgR'))}</th><th>${esc(T('bt.outSample'))}</th><th></th><th></th></tr></thead><tbody>
            ${c.rows.map((x, i) => `<tr><td>${esc(T(`exec.${x.execution}`))}</td><td>${x.require.length ? esc(x.require.map((id) => T(`checks.${id}`)).join('، ')) : '—'}</td><td class="mono">${x.all.n}</td><td class="mono ${x.all.avgR > 0 ? 'up' : 'down'}">${rv(x.all.avgR)}</td>
              <td class="mono ${x.oos.avgR > 0 ? 'up' : 'down'}">${x.oos.n} · ${rv(x.oos.avgR)}</td><td><small>${esc(T(`bt.verdict.${x.verdict}`))}</small></td>
              <td>${onApply ? `<button type="button" class="btn btn-sm btn-ghost" data-apply="${i}">${esc(T('cmp.apply'))}</button>` : ''}</td></tr>`).join('')}</tbody></table></div><p class="sa-note muted">${esc(T('cmp.warn'))}</p>`;
          box.querySelectorAll('[data-apply]').forEach((bb) => bb.addEventListener('click', () => { const x = c.rows[Number(bb.dataset.apply)]; onApply({ execution: x.execution, require: x.require }); bb.disabled = true; bb.textContent = T('bt.applied'); }));
        } finally { b2.disabled = false; prog.hidden = true; }
      });
    } catch (err) { out.innerHTML = `<p class="sa-note down">${esc(String(err?.message || err))}</p>`; }
    finally { btn.disabled = false; body.querySelector('[data-stop]').hidden = true; prog.hidden = true; }
  });
}

function paintResult(out, res, { inst, onRequire, inputs, htfNote, onApplyRisk }) {
  const a = res.all; const d = (s) => new Date(s * 1000).toLocaleDateString(getLang() === 'ar' ? 'ar-EG-u-nu-latn' : 'en-GB', { year: 'numeric', month: 'short', day: 'numeric' });
  const kpi = (k, v, cls = '') => `<div class="sa-kpi"><span>${esc(k)}</span><b class="mono ${cls}">${v}</b></div>`;
  const row = (name, s) => `<tr><td>${esc(name)}</td><td class="mono">${s.n}</td><td class="mono">${pct(s.winRate)}</td><td class="mono ${s.avgR > 0 ? 'up' : s.avgR < 0 ? 'down' : ''}">${rv(s.avgR)}</td><td class="mono">${rv(s.totalR)}</td></tr>`;
  const helpful = res.conditions.filter((c) => OPTIONAL.includes(c.id) && c.diff != null && c.diff >= 0.2 && c.with.avgR > 0 && !(inputs.require || []).includes(c.id));
  out.innerHTML = `
    <div class="sa-verdict sa-bt-${res.verdict}"><b>${esc(T(`bt.verdict.${res.verdict}`))}</b><span>${esc(T('bt.period', { from: d(res.from), to: d(res.to), bars: res.bars }))}</span></div>
    <p class="sa-note">${esc(T(`bt.explain.${res.verdict}`, { n: a.n, min: res.minTrades }))}</p>
    ${htfNote ? `<p class="sa-note muted">${esc(T('bt.htfNote'))}</p>` : ''}
    <div class="sa-kpis">${kpi(T('bt.trades'), a.n)}${kpi(T('bt.winRate'), pct(a.winRate))}${kpi(T('bt.avgR'), rv(a.avgR), a.avgR > 0 ? 'up' : 'down')}${kpi(T('bt.totalR'), rv(a.totalR))}
      ${kpi(T('bt.pf'), a.profitFactor == null ? '—' : fmtNum(a.profitFactor, 2))}${kpi(T('bt.maxDD'), a.maxDD ? `-${fmtNum(a.maxDD, 2)}R` : '0')}${kpi(T('bt.streak'), a.maxLossStreak)}</div>
    ${a.equity.length > 1 ? `<div class="sa-equity">${lineSvg(a.equity, { height: 120 })}</div>` : ''}
    <h4 class="sa-h">${esc(T('bt.wf'))}</h4>
    <table class="kv-table sa-table"><thead><tr><th></th><th>${esc(T('bt.trades'))}</th><th>${esc(T('bt.winRate'))}</th><th>${esc(T('bt.avgR'))}</th><th>${esc(T('bt.totalR'))}</th></tr></thead>
      <tbody>${row(T('bt.inSample'), res.inSample)}${row(T('bt.outSample'), res.outOfSample)}</tbody></table>
    <p class="sa-note muted">${esc(T('bt.wfNote'))} ${esc(T('bt.unfilled', { e: res.unfilled.expired, m: res.unfilled.missed, o: res.open }))} ${esc(T('bt.costs', { c: fmtNum(res.costPct ?? 0, 2) }))}</p>
    <h4 class="sa-h">${esc(T('bt.cond'))}</h4>
    <p class="sa-note muted">${esc(T('bt.condNote', { n: res.candidates.n }))}</p>
    <div class="sa-table-wrap"><table class="kv-table sa-table"><thead><tr><th>${esc(T('checks.title'))}</th><th>${esc(T('bt.with'))}</th><th>${esc(T('bt.without'))}</th><th>${esc(T('bt.effect'))}</th></tr></thead><tbody>
      ${res.conditions.map((c) => `<tr><td>${esc(T(`checks.${c.id}`))}</td><td class="mono">${c.with.n} · ${rv(c.with.avgR)}</td><td class="mono">${c.without.n} · ${rv(c.without.avgR)}</td>
        <td>${c.diff == null ? `<span class="muted">${esc(T('bt.fx.few'))}</span>` : c.diff >= 0.2 ? `<b class="up">${esc(T('bt.fx.helps'))} (${rv(c.diff)})</b>` : c.diff <= -0.2 ? `<b class="down">${esc(T('bt.fx.hurts'))} (${rv(c.diff)})</b>` : `<span class="muted">${esc(T('bt.fx.none'))}</span>`}</td></tr>`).join('')}
    </tbody></table></div>
    ${helpful.length && onRequire ? `<div class="sa-hint">${esc(T('bt.suggest', { list: helpful.map((c) => T(`checks.${c.id}`)).join('، ') }))} <button type="button" class="btn btn-sm" data-req>${esc(T('bt.apply'))}</button></div>` : ''}
    ${res.monteCarlo ? `<h4 class="sa-h">${esc(T('mc.title'))}</h4><p class="sa-note">${esc(T('mc.text', { runs: res.monteCarlo.runs, n: res.monteCarlo.trades, r50: fmtNum(res.monteCarlo.ddR.p50, 1), r95: fmtNum(res.monteCarlo.ddR.p95, 1), p50: fmtNum(res.monteCarlo.ddPct.p50, 1), p95: fmtNum(res.monteCarlo.ddPct.p95, 1), risk: fmtNum(res.monteCarlo.riskPct, 2), dd20: Math.round(res.monteCarlo.probDD20 * 100) }))}</p>` : ''}
    <div data-risk></div>
    <details class="sa-checks"><summary>${esc(T('bt.list'))} (${res.trades.length})</summary><div class="sa-table-wrap"><table class="kv-table sa-table"><tbody>
      ${res.trades.slice(-60).reverse().map((x) => `<tr><td class="mono">${esc(d(x.time))}</td><td class="${x.direction === 'long' ? 'up' : 'down'}">${esc(T(`dir.${x.direction}`))}</td><td class="mono">${fmtNum(x.entry, inst?.precision ?? 2)}</td><td>${esc(T(`history.status.${x.status}`))}${x.hits ? ` · TP${x.hits}` : ''}</td><td class="mono ${x.resultR > 0 ? 'up' : 'down'}">${rv(x.resultR)}</td></tr>`).join('')}
    </tbody></table></div></details>
    <p class="side-foot">${esc(T('bt.honest'))}</p>`;
  // How much to risk per trade, from these results (re-computed when the accepted drawdown changes).
  const riskBox = out.querySelector('[data-risk]');
  const paintRisk = (maxDD) => {
    const ra = riskAdvice(res.trades.map((x) => x.resultR), { maxDDPct: maxDD });
    if (!ra) { riskBox.innerHTML = `<h4 class="sa-h">${esc(T('ra.title'))}</h4><p class="sa-note muted">${esc(T('ra.few'))}</p>`; return; }
    riskBox.innerHTML = `<h4 class="sa-h">${esc(T('ra.title'))}</h4>
      <label class="sa-field sa-ra"><span>${esc(T('ra.maxDD'))}</span><input class="input mono" data-maxdd inputmode="decimal" value="${maxDD}" maxlength="4"></label>
      <p class="sa-note">${esc(ra.halfKelly === 0 ? T('ra.noEdge') : T('ra.text', { dd: maxDD, r: fmtNum(ra.riskForDD, 2), k: fmtNum(ra.halfKelly, 2) }))}</p>
      ${ra.halfKelly > 0 && onApplyRisk ? `<button type="button" class="btn btn-sm" data-userisk>${esc(T('ra.apply', { r: fmtNum(Math.min(ra.riskForDD, ra.halfKelly), 2) }))}</button>` : ''}
      <p class="sa-note muted">${esc(T('ra.note'))}</p>`;
    riskBox.querySelector('[data-maxdd]').addEventListener('change', (e) => { const v = Math.min(50, Math.max(1, Number(e.target.value) || 10)); paintRisk(v); });
    riskBox.querySelector('[data-userisk]')?.addEventListener('click', (e) => { onApplyRisk(Math.max(0.05, Math.min(ra.riskForDD, ra.halfKelly))); e.currentTarget.disabled = true; e.currentTarget.textContent = T('bt.applied'); });
  };
  paintRisk(10);
  out.querySelector('[data-req]')?.addEventListener('click', (e) => { onRequire([...(inputs.require || []), ...helpful.map((c) => c.id)]); e.currentTarget.disabled = true; e.currentTarget.textContent = T('bt.applied'); });
}

/* ───────── scanner dialog ───────── */
export function renderScanner(body, { tf, inputs, onPick }) {
  body.innerHTML = `<p class="sa-note">${esc(T('scan.intro', { tf: tfName(tf), style: T(`style.${inputs.style}`) }))}</p>
    <div class="sa-progress" data-prog><span style="width:2%"></span></div><p class="sa-note muted" data-count></p><div data-rows></div>`;
  const rows = []; const box = body.querySelector('[data-rows]'); const prog = body.querySelector('[data-prog]');
  const draw = () => {
    const sorted = [...rows].sort((a, b) => ({ trade: 0, wait: 1 }[a.verdict] ?? 2) - ({ trade: 0, wait: 1 }[b.verdict] ?? 2) || (b.rrMain ?? -9) - (a.rrMain ?? -9));
    box.innerHTML = `<div class="sa-table-wrap"><table class="kv-table sa-table"><thead><tr><th>${esc(T('history.cols.symbol'))}</th><th>${esc(T('scan.reading'))}</th><th>${esc(T('entry'))}</th><th>${esc(T('rr'))}</th><th></th></tr></thead><tbody>
      ${sorted.map((r) => `<tr class="${r.verdict === 'trade' ? 'sa-row-hot' : ''}"><td class="mono">${esc(r.symbol)}</td>
        <td>${r.verdict === 'trade' || r.verdict === 'wait' ? `<b class="${r.direction === 'long' ? 'up' : 'down'}">${esc(T(`verdict.${r.verdict}`))} · ${esc(T(`dir.${r.direction}`))}</b>` : `<span class="muted">${esc(r.verdict === 'no_data' || r.verdict === 'error' ? T('scan.noData') : T(`verdict.${r.verdict}`))}</span>`}</td>
        <td class="mono">${r.entry != null && r.verdict !== 'no_trade' ? fmtNum(r.entry, r.precision) : '—'}</td><td class="mono">${r.rrMain != null && r.verdict !== 'no_trade' ? `1:${fmtNum(r.rrMain, 2)}` : '—'}</td>
        <td>${r.verdict === 'no_data' || r.verdict === 'error' ? '' : `<button type="button" class="btn btn-sm btn-ghost" data-open="${esc(r.symbol)}">${esc(T('scan.open'))}</button>`}</td></tr>`).join('')}
    </tbody></table></div>`;
    box.querySelectorAll('[data-open]').forEach((b) => b.addEventListener('click', () => onPick(b.dataset.open)));
  };
  scanMarkets({ tf, inputs, isCancelled: () => !body.isConnected, onRow: (row, done, total) => { rows.push(row); prog.firstElementChild.style.width = `${Math.round((done / total) * 100)}%`; body.querySelector('[data-count]').textContent = T('scan.count', { d: done, t: total }); draw(); } })
    .then(() => { prog.hidden = true; const hot = rows.filter((r) => r.verdict === 'trade').length; body.querySelector('[data-count]').textContent = T('scan.done', { n: hot, t: rows.length }); });
}

/* ───────── breakdown of the user's own results ───────── */
export function renderBreakdown(box) {
  const b = breakdown(listTrades());
  const o = b.overall;
  if (!o.n) { box.innerHTML = `<p class="muted sa-note">${esc(T('bd.empty'))}</p>`; return; }
  const table = (title, rows, name) => (rows.length ? `<h4 class="sa-h">${esc(title)}</h4><table class="kv-table sa-table"><tbody>${rows.map((r) => `<tr><td>${esc(name(r.key))}</td><td class="mono">${r.n}</td><td class="mono">${pct(r.winRate)}</td><td class="mono ${r.avgR > 0 ? 'up' : r.avgR < 0 ? 'down' : ''}">${rv(r.avgR)}</td></tr>`).join('')}</tbody></table>` : '');
  const wkLine = `<p class="sa-note mono">${esc(T('bd.weeks', { n: b.weeks.this.n, r: rv(b.weeks.this.totalR), ln: b.weeks.last.n, lr: rv(b.weeks.last.totalR) }))}</p>`;
  box.innerHTML = wkLine + `<p class="sa-note">${esc(T('bd.overall', { n: o.n, w: pct(o.winRate), a: rv(o.avgR), dd: o.maxDD ? fmtNum(o.maxDD, 2) : '0' }))}</p>
    ${o.n < 30 ? `<p class="sa-note muted">${esc(T('bd.small'))}</p>` : ''}
    <div class="sa-bd-grid">
      ${table(T('bd.byStyle'), b.byStyle, (k) => T(`style.${k}`))}${table(T('bd.byDirection'), b.byDirection, (k) => T(`dir.${k}`))}
      ${table(T('bd.byExecution'), b.byExecution, (k) => T(`exec.${k}`))}${table(T('bd.bySession'), b.bySession, (k) => T(`bd.kz.${k}`))}
      ${table(T('bd.bySymbol'), b.bySymbol.slice(0, 8), (k) => k)}
      <div><h4 class="sa-h">${esc(T('bd.byTag'))}</h4><table class="kv-table sa-table"><tbody>${b.byTag.map((g) => `<tr><td>${esc(T(`checks.${g.tag}`))}</td><td class="mono">${g.with.n} · ${rv(g.with.avgR)}</td><td class="mono muted">${esc(T('bt.without'))} ${g.without.n} · ${rv(g.without.avgR)}</td></tr>`).join('')}</tbody></table></div>
    </div>
    ${(() => { const d = drift(listTrades().filter((x) => x.mode === 'live' && ['done', 'stopped', 'breakeven'].includes(x.status) && Number.isFinite(x.resultR)).sort((p, q) => p.closedAt - q.closedAt).map((x) => x.resultR)); return d ? `<p class="sa-note ${d.worse ? 'down' : ''}">${esc(T(d.worse ? 'bd.driftBad' : 'bd.drift', { n: d.n, a: rv(d.recent.avgR), b: rv(d.before.avgR) }))}</p>` : ''; })()}
    ${b.afterLoss.n ? `<p class="sa-note">${esc(T('bd.afterLoss', { n: b.afterLoss.n, a: rv(b.afterLoss.avgR), all: rv(o.avgR) }))}</p>` : ''}
    <button type="button" class="btn btn-sm" data-review>${icons.brain || ''}<span>${esc(T('bd.ai'))}</span></button><div class="sa-ai-out" data-review-out hidden></div>`;
  box.querySelector('[data-review]').addEventListener('click', async (e) => {
    const btn = e.currentTarget; const res = box.querySelector('[data-review-out]');
    btn.disabled = true; res.hidden = false; res.className = 'sa-ai-out muted'; res.textContent = t('syn.explaining');
    try {
      const ctx = { source: 'smc_ict_assistant', note: 'R after costs; equal parts at each target, stop to entry after TP1', overall: b.overall,
        groups: { style: b.byStyle, direction: b.byDirection, orderType: b.byExecution, session: b.bySession, symbol: b.bySymbol.slice(0, 10), conditions: b.byTag }, diagnostics: { afterLoss: b.afterLoss } };
      res.className = 'sa-ai-out'; res.textContent = await reviewTrades(ctx, getLang());
    } catch (err) { res.className = 'sa-ai-out down'; res.textContent = err?.code && /^[a-z_]+$/.test(err.code) ? aiErrorText(err.code) : String(err?.message || err); }
    finally { btn.disabled = false; }
  });
}

/* ───────── top-down analysis (Weekly → 15 min) ───────── */
export function renderTopDown(body, { symbol }) {
  body.innerHTML = `<p class="sa-note">${esc(T('td.intro', { sym: symbol }))}</p><div data-td><p class="muted sa-note">${esc(T('bt.loading'))}</p></div>`;
  const prec = getInstrument(symbol)?.precision ?? 2;
  const px = (v) => (v == null ? '—' : fmtNum(v, prec));
  (async () => {
    const h = htfCandles(symbol) || {};
    const [d1, h4, h1, m15] = await Promise.all([
      h.d1?.length ? { mode: 'live', candles: h.d1 } : getHistory(symbol, '1D', 400), h.h4?.length ? { mode: 'live', candles: h.h4 } : getHistory(symbol, '4h', 500),
      getHistory(symbol, '1h', 500), getHistory(symbol, '15m', 500)]);
    const frames = [['w1', d1.mode === 'live' ? weekly(d1.candles) : null, 2], ['1D', d1.mode === 'live' ? d1.candles : null, 2], ['4h', h4.mode === 'live' ? h4.candles : null, 3], ['1h', h1.mode === 'live' ? h1.candles : null, 3], ['15m', m15.mode === 'live' ? m15.candles : null, 3]];
    const rows = frames.map(([id, cs, len]) => ({ id, s: cs ? frameSummary(cs, len) : null }));
    if (!body.isConnected) return;
    const known = rows.filter((x) => x.s?.trend); const bull = known.filter((x) => x.s.trend === 'bull').length;
    const zone = (z) => (z ? `<span class="${z.dir === 'bull' ? 'up' : 'down'}">${esc(z.kind)}</span> <span class="mono">${px(z.bottom)}–${px(z.top)}</span>` : '—');
    body.querySelector('[data-td]').innerHTML = `<p class="sa-verdict ${bull === known.length && known.length ? 'sa-bt-positive' : bull === 0 && known.length ? 'sa-bt-negative' : 'sa-bt-too_few'}"><b>${esc(T('td.align', { b: bull, s: known.length - bull, t: known.length }))}</b></p>
      <div class="sa-table-wrap"><table class="kv-table sa-table"><thead><tr><th>${esc(T('td.frame'))}</th><th>${esc(T('td.trend'))}</th><th>${esc(T('td.break'))}</th><th>${esc(T('td.pd'))}</th><th>${esc(T('td.above'))}</th><th>${esc(T('td.below'))}</th><th>BSL / SSL</th></tr></thead><tbody>
      ${rows.map(({ id, s }) => `<tr><td><b>${esc(id === 'w1' ? T('bias.w1') : tfName(id))}</b></td>${s ? `<td class="${s.trend === 'bull' ? 'up' : s.trend === 'bear' ? 'down' : ''}">${esc(s.trend ? T(`bias.${s.trend}`) : '—')}</td>
        <td>${s.lastBreak ? `${esc(s.lastBreak.kind)} ${s.lastBreak.dir === 'bull' ? '▲' : '▼'}` : '—'}</td><td>${s.pd ? esc(T(`td.${s.pd}`)) : '—'}</td><td>${zone(s.above)}</td><td>${zone(s.below)}</td><td class="mono">${px(s.bsl)} / ${px(s.ssl)}</td>` : `<td colspan="6" class="muted">${esc(T('scan.noData'))}</td>`}</tr>`).join('')}
      </tbody></table></div><p class="sa-note muted">${esc(T('td.note'))}</p>`;
  })().catch((e) => { if (body.isConnected) body.querySelector('[data-td]').innerHTML = `<p class="sa-note down">${esc(String(e?.message || e))}</p>`; });
}
