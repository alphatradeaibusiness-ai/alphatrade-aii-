// Market-data key option inside the "AI key" page (owner only): Twelve Data key for gold, indices and forex.
// Crypto (BTC, ETH, SOL, BNB) comes from Binance public data and needs no key.
// "Connected" is shown only after the server made a real request with the key; the page never keeps the key.
import { esc } from '../utils/dom.js';
import { t } from '../i18n/index.js';
import { icons } from './icons.js';
import { toast } from './ui.js';
import { statePill, aiErrorText as aiErr } from './aiKeyCard.js';

const aiErrorText = (code) => (code === 'no_permission' ? t('mkey.noPlan') : aiErr(code));   // plan limits, not an AI-model permission
import { marketKeyStatus, saveMarketKey, testMarketKey, deleteMarketKey, onMarketKey, lastMarketKey } from '../services/market/keyApi.js';
import { auth } from '../services/auth/index.js';

export function marketKeyCardHtml() {
  return `<article class="card tool-card fade-in ai-key-card" data-mk-panel>
    <div class="tool-head"><h2 class="card-title">${icons.chart || icons.lock}<span>${esc(t('mkey.title'))}</span></h2><span data-mk-pill>${statePill('checking')}</span></div>
    <div data-mk-body><p class="muted">${esc(t('aiKey.loading'))}</p></div>
  </article>`;
}

export function bindMarketKeyCard(root) {
  const panel = root.querySelector('[data-mk-panel]');
  const $ = (s) => panel.querySelector(s);
  let busy = false; let note = null;

  const markets = (m) => (m ? ['forex', 'gold', 'indices'].map((k) => `<li class="${m[k]?.ok ? 'up' : 'warn'}">${esc(t(`mkey.m.${k}`))} — ${esc(m[k] ? (m[k].ok ? t('mkey.ok') : aiErrorText(m[k].code || 'unknown')) : t('mkey.notTested'))}</li>`).join('') : '');

  const form = (st) => `
    <p class="ai-k-meta">${st.source === 'site' ? esc(t('mkey.meta', { k: st.last4 || '—', e: st.boundTo || '—' })) : st.source === 'env' ? esc(t('mkey.metaEnv', { k: st.last4 || '—' })) : esc(t('mkey.noKey'))}</p>
    ${st.state === 'connected' && st.markets ? `<ul class="tool-list ai-k-markets">${markets(st.markets)}</ul>` : ''}
    ${st.state === 'failed' && st.error ? `<p class="ai-k-err down">${esc(aiErrorText(st.error))}</p>` : ''}
    <label class="tf-field tf-wide"><span>${esc(t('mkey.key'))}</span><input class="input mono" type="password" data-mk-key dir="ltr" autocomplete="new-password" spellcheck="false" placeholder="${esc(st.source === 'site' ? t('aiKey.keyKeep', { k: st.last4 }) : t('mkey.keyPh'))}"/></label>
    <div class="tool-actions">
      <button type="button" class="btn btn-sm btn-primary" data-mk-save>${icons.check}<span>${esc(t('aiKey.save'))}</span></button>
      <button type="button" class="btn btn-sm" data-mk-test ${st.source === 'none' ? 'disabled' : ''}>${icons.refresh}<span>${esc(t('aiKey.retest'))}</span></button>
      <button type="button" class="btn btn-sm btn-ghost" data-mk-del ${st.source === 'site' ? '' : 'hidden'}>${icons.trash}<span>${esc(t('aiKey.delete'))}</span></button>
    </div>
    <p class="ai-k-note ${note ? note.kind : ''}" aria-live="polite">${note ? esc(note.text) : ''}</p>
    ${st.canSave === false ? `<p class="ai-k-err down">${esc(aiErrorText('no_secret'))}</p>` : ''}
    <p class="muted tool-note">${esc(t('mkey.cryptoNote'))}</p>
    <p class="muted tool-note">${esc(t('mkey.secureNote'))}</p>
    <p class="muted tool-note">${esc(t('mkey.howGet'))}</p>`;

  const notOwner = (st) => (st.state === 'no_server' ? `<p class="ai-k-err down">${esc(t('aiKey.line.noServer'))}</p>`
    : st.signinConfigured === false ? `<p class="ai-k-err down">${esc(t('aiKey.line.noSignin'))}</p>`
      : auth.current()?.provider === 'local' ? `<p class="muted">${esc(t('aiKey.line.localAccount'))}</p>`
        : `<p class="muted">${esc(t('mkey.ownerOnly'))}</p>`);

  function render(st, checking = false) {
    $('[data-mk-pill]').innerHTML = statePill(checking ? 'checking' : st.state);
    $('[data-mk-body]').innerHTML = st.owner ? form(st) : notOwner(st);
    if (!st.owner) return;
    if (busy) panel.querySelectorAll('button').forEach((b) => { b.disabled = true; });
    $('[data-mk-save]').addEventListener('click', () => {
      const key = $('[data-mk-key]').value.trim();   // read before run() re-renders the form
      run(async () => {
        if (!key) return { kind: 'down', text: aiErrorText('key_missing') };
        const r = await saveMarketKey(key);
        return r.ok ? { kind: 'up', text: t('mkey.saved') } : { kind: 'down', text: t('aiKey.notSaved', { why: aiErrorText(r.code) }) };
      });
    });
    $('[data-mk-test]').addEventListener('click', () => run(async () => { const r = await testMarketKey(); return r.ok ? { kind: 'up', text: t('aiKey.testOk') } : { kind: 'down', text: aiErrorText(r.code) }; }));
    $('[data-mk-del]').addEventListener('click', () => {
      if (!window.confirm(t('mkey.deleteAsk'))) return;
      run(async () => { await deleteMarketKey(); return { kind: 'muted', text: t('mkey.deleted') }; });
    });
  }

  async function run(fn) {
    if (busy) return; busy = true; note = null;
    const st0 = lastMarketKey() || {};
    render(st0, true);
    try { note = await fn(); } catch (e) { note = { kind: 'down', text: aiErrorText(e?.code || 'unknown') }; }
    finally {
      busy = false; render(lastMarketKey() || st0);
      if (note?.kind === 'up') toast(note.text, 'success');
    }
  }
  const off = onMarketKey((st) => { if (!busy && panel.isConnected) render(st); else if (!panel.isConnected) off(); });
  marketKeyStatus();
}
