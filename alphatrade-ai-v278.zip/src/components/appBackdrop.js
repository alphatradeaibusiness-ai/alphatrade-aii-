// Moving background for the signed-in app — the same family as the login page (drifting aurora
// light, a flowing grid, light running along waves, rising sparks), toned down so the charts and
// numbers stay easy to read. Transform/opacity only; stops under reduced motion.
export function appBackdrop() {
  const sparks = Array.from({ length: 8 }, (_, i) => {
    const x = (i * 41 + 7) % 97;
    const y = (i * 59 + 13) % 95;
    return `<i style="--x:${x}%;--y:${y}%;--d:${((i * 0.81) % 7).toFixed(2)}s;--s:${2 + (i % 2)}px;--t:${7 + (i % 4) * 1.5}s"></i>`;
  }).join('');
  return `<div class="app-fx" aria-hidden="true">
    <i class="fx-blob fx-b1"></i><i class="fx-blob fx-b2"></i>
    <svg class="app-waves" viewBox="0 0 1440 900" preserveAspectRatio="none">
      <defs><linearGradient id="awv" x1="0" x2="1"><stop offset="0" class="lg-a0" stop-opacity="0"/><stop offset=".5" class="lg-a2"/><stop offset="1" class="lg-a0" stop-opacity="0"/></linearGradient></defs>
      <g><path d="M-40 260 C 260 180, 520 340, 760 270 S 1220 170, 1480 250" stroke="url(#awv)" stroke-width="1.4" fill="none"/>
         <path d="M-40 282 C 280 205, 540 360, 780 292 S 1240 195, 1480 272" stroke="url(#awv)" stroke-width=".8" fill="none" opacity=".6"/></g>
      <g><path d="M-40 720 C 300 650, 600 800, 900 730 S 1300 660, 1480 710" stroke="url(#awv)" stroke-width="1.2" fill="none"/></g>
      <path class="w-run" d="M-40 260 C 260 180, 520 340, 760 270 S 1220 170, 1480 250" pathLength="100"/>
      <path class="w-run w-run2" d="M-40 720 C 300 650, 600 800, 900 730 S 1300 660, 1480 710" pathLength="100"/>
    </svg>
    <div class="auth-sparks">${sparks}</div>
  </div>`;
}
