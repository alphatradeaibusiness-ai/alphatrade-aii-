// The site's single AI setting (owner only): provider, models, the key, "Save & activate", re-check and delete.
// Everything goes to the server (services/ai/gateway.js): the key is stored there encrypted, tied to the owner's
// verified account, and is never sent back — only its last 4 characters. "Connected" is shown only after the server
// made a real successful request with the key.
import { esc } from '../utils/dom.js';
import { t } from '../i18n/index.js';
import { icons } from './icons.js';
import { toast } from './ui.js';
import { aiStatus, saveAiConfig, testAiConfig, deleteAiConfig, onAiStatus, lastAiStatus } from '../services/ai/gateway.js';
import { auth } from '../services/auth/index.js';

/** Pill for one of: none · checking · connected · failed · unchecked · no_server · unknown */
export function statePill(state) {
  const cls = state === 'connected' ? 'badge-live' : state === 'checking' || state === 'unchecked' ? 'badge-warn' : state === 'failed' || state === 'no_server' ? 'badge-error' : 'badge-muted';
  return `<span class="badge ${cls}" data-ai-state="${esc(state)}">${state === 'checking' ? '<span class="spinner"></span> ' : ''}${esc(t(`aiKey.state.${state}`))}</span>`;
}
export const aiErrorText = (code) => t(`aiErr.${code}`) || t('aiErr.unknown');

function lineHtml(st) {
  if (!st) return statePill('checking');
  const local = auth.current()?.provider === 'local';
  let note;
  if (st.state === 'no_server') note = t('aiKey.line.noServer');
  else if (st.state === 'none') note = t(st.owner ? 'aiKey.line.ownerAdd' : 'aiKey.line.none');
  else if (st.state === 'failed') note = st.owner ? aiErrorText(st.error) : t('aiKey.line.failed');
  else if (st.signinConfigured === false) note = t('aiKey.line.noSignin');
  else if (local) note = t('aiKey.line.localAccount');
  else note = t(st.vision ? 'aiKey.line.ok' : 'aiKey.line.okNoVision');
  return `${statePill(st.state)}<span class="muted">${esc(note)}</span>${st.owner ? `<a class="btn btn-sm btn-ghost" href="#/app/ai-key">${icons.lock}<span>${esc(t('aiKey.manage'))}</span></a>` : ''}`;
}
function fillLines(st) { document.querySelectorAll('[data-ai-line]').forEach((el) => { el.innerHTML = lineHtml(st); }); }
onAiStatus(fillLines);

/* ───────── the owner panel ───────── */
export function aiKeyCardHtml() {
  return `<article class="card tool-card fade-in ai-key-card" data-ai-panel>
    <div class="tool-head"><h2 class="card-title">${icons.lock}<span>${esc(t('aiKey.title'))}</span></h2><span data-k-pill>${statePill('checking')}</span></div>
    <div data-k-body><p class="muted">${esc(t('aiKey.loading'))}</p></div>
  </article>`;
}

export function bindAiKeyCard(root) {
  const panel = root.querySelector('[data-ai-panel]');
  const $ = (s) => panel.querySelector(s);
  let busy = false; let note = null;   // note = { kind: 'ok'|'err', text }

  const form = (st) => `
    <p class="ai-k-meta">${st.source === 'site' ? esc(t('aiKey.meta', { k: st.last4 || '—', p: t(`aiKey.prov.${st.provider}`), m: st.model || '—', e: st.boundTo || '—' })) : st.source === 'env' ? esc(t('aiKey.metaEnv', { k: st.last4 || '—' })) : esc(t('aiKey.noKey'))}</p>
    ${st.state === 'connected' ? `<p class="ai-k-vision ${st.vision ? 'up' : 'warn'}">${esc(st.vision ? t('aiKey.visionOk') : t('aiKey.visionNo', { why: aiErrorText(st.visionError || 'vision_unsupported') }))}</p>` : ''}
    ${st.state === 'failed' && st.error ? `<p class="ai-k-err down">${esc(aiErrorText(st.error))}</p>` : ''}
    <div class="tf-grid">
      <label class="tf-field"><span>${esc(t('aiKey.provider'))}</span><select class="select" data-k-prov>
        <option value="anthropic" ${st.provider !== 'openai' ? 'selected' : ''}>${esc(t('aiKey.prov.anthropic'))}</option>
        <option value="openai" ${st.provider === 'openai' ? 'selected' : ''}>${esc(t('aiKey.prov.openai'))}</option></select></label>
      <label class="tf-field tf-wide"><span>${esc(t('aiKey.key'))}</span><input class="input mono" type="password" data-k-key dir="ltr" autocomplete="new-password" spellcheck="false" placeholder="${esc(st.source === 'site' ? t('aiKey.keyKeep', { k: st.last4 }) : t('aiKey.keyPh'))}"/></label>
    </div>
    <details class="ai-k-adv" ${st.provider === 'openai' ? 'open' : ''}><summary>${esc(t('aiKey.advanced'))}</summary>
      <div class="tf-grid">
        <label class="tf-field" data-k-oa><span>${esc(t('aiKey.baseUrl'))}</span><input class="input mono" data-k-base dir="ltr" value="${esc(st.baseUrl || '')}" placeholder="https://api.openai.com/v1"/></label>
        <label class="tf-field"><span>${esc(t('aiKey.model'))}</span><input class="input mono" data-k-model dir="ltr" value="${esc(st.model || '')}" placeholder="${esc(t('aiKey.modelPh'))}"/></label>
        <label class="tf-field" data-k-oa><span>${esc(t('aiKey.visionModel'))}</span><input class="input mono" data-k-vmodel dir="ltr" value="${esc(st.visionModel || '')}" placeholder="${esc(t('aiKey.visionModelPh'))}"/></label>
      </div>
      <p class="muted tool-note">${esc(t('aiKey.advNote'))}</p>
    </details>
    <div class="tool-actions">
      <button type="button" class="btn btn-sm btn-primary" data-k-save>${icons.check}<span>${esc(t('aiKey.save'))}</span></button>
      <button type="button" class="btn btn-sm" data-k-test ${st.source === 'none' ? 'disabled' : ''}>${icons.refresh}<span>${esc(t('aiKey.retest'))}</span></button>
      <button type="button" class="btn btn-sm btn-ghost" data-k-del ${st.source === 'site' ? '' : 'hidden'}>${icons.trash}<span>${esc(t('aiKey.delete'))}</span></button>
    </div>
    <p class="ai-k-note ${note ? note.kind : ''}" data-k-note aria-live="polite">${note ? esc(note.text) : ''}</p>
    ${st.canSave === false ? `<p class="ai-k-err down">${esc(aiErrorText('no_secret'))}</p>` : ''}
    <p class="muted tool-note">${esc(t('aiKey.secureNote'))}</p>`;

  const notOwner = (st) => {
    if (st.state === 'no_server') return `<p class="ai-k-err down">${esc(t('aiKey.line.noServer'))}</p><p class="muted tool-note">${esc(t('aiKey.needServer'))}</p>`;
    if (st.signinConfigured === false) return `<p class="ai-k-err down">${esc(t('aiKey.line.noSignin'))}</p><p class="muted tool-note">${esc(t('aiKey.needSignin'))}</p>`;
    if (auth.current()?.provider === 'local') return `<p class="muted">${esc(t('aiKey.line.localAccount'))}</p>`;
    return `<p class="muted">${esc(t('aiKey.ownerOnly'))}</p>`;
  };

  function render(st, checking = false) {
    $('[data-k-pill]').innerHTML = statePill(checking ? 'checking' : st.state);
    $('[data-k-body]').innerHTML = st.owner ? form(st) : notOwner(st);
    if (!st.owner) return;
    const syncProv = () => panel.querySelectorAll('[data-k-oa]').forEach((x) => { x.hidden = $('[data-k-prov]').value !== 'openai'; });
    $('[data-k-prov]').addEventListener('change', () => { syncProv(); if ($('[data-k-prov]').value === 'openai') panel.querySelector('.ai-k-adv').open = true; });
    syncProv();
    if (busy) panel.querySelectorAll('button').forEach((b) => { b.disabled = true; });
    $('[data-k-save]').addEventListener('click', () => {
      // read the form BEFORE run() re-renders it (the re-render shows the "checking" state and clears the inputs)
      const cfg = { provider: $('[data-k-prov]').value, apiKey: $('[data-k-key]').value.trim(), baseUrl: $('[data-k-base]').value.trim(), model: $('[data-k-model]').value.trim(), visionModel: $('[data-k-vmodel]').value.trim() };
      run(async () => {
        const r = await saveAiConfig(cfg);
        return r.ok ? { kind: 'up', text: t('aiKey.saved') } : { kind: 'down', text: t('aiKey.notSaved', { why: aiErrorText(r.code) }) };
      });
    });
    $('[data-k-test]').addEventListener('click', () => run(async () => {
      const r = await testAiConfig();
      return r.ok ? { kind: 'up', text: t('aiKey.testOk') } : { kind: 'down', text: aiErrorText(r.code) };
    }));
    $('[data-k-del]').addEventListener('click', () => {
      if (!window.confirm(t('aiKey.deleteAsk'))) return;
      run(async () => { await deleteAiConfig(); return { kind: 'muted', text: t('aiKey.deleted') }; });
    });
  }

  async function run(fn) {
    if (busy) return; busy = true; note = null;
    const st0 = lastAiStatus() || {};
    render(st0, true);
    try { note = await fn(); }
    catch (e) { note = { kind: 'down', text: aiErrorText(e?.code || 'unknown') }; }
    finally {
      busy = false;
      const st = lastAiStatus() || st0;
      render(st);
      if (note?.kind === 'up') toast(note.text, 'success');
    }
  }

  const off = onAiStatus((st) => { if (!busy && panel.isConnected) render(st); else if (!panel.isConnected) off(); });
  aiStatus();
}
