// "Analysis Hub" card at the top of the chart's side column: one reading that combines chart trend,
// higher timeframes, momentum, RSI, volatility, SMC structure and news risk (services/synthesis.js).
// It explains; it does not tell anyone to buy or sell. News comes from the economic calendar (refreshed every 10 minutes).
import { h, esc } from '../utils/dom.js';
import { t } from '../i18n/index.js';
import { icons } from './icons.js';
import { getCalendar } from '../services/news.js';
import { htfCandles } from '../services/htfData.js';
import { synthesize, newsRisk } from '../services/synthesis.js';
import { explainAnalysis } from '../services/ai/client.js';
import { aiErrorText } from './aiKeyCard.js';
import { getLang } from '../i18n/index.js';

/** The real numbers on screen, for the AI to explain (it gets nothing else: no live data of its own). */
export function explainContext(an, candles, s) {
  const last = candles?.length > 1 ? candles[candles.length - 2] : null;
  const tr = an.strategyTrades || [];
  const decided = tr.filter((x) => x.outcome !== 'open');
  const r = (v) => (Number.isFinite(v) ? Number(v.toFixed(an.precision ?? 2)) : null);
  return {
    symbol: an.symbol, timeframe: an.tf, mode: an.mode, lastClosedPrice: r(last?.close), lastClosedTime: last ? new Date(last.time * 1000).toISOString() : null,
    strategy: an.strategy,
    plan: an.plan ? { direction: an.plan.direction, status: an.plan.status, entry: r(an.plan.entry), stop: r(an.plan.stop), targets: (an.plan.targets || []).map(r), targetsHit: an.plan.hits || 0 } : null,
    confirmation: an.gate ? { verdict: an.gate.verdict || (an.gate.rejected ? 'no-trade' : null), blockers: an.gate.blockers || [], agreeingFamilies: an.gate.agree ?? null, evidenceScore: an.gate.score ?? null, families: (an.gate.groups || []).map((g) => ({ family: g.key, side: g.side })) } : null,
    combinedReading: { stance: s.stance, confidence: s.confidence, reasons: s.reasons, factors: s.factors.map((f) => ({ factor: f.key, side: f.side, ...f.params })) },
    backtestOnLoadedCandles: tr.length ? { trades: decided.length, reachedTarget1: decided.filter((x) => (x.hits || 0) >= 1).length, netR: Number(decided.reduce((a, x) => a + (x.r || 0), 0).toFixed(2)), note: 'past test on the candles loaded in the chart, not a prediction' } : null,
  };
}

let calendar = { events: null, at: 0, pending: null };
async function loadCalendar() {
  if (calendar.pending) return calendar.pending;
  calendar.pending = getCalendar().then((r) => { calendar = { events: r.events || [], at: Date.now(), pending: null }; })
    .catch(() => { calendar = { events: null, at: Date.now(), pending: null }; });   // null = unknown (not "no news")
  return calendar.pending;
}

/** Strict-confirmation box: CONFIRMED (families that agree) or NO TRADE (the reasons). */
function confirmHtml(an) {
  const g = an?.gate; const shown = an?.plan || an?.proposal;
  if (g?.verdict === 'trade' && shown) {
    const rows = g.groups.map((x) => `<li class="${x.side === 'for' ? 'up' : x.side === 'against' ? 'down' : 'muted'}"><i aria-hidden="true">${x.side === 'for' ? '✓' : x.side === 'against' ? '✕' : '•'}</i><span>${esc(t(`cnf.g.${x.key}`))} — ${esc(t(`cnf.side.${x.side}`))}</span></li>`).join('');
    return `<div class="cnf-head"><span class="badge badge-live">${esc(t('cnf.trade'))}</span><small class="muted">${esc(t('cnf.score', { s: g.score, a: g.agree }))}${g.levels.rr != null ? ` · ${esc(t('cnf.rr', { r: g.levels.rr }))}` : ''}</small></div><ul class="syn-list">${rows}</ul><p class="side-foot">${esc(t('cnf.note'))}</p>`;
  }
  if (shown) return '';
  if (g?.rejected) {
    const why = [...g.blockers.filter((b) => b !== 'levels').map((b) => t(`cnf.b.${b}`)), ...(g.levels?.issues || []).map((k) => t(`cnf.lv.${k}`))];
    return `<div class="cnf-head"><span class="badge badge-error">${esc(t('cnf.noTrade'))}</span></div><p class="side-foot">${esc(why.join(' · '))}</p><p class="side-foot">${esc(t('cnf.note'))}</p>`;
  }
  return `<div class="cnf-head"><span class="badge badge-muted">${esc(t('cnf.noTrade'))}</span></div><p class="side-foot">${esc(t('cnf.idle'))}</p>`;
}

const sideCls = (s) => (s === 'bull' ? 'up' : s === 'bear' ? 'down' : s === 'risk' ? 'warn' : 'muted');
const sideIcon = (s) => (s === 'bull' ? '▲' : s === 'bear' ? '▼' : s === 'risk' ? '!' : '•');

export function createSynthesisCard() {
  const el = h(`<section class="card side-card syn-card fade-in" style="animation-delay:200ms" aria-live="polite">
    <div class="side-head"><h3 class="card-title">${icons.sparkle || ''}<span>${esc(t('syn.title'))}</span></h3><span data-syn-stance></span></div>
    <div class="syn-news" data-syn-news hidden></div>
    <div class="cnf-box" data-cnf></div>
    <ul class="syn-list" data-syn-list></ul>
    <p class="side-foot" data-syn-foot></p>
    <div class="syn-ai"><button type="button" class="btn btn-sm" data-syn-explain>${icons.sparkle || ''}<span>${esc(t('syn.explain'))}</span></button><div class="syn-ai-out" data-syn-ai aria-live="polite"></div></div>
  </section>`);
  const $ = (s) => el.querySelector(s);
  let lastHtml = ''; let last = null;

  const render = () => {
    if (!last) return;
    const { an, candles } = last;
    const news = calendar.events ? newsRisk(an.symbol, calendar.events) : null;
    const s = synthesize(an, candles, htfCandles(an.symbol), news);
    const stance = `<span class="badge ${s.stance === 'long' ? 'badge-live' : s.stance === 'short' ? 'badge-error' : 'badge-muted'}">${esc(t(`syn.stance.${s.stance}`))}</span>${s.stance !== 'wait' ? ` <small class="muted">${esc(t(`syn.conf.${s.confidence}`))}</small>` : ''}`;
    const items = s.factors.map((f) => `<li class="${sideCls(f.side)}"><i aria-hidden="true">${sideIcon(f.side)}</i><span>${esc(t(`syn.f.${f.key}`, { ...f.params, h4: t(`syn.side.${f.params.h4 || '-'}`), d1: t(`syn.side.${f.params.d1 || '-'}`), zone: f.params.zone ? t(`syn.zone.${f.params.zone}`) : '', state: f.params.state ? t(`syn.vol.${f.params.state}`) : '' }))}</span></li>`).join('');
    const why = s.reasons.map((r) => t(`syn.r.${r}`)).join(' · ');
    const newsHtml = news && news.level !== 'none'
      ? `${icons.alert || ''}<span>${esc(t(news.level === 'high' ? 'syn.newsHigh' : 'syn.newsSoon', { title: news.event.title, m: Math.abs(news.minutes), when: t(news.minutes >= 0 ? 'syn.in' : 'syn.ago', { m: Math.abs(news.minutes) }) }))}</span>`
      : '';
    const cnf = confirmHtml(an);
    const html = `${stance}|${newsHtml}|${items}|${why}|${cnf}`;
    if (html === lastHtml) return;
    lastHtml = html;
    $('[data-syn-stance]').innerHTML = stance;
    const nb = $('[data-syn-news]'); nb.hidden = !newsHtml; nb.className = `syn-news ${news?.level === 'high' ? 'is-high' : 'is-soon'}`; nb.innerHTML = newsHtml;
    $('[data-cnf]').innerHTML = cnf;
    $('[data-syn-list]').innerHTML = items;
    $('[data-syn-foot]').textContent = `${why ? `${why}. ` : ''}${t('syn.note')}`;
  };

  el.querySelector('[data-syn-explain]').addEventListener('click', async (e) => {
    if (!last) return;
    const btn = e.currentTarget; const out = el.querySelector('[data-syn-ai]');
    const { an, candles } = last;
    const news = calendar.events ? newsRisk(an.symbol, calendar.events) : null;
    const s = synthesize(an, candles, htfCandles(an.symbol), news);
    btn.disabled = true; out.className = 'syn-ai-out muted'; out.textContent = t('syn.explaining');
    try {
      const text = await explainAnalysis(explainContext(an, candles, s), getLang());
      out.className = 'syn-ai-out'; out.textContent = text;
      out.insertAdjacentHTML('beforeend', `<small class="muted">${esc(t('syn.explainNote'))}</small>`);
    } catch (err) {
      out.className = 'syn-ai-out down'; out.textContent = err?.code && /^[a-z_]+$/.test(err.code) ? aiErrorText(err.code) : String(err?.message || err);
    } finally { btn.disabled = false; }
  });

  return {
    el,
    update(an, dataset) {
      if (!an || !dataset?.candles?.length) return;
      last = { an, candles: dataset.candles };
      if (!calendar.events && !calendar.pending && Date.now() - calendar.at > 60_000) loadCalendar().then(render);
      else if (Date.now() - calendar.at > 10 * 60_000) loadCalendar().then(render);
      render();
    },
  };
}
