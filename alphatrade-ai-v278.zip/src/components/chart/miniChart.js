// Small live candle chart used by the radar screens (multi-screen view, support/resistance).
import { createChart, CandlestickSeries, LineSeries, LineStyle } from 'lightweight-charts';
import { fmtNum } from '../../utils/dom.js';

export function createMiniChart(el, { precision = 2, compact = false } = {}) {
  const dark = () => document.documentElement.dataset.theme !== 'light';
  const fmt = (v) => (Number.isFinite(v) ? fmtNum(v, precision) : '');   // cached formatter (called per axis label, per frame)
  const options = () => {
    const grid = dark() ? 'rgba(148, 130, 255, 0.05)' : 'rgba(91, 33, 182, 0.06)';
    const border = dark() ? 'rgba(148,130,255,.14)' : 'rgba(91,33,182,.14)';
    return {
      autoSize: true,
      layout: { background: { type: 'solid', color: 'transparent' }, textColor: dark() ? '#9b98b5' : '#5b5775', fontSize: compact ? 10 : 11, attributionLogo: true },
      grid: { vertLines: { color: grid }, horzLines: { color: grid } },
      rightPriceScale: { borderColor: border, scaleMargins: { top: 0.1, bottom: 0.08 } },
      timeScale: { borderColor: border, timeVisible: true, secondsVisible: false, rightOffset: 6, barSpacing: compact ? 5 : 6 },
      crosshair: { vertLine: { color: 'rgba(167,139,250,.5)', labelBackgroundColor: '#5b21b6' }, horzLine: { color: 'rgba(167,139,250,.5)', labelBackgroundColor: '#5b21b6' } },
      localization: { locale: 'en-US', priceFormatter: fmt },
      handleScroll: { mouseWheel: true, pressedMouseMove: true, horzTouchDrag: true, vertTouchDrag: false },
      handleScale: { mouseWheel: true, pinch: true, axisPressedMouseMove: true },
    };
  };
  const chart = createChart(el, options());
  const candles = chart.addSeries(CandlestickSeries, { upColor: '#22c55e', downColor: '#f0444f', borderVisible: false, wickUpColor: '#22c55e', wickDownColor: '#f0444f', priceLineColor: '#a855f7', priceLineStyle: LineStyle.Dotted });
  const emaLine = chart.addSeries(LineSeries, { color: 'rgba(245, 158, 11, .8)', lineWidth: 1, priceLineVisible: false, lastValueVisible: false, crosshairMarkerVisible: false });
  let lines = [];
  let lastTime = null;

  return {
    chart,
    setPrecision(p) { precision = p; chart.applyOptions({ localization: { locale: 'en-US', priceFormatter: fmt } }); },
    setData(list, emaValues = null) {
      candles.setData(list.map((c) => ({ time: c.time, open: c.open, high: c.high, low: c.low, close: c.close })));
      emaLine.setData(emaValues ? list.map((c, i) => (emaValues[i] != null ? { time: c.time, value: emaValues[i] } : { time: c.time })) : []);
      lastTime = list.at(-1)?.time ?? null;
    },
    update(c) {
      if (lastTime != null && c.time < lastTime) return;
      candles.update({ time: c.time, open: c.open, high: c.high, low: c.low, close: c.close });
      lastTime = c.time;
    },
    /** Horizontal lines: [{ price, color, title, width, style }] */
    setLines(list) {
      lines.forEach((l) => candles.removePriceLine(l));
      lines = list.map((l) => candles.createPriceLine({ price: l.price, color: l.color, lineWidth: l.width || 1, lineStyle: l.style ?? LineStyle.Dashed, axisLabelVisible: l.axis !== false, title: l.title || '' }));
    },
    fit() { chart.timeScale().fitContent(); },
    showLast(n) { const len = candles.data().length; if (len) chart.timeScale().setVisibleLogicalRange({ from: Math.max(0, len - n), to: len + 4 }); },
    theme() { chart.applyOptions(options()); },
    destroy() { try { chart.remove(); } catch { /* already gone */ } },
  };
}
