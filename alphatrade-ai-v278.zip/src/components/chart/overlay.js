import { cssVar } from '../../utils/cssVars.js';
// Canvas overlay drawn inside the Lightweight Charts price pane via the series-primitive API:
// sell/buy zones, Fibonacci levels, plan lines (entry / stop / targets), Volume Profile,
// Fixed Range Volume Profile, and user drawings.

const C = {
  sell: 'rgba(240, 68, 79, 0.10)', sellBorder: 'rgba(240, 68, 79, 0.45)', sellText: '#ff6b75',
  buy: 'rgba(34, 197, 94, 0.09)', buyBorder: 'rgba(34, 197, 94, 0.45)', buyText: '#4ade80',
  vp: 'rgba(124, 92, 246, 0.42)', vpVa: 'rgba(139, 92, 246, 0.72)', poc: '#e9d5ff',
  frvpBuy: 'rgba(56, 189, 248, 0.55)', frvpSell: 'rgba(56, 189, 248, 0.28)', frvpEdge: 'rgba(56, 189, 248, 0.6)',
  entry: '#e5e7eb', stop: '#f0444f', tp: '#22c55e', draw: '#c4b5fd', measureUp: 'rgba(34,197,94,.18)', measureDown: 'rgba(240,68,79,.18)',
};
// Accent colours follow the selected site palette (CSS variables on <html>).
export function syncAccent() {
  const v = (n) => cssVar(n);   // cached per theme (v230)
  const a0 = v('--a0-rgb'); const a1 = v('--a1-rgb');
  if (!a1) return;
  C.vp = `rgba(${a0}, 0.42)`; C.vpVa = `rgba(${a1}, 0.72)`; C.poc = v('--a-tint') || C.poc; C.draw = v('--a-tint2') || C.draw;
}
const FIB_COLORS = { 0: '#e5e7eb', 0.236: '#d6c6a0', 0.382: '#f59e0b', 0.5: '#94a3b8', 0.618: '#3b82f6', 0.786: '#2dd4bf', 1: '#e5e7eb' };

export class ChartOverlay {
  constructor() {
    this.state = { smc: null, zones: null, fib: null, plan: null, vp: null, frvp: null, drawings: [], preview: null, labels: {}, fmt: (v) => String(v), rtl: false, vpWidthPct: 22, font: 'Inter, sans-serif', showPlan: true, clean: true, showZones: true, showFib: true, showPoc: true };
    this._geom = null;
    const self = this;
    this._bgView = { zOrder: () => 'bottom', renderer: () => ({ draw: (target) => self._drawBackground(target) }) };
    this._fgView = { zOrder: () => 'top', renderer: () => ({ draw: (target) => self._drawForeground(target) }) };
  }

  attached({ chart, series, requestUpdate }) { this.chart = chart; this.series = series; this.requestUpdate = requestUpdate; }
  detached() { this.chart = null; this.series = null; }
  set(patch) { Object.assign(this.state, patch); this.requestUpdate?.(); }

  /** Map a unix time to a (fractional) logical index, extrapolating past the data edges. */
  timeToLogical(time) {
    const cs = this.state.candles;
    if (!cs || !cs.length || time == null) return null;
    const step = cs.length > 1 ? cs[1].time - cs[0].time : 60;
    if (time <= cs[0].time) return (time - cs[0].time) / step;
    if (time >= cs[cs.length - 1].time) return cs.length - 1 + (time - cs[cs.length - 1].time) / step;
    let lo = 0;
    let hi = cs.length - 1;
    while (hi - lo > 1) { const m = (lo + hi) >> 1; if (cs[m].time <= time) lo = m; else hi = m; }
    return lo + (time - cs[lo].time) / (cs[hi].time - cs[lo].time);
  }
  x(time) {
    const l = this.timeToLogical(time);
    return l == null ? null : this.chart.timeScale().logicalToCoordinate(l);
  }
  y(price) { return this.series.priceToCoordinate(price); }

  updateAllViews() {}

  /** Include entry, stop and targets in the price-scale range so every plan line stays on the chart. */
  autoscaleInfo() {
    const p = this.state.plan;
    const prices = [];
    if (p && this.state.showPlan) prices.push(...(p.proposal ? [p.entry, p.stop, p.targets[0]] : [p.entry, p.stop, ...p.targets]));
    const ap = this.state.assist?.plan;   // the SMC / ICT assistant's plan: entry, stop and the first target stay in view
    if (ap) prices.push(ap.entry, ap.stop, ap.targets[0]);
    if (!prices.length) return null;
    return { priceRange: { minValue: Math.min(...prices), maxValue: Math.max(...prices) } };
  }
  paneViews() { return [this._bgView, this._fgView]; }

  priceAxisViews() {
    const s = this.state;
    if (!this.series || !s.plan || !s.showPlan) return [];
    const mk = (price, color, text = '#fff') => ({
      coordinate: () => this.y(price) ?? -100, text: () => s.fmt(price), textColor: () => text, backColor: () => color, visible: () => true, tickVisible: () => true,
    });
    // Entry equals the last price (already labelled by the series); targets are boxed in the pane.
    return [mk(s.plan.stop, C.stop)];
  }

  /* ───────── drawing helpers ───────── */
  _font(ctx, size = 11, weight = 500) { ctx.font = `${weight} ${size}px ${this.state.font}`; }
  /** EDH: yesterday's high (buy trigger) and low (sell trigger), drawn across the chart from the start of today. */
  _drawEdh(ctx, e, W, H) {
    const x0 = Math.max(0, this.x(e.dayStart) ?? 0);
    const placed = [];
    const lab = (text, x, y, col) => { // keeps labels from sitting on top of each other
      this._font(ctx, 9.5, 800);
      const w = ctx.measureText(text).width + 10;
      for (let k = 0; k < 5; k++) {
        const r = { x, y: y + k * 15, w, h: 14 };
        if (r.y < 0 || r.y + r.h > H) continue;
        if (placed.some((q) => r.x < q.x + q.w + 2 && r.x + r.w + 2 > q.x && r.y < q.y + q.h + 1 && r.y + r.h + 1 > q.y)) continue;
        placed.push(r); this._label(ctx, text, r.x, r.y, { bg: 'rgba(10,9,22,.72)', color: col, h: 14, padX: 5, radius: 3 }); return;
      }
    };
    const one = (price, col, tag) => {
      const y = this.y(price);
      if (y == null || y < 0 || y > H) return;
      ctx.strokeStyle = col; ctx.globalAlpha = 0.85; ctx.lineWidth = 1.2; ctx.setLineDash([6, 4]);
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke(); ctx.setLineDash([]); ctx.globalAlpha = 1;
      ctx.direction = 'ltr'; ctx.textAlign = 'left';
      lab(tag, Math.max(6, x0 + 6), tag.startsWith('PDH') ? y - 17 : y + 3, col);
    };
    // Order blocks (same boxes as SMC) and liquidity-sweep zones (swing price -> the wick that took it).
    if (e.obs?.length) this._drawSmcLines(ctx, { obs: e.obs, fvgs: [], events: [], swings: [], range: null, bsl: [], ssl: [] }, W, H);
    for (const z of e.sweeps || []) {
      const xa = this.x(z.time); const y1 = this.y(z.price); const y2 = this.y(z.extreme);
      if (xa == null || y1 == null || y2 == null) continue;
      const left = Math.max(0, xa); const top = Math.min(y1, y2); const hh = Math.max(2, Math.abs(y2 - y1));
      if (top > H || top + hh < 0) continue;
      const col = z.dir === 'sell' ? '#ff6b75' : '#4ade80';
      ctx.fillStyle = z.dir === 'sell' ? 'rgba(240,68,79,.16)' : 'rgba(34,197,94,.16)';
      const xb = this.x(z.sweepTime) ?? W;
      ctx.fillRect(left, top, Math.max(4, xb - left), hh);
      ctx.strokeStyle = col; ctx.globalAlpha = 0.8; ctx.lineWidth = 1; ctx.setLineDash([2, 3]);
      ctx.beginPath(); ctx.moveTo(left, y1); ctx.lineTo(W, y1); ctx.stroke(); ctx.setLineDash([]); ctx.globalAlpha = 1;
      ctx.direction = 'ltr'; ctx.textAlign = 'left';
      lab(z.dir === 'sell' ? 'SWEEP ▼' : 'SWEEP ▲', Math.min(W - 70, Math.max(6, (this.x(z.sweepTime) ?? left) + 4)), z.dir === 'sell' ? y2 - 15 : y2 + 2, col);
    }
    one(e.high, '#4ade80', 'PDH · EDH ▲');
    one(e.low, '#ff6b75', 'PDL · EDH ▼');
  }

  _label(ctx, text, x, y, { bg, border, color = '#fff', align = 'left', padX = 7, h = 20, radius = 4 }) {
    ctx.direction = this.state.rtl ? 'rtl' : 'ltr';
    const w = ctx.measureText(text).width + padX * 2;
    const left = align === 'right' ? x - w : align === 'center' ? x - w / 2 : x;
    ctx.beginPath();
    ctx.roundRect(left, y - h / 2, w, h, radius);
    if (bg) { ctx.fillStyle = bg; ctx.fill(); }
    if (border) { ctx.strokeStyle = border; ctx.lineWidth = 1; ctx.stroke(); }
    ctx.fillStyle = color;
    ctx.textBaseline = 'middle';
    ctx.textAlign = 'center';
    ctx.fillText(text, left + w / 2, y + 0.5);
    return w;
  }

  _drawBackground(target) {
    // Tags are rebuilt on every frame: the background pass runs first, so nothing from an earlier frame (or an earlier strategy)
    // can stay painted at a fixed screen position while the chart moves.
    this._smcTags = [];
    if (!this.chart || !this.series || !this.state.candles?.length) return;
    target.useMediaCoordinateSpace(({ context: ctx, mediaSize }) => {
      const s = this.state;
      const W = mediaSize.width;
      const H = mediaSize.height;
      ctx.save();
      // Zones
      if (s.showZones && s.zones) {
        for (const kind of ['sell', 'buy']) {
          const z = s.zones[kind];
          if (!z) continue;
          const x0 = Math.max(0, this.x(z.fromTime) ?? 0);
          const yTop = this.y(z.top);
          const yBot = this.y(z.bottom);
          if (yTop == null || yBot == null || x0 > W) continue;
          const x1 = W - (s.vp ? (W * s.vpWidthPct) / 100 + 6 : 4);
          if (x1 <= x0) continue;
          ctx.save(); if (s.clean) ctx.globalAlpha = 0.6;
          ctx.fillStyle = C[kind];
          ctx.fillRect(x0, yTop, x1 - x0, yBot - yTop);
          ctx.strokeStyle = C[`${kind}Border`];
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.moveTo(x0, kind === 'sell' ? yBot : yTop);
          ctx.lineTo(x1, kind === 'sell' ? yBot : yTop);
          ctx.stroke();
          ctx.restore();
          // Small tag in the zone's corner (inside the zone, away from candles' busy middle).
          const nz = W < 480;
          this._font(ctx, nz ? 9 : 10.5, 600);
          const ly = Math.max(yTop, 0) + (nz ? 9 : 12); // top-left corner, clear of the 0 / 1 Fibonacci labels' rows below
          if (!(s.clean && s.plan) && ly > 6 && ly < H - 6) this._label(ctx, s.labels[kind] || kind, x0 + 6, ly, { bg: 'rgba(10,9,22,.72)', color: C[`${kind}Text`], h: nz ? 13 : 18, padX: nz ? 4 : 6 });
        }
      }
      // Strong zones: a Fibonacci line with other levels at the same price (see services/fibSignals.js)
      if (s.showFib && s.fibSig?.strong?.length) {
        const x0 = Math.max(0, this.x(s.fib?.fromTime) ?? 0);
        const x1 = W - (s.vp ? (W * s.vpWidthPct) / 100 + 6 : 4);
        for (const z of s.fibSig.strong) {
          const yT = this.y(z.top); const yB = this.y(z.bottom);
          if (yT == null || yB == null || x1 <= x0) continue;
          const up = z.side === 'support';
          const h = Math.max(6, yB - yT);
          ctx.fillStyle = up ? 'rgba(250,204,21,.13)' : 'rgba(251,146,60,.13)';
          ctx.fillRect(x0, yT, x1 - x0, h);
          ctx.strokeStyle = up ? 'rgba(250,204,21,.65)' : 'rgba(251,146,60,.65)';
          ctx.lineWidth = 1; ctx.setLineDash([5, 4]);
          ctx.strokeRect(x0 + 0.5, yT + 0.5, x1 - x0 - 1, h - 1);
          ctx.setLineDash([]);
        }
      }
      if (s.smc) this._drawSmcBoxes(ctx, s.smc, W, H);
      if (s.assist) this._drawAssistZones(ctx, s.assist, W, H);
      // Volume Profile (anchored to the right edge, beside the price axis)
      if (s.vp) {
        const vp = s.vp;
        const maxW = (W * s.vpWidthPct) / 100;
        for (let i = 0; i < vp.bins.length; i++) {
          const b = vp.bins[i];
          const yt = this.y(b.high);
          const yb = this.y(b.low);
          if (yt == null || yb == null || yb < 0 || yt > H) continue;
          const w = vp.maxVolume > 0 ? (b.volume / vp.maxVolume) * maxW : 0;
          const inVa = i >= vp.vaFrom && i <= vp.vaTo;
          const grad = ctx.createLinearGradient(W - w, 0, W, 0);
          const k = s.clean ? 0.65 : 1;
          grad.addColorStop(0, inVa ? `rgba(139,92,246,${0.22 * k})` : `rgba(124,92,246,${0.08 * k})`);
          grad.addColorStop(1, inVa ? `rgba(139,92,246,${0.55 * k})` : `rgba(124,92,246,${0.3 * k})`);
          ctx.fillStyle = grad;
          ctx.fillRect(W - w, yt + 0.5, w, Math.max(1, yb - yt - 1));
        }
        if (s.showPoc) {
          const yp = this.y(vp.poc);
          if (yp != null) {
            ctx.strokeStyle = C.poc; ctx.lineWidth = 1; ctx.setLineDash([2, 3]);
            ctx.beginPath(); ctx.moveTo(W - maxW - 8, yp); ctx.lineTo(W, yp); ctx.stroke(); ctx.setLineDash([]);
            this._font(ctx, 9.5, 700); ctx.fillStyle = C.poc; ctx.textAlign = 'right'; ctx.textBaseline = 'bottom'; ctx.direction = 'ltr';
            ctx.fillText('POC', W - maxW - 10, yp - 2);
          }
        }
      }
      // Fixed Range Volume Profile
      if (s.frvp && s.frvp.profile) {
        const p = s.frvp.profile;
        const xa = this.x(p.fromTime);
        const xb = this.x(p.toTime);
        if (xa != null && xb != null) {
          const left = Math.min(xa, xb);
          const right = Math.max(xa, xb);
          const maxW = Math.max(30, (right - left) * 0.9);
          ctx.fillStyle = 'rgba(56,189,248,.05)';
          ctx.fillRect(left, 0, right - left, H);
          ctx.strokeStyle = C.frvpEdge; ctx.setLineDash([4, 4]); ctx.lineWidth = 1;
          ctx.beginPath(); ctx.moveTo(left, 0); ctx.lineTo(left, H); ctx.moveTo(right, 0); ctx.lineTo(right, H); ctx.stroke(); ctx.setLineDash([]);
          for (const b of p.bins) {
            const yt = this.y(b.high);
            const yb = this.y(b.low);
            if (yt == null || yb == null) continue;
            const wb = p.maxVolume > 0 ? (b.buy / p.maxVolume) * maxW : 0;
            const ws = p.maxVolume > 0 ? (b.sell / p.maxVolume) * maxW : 0;
            const hh = Math.max(1, yb - yt - 1);
            ctx.fillStyle = C.frvpBuy; ctx.fillRect(left, yt + 0.5, wb, hh);
            ctx.fillStyle = C.frvpSell; ctx.fillRect(left + wb, yt + 0.5, ws, hh);
          }
          const yp = this.y(p.poc);
          if (yp != null) {
            ctx.strokeStyle = '#7dd3fc'; ctx.beginPath(); ctx.moveTo(left, yp); ctx.lineTo(right, yp); ctx.stroke();
            this._font(ctx, 9.5, 700); ctx.fillStyle = '#7dd3fc'; ctx.textAlign = 'left'; ctx.textBaseline = 'bottom'; ctx.direction = 'ltr';
            ctx.fillText(`FRVP POC ${s.fmt(p.poc)}`, left + 4, yp - 2);
          }
        }
      }
      ctx.restore();
    });
  }

  _drawForeground(target) {
    if (!this.chart || !this.series || !this.state.candles?.length) return;
    target.useMediaCoordinateSpace(({ context: ctx, mediaSize }) => {
      const s = this.state;
      const W = mediaSize.width;
      ctx.save();
      // Fibonacci
      if (s.showFib && s.fib) {
        const x0 = Math.max(0, this.x(s.fib.fromTime) ?? 0);
        const nar = W < 480; // phone: lighter lines, ratio-only tags
        const fibOn = x0 < W - 30;   // panned so the Fibonacci starts off the right edge: draw nothing (no labels floating without their lines)
        for (const lv of s.fib.levels) {
          const y = this.y(lv.price);
          if (y == null || !fibOn) continue;
          let col = FIB_COLORS[lv.ratio] || '#d6c6a0';
          if (document.documentElement.dataset.theme === 'light' && (lv.ratio === 0 || lv.ratio === 1)) col = '#475569';
          ctx.strokeStyle = col; ctx.globalAlpha = s.clean ? (nar ? 0.4 : 0.55) : (nar ? 0.55 : 0.85); ctx.lineWidth = 1;
          ctx.beginPath(); ctx.moveTo(x0, y); ctx.lineTo(W, y); ctx.stroke();
          ctx.globalAlpha = 1;
          this._font(ctx, nar ? 8.5 : 10, 600);
          const rt = lv.ratio === 0 || lv.ratio === 1 ? lv.ratio : lv.ratio.toFixed(3);
          const txt = nar ? `${rt}` : `${rt}  ${s.fmt(lv.price)}`;
          let tx = Math.min(x0 + 4, W - (nar ? 60 : 150));
          // Keep labels clear of the HTML legend in the top-left corner.
          if (s.avoid && y - 18 < s.avoid.h && tx < s.avoid.w) tx = s.avoid.w + 8;
          const saveRtl = s.rtl; s.rtl = false;
          this._label(ctx, txt, tx, y - 9, { bg: nar ? 'rgba(10,9,22,.45)' : 'rgba(10,9,22,.7)', color: col, h: nar ? 12 : 15, padX: nar ? 3 : 5, radius: 3 });
          s.rtl = saveRtl;
        }
      }
      // Strong-zone tags and break labels on the Fibonacci lines (tags first, break labels step aside)
      if (s.showFib && s.fibSig) {
        const xMax = W - (s.vp ? (W * s.vpWidthPct) / 100 + 6 : 4);
        const taken = [];
        const nar2 = W < 480;
        const hit = (x, y, w, h) => taken.some((r) => x < r.x + r.w + 3 && x + w + 3 > r.x && y - h / 2 < r.y + r.h / 2 + 2 && y + h / 2 + 2 > r.y - r.h / 2);
        this._font(ctx, nar2 ? 9 : 10.5, 700);
        const tags = (s.fibSig.strong || []).slice(0, nar2 || s.clean ? 1 : 2).map((z) => ({ z, y: this.y(z.price) })).filter((t2) => t2.y != null)
          .map((t2) => ({ ...t2, y: t2.y + 14 })).sort((p, q) => p.y - q.y);
        tags.forEach((tg, k) => { if (k && tg.y - tags[k - 1].y < 20) tg.y = tags[k - 1].y + 20; });
        for (const { z, y } of tags) {
          const txt = nar2 ? `★ ×${z.strength}` : `★ ${s.labels.fibStrong} ×${z.strength} · ${z.kinds.slice(0, 2).map((k) => s.labels.fibKind?.(k) ?? k).join(' + ')}`;
          const w = ctx.measureText(txt).width + 12;
          const x = Math.max(4, xMax - w - 2);
          this._label(ctx, txt, x, y, { bg: 'rgba(10,9,22,.82)', border: z.side === 'support' ? 'rgba(250,204,21,.8)' : 'rgba(251,146,60,.8)', color: z.side === 'support' ? '#fde047' : '#fdba74', h: nar2 ? 13 : 17, padX: nar2 ? 4 : 6, radius: 4 });
          taken.push({ x, y, w, h: 17 });
        }
        const brk = nar2 || s.clean ? [...(s.fibSig.breaks || [])].sort((a, b) => b.index - a.index).slice(0, 1) : (s.fibSig.breaks || []);
        if (nar2) this._font(ctx, 9.5, 700);
        for (const b of brk) {
          const yl = this.y(b.price); const bx = this.x(b.time); if (yl == null || bx == null) continue;
          if (bx < 0 || bx > xMax) continue;   // its candle is scrolled out of view: the label must not stick to the edge
          const sell = b.dir === 'sell';
          const text = `${sell ? '▼' : '▲'} ${sell ? s.labels.fibSell : s.labels.fibBuy}${b.live && !nar2 ? ` · ${s.labels.fibLive}` : ''}`;
          const col = sell ? '#ff6b75' : '#4ade80';
          const w = ctx.measureText(text).width + 12;
          const y = sell ? yl + 12 : yl - 12; // sell: under the line · buy: above the line
          let x = Math.min(Math.max(4, bx - w / 2), xMax - w);
          if (hit(x, y, w, 17)) { const alt = [x - w - 6, x + w + 6, x - 2 * w - 12].find((c2) => c2 >= 4 && c2 + w <= xMax && !hit(c2, y, w, 17)); if (alt == null) continue; x = alt; }
          ctx.globalAlpha = b.htfAgrees === false || b.live ? 0.75 : 1;
          this._label(ctx, text, x, y, { bg: sell ? 'rgba(127,29,29,.9)' : 'rgba(22,101,52,.9)', border: col, color: '#fff', h: nar2 ? 14 : 17, padX: nar2 ? 5 : 6, radius: 4 });
          if (b.live) { ctx.setLineDash([3, 3]); ctx.strokeStyle = col; ctx.strokeRect(x + 0.5, y - 8, w - 1, 16); ctx.setLineDash([]); }
          ctx.globalAlpha = 1;
          taken.push({ x, y, w, h: 17 });
        }
      }
      if (s.smc) this._drawSmcLines(ctx, s.smc, W, mediaSize.height);
      if (s.sessions?.length) this._drawSessions(ctx, s.sessions, W, mediaSize.height);
      if (s.edh) this._drawEdh(ctx, s.edh, W, mediaSize.height);
      if (s.assist) this._drawAssistLines(ctx, s.assist, W, mediaSize.height);
      // Plan lines with boxed labels (entry, stop, targets). Labels are de-overlapped:
      // with a 30-point stop the lines can sit only a few pixels apart.
      if (!(s.showPlan && s.plan)) this._labelRects = [];
      if (s.showPlan && s.plan) {
        const p = s.plan;
        const H = mediaSize.height;
        const narrow = W < 420;
        const n = s.candles.length;
        // Lines cover only the most recent bars, so the history stays readable.
        const recent = this.chart.timeScale().logicalToCoordinate(Math.max(0, n - (narrow ? 12 : 24))) ?? 0;
        const opened = p.openedTime != null ? this.x(p.openedTime) : null;
        // Lines start at the bar where the trade was opened (at most ~24 bars back, so history stays readable).
        const lineFrom = Math.max(0, opened != null ? Math.max(opened, recent) : recent);
        const planVisible = lineFrom < W - 40;   // false while the user looks at older candles: no plan labels over unrelated history
        const short = (txt) => txt;
        const items = [
          { price: p.entry, color: C.entry, dash: [5, 4], text: `${p.proposal ? (p.direction === 'long' ? '▲ ' : '▼ ') : ''}${s.labels.entry}${p.proposal && !narrow ? ` (${s.labels.proposal})` : ''} ${s.fmt(p.entry)}`, box: { bg: 'rgba(229,231,235,.95)', color: '#0b0a16' } },
          { price: p.stop, color: C.stop, dash: [4, 4], text: `${p.hits > 0 && p.stop === p.entry && s.labels.be ? s.labels.be : (s.labels.stopShort || s.labels.stop)} ${s.fmt(p.stop)}`, box: { bg: 'rgba(185,28,28,.92)' } },
          ...p.targets.map((v, i) => ({ price: v, color: C.tp, dash: [], text: short(`${i < (p.hits || 0) ? '✓ ' : ''}TP${i + 1} ${s.fmt(v)}${p.proposal && p.probs?.[i] != null ? ` · ${Math.round(p.probs[i] * 100)}%` : ''}`), box: { bg: 'rgba(21,128,61,.92)' } })),
        ].map((it) => ({ ...it, y: this.y(it.price) })).filter((it) => it.y != null && planVisible);
        // Position-tool look: a soft red box from entry to stop and a soft green box from entry to the last target.
        {
          const yE = this.y(p.entry), yS = this.y(p.stop), yT = this.y(p.targets[p.targets.length - 1]);
          const x0 = lineFrom, x1 = W - 3;
          ctx.save(); ctx.globalAlpha = p.proposal ? 0.7 : 1;
          if (planVisible && yE != null && yS != null) { ctx.fillStyle = s.clean ? 'rgba(239,68,68,.07)' : 'rgba(239,68,68,.10)'; ctx.fillRect(x0, Math.min(yE, yS), x1 - x0, Math.abs(yS - yE)); }
          if (planVisible && yE != null && yT != null) { ctx.fillStyle = s.clean ? 'rgba(34,197,94,.06)' : 'rgba(34,197,94,.09)'; ctx.fillRect(x0, Math.min(yE, yT), x1 - x0, Math.abs(yT - yE)); }
          ctx.restore();
        }
        ctx.lineWidth = 1;
        ctx.globalAlpha = p.proposal && !p.edge ? 0.7 : 0.9;
        for (const it of items) {
          ctx.strokeStyle = it.color; ctx.setLineDash(it.dash);
          ctx.beginPath(); ctx.moveTo(lineFrom, it.y); ctx.lineTo(W, it.y); ctx.stroke();
        }
        ctx.setLineDash([]);
        ctx.globalAlpha = 1;
        const h = narrow ? 15 : 17;
        const GAP = h + 2;
        const top = h / 2 + 2 + (s.avoidR?.h || 0);   // below the AI badge in the top-right corner
        const bottom = H - h / 2 - 2;
        // Labels sit on their own line. Only lines that are close together are nudged apart (GAP), and a line that is
        // outside the visible pane is pinned to the edge on its own, so it never drags the other labels away from their lines.
        const all = [...items].sort((a, b) => a.y - b.y);
        const above = all.filter((it) => it.y < top), below = all.filter((it) => it.y > bottom);
        const sorted = all.filter((it) => it.y >= top && it.y <= bottom);
        sorted.forEach((it) => { it.ly = it.y; });
        for (let i = 1; i < sorted.length; i++) sorted[i].ly = Math.max(sorted[i].ly, sorted[i - 1].ly + GAP);           // push down
        const lim = below.length ? bottom - below.length * GAP : bottom;
        for (let i = sorted.length - 1; i >= 0; i--) { const cap = i === sorted.length - 1 ? lim : sorted[i + 1].ly - GAP; if (sorted[i].ly > cap) sorted[i].ly = cap; } // pull back up
        above.forEach((it, k) => { it.ly = top + k * GAP; it.pinned = true; });
        below.forEach((it, k) => { it.ly = bottom - (below.length - 1 - k) * GAP; it.pinned = true; });
        sorted.push(...above, ...below);
        this._labelRects = [];
        this._font(ctx, narrow ? 9.5 : 10.5, 700);
        const xR = W - 3;
        for (const it of sorted) {
          ctx.direction = 'ltr';
          const w = ctx.measureText(it.text).width + (narrow ? 8 : 10);
          if (!it.pinned && Math.abs(it.ly - it.y) > 1) {
            // right-angle leader (never a slanted line): along the label's own height, then into the label
            ctx.strokeStyle = it.color; ctx.globalAlpha = 0.7; ctx.lineWidth = 1; ctx.setLineDash([]);
            ctx.beginPath(); ctx.moveTo(xR - w - 8, it.y); ctx.lineTo(xR - w - 8, it.ly); ctx.lineTo(xR - w - 1, it.ly); ctx.stroke();
            ctx.globalAlpha = 1;
          }
          const saveRtl = s.rtl; s.rtl = false;
          this._label(ctx, it.text, xR, it.ly, { align: 'right', h, padX: narrow ? 4 : 5, radius: 3, color: '#fff', ...it.box });
          s.rtl = saveRtl;
          this._labelRects.push({ text: it.text, price: it.price, x: xR - w, y: it.ly - h / 2, w, h, W, H });
        }
      }
      // User drawings
      for (const d of [...s.drawings, ...(s.preview ? [s.preview] : [])]) this._drawDrawing(ctx, d, W, d === s.preview);
      ctx.restore();
    });
  }

  /* ───────── SMC / ICT assistant ─────────
     Zones (background): every order block / fair value gap the assistant read, the chosen POI outlined, the OTE band and the
     dealing-range 50% line. Lines (foreground): liquidity levels with their names, the sweep, and the plan (entry / stop /
     targets with R:R). The assistant's tags sit at the LEFT end of their lines so they never cover the strategy plan's tags
     on the right edge. */
  _drawAssistZones(ctx, a, W, H) {
    const z = a.zones; if (!z) return;
    const right = W - 4;
    const box = (o, fill, stroke, dash = []) => {
      const x0 = Math.max(0, this.x(o.time) ?? 0); const y1 = this.y(o.top); const y2 = this.y(o.bottom);
      if (y1 == null || y2 == null || x0 >= right) return null;
      const top = Math.min(y1, y2); const hh = Math.max(2, Math.abs(y2 - y1));
      if (top > H || top + hh < 0) return null;
      ctx.fillStyle = fill; ctx.fillRect(x0, top, right - x0, hh);
      if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = 1; ctx.setLineDash(dash); ctx.strokeRect(x0 + 0.5, top + 0.5, right - x0 - 1, hh - 1); ctx.setLineDash([]); }
      return { x0, top, hh };
    };
    if (z.ote) {
      const t0 = z.range?.fromTime ?? z.poi?.time;
      box({ ...z.ote, time: t0 }, 'rgba(250,204,21,.06)', 'rgba(250,204,21,.35)', [2, 4]);
    }
    for (const g of z.fvgs || []) {
      const r = box(g, g.dir === 'bull' ? 'rgba(56,189,248,.09)' : 'rgba(244,114,182,.09)', null);
      if (r) { const ym = this.y((g.top + g.bottom) / 2); if (ym != null) { ctx.strokeStyle = g.dir === 'bull' ? 'rgba(56,189,248,.5)' : 'rgba(244,114,182,.5)'; ctx.setLineDash([3, 3]); ctx.beginPath(); ctx.moveTo(r.x0, ym); ctx.lineTo(right, ym); ctx.stroke(); ctx.setLineDash([]); } }
    }
    for (const o of z.obs || []) box(o, o.dir === 'bull' ? 'rgba(34,197,94,.10)' : 'rgba(240,68,79,.10)', o.dir === 'bull' ? 'rgba(34,197,94,.45)' : 'rgba(240,68,79,.45)');
    // Breaker blocks (failed order blocks, flipped) and inverse FVGs: dashed borders so they read as "flipped" zones.
    for (const o of z.breakers || []) box({ ...o, time: o.flipTime ?? o.time }, o.dir === 'bull' ? 'rgba(34,197,94,.07)' : 'rgba(240,68,79,.07)', 'rgba(251,146,60,.7)', [4, 3]);
    for (const g of z.ifvgs || []) box({ ...g, time: g.flipTime ?? g.time }, g.dir === 'bull' ? 'rgba(56,189,248,.06)' : 'rgba(244,114,182,.06)', 'rgba(251,146,60,.55)', [2, 3]);
    if (z.poi) box(z.poi, 'rgba(196,181,253,.10)', 'rgba(196,181,253,.95)', [6, 3]);
    if (z.range) {
      const y = this.y(z.range.eq); const x0 = Math.max(0, this.x(z.range.fromTime) ?? 0);
      if (y != null && y > 0 && y < H && x0 < right) { ctx.strokeStyle = 'rgba(196,181,253,.6)'; ctx.setLineDash([8, 5]); ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(x0, y); ctx.lineTo(right, y); ctx.stroke(); ctx.setLineDash([]); }
    }
  }
  _drawAssistLines(ctx, a, W, H) {
    const z = a.zones || {}; const fmt = this.state.fmt; const L = a.labels || {};
    const right = W - 4; const placed = [];
    const tag = (text, x, y, color, bg = 'rgba(10,9,22,.8)') => {
      this._font(ctx, 9.5, 700);
      const w = ctx.measureText(text).width + 10;
      let ty = y;
      for (let k = 0; k < 6; k++) {
        const r = { x: Math.min(Math.max(2, x), right - w - 60), y: ty, w, h: 15 };
        if (!placed.some((q) => r.x < q.x + q.w + 2 && r.x + r.w + 2 > q.x && Math.abs(r.y - q.y) < 15)) {
          placed.push(r);
          const saveRtl = this.state.rtl; this.state.rtl = false;
          this._label(ctx, text, r.x, r.y, { bg, border: color, color, h: 15, padX: 5, radius: 3 });
          this.state.rtl = saveRtl; return;
        }
        ty += k % 2 ? -16 * (k + 1) : 16 * (k + 1);
      }
    };
    const hline = (price, from, color, dash, text, bg) => {
      const y = this.y(price); if (y == null || y < -2 || y > H + 2) return;
      const x0 = Math.max(0, this.x(from) ?? 0); if (x0 >= right) return;
      ctx.strokeStyle = color; ctx.lineWidth = 1; ctx.setLineDash(dash); ctx.globalAlpha = 0.9;
      ctx.beginPath(); ctx.moveTo(x0, y); ctx.lineTo(right, y); ctx.stroke(); ctx.setLineDash([]); ctx.globalAlpha = 1;
      if (text) tag(text, x0 + 4, y, color, bg);
    };
    for (const l of z.liquidity || []) hline(l.price, l.time, 'rgba(251,191,36,.75)', [2, 3], `${l.kind} ${fmt(l.price)}`);
    for (const o of z.obs || []) { const y = this.y(o.dir === 'bull' ? o.top : o.bottom); const x = this.x(o.time); if (y != null && x != null && x < right && y > 0 && y < H) tag(`${o.withFvg ? 'OB+FVG' : 'OB'}${o.mitigated ? ' ·m' : ''}`, x + 2, o.dir === 'bull' ? y + 9 : y - 9, o.dir === 'bull' ? '#4ade80' : '#ff6b75'); }
    for (const g of z.fvgs || []) { const y = this.y(g.top); const x = this.x(g.time); if (y != null && x != null && x < right && y > 0 && y < H) tag('FVG', x + 2, y - 9, g.dir === 'bull' ? '#7dd3fc' : '#f9a8d4'); }
    if (z.range) { const y = this.y(z.range.eq); const x = this.x(z.range.fromTime); if (y != null && x != null) tag(`EQ 50% ${fmt(z.range.eq)}`, Math.max(2, x) + 4, y - 9, '#c4b5fd'); }
    for (const o of z.breakers || []) { const y = this.y(o.dir === 'bull' ? o.top : o.bottom); const x = this.x(o.flipTime ?? o.time); if (y != null && x != null && x < right && y > 0 && y < H) tag('BB', x + 2, o.dir === 'bull' ? y + 9 : y - 9, '#fb923c'); }
    for (const g of z.ifvgs || []) { const y = this.y(g.top); const x = this.x(g.flipTime ?? g.time); if (y != null && x != null && x < right && y > 0 && y < H) tag('IFVG', x + 2, y - 9, '#fb923c'); }
    if (z.nyOpen) hline(z.nyOpen.price, z.nyOpen.time, 'rgba(148,163,184,.8)', [1, 3], `NY 00:00 ${fmt(z.nyOpen.price)}`);
    if (z.sweep) {
      const x = this.x(z.sweep.time); const y = this.y(z.sweep.extreme);
      if (x != null && y != null && x > 0 && x < right && y > 0 && y < H) {
        const col = z.sweep.dir === 'bull' ? '#4ade80' : '#ff6b75';
        ctx.strokeStyle = col; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.moveTo(x - 4, y - 4); ctx.lineTo(x + 4, y + 4); ctx.moveTo(x + 4, y - 4); ctx.lineTo(x - 4, y + 4); ctx.stroke();
        tag(`${L.sweep || 'SWEEP'} ${z.sweep.dir === 'bull' ? '▲' : '▼'}`, x + 6, z.sweep.dir === 'bull' ? y + 12 : y - 12, col);
      }
    }
    if (z.mss) { const y = this.y(z.mss.level); const x = this.x(z.mss.time); if (y != null && x != null && x < right) tag(`MSS ${z.mss.kind}`, x + 4, z.mss.dir === 'bull' ? y - 10 : y + 10, '#c4b5fd'); }
    const p = a.plan; if (!p) return;
    // Plan lines cover only the recent candles (like the strategy plan), so the history stays readable.
    const cs = this.state.candles; const recentT = cs[Math.max(0, cs.length - (W < 480 ? 14 : 30))].time;
    const from = Math.max(p.poi?.time ?? p.createdAt, recentT);
    const mk = (r) => `${r}R`;
    hline(p.entry, from, '#e5e7eb', [6, 4], `${L.entry || 'ENTRY'} ${fmt(p.entry)} · ${p.execution === 'market' ? (L.market || 'MARKET') : (L.limit || 'LIMIT')}`, 'rgba(30,27,46,.92)');
    hline(p.stop, from, '#f0444f', [4, 4], `${L.stop || 'SL'} ${fmt(p.stop)} · -1R`, 'rgba(127,29,29,.9)');
    p.targets.forEach((tp, k) => hline(tp, from, '#22c55e', [], `TP${k + 1} ${fmt(tp)} · ${mk(p.rr[k])}${p.sources?.[k] && !/R$/.test(p.sources[k]) ? ` · ${p.sources[k]}` : ''}`, 'rgba(20,83,45,.9)'));
  }

  /* ───────── SMC ─────────
     Kept deliberately sparse: one order block, one FVG, the last break(s) and the nearest
     liquidity on each side. Tags are small and sit at the left of each object, away from the
     plan tags on the right edge. */
  _smcTag(ctx, text, x, y, color, W) {
    this._font(ctx, 9.5, 700);
    const saveRtl = this.state.rtl; this.state.rtl = false;
    const w = ctx.measureText(text).width + 10;
    this._label(ctx, text, Math.min(Math.max(2, x), W - w - 70), y, { bg: 'rgba(10,9,22,.78)', border: color, color, h: 15, padX: 5, radius: 3 });
    this.state.rtl = saveRtl;
  }

  _drawSmcBoxes(ctx, m, W, H) {
    const right = W - 4;
    this._smcTags = [];
    // Dealing range: premium (upper half) / discount (lower half) shading and the 50% line.
    if (m.range) {
      const x0 = Math.max(0, this.x(m.range.fromTime) ?? 0);
      const yH = this.y(m.range.high);
      const yE = this.y(m.range.eq);
      const yL = this.y(m.range.low);
      if (yH != null && yE != null && yL != null && x0 < right) {
        ctx.fillStyle = 'rgba(240,68,79,.045)'; ctx.fillRect(x0, yH, right - x0, yE - yH);
        ctx.fillStyle = 'rgba(34,197,94,.045)'; ctx.fillRect(x0, yE, right - x0, yL - yE);
        ctx.strokeStyle = 'rgba(196,181,253,.55)'; ctx.setLineDash([6, 4]); ctx.lineWidth = 1;
        ctx.beginPath(); ctx.moveTo(x0, yE); ctx.lineTo(right, yE); ctx.stroke(); ctx.setLineDash([]);
        this._smcTags.push(['EQ 50%', x0 + 4, Math.min(Math.max(yE, 9), H - 9), '#c4b5fd', 'small']);
      }
    }
    const box = (z, fill, stroke, tag, tagColor, dashed) => {
      const x0 = this.x(z.time);
      const yT = this.y(z.top);
      const yB = this.y(z.bottom);
      if (x0 == null || yT == null || yB == null || x0 > right) return;
      const left = Math.max(0, x0);
      const top = Math.min(yT, yB);
      const hgt = Math.max(2, Math.abs(yB - yT));
      if (top > H || top + hgt < 0) return;
      ctx.fillStyle = fill; ctx.fillRect(left, top, right - left, hgt);
      ctx.strokeStyle = stroke; ctx.lineWidth = 1;
      if (dashed) ctx.setLineDash([3, 3]);
      ctx.strokeRect(left + 0.5, top + 0.5, right - left - 1, hgt - 1);
      ctx.setLineDash([]);
      // Tags are drawn on the foreground layer (after the candles) so they stay readable.
      if (tag) this._smcTags.push([tag, left + 4, Math.min(Math.max(top + hgt / 2, 9), H - 9), tagColor]);
    };
    // Fair value gaps (open), newest strongest.
    (m.fvgs || []).forEach((g, k, arr) => {
      const bull = g.dir === 'bull';
      const a = 0.35 + 0.65 * ((k + 1) / arr.length);
      box(g, bull ? `rgba(56,189,248,${0.07 * a})` : `rgba(251,146,60,${0.07 * a})`, bull ? `rgba(56,189,248,${0.35 * a})` : `rgba(251,146,60,${0.35 * a})`, k === arr.length - 1 ? 'FVG' : '', bull ? '#7dd3fc' : '#fdba74');
    });
    // Order blocks still valid: newest first in the list; tags on the two newest only.
    [...(m.obs || [])].reverse().forEach((ob, k, arr) => {
      const bull = ob.dir === 'bull';
      const rank = arr.length - 1 - k; // 0 = newest
      const a = rank === 0 ? 1 : rank === 1 ? 0.7 : 0.45;
      const tag = rank < 2 ? `${bull ? 'Bull' : 'Bear'} OB${ob.mitigated ? ' ✓' : ''}` : '';
      box(ob, bull ? `rgba(34,197,94,${0.14 * a})` : `rgba(240,68,79,${0.14 * a})`, bull ? `rgba(34,197,94,${0.6 * a})` : `rgba(240,68,79,${0.6 * a})`, tag, bull ? '#4ade80' : '#ff6b75', ob.mitigated);
    });
  }

  /* Session liquidity: the last completed Asia / London / New York high and low, from the candle that made it to the right edge. */
  _drawSessions(ctx, list, W, H) {
    const COL = { ASIA: '#a78bfa', LONDON: '#38bdf8', NY: '#f472b6' };
    const narrow = W < 480;
    this._font(ctx, narrow ? 8.5 : 9, 700); ctx.direction = 'ltr'; ctx.textAlign = 'left';
    const used = [];
    for (const sx of list) {
      for (const [price, time, tag, above] of [[sx.high, sx.highTime, 'H', true], [sx.low, sx.lowTime, 'L', false]]) {
        const y = this.y(price); const x0 = this.x(time);
        if (y == null || x0 == null || y < 0 || y > H || x0 > W - 20) continue;   // off screen: nothing pinned to the edges
        const col = COL[sx.name] || '#cbd5e1';
        ctx.strokeStyle = col; ctx.globalAlpha = 0.6; ctx.lineWidth = 1; ctx.setLineDash([2, 4]);
        ctx.beginPath(); ctx.moveTo(Math.max(0, x0), y); ctx.lineTo(W, y); ctx.stroke(); ctx.setLineDash([]); ctx.globalAlpha = 1;
        const txt = `${sx.name} ${tag}`;
        const w = ctx.measureText(txt).width;
        const lx = Math.max(2, x0) + 16; const ty = above ? y - 12 : y + 2;   // clear of the swing label (HH / LL) on the same candle
        if (used.some((r) => Math.abs(r.y - ty) < 11 && lx < r.x + r.w + 4 && lx + w + 4 > r.x)) continue;
        used.push({ x: lx, y: ty, w });
        ctx.fillStyle = col; ctx.textBaseline = 'top'; ctx.fillText(txt, lx, ty);
      }
    }
  }

  _drawSmcLines(ctx, m, W, H) {
    const narrow = W < 480;
    // Simple label collision check: a label that would overlap one already drawn is skipped.
    const placed = [];
    const free = (x, y, w, h) => {
      const r = { x, y, w, h };
      if (placed.some((p) => r.x < p.x + p.w + 3 && r.x + r.w + 3 > p.x && r.y < p.y + p.h + 2 && r.y + r.h + 2 > p.y)) return false;
      placed.push(r);
      return true;
    };
    for (const [tag, x, y, col, small] of this._smcTags || []) {
      if (small) {
        this._font(ctx, 9, 700); ctx.direction = 'ltr'; ctx.textAlign = 'left'; ctx.textBaseline = 'bottom';
        const w = ctx.measureText(tag).width;
        if (free(x, y - 13, w, 11)) { ctx.fillStyle = col; ctx.fillText(tag, x, y - 2); }
      } else {
        this._font(ctx, 9.5, 700);
        const w = ctx.measureText(tag).width + 10;
        placed.push({ x: Math.min(Math.max(2, x), W - w - 70), y: y - 8, w, h: 15 });
        this._smcTag(ctx, tag, x, y, col, W);
      }
    }
    ctx.lineWidth = 1;
    // Structure breaks (most important labels first).
    (m.events || []).slice(narrow ? -3 : -5).forEach((ev, k, arr) => {
      const xa = this.x(ev.swingTime);
      const xb = this.x(ev.time);
      const y = this.y(ev.level);
      if (xa == null || xb == null || y == null || y < 0 || y > H) return;
      if (xb < 0 || xa > W) return;   // entirely outside the visible range
      const col = ev.dir === 'bull' ? '#4ade80' : '#ff6b75';
      ctx.strokeStyle = col; ctx.globalAlpha = k === arr.length - 1 ? 0.95 : 0.55; ctx.setLineDash([4, 3]);
      ctx.beginPath(); ctx.moveTo(Math.max(0, xa), y); ctx.lineTo(xb, y); ctx.stroke();
      ctx.setLineDash([]);
      const mid = (Math.max(0, xa) + Math.min(W, xb)) / 2;
      this._font(ctx, 9.5, 800); ctx.direction = 'ltr'; ctx.textAlign = 'center';
      const w = ctx.measureText(ev.kind).width;
      const ty = ev.dir === 'bull' ? y - 13 : y + 2;
      if (free(mid - w / 2, ty, w, 11)) { ctx.fillStyle = col; ctx.textBaseline = 'top'; ctx.fillText(ev.kind, mid, ty); }
      ctx.globalAlpha = 1;
    });
    // Liquidity pools.
    const liq = (lv, tag, col) => {
      if (!lv) return;
      const y = this.y(lv.price);
      const x0 = this.x(lv.time);
      if (y == null || x0 == null || y < 0 || y > H || x0 > W - 20) return;
      ctx.strokeStyle = col; ctx.globalAlpha = 0.65; ctx.setLineDash([1, 3]);
      ctx.beginPath(); ctx.moveTo(Math.max(0, x0), y); ctx.lineTo(W, y); ctx.stroke();
      ctx.setLineDash([]); ctx.globalAlpha = 1;
      this._font(ctx, 9, 700); ctx.direction = 'ltr'; ctx.textAlign = 'left';
      const txt = `${tag} $$`;
      const w = ctx.measureText(txt).width;
      const lx = Math.min(Math.max(2, x0) + Math.max(4, (W - Math.max(2, x0)) * 0.45), W - 120);
      const ty = tag === 'BSL' ? y - 13 : y + 2;
      if (free(lx, ty, w, 11)) { ctx.fillStyle = col; ctx.textBaseline = 'top'; ctx.fillText(txt, lx, ty); }
    };
    const list = (v) => (Array.isArray(v) ? v : v ? [v] : []);
    list(m.bsl).slice(0, narrow ? 1 : 2).forEach((lv) => liq(lv, 'BSL', '#fbbf24'));
    list(m.ssl).slice(0, narrow ? 1 : 2).forEach((lv) => liq(lv, 'SSL', '#fbbf24'));
    // Swing labels last (lowest priority): the most recent ones, skipped where crowded.
    this._font(ctx, 8.5, 800); ctx.direction = 'ltr'; ctx.textAlign = 'center';
    for (const sw of (m.swings || []).slice(narrow ? -3 : -10)) {
      const x = this.x(sw.time);
      const y = this.y(sw.price);
      if (x == null || y == null || x < 0 || x > W || y < 0 || y > H) continue;
      const w = ctx.measureText(sw.label).width;
      const ty = sw.type === 'high' ? y - 13 : y + 3;
      if (!free(x - w / 2, ty, w, 10)) continue;
      const good = sw.label === 'HH' || sw.label === 'HL';
      ctx.fillStyle = good ? 'rgba(74,222,128,.85)' : sw.label === 'H' || sw.label === 'L' ? 'rgba(203,213,225,.7)' : 'rgba(255,107,117,.85)';
      ctx.textBaseline = 'top';
      ctx.fillText(sw.label, x, ty);
    }
  }

  _drawDrawing(ctx, d, W, isPreview) {
    const s = this.state;
    ctx.globalAlpha = isPreview ? 0.7 : 1;
    if (d.type === 'hline') {
      const y = this.y(d.a.price);
      if (y == null) return;
      ctx.strokeStyle = C.draw; ctx.lineWidth = 1.2;
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke();
      this._font(ctx, 10.5, 600); ctx.fillStyle = C.draw; ctx.textAlign = 'left'; ctx.textBaseline = 'bottom'; ctx.direction = 'ltr';
      ctx.fillText(s.fmt(d.a.price), 6, y - 2);
    } else if (d.type === 'trend' || d.type === 'measure' || d.type === 'fibpick' || d.type === 'frvppick') {
      const xa = this.x(d.a.time); const ya = this.y(d.a.price);
      const xb = this.x(d.b.time); const yb = this.y(d.b.price);
      if ([xa, ya, xb, yb].some((v) => v == null)) return;
      if (d.type === 'measure') {
        const up = d.b.price >= d.a.price;
        ctx.fillStyle = up ? C.measureUp : C.measureDown;
        ctx.fillRect(Math.min(xa, xb), Math.min(ya, yb), Math.abs(xb - xa), Math.abs(yb - ya));
        const diff = d.b.price - d.a.price;
        const pct = (diff / d.a.price) * 100;
        const bars = Math.round(Math.abs(this.timeToLogical(d.b.time) - this.timeToLogical(d.a.time)));
        this._font(ctx, 11, 600);
        this._label(ctx, s.labels.measure(`${diff >= 0 ? '+' : ''}${s.fmt(diff)}`, `${pct >= 0 ? '+' : ''}${pct.toFixed(2)}%`, bars), (xa + xb) / 2, Math.min(ya, yb) - 14, { align: 'center', bg: up ? '#166534' : '#7f1d1d' });
        return;
      }
      if (d.type === 'frvppick') {
        ctx.strokeStyle = C.frvpEdge; ctx.setLineDash([4, 4]);
        ctx.beginPath(); ctx.moveTo(xa, 0); ctx.lineTo(xa, 4000); ctx.moveTo(xb, 0); ctx.lineTo(xb, 4000); ctx.stroke(); ctx.setLineDash([]);
        return;
      }
      ctx.strokeStyle = d.type === 'fibpick' ? '#f59e0b' : C.draw; ctx.lineWidth = 1.6;
      ctx.beginPath(); ctx.moveTo(xa, ya); ctx.lineTo(xb, yb); ctx.stroke();
      ctx.fillStyle = '#fff';
      for (const [x, y] of [[xa, ya], [xb, yb]]) { ctx.beginPath(); ctx.arc(x, y, 3, 0, Math.PI * 2); ctx.fill(); }
    } else if (d.type === 'text') {
      const x = this.x(d.a.time); const y = this.y(d.a.price);
      if (x == null || y == null) return;
      this._font(ctx, 12, 600);
      this._label(ctx, d.text, x, y, { bg: 'rgba(120,53,15,.88)', border: '#f59e0b', h: 22 });
    } else if (d.type === 'point') {
      const x = this.x(d.a.time); const y = this.y(d.a.price);
      if (x == null || y == null) return;
      ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(x, y, 3.5, 0, Math.PI * 2); ctx.fill();
    }
    ctx.globalAlpha = 1;
  }
}
