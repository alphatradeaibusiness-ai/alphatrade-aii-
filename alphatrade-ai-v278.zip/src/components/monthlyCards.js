// Pips (points) per calendar month for every strategy: one card per month, a bar per strategy, the strongest
// one crowned automatically. Used by the "Monthly pips" page.
import { fmtNum } from '../utils/dom.js';
import { getLang } from '../i18n/index.js';

export const KEYS = ['edh', 'lbr', 'classic', 'smc', 'zone'];   // active first; classic / smc / zone are retired (v173), shown for transparency
export const signPts = (v) => `${v > 0 ? '+' : v < 0 ? '−' : ''}${fmtNum(Math.abs(v), 1)}`;
export const monthName = (key) => {
  const [y, m] = key.split('-').map(Number);
  return new Date(Date.UTC(y, m - 1, 1)).toLocaleDateString(getLang() === 'ar' ? 'ar-EG-u-nu-latn' : 'en-GB', { month: 'long', year: 'numeric', timeZone: 'UTC' });
};

