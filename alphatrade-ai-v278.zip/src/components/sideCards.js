// Right column: momentum gauge, Fibonacci table, suggested trading plan.
import { h, esc, fmtNum } from '../utils/dom.js';
import { t, getLang } from '../i18n/index.js';
import { store } from '../state/store.js';
import { tweenNumber, replayClass } from '../utils/motion.js';
import { icons } from './icons.js';
import { DERIV_SYMBOLS, getDerivs, readDerivs, derivCheck } from '../services/derivatives.js';

const ARC_LEN = Math.PI * 80;

export function createSideCards({ onOpenSettings, onNewTrade } = {}) {
  const el = h(`<aside class="side-col">
    <section class="card side-card momentum-card fade-in" style="animation-delay:240ms">
      <div class="side-head"><h3 class="card-title">${esc(t('momentum.title'))}</h3><span class="m-live mono" data-m-live></span></div>
      <div class="gauge">
        <svg viewBox="0 0 200 112" aria-hidden="true">
          <defs><linearGradient id="gaugeGrad" x1="20" y1="0" x2="180" y2="0" gradientUnits="userSpaceOnUse">
            <stop offset="0" class="lg-a0"/><stop offset=".45" class="lg-a2"/><stop offset=".75" stop-color="#22c55e"/><stop offset="1" stop-color="#4ade80"/></linearGradient></defs>
          <path d="M20 100 A80 80 0 0 1 180 100" class="g-track"/>
          <path d="M20 100 A80 80 0 0 1 180 100" class="g-value" stroke="url(#gaugeGrad)" stroke-dasharray="${ARC_LEN}" stroke-dashoffset="${ARC_LEN}"/>
          <circle class="g-knob" r="5" cx="20" cy="100"/>
        </svg>
        <div class="g-text"><div class="g-label" data-g-label>—</div><div class="g-desc" data-g-desc></div></div>
      </div>
      <div class="strength">
        <div class="st-row"><span>${esc(t('momentum.buyers'))}</span><b class="up mono" data-buy-pct>—</b></div>
        <div class="bar"><span class="bar-fill buy" data-buy-bar></span></div>
        <div class="st-row"><span>${esc(t('momentum.sellers'))}</span><b class="down mono" data-sell-pct>—</b></div>
        <div class="bar"><span class="bar-fill sell" data-sell-bar></span></div>
      </div>
      <p class="side-foot" data-m-basis></p>
    </section>
    <section class="card side-card fade-in" style="animation-delay:300ms">
      <h3 class="card-title">${esc(t('fib.title'))}</h3>
      <div class="fib-verdict" data-fib-verdict hidden></div>
      <table class="kv-table fib-table"><tbody data-fib-rows></tbody></table>
      <p class="side-foot mono" data-fib-points></p>
    </section>
    <section class="card side-card plan-card fade-in" style="animation-delay:360ms">
      <div class="side-head"><h3 class="card-title" data-plan-title>${esc(t('plan.title'))}</h3><span data-plan-dir></span></div>
      <div class="smc2-box" data-smc2 hidden></div>
      <div class="smc2-box" data-zone-box hidden></div>
      <div class="smc-sum" data-smc-sum hidden></div>
      <p class="plan-status" data-plan-status></p>
      <table class="kv-table plan-table"><tbody data-plan-rows></tbody></table>
      <div class="dv-box" data-dv hidden></div>
      <button type="button" class="btn btn-sm plan-new" data-new-trade>${esc(t('plan.newTrade'))}</button>
      <button class="side-foot plan-rule" data-plan-rule title="${esc(t('settings.points'))}"></button>
      <p class="side-foot disclaimer">${esc(t('plan.disclaimer'))}</p>
    </section>
    <section class="card side-card ai-card fade-in" style="animation-delay:420ms" data-ai-card hidden>
      <div class="side-head"><h3 class="card-title">${icons.brain}<span>${esc(t('aie.title'))}</span></h3><span data-ai-grade></span><button type="button" class="ai-switch is-on" data-ai-switch role="switch" aria-checked="true" aria-label="${esc(t('aie.tip'))}"><i></i></button></div>
      <div data-ai-body></div>
    </section>
  </aside>`);
  el.querySelector('[data-ai-switch]').addEventListener('click', () => store.updateSettings('ai', { enabled: store.get('settings').ai?.enabled === false }));
  el.querySelector('[data-plan-rule]').addEventListener('click', () => onOpenSettings?.());
  el.querySelector('[data-new-trade]').addEventListener('click', () => onNewTrade?.());

  const q = (s) => el.querySelector(s);
  const q0 = (sel) => el.querySelector(sel);
  const PART_KEYS = ['htf', 'sweep', 'ob', 'confirm', 'session', 'volume'];
  const PART_MAX = { htf: 25, sweep: 20, ob: 15, confirm: 20, session: 10, volume: 10 };
  function renderSmc2(an, pl) {
    const x = an.smc2;
    const dirTxt = (v) => (v === 'bull' ? `<b class="up">▲ ${esc(t('smcv2.bull'))}</b>` : v === 'bear' ? `<b class="down">▼ ${esc(t('smcv2.bear'))}</b>` : `<span class="muted">${esc(t('smcv2.none'))}</span>`);
    const min = an.rules?.smcMinScore ?? 80;
    let html = '';
    if (x) {
      const zone = !x.zoneApplies ? `<span class="muted">${esc(t('smcv2.zoneNA'))}</span>` : x.zone ? `<b class="up">${esc(t(`smcv2.${x.zone}`))}</b>` : `<span class="down">${esc(t('smcv2.outside'))}</span>`;
      html += `<div class="s2-chips">${x.htfApplies ? `${x.needsH4 ? `<span>4h ${dirTxt(x.h4)}</span>` : ''}<span>Daily ${dirTxt(x.d1)}</span>` : `<span class="muted">${esc(t('smcv2.htfNA'))}</span>`}<span>${esc(t('smcv2.zone'))} ${zone}</span></div>`;
    }
    if (pl && pl.score != null) {
      const parts = pl.scoreParts || {}; const na = pl.scoreNa || {};
      html += `<div class="s2-score"><div class="s2-num"><b class="mono">${Math.round(pl.score)}</b><small>/100</small></div><div class="s2-bars">${PART_KEYS.map((k) => `<div class="s2-p${na[k] ? ' is-na' : ''}" title="${esc(t(`smcv2.parts.${k}`))}"><span>${esc(t(`smcv2.parts.${k}`))}</span><i><u style="width:${na[k] ? 0 : Math.round(((parts[k] || 0) / PART_MAX[k]) * 100)}%"></u></i><em class="mono">${na[k] ? '—' : Math.round(parts[k] || 0)}</em></div>`).join('')}</div></div>
        <p class="s2-note">${esc(t('smcv2.sweepType', { type: t(`smcv2.sweepTypes.${pl.sweepType}`) }))} · ${esc(t('smcv2.min', { n: min }))}</p>`;
    } else if (x) {
      html += `<div class="s2-stages">${['long', 'short'].map((d) => `<div><b class="${d === 'long' ? 'up' : 'down'}">${d === 'long' ? '▲' : '▼'}</b><span>${esc(t(`smcv2.stage.${x.stage[d]}`))}</span></div>`).join('')}</div>
        <p class="s2-note">${esc(t('smcv2.min', { n: min }))}${x.htfApplies && !x.d1 ? ` · ${esc(t('smcv2.loadingHtf'))}` : ''}</p>`;
    }
    return html;
  }
  const ZPARTS = ['zone', 'vp', 'fib', 'rsi'];
  const ZMAX = { zone: 30, vp: 25, fib: 25, rsi: 20, flow: 15, stat: 10 };
  function renderEdh(an, pl) {
    const e = an.edh; const E = an.rules?.edh || {}; const T = an.edhT || { t1: 30, t2: 75, sl: 30 }; const pip = (an.rules?.edhPipPts || 1) * (pl?.pointSize || an.rules?.pointSize || 1);
    const p = (v) => fmtNum(v, an.precision);
    if (!e) return `<p class="s2-note">${esc(t('ed.noLevels'))}</p>`;
    const px = an.last?.close;
    const state = px > e.high ? ['▲', t('ed.above'), 'up'] : px < e.low ? ['▼', t('ed.below'), 'down'] : ['•', t('ed.inside'), ''];
    const t1 = T.t1; const t2 = T.t2;
    const obs = (e.obs || []).slice(-2).map((o) => `<span class="${o.dir === 'bull' ? 'up' : 'down'}">${o.dir === 'bull' ? 'Bull' : 'Bear'} OB ${p(o.bottom)} – ${p(o.top)}</span>`).join(' · ');
    const sw = (e.sweeps || []).slice(-2).map((z) => `<span class="${z.dir === 'buy' ? 'up' : 'down'}">${z.dir === 'buy' ? '▲' : '▼'} ${p(z.price)}</span>`).join(' · ');
    return `<div class="s2-chips"><span>${esc(t('ed.high'))} <b class="mono up">${p(e.high)}</b></span><span>${esc(t('ed.low'))} <b class="mono down">${p(e.low)}</b></span><span>${esc(t('ed.price'))} <b class="${state[2]}">${state[0]} ${esc(state[1])}</b></span></div>
      <div class="s2-chips"><span>${esc(t('ed.trend', { h: e.trend?.hours || 0 }))} ${e.trend ? `<b class="${e.trend.side === 'long' ? 'up' : 'down'}">${e.trend.side === 'long' ? '▲' : '▼'} ${esc(t(e.trend.side === 'long' ? 'ed.longsOnly' : 'ed.shortsOnly'))}</b> <span class="mono">${p(e.trend.ema)}</span>` : `<b>${esc(t('ed.trendOff'))}</b>`}</span><span>T1 <b class="mono">${t1} pip</b> · ${p(t1 * pip)}</span><span>T2 <b class="mono">${t2} pip</b> · ${p(t2 * pip)}</span><span>SL <b class="mono">${T.sl} pip</b></span><span>${esc(t('ed.tfSet'))} <b>${an.tf === '1m' ? '1m' : '5m'}</b></span></div>
      <div class="s2-chips"><span>${esc(t('ed.sweeps'))}: ${sw || '—'}</span><span>${esc(t('ed.obs'))}: ${obs || '—'}</span></div>
      <p class="s2-note">${esc(t('ed.trigger'))}</p>`;
  }

  function renderZone(an, pl) {
    const x = an.zone;
    const p = (v) => fmtNum(v, an.precision);
    const min = an.rules?.zoneMinScore ?? 80;
    const dirTxt = (v) => (v === 1 ? `<b class="up">▲ ${esc(t('smcv2.bull'))}</b>` : v === -1 ? `<b class="down">▼ ${esc(t('smcv2.bear'))}</b>` : `<span class="muted">${esc(t('smcv2.none'))}</span>`);
    let html = '';
    if (x) {
      const zr = (z, cls) => (z ? `<b class="${cls}">${p(z.bottom)} – ${p(z.top)}</b>` : '<span class="muted">—</span>');
      html += `<div class="s2-chips"><span>${esc(t('zs.htf'))} ${dirTxt(x.htf)}</span><span>RSI <b class="mono">${x.rsi != null ? Math.round(x.rsi) : '—'}</b></span>${pl?.regime ? `<span>${esc(t('qn.regime'))} <b>${esc(t(`qn.reg.${pl.regime}`))}</b></span>` : ''}${pl?.zscore != null ? `<span>Z <b class="mono">${pl.zscore.toFixed(1)}</b></span>` : ''}</div>
        <div class="s2-chips"><span>${esc(t('zs.demand'))} ${zr(x.zones.demand, 'up')}</span><span>${esc(t('zs.supply'))} ${zr(x.zones.supply, 'down')}</span></div>`;
    }
    if (pl && pl.score != null) {
      const parts = pl.scoreParts || {}; const na = pl.scoreNa || {};
      html += `<div class="s2-score"><div class="s2-num"><b class="mono">${Math.round(pl.score)}</b><small>/100</small></div><div class="s2-bars">${ZPARTS.concat(['flow', 'stat']).filter((k) => parts[k] != null || na[k]).map((k) => `<div class="s2-p${na[k] ? ' is-na' : ''}" title="${esc(t(`zs.parts.${k}`))}"><span>${esc(t(`zs.parts.${k}`))}</span><i><u style="width:${na[k] ? 0 : Math.round(((parts[k] || 0) / ZMAX[k]) * 100)}%"></u></i><em class="mono">${na[k] ? '—' : Math.round(parts[k] || 0)}</em></div>`).join('')}</div></div>
        <p class="s2-note">${esc(t('zs.fibAt', { r: pl.fibRatio != null ? fmtNum(pl.fibRatio, 3) : '—' }))} · ${esc(t('smcv2.min', { n: min }))}</p>`;
    } else if (x) {
      html += `<div class="s2-stages">${['long', 'short'].map((d) => `<div><b class="${d === 'long' ? 'up' : 'down'}">${d === 'long' ? '▲' : '▼'}</b><span>${esc(t(`zs.stage.${x.stage[d]}`))}</span></div>`).join('')}</div>
        <p class="s2-note">${esc(t('smcv2.min', { n: min }))}</p>`;
    }
    return html;
  }
  // Position size (from the risk settings) and futures positioning (funding / open interest, live only).
  let dv = { symbol: null, at: 0, read: null }; let dvLast = null; let dvHtml = '';
  function renderExtras(an) {
    dvLast = an;
    const box = q('[data-dv]');
    const pl = an.plan;
    const parts = [];
    if (pl?.sizing) {
      const z = pl.sizing;
      const u = fmtNum(z.units, z.units >= 100 ? 0 : z.units >= 1 ? 2 : 4);
      parts.push(`<div class="dv-row"><b>${esc(t('dv.sizeTitle'))}</b><span class="mono">${u}</span></div><p class="dv-note">${esc(t('dv.sizeLine', { amt: fmtNum(z.riskAmount, 2), pct: fmtNum(z.pct, 2), notional: fmtNum(z.notional, 0) }))}${z.scale < 1 ? ` · ${esc(t('dv.sizeReduced', { s: Math.round(z.scale * 100) }))}` : ''}</p>`);
    }
    if (DERIV_SYMBOLS.includes(an.symbol) && an.mode === 'live' && store.get('settings').risk?.derivFilter !== false) {
      if (dv.symbol !== an.symbol || Date.now() - dv.at > 60_000) {
        const sym = an.symbol; dv = { ...dv, symbol: sym, at: Date.now() };
        getDerivs(sym).then((d) => { if (dv.symbol === sym) { dv.read = readDerivs(d); if (dvLast) renderExtras(dvLast); } });
      }
      const r = dv.read && dv.read.symbol === an.symbol ? dv.read : null;
      if (r) {
        const sg = (v) => (v == null ? '—' : `${v >= 0 ? '+' : ''}${fmtNum(v, 2)}%`);
        const tags = ['crowdedLongs', 'crowdedShorts', 'longFlush', 'shortSqueeze'].filter((k) => r[k]);
        const chk = pl ? derivCheck(r, pl.direction) : { ok: true };
        parts.push(`<div class="dv-row"><b>${esc(t('dv.title'))}</b><span class="mono">${r.funding != null ? `${fmtNum(r.funding * 100, 3)}%` : '—'}</span></div>
          <p class="dv-note">${esc(t('dv.oi', { h1: sg(r.oiChange1h), h4: sg(r.oiChange4h) }))}${tags.length ? ` · <b class="${chk.ok ? '' : 'down'}">${esc(tags.map((k) => t(`dv.tag.${k}`)).join(' · '))}</b>` : ` · ${esc(t('dv.balanced'))}`}</p>
          ${pl && !chk.ok ? `<p class="dv-warn">${esc(t('dv.blocked', { why: t(`dv.why.${chk.key}`) }))}</p>` : ''}`);
      }
    }
    const html = parts.join('');
    if (html !== dvHtml) { dvHtml = html; box.innerHTML = html; }
    box.hidden = !html;
  }
  const aiOpen = { ind: false, how: false }; // <details> state survives the once-a-second refresh
  let aiHtml = '';
  q0('[data-ai-body]').addEventListener('toggle', (e) => { const d = e.target.closest?.('details[data-d]'); if (d) aiOpen[d.dataset.d] = d.open; }, true);
  function renderAi(an) {
    const card = q0('[data-ai-card]');
    const on = store.get('settings').ai?.enabled !== false;
    card.hidden = false;
    const sw = q0('[data-ai-switch]');
    sw.classList.toggle('is-on', on); sw.setAttribute('aria-checked', String(on));
    const body = q0('[data-ai-body]');
    const ai = an.ai;
    const pc = (v) => `${Math.round(v * 100)}%`;
    const p = (v) => fmtNum(v, an.precision);
    const put = (html) => { if (html !== aiHtml) { aiHtml = html; body.innerHTML = html; } };
    q0('[data-ai-grade]').innerHTML = '';
    if (!on) { put(`<p class="ai-note">${esc(t('aie.off2'))}</p>`); return; }
    if (an.mode !== 'live') { put(`<p class="ai-note">${esc(t('aie.demo'))}</p>`); return; }
    if (!ai) { put(''); return; }
    if (!ai.ready) { put(`<p class="ai-note">${esc(t('aie.short', { need: ai.need ?? '—', have: ai.have ?? '—' }))}</p>`); return; }
    const m = ai.m;
    const long = ai.side === 'long';
    const edge = m.edge;
    const hits = an.plan?.hits || 0;
    if (edge) q0('[data-ai-grade]').innerHTML = `<span class="ai-grade g-${m.grade}">${esc(t('aie.quality'))} ${m.grade}</span>`;
    const tps = ai.tp.map((x, k) => `<div class="ai-tp${k < hits ? ' is-hit' : ''}"><span>TP${k + 1}${k < hits ? ' ✓' : ''}</span><b class="mono">${x ? pc(x.p) : '—'}</b><i><u style="width:${x ? Math.round(x.p * 100) : 0}%"></u></i></div>`).join('');
    const verdict = edge
      ? `<span class="ai-ok">✓ ${esc(t('aie.verdictEdge'))}</span> <span class="mono">AUC ${m.oos.auc.toFixed(2)}</span> · ${esc(t('aie.cases', { n: m.oos.n }))}`
      : `<span class="ai-no">○ ${esc(t('aie.verdictNone'))}</span>`;
    const fc = ai.forecast;
    const fcLine = fc ? `<div class="ai-row"><span class="muted">${esc(t('aie.forecast', { h: fc.h }))}</span><span>${fc.edge && fc.pUp != null ? `<b class="${fc.pUp >= 0.5 ? 'up' : 'down'}">${fc.pUp >= 0.5 ? '▲' : '▼'} ${Math.round((fc.pUp >= 0.5 ? fc.pUp : 1 - fc.pUp) * 100)}%</b>` : `<span class="muted">${esc(t('aie.noForecast'))}</span>`}${fc.range ? ` <span class="mono ai-rng" dir="ltr">${p(fc.range.lo)}–${p(fc.range.hi)}</span>` : ''}</span></div>` : '';
    const voteTxt = (v) => t(v > 0 ? 'aie.vote.with' : v < 0 ? 'aie.vote.against' : 'aie.vote.flat');
    const list = (m.indicators || []).filter((i) => i.available);
    const indRows = list.map((i) => `<tr class="${i.proven ? 'is-proven' : ''}"><td>${esc(t(`aie.ind.${i.key}`))}</td><td class="${i.vote > 0 ? 'up' : i.vote < 0 ? 'down' : 'muted'}">${esc(voteTxt(i.vote))}</td><td class="mono">${i.rate == null ? '—' : pc(i.rate)}<small>${i.n}</small></td><td class="mono">${i.oosRate == null ? '—' : pc(i.oosRate)}<small>${i.oosN}</small></td></tr>`).join('');
    const proven = list.filter((i) => i.proven).length;
    const drv = (m.drivers || []).map((d) => `<span class="ai-drv ${d.sign > 0 ? 'pos' : 'neg'}">${d.sign > 0 ? '▲' : '▼'} ${esc(t(`aie.drv.${d.key}`))}</span>`).join('');
    put(`
      <div class="ai-hero ${long ? 'is-long' : 'is-short'}${edge ? '' : ' is-base'}">
        <div class="ai-pct mono">${pc(m.p)}</div>
        <div class="ai-hero-t"><b>${long ? '▲' : '▼'} ${esc(t(long ? 'common.long' : 'common.short'))}</b><span>${esc(t('aie.probTitle'))}</span></div>
        <div class="ai-mix"><span>${esc(t('aie.mixAi'))}<b class="mono">${pc(m.aiP)}</b></span><span>${esc(t('aie.mixInd'))}<b class="mono">${m.indP != null ? pc(m.indP) : '—'}</b></span><span>${esc(t('aie.mixBase'))}<b class="mono">${pc(m.base)}</b></span></div>
      </div>
      <div class="ai-tps">${tps}</div>
      <div class="ai-row ai-verdict">${verdict}</div>
      ${fcLine}
      <details class="ai-det" data-d="ind" ${aiOpen.ind ? 'open' : ''}><summary>${esc(t('aie.indTitle'))}<em>${proven ? `${proven} ✓` : `${list.length}`}</em></summary>
        <div class="table-scroll"><table class="ai-ind"><thead><tr><th>${esc(t('aie.indName'))}</th><th>${esc(t('aie.indNow'))}</th><th>${esc(t('aie.indRate'))}</th><th>${esc(t('aie.indOos'))}</th></tr></thead><tbody>${indRows}</tbody></table></div>
        <p class="ai-note">${esc(t('aie.indNote', { base: pc(m.base) }))}</p></details>
      <details class="ai-det" data-d="how" ${aiOpen.how ? 'open' : ''}><summary>${esc(t('aie.howTitle'))}</summary>
        <p class="ai-note">${esc(t(edge ? 'aie.edge' : 'aie.noEdge'))}</p>
        ${drv ? `<div class="ai-drvs"><span class="muted">${esc(t('aie.drivers'))}</span>${drv}</div>` : ''}
        ${ai.strategy ? `<p class="ai-note">${esc(t('aie.strategy', { w: Math.round(ai.strategy.winRate * 100), n: ai.strategy.n }))}</p>` : ''}
        <p class="ai-note">${esc(t('aie.basis', { bars: ai.bars }))} · ${esc(ai.deep ? t('aie.deep') : t('aie.shallow'))}</p>
        <p class="ai-note">${esc(t('aie.disclaimer'))}</p></details>`);
  }
  let lastKey = null; // symbol|timeframe|direction — a change means a new plan, not a price tick

  return {
    el,
    update(an) {
      if (!an) return;
      const p = (v) => fmtNum(v, an.precision);
      renderAi(an);
      renderExtras(an);
      const key = `${an.symbol}|${an.tf}|${an.plan?.openedTime}|${an.plan?.direction}`;
      const fresh = key !== lastKey;
      // Same plan, new price → count smoothly. New symbol/timeframe/direction → show at once and highlight the card.
      const dur = fresh ? 0 : 520;
      if (fresh && lastKey !== null) replayClass(q('.plan-card'), 'plan-refresh');
      lastKey = key;
      // Momentum
      const m = an.momentum;
      const score = m ? m.score : 50;
      q('.g-value').style.strokeDashoffset = String(ARC_LEN * (1 - score / 100));
      const ang = Math.PI * (1 - score / 100);
      q('.g-knob').setAttribute('cx', String(100 + 80 * Math.cos(ang)));
      q('.g-knob').setAttribute('cy', String(100 - 80 * Math.sin(ang)));
      const lab = q('[data-g-label]');
      lab.textContent = m ? t(`momentum.${m.label}`) : '—';
      lab.className = `g-label ${m?.label === 'positive' ? 'up' : m?.label === 'negative' ? 'down' : ''}`;
      q('[data-g-desc]').textContent = m ? `${t(`momentum.${m.descKey}`)} · ${score.toFixed(1)}/100` : '';
      // Live badge: time of this calculation; pulses on every refresh (once per second while streaming).
      const live = q('[data-m-live]');
      live.innerHTML = `<span class="dot ${an.mode === 'live' ? 'ok' : 'warn'}"></span>${new Date().toLocaleTimeString('en-GB')}`;
      replayClass(live, 'm-pulse');
      tweenNumber(q('[data-buy-pct]'), an.strength.buyPct, (v) => `${Math.round(v)}%`, dur);
      tweenNumber(q('[data-sell-pct]'), an.strength.sellPct, (v) => `${Math.round(v)}%`, dur);
      q('[data-buy-bar]').style.width = `${an.strength.buyPct}%`;
      q('[data-sell-bar]').style.width = `${an.strength.sellPct}%`;
      const window = store.get('settings').pressure.window;
      q('[data-m-basis]').textContent = an.strength.basis === 'volume'
        ? t('momentum.basis', { n: window })
        : t('momentum.basisPrice', { n: window });

      // Fibonacci table (compact, as in the reference)
      const rows = an.fib ? an.fib.levels.filter((l) => [0.382, 0.5, 0.618, 1].includes(l.ratio)) : [];
      q('[data-fib-rows]').innerHTML = rows.map((l) => `<tr><td class="mono">${l.ratio.toFixed(3)}</td><td class="mono">${p(l.price)}</td></tr>`).join('');
      // Verdict: the latest candle close through one of the displayed Fibonacci lines
      const vEl = q('[data-fib-verdict]');
      const shown = store.get('settings').fib;
      const br = (an.fibSig?.breaks || []).filter((b) => shown.signals !== false && (shown.levels?.includes(b.ratio) ?? true)).sort((x, y) => y.index - x.index)[0];
      vEl.hidden = !an.fib || shown.signals === false;
      if (!vEl.hidden) {
        vEl.className = `fib-verdict ${br ? (br.dir === 'sell' ? 'is-sell' : 'is-buy') : ''}`;
        vEl.innerHTML = br
          ? `<b>${br.dir === 'sell' ? '▼' : '▲'} ${esc(br.dir === 'sell' ? t('fs.sell') : t('fs.buy'))}</b><span>${esc(t(br.dir === 'sell' ? 'fs.closedBelow' : 'fs.closedAbove', { r: br.ratio.toFixed(3), p: p(br.price) }))}${br.live ? ` · ${esc(t('fs.live'))}` : ''}</span>`
          : `<span class="muted">${esc(t('fs.noBreak'))}</span>`;
      }
      q('[data-fib-points]').textContent = an.fib ? t('fib.points', { high: p(an.fib.high), low: p(an.fib.low) }) : '';

      // Plan — from the strategy engine (services/backtest.js): an active trade, an SMC setup waiting
      // for its entry, or nothing (waiting for the next signal) with the last trade's result.
      const pl = an.plan;
      const zoneOn = an.strategy === 'zone';
      const edhOn = an.strategy === 'edh';
      const smcOn = an.strategy === 'smc';
      const card = q('.plan-card');
      card.classList.toggle('is-smc', smcOn || zoneOn || edhOn);
      q('[data-plan-title]').textContent = edhOn ? t('ed.planTitle') : zoneOn ? t('zs.title') : smcOn ? t('smc.title') : t('plan.title');
      const boxZ = q('[data-zone-box]');
      boxZ.hidden = !(zoneOn || edhOn);
      if (zoneOn) boxZ.innerHTML = renderZone(an, pl);
      if (edhOn) boxZ.innerHTML = renderEdh(an, pl);
      q('[data-new-trade]').hidden = true;
      // SMC reading of the whole loaded history — shown all the time, trade or no trade.
      const box2 = q('[data-smc2]');
      box2.hidden = !smcOn;
      if (smcOn) box2.innerHTML = renderSmc2(an, pl);
      const sumEl = q('[data-smc-sum]');
      sumEl.hidden = !(smcOn && an.smc);
      if (smcOn && an.smc) {
        const m = an.smc;
        const nearOb = (dir) => (m.obs || []).find((o) => o.dir === dir);
        const obTxt = (o) => (o ? `${p(o.bottom)} – ${p(o.top)}${o.mitigated ? ' ✓' : ''}` : '—');
        const lb = m.lastBreak;
        const rows = [
          [t('smc.sum.bars'), String(m.bars || an.last ? (m.bars || '') : ''), ''],
          [t('smc.sum.trend'), m.trend ? t(`smc.trend.${m.trend}`) : '—', m.trend === 'bull' ? 'up' : m.trend === 'bear' ? 'down' : ''],
          [t('smc.sum.last'), lb ? `${lb.kind} ${lb.dir === 'bull' ? '↑' : '↓'} ${p(lb.level)}` : '—', lb?.dir === 'bull' ? 'up' : lb ? 'down' : ''],
          [t('smc.sum.zone'), m.range ? `${t(`smc.sum.${m.range.zone}`)} · EQ ${p(m.range.eq)}` : '—', m.range?.zone === 'discount' ? 'up' : m.range ? 'down' : ''],
          [t('smc.sum.bullOb'), obTxt(nearOb('bull')), 'up'],
          [t('smc.sum.bearOb'), obTxt(nearOb('bear')), 'down'],
          [t('smc.sum.fvg'), String((m.fvgs || []).length), ''],
          ['BSL / SSL', `${m.bsl?.[0] ? p(m.bsl[0].price) : '—'} / ${m.ssl?.[0] ? p(m.ssl[0].price) : '—'}`, ''],
        ];
        sumEl.innerHTML = `<div class="smc-sum-head">${esc(t('smc.sum.title', { n: m.bars || '' }))}</div>
          <table class="kv-table smc-sum-table"><tbody>${rows.slice(1).map(([k, v, c]) => `<tr><td>${esc(k)}</td><td class="mono ${c}">${esc(v)}</td></tr>`).join('')}</tbody></table>`;
      }
      const dirName = (d) => t(d === 'long' ? 'common.long' : 'common.short');
      const when = (sec) => new Date(sec * 1000).toLocaleString(getLang() === 'ar' ? 'ar-EG-u-nu-latn' : 'en-GB', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
      const outcome = (o, hits) => (o === 'tp3' ? t('plan.status.tp3') : o === 'sl' ? t('plan.status.stopped') : o === 'be' ? t('plan.status.be', { n: hits }) : '');
      const prev = an.previousTrade;
      const prevLine = prev ? t('plan.status.prev2', { dir: dirName(prev.direction), result: outcome(prev.status, prev.hits), pts: `${prev.points >= 0 ? '+' : '−'}${fmtNum(Math.abs(prev.points), 1)}` }) : '';
      const ruleText = () => {
        const r = an.rules || {};
        if (zoneOn) return t('zs.rule', { n: an.rules?.zoneMinScore ?? 80 });
        if (smcOn) return t('smcv2.rule', { n: an.rules?.smcMinScore ?? 80 });
        if (r.stopMode === 'points') return t('plan.rulePoints', { sl: 30, tp: '50 / 80 / 130', size: pl?.pointSize ?? '' });
        return t('plan.ruleAtr', { k: r.atrMult, r1: r.firstTargetR > 0 ? r.firstTargetR : r.tpR?.[0], r2: r.tpR?.[1], r3: r.tpR?.[2] });
      };
      card.dataset.state = pl ? pl.status : 'waiting';
      q('[data-plan-rows]').closest('table').hidden = !pl;
      if (!pl) {
        q('[data-plan-dir]').innerHTML = `<span class="badge badge-muted">${esc(t('plan.waitingBadge'))}</span>`;
        q('[data-plan-status]').textContent = [zoneOn ? t('zs.none') : smcOn ? t('smc.none') : t('plan.waiting'), prevLine].filter(Boolean).join(' · ');
        q('[data-plan-rule]').textContent = ruleText();
        return;
      }
      q('[data-plan-dir]').innerHTML = `<span class="badge ${pl.direction === 'long' ? 'badge-live' : 'badge-error'}">${esc(dirName(pl.direction))}</span>`;
      const rowsEl = q('[data-plan-rows]');
      const be = pl.hits >= 1;
      const planRows = [
        [t('plan.entry'), pl.entry, ''],
        [be ? t('plan.stopBe') : t('plan.stop'), pl.stop, 'down'],
        [t('plan.tp1'), pl.targets[0], 'up'],
        [t('plan.tp2'), pl.targets[1], 'up'],
        [t('plan.tp3'), pl.targets[2], 'up'],
      ];
      if (rowsEl.children.length !== planRows.length || !rowsEl.querySelector('[data-pv]')) {
        rowsEl.innerHTML = planRows.map(([k, , c]) => `<tr><td>${esc(k)}</td><td class="mono ${c}"><span data-pv></span><small class="pts" data-pd></small></td></tr>`).join('');
      }
      // Distance from the entry in points (instrument point size), shown under every level.
      const ptsOf = (v) => Math.abs(v - pl.entry) / (pl.pointSize || 1);
      const fmtPts = (x) => fmtNum(x, x >= 100 ? 0 : 1);
      planRows.forEach(([k, v], i) => {
        const tr = rowsEl.children[i];
        tr.firstElementChild.textContent = k;
        tweenNumber(tr.querySelector('[data-pv]'), v, p, dur);
        const d = tr.querySelector('[data-pd]');
        if (i === 0) d.textContent = '';
        else if (i === 1) d.textContent = pl.hits >= 1 ? t('plan.ptsBe') : t('plan.ptsLoss', { n: `\u2066−${fmtPts(ptsOf(pl.initialStop ?? v))}\u2069` });
        else d.textContent = t('plan.ptsGain', { n: `\u2066+${fmtPts(ptsOf(v))}\u2069` });
      });
      [...rowsEl.children].forEach((tr, i) => tr.classList.toggle('hit', i >= 2 && i - 2 < (pl.hits || 0)));
      const lines = [];
      if (pl.status === 'pending') lines.push(t('smc.pending', { dir: dirName(pl.direction) }));
      else {
        lines.push(t('plan.status.active2', { dir: dirName(pl.direction), time: when(pl.openedTime) }));
        if (pl.hits) lines.push(t('plan.status.tp', { n: pl.hits }));
      }
      if (prevLine) lines.push(prevLine);
      q('[data-plan-status]').textContent = lines.join(' · ');
      const rr = (pl.rr || []).map((x) => `${fmtNum(x, 1)}R`).join(' / ');
      q('[data-plan-rule]').textContent = `${ruleText()} · ${t('plan.riskLine', { dist: p(pl.distance), rr })}`;
    },
  };
}
