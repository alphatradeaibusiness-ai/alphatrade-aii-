// Indicator controls (modal + Indicators page) and the Settings panel.
import { h, esc, fmtTime } from '../utils/dom.js';
import { gate } from './gate.js';
import { icons } from './icons.js';
import { t, getLang } from '../i18n/index.js';
import { store, DEFAULT_SETTINGS } from '../state/store.js';
import { INSTRUMENTS, STOP_LOSS_POINTS, TARGET_POINTS } from '../config/instruments.js';
import { FIB_RATIOS } from '../indicators/index.js';
import { toast } from './ui.js';

const num = (name, value, { min, max, step = 1 } = {}) =>
  `<input class="input mono" type="number" name="${name}" value="${value ?? ''}" ${min !== undefined ? `min="${min}"` : ''} ${max !== undefined ? `max="${max}"` : ''} step="${step}"/>`;
const sw = (name, on) => `<span class="switch"><input type="checkbox" name="${name}" ${on ? 'checked' : ''} aria-label="${name}"/></span>`;

/**
 * @param {{ hasVolume:boolean, onPickFrvp?:()=>void, onPickFib?:()=>void, compact?:boolean }} opts
 */
export function createIndicatorPanel(opts = {}) {
  const s = store.get('settings');
  const noVol = opts.hasVolume === false ? `<div class="alert alert-info ind-novol">${icons.info}<div>${esc(t('chart.noVolume'))}</div></div>` : '';
  const frvpRange = s.frvp.from && s.frvp.to
    ? t('ind.frvpRange', { from: fmtTime(s.frvp.from * 1000, getLang(), true), to: fmtTime(s.frvp.to * 1000, getLang(), true), bars: '…' })
    : t('ind.frvpNone');
  const el = h(`<form class="ind-panel" novalidate>
    <fieldset class="ind-sec"><legend><span>${esc(t('ind.vp'))}</span>${sw('vp.enabled', s.vp.enabled)}</legend>
      ${noVol}
      <div class="ind-grid">
        <label>${esc(t('ind.vpRows'))}${num('vp.rows', s.vp.rows, { min: 10, max: 120 })}</label>
        <label>${esc(t('ind.vpWidth'))}${num('vp.widthPct', s.vp.widthPct, { min: 5, max: 50 })}</label>
        <label>${esc(t('ind.valueArea'))}${num('vp.valueAreaPct', s.vp.valueAreaPct, { min: 50, max: 95 })}</label>
        <label>${esc(t('ind.vpRange'))}<select class="select" name="vp.range">
          <option value="visible" ${s.vp.range === 'visible' ? 'selected' : ''}>${esc(t('ind.vpVisible'))}</option>
          <option value="all" ${s.vp.range === 'all' ? 'selected' : ''}>${esc(t('ind.vpAll'))}</option></select></label>
        <label class="ind-inline">${sw('vp.showPoc', s.vp.showPoc)}<span>${esc(t('ind.poc'))}</span></label>
      </div>
    </fieldset>
    <fieldset class="ind-sec"><legend><span>${esc(t('ind.frvp'))}</span>${sw('frvp.enabled', s.frvp.enabled)}</legend>
      ${noVol}
      <div class="ind-grid">
        <label>${esc(t('ind.vpRows'))}${num('frvp.rows', s.frvp.rows, { min: 10, max: 120 })}</label>
        <div class="ind-range"><span class="muted" data-frvp-range>${esc(frvpRange)}</span>
          <div class="ind-actions"><button type="button" class="btn btn-sm" data-pick-frvp>${icons.frvp}<span>${esc(t('ind.frvpPick'))}</span></button>
          <button type="button" class="btn btn-sm btn-ghost" data-clear-frvp>${esc(t('common.clear'))}</button></div></div>
      </div>
    </fieldset>
    <fieldset class="ind-sec"><legend><span>${esc(t('ind.rsi'))}</span>${sw('rsi.enabled', s.rsi.enabled)}</legend>
      <div class="ind-grid">
        <label>${esc(t('ind.period'))}${num('rsi.period', s.rsi.period, { min: 2, max: 100 })}</label>
        <label>${esc(t('ind.overbought'))}${num('rsi.overbought', s.rsi.overbought, { min: 50, max: 99 })}</label>
        <label>${esc(t('ind.oversold'))}${num('rsi.oversold', s.rsi.oversold, { min: 1, max: 50 })}</label>
      </div>
    </fieldset>
    <fieldset class="ind-sec"><legend><span>${esc(t('ind.pressure'))}</span>${sw('pressure.enabled', s.pressure.enabled)}</legend>
      ${noVol}
      <div class="ind-grid"><label>${esc(t('ind.pressureWindow'))}${num('pressure.window', s.pressure.window, { min: 5, max: 500 })}</label></div>
    </fieldset>
    <fieldset class="ind-sec"><legend><span>${esc(t('ind.fib'))}</span>${sw('fib.enabled', s.fib.enabled)}</legend>
      <div class="ind-grid">
        <label class="ind-check">${sw('fib.signals', s.fib.signals !== false)}<span>${esc(t('fs.optSignals'))}</span></label>
        <label class="ind-check">${sw('fib.notify', s.fib.notify !== false)}<span>${esc(t('fs.optNotify'))}</span></label>
        <label class="ind-check">${sw('fib.strong', s.fib.strong !== false)}<span>${esc(t('fs.optStrong'))}</span></label>
      </div>
      <p class="muted ind-help">${esc(t('fs.help'))}</p>
      <div class="fib-levels">${FIB_RATIOS.map((r) => `<label class="checkbox"><input type="checkbox" name="fib.level" value="${r}" ${s.fib.levels.includes(r) ? 'checked' : ''}/><span class="mono">${r}</span></label>`).join('')}</div>
      <div class="ind-grid">
        <label class="ind-check">${sw('fib.follow', s.fib.follow !== false)}<span>${esc(t('ind.fibFollow'))}</span></label>
        <label>${esc(t('ind.fibMode'))}<select class="select" name="fib.mode">
          <option value="auto" ${s.fib.mode === 'auto' ? 'selected' : ''}>${esc(t('ind.fibAuto'))}</option>
          <option value="manual" ${s.fib.mode === 'manual' ? 'selected' : ''}>${esc(t('ind.fibManual'))}</option></select></label>
        <label data-fib-auto>${esc(t('ind.fibLookback'))}${num('fib.lookback', s.fib.lookback, { min: 10, max: 500 })}</label>
        <label data-fib-manual>${esc(t('ind.fibHigh'))}${num('fib.high', s.fib.high, { step: 'any' })}</label>
        <label data-fib-manual>${esc(t('ind.fibLow'))}${num('fib.low', s.fib.low, { step: 'any' })}</label>
        <div class="ind-actions"><button type="button" class="btn btn-sm" data-pick-fib>${icons.fib}<span>${esc(t('ind.fibPick'))}</span></button></div>
      </div>
    </fieldset>
    <fieldset class="ind-sec ind-toggles">
      <label class="ind-inline">${sw('zones.enabled', s.zones.enabled)}<span>${esc(t('ind.zones'))}</span></label>
      <label class="ind-inline">${sw('planLines.enabled', s.planLines.enabled)}<span>${esc(t('ind.plan'))}</span></label>
      <label class="ind-inline">${sw('ema.enabled', s.ema.enabled)}<span>${esc(t('ind.ema'))}</span></label>
      <label class="ind-inline">${sw('bb.enabled', s.bb?.enabled)}<span>${esc(t('ind.bb'))}</span></label>
      <label class="ind-inline">${sw('aview', s.aview !== false)}<span>${esc(t('ind.aview'))}</span></label>
    </fieldset>
  </form>`);

  const syncFibMode = () => {
    const manual = el.querySelector('[name="fib.mode"]').value === 'manual';
    el.querySelectorAll('[data-fib-manual]').forEach((x) => { x.hidden = !manual; });
    el.querySelectorAll('[data-fib-auto]').forEach((x) => { x.hidden = manual; });
  };
  syncFibMode();

  el.addEventListener('change', (e) => {
    const input = e.target;
    const name = input.name;
    if (!name) return;
    if (name === 'frvp.enabled' && input.checked && !gate('frvp')) { input.checked = false; return; }
    if (name === 'fib.level') {
      const levels = [...el.querySelectorAll('[name="fib.level"]:checked')].map((x) => Number(x.value));
      store.updateSettings('fib', { levels });
      return;
    }
    const [section, key] = name.split('.');
    if (!key && input.type === 'checkbox') { store.updateSettings(section, input.checked); return; }   // plain boolean settings (aview)
    let value;
    if (input.type === 'checkbox') value = input.checked;
    else if (input.type === 'number') {
      value = input.value === '' ? null : Number(input.value);
      if (value !== null) {
        const min = input.min !== '' ? Number(input.min) : -Infinity;
        const max = input.max !== '' ? Number(input.max) : Infinity;
        if (!Number.isFinite(value) || value < min || value > max) { input.classList.add('is-invalid'); return; }
      }
      input.classList.remove('is-invalid');
    } else value = input.value;
    const patch = { [key]: value };
    if (section === 'rsi' && (key === 'overbought' || key === 'oversold')) {
      const cur = { ...store.get('settings').rsi, ...patch };
      if (cur.oversold >= cur.overbought) { input.classList.add('is-invalid'); return; }
    }
    if (section === 'fib' && (key === 'high' || key === 'low')) { patch.highTime = null; patch.lowTime = null; patch.mode = 'manual'; patch.symbol = store.get('symbol'); el.querySelector('[name="fib.mode"]').value = 'manual'; }
    store.updateSettings(section, patch);
    if (name === 'fib.mode') syncFibMode();
  });
  el.querySelector('[data-pick-frvp]').addEventListener('click', () => opts.onPickFrvp?.());
  el.querySelector('[data-pick-fib]').addEventListener('click', () => opts.onPickFib?.());
  el.querySelector('[data-clear-frvp]').addEventListener('click', () => {
    store.updateSettings('frvp', { from: null, to: null });
    el.querySelector('[data-frvp-range]').textContent = t('ind.frvpNone');
  });
  return el;
}

export function createSettingsPanel({ onClose } = {}) {
  const s = store.get('settings');
  const el = h(`<form class="ind-panel" novalidate>
    <fieldset class="ind-sec"><legend><span>${esc(t('settings.rulesTitle'))}</span></legend>
      <p class="muted ind-help">${esc(t('settings.rulesHelp'))}</p>
      <div class="ind-grid">
        <label>${esc(t('settings.stopMode'))}<select class="select" name="stopMode">
          <option value="atr" ${s.plan.stopMode !== 'points' ? 'selected' : ''}>${esc(t('settings.stopAtr'))}</option>
          <option value="points" ${s.plan.stopMode === 'points' ? 'selected' : ''}>${esc(t('settings.stopPoints'))}</option></select></label>
        <label>${esc(t('settings.tpGap'))}${num('tpGapPts', s.plan.tpGapPts ?? 50, { min: 0, max: 100000, step: 10 })}</label>
        <label>${esc(t('settings.tp3Gap'))}${num('tp3GapPts', s.plan.tp3GapPts ?? 30, { min: 0, max: 100000, step: 10 })}</label>
        <label>${esc(t('settings.htfTrend'))}${num('htfTrendHours', s.plan.htfTrendHours ?? 200, { min: 0, max: 1000, step: 10 })}</label>
        <label>${esc(t('settings.atrMult'))}${num('atrMult', s.plan.atrMult ?? 3, { min: 0.5, max: 6, step: 0.5 })}</label>
        <label>${esc(t('settings.feePct'))}${num('feePct', s.plan.feePct ?? '', { min: 0, max: 1, step: 0.01 })}</label>
        <label class="ind-check">${sw('trendFilter', s.plan.trendFilter !== false)}<span>${esc(t('settings.trendFilter'))}</span></label>
        <label>${esc(t('settings.maxPerDay'))}${num('maxPerDay', s.plan.maxPerDay ?? 0, { min: 0, max: 50, step: 1 })}</label>
        <label class="ind-check">${sw('closeFirstTarget', !!s.plan.closeFirstTarget)}<span>${esc(t('settings.highAccuracy'))}</span></label>
      </div>
      <p class="muted ind-help">${esc(t('settings.highAccuracyHelp'))}</p>
    </fieldset>
    <fieldset class="ind-sec"><legend><span>${esc(t('smcv2.settingsTitle'))}</span></legend>
      <p class="muted ind-help">${esc(t('smcv2.settingsHelp'))}</p>
      <div class="ind-grid">
        <label>${esc(t('smcv2.minScore'))}${num('smc2.minScore', s.smc2?.minScore ?? 80, { min: 0, max: 100, step: 1 })}</label>
        <label class="ind-check">${sw('smc2.killZone', s.smc2?.killZone !== false)}<span>${esc(t('smcv2.killZone'))}</span></label>
        <label class="ind-check">${sw('smc2.htf', s.smc2?.htf !== false)}<span>${esc(t('smcv2.htf'))}</span></label>
        <label class="ind-check">${sw('smc2.publishUnproven', !!s.smc2?.publishUnproven)}<span>${esc(t('smcv2.publishUnproven'))}</span></label>
        <label>${esc(t('smcv2.htfMode'))}<select class="select" name="smc2.htfMode">${['both', 'h4', 'd1'].map((m) => `<option value="${m}" ${(s.smc2?.htfMode || 'both') === m ? 'selected' : ''}>${esc(t(`smcv2.htfMode_${m}`))}</option>`).join('')}</select></label>
        <label class="ind-check">${sw('smc2.reversal', !!s.smc2?.reversal)}<span>${esc(t('smcv2.reversal'))}</span></label>
        <label class="ind-check">${sw('smc2.rsiGate', !!s.smc2?.rsiGate)}<span>${esc(t('smcv2.rsiGate'))}</span></label>
        <label>${esc(t('smcv2.minDisp'))}${num('smc2.minDisp', s.smc2?.minDisp ?? 1, { min: 0.3, max: 4, step: 0.1 })}</label>
        <label>${esc(t('smcv2.fvgMin'))}${num('smc2.fvgMin', s.smc2?.fvgMin ?? 0.1, { min: 0, max: 2, step: 0.05 })}</label>
        <label>${esc(t('smcv2.maxAfterTap'))}${num('smc2.maxAfterTap', s.smc2?.maxAfterTap ?? 15, { min: 3, max: 60, step: 1 })}</label>
        <label>${esc(t('smcv2.stopBufAtr'))}${num('smc2.stopBufAtr', s.smc2?.stopBufAtr ?? 0.2, { min: 0, max: 2, step: 0.05 })}</label>
        <label>${esc(t('smcv2.maxRiskAtr'))}${num('smc2.maxRiskAtr', s.smc2?.maxRiskAtr ?? 5, { min: 1, max: 10, step: 0.5 })}</label>
      </div>
      <p class="muted ind-help">${esc(t('smcv2.optsNote'))}</p>
    </fieldset>
    <fieldset class="ind-sec"><legend><span>${esc(t('ed.title'))}</span></legend>
      <p class="muted ind-help">${esc(t('ed.note'))}</p>
      <div class="ind-grid">
        <label>${esc(t('ed.t1m1'))}${num('edh.m1.t1Pips', s.edh?.m1?.t1Pips ?? 30, { min: 30, max: 500, step: 1 })}</label>
        <label>${esc(t('ed.t2m1'))}${num('edh.m1.t2Pips', s.edh?.m1?.t2Pips ?? 70, { min: 70, max: 80, step: 1 })}</label>
        <label>${esc(t('ed.slm1'))}${num('edh.m1.slPips', s.edh?.m1?.slPips ?? 30, { min: 5, max: 500, step: 1 })}</label>
        <label>${esc(t('ed.t1m5'))}${num('edh.m5.t1Pips', s.edh?.m5?.t1Pips ?? 45, { min: 30, max: 500, step: 1 })}</label>
        <label>${esc(t('ed.t2m5'))}${num('edh.m5.t2Pips', s.edh?.m5?.t2Pips ?? 80, { min: 70, max: 80, step: 1 })}</label>
        <label>${esc(t('ed.slm5'))}${num('edh.m5.slPips', s.edh?.m5?.slPips ?? 60, { min: 5, max: 500, step: 1 })}</label>
        <label>${esc(t('ed.perSide'))}${num('edh.maxPerSide', s.edh?.maxPerSide ?? 1, { min: 1, max: 10, step: 1 })}</label>
        <label>${esc(t('ed.trendHours'))}${num('edh.trendHours', s.edh?.trendHours ?? 200, { min: 0, max: 1000, step: 10 })}</label>
        <label class="ind-check">${sw('edh.confirm5', s.edh?.confirm5 !== false)}<span>${esc(t('ed.confirm5'))}</span></label>
        <label class="ind-check">${sw('edh.showZones', s.edh?.showZones !== false)}<span>${esc(t('ed.showZones'))}</span></label>
        <label>${esc(t('ed.pivLen'))}${num('edh.pivLen', s.edh?.pivLen ?? 5, { min: 2, max: 20, step: 1 })}</label>
        <label>${esc(t('ed.dispMult'))}${num('edh.dispMult', s.edh?.dispMult ?? 2, { min: 1, max: 6, step: 0.25 })}</label>
        <label>${esc(t('ed.maxOb'))}${num('edh.maxOb', s.edh?.maxOb ?? 2, { min: 1, max: 8, step: 1 })}</label>
        <label>${esc(t('ed.maxSw'))}${num('edh.maxSw', s.edh?.maxSw ?? 3, { min: 1, max: 10, step: 1 })}</label>
      </div>
    </fieldset>
    <fieldset class="ind-sec"><legend><span>${esc(t('ex.title'))}</span></legend>
      <p class="muted ind-help">${esc(t('ex.help'))}</p>
      <div class="ind-grid">
        <label class="ind-check">${sw('exec.killzone', !!s.exec?.killzone)}<span>${esc(t('ex.killzone'))}</span></label>
        <label class="ind-check">${sw('exec.silverBullet', !!s.exec?.silverBullet)}<span>${esc(t('ex.silverBullet'))}</span></label>
        <label class="ind-check">${sw('exec.atrBand', !!s.exec?.atrBand)}<span>${esc(t('ex.atrBand'))}</span></label>
        <label>${esc(t('ex.atrLo'))}${num('exec.atrLo', s.exec?.atrLo ?? 0.7, { min: 0.1, max: 2, step: 0.05 })}</label>
        <label>${esc(t('ex.atrHi'))}${num('exec.atrHi', s.exec?.atrHi ?? 3, { min: 1, max: 10, step: 0.25 })}</label>
        <label class="ind-check">${sw('exec.sweep', !!s.exec?.sweep)}<span>${esc(t('ex.sweep'))}</span></label>
        <label>${esc(t('ex.sweepBars'))}${num('exec.sweepBars', s.exec?.sweepBars ?? 12, { min: 2, max: 60, step: 1 })}</label>
        <label class="ind-check">${sw('exec.cvd', !!s.exec?.cvd)}<span>${esc(t('ex.cvd'))}</span></label>
        <label class="ind-check">${sw('exec.htfOb', !!s.exec?.htfOb)}<span>${esc(t('ex.htfOb'))}</span></label>
        <label class="ind-check">${sw('exec.anomaly', !!s.exec?.anomaly)}<span>${esc(t('ex.anomaly'))}</span></label>
        <label class="ind-check">${sw('exec.voidCheck', !!s.exec?.voidCheck)}<span>${esc(t('ex.voidCheck'))}</span></label>
        <label class="ind-check">${sw('exec.dom', !!s.exec?.dom)}<span>${esc(t('ex.dom'))}</span></label>
      </div>
      <button type="button" class="btn btn-ghost" data-pro-preset style="width:100%;white-space:normal;text-align:center;margin-top:10px;height:auto;padding:10px 12px;line-height:1.5">${esc(t('ex.preset'))}</button>
    </fieldset>
    <fieldset class="ind-sec"><legend><span>${esc(t('dv.settingsTitle'))}</span></legend>
      <p class="muted ind-help">${esc(t('dv.settingsHelp'))}</p>
      <div class="ind-grid">
        <label>${esc(t('dv.beAtR'))}${num('beAtR', s.plan.beAtR ?? 0, { min: 0, max: 5, step: 0.1 })}</label>
        <label>${esc(t('dv.account'))}${num('risk.accountSize', s.risk?.accountSize ?? 1000, { min: 0, max: 100000000, step: 100 })}</label>
        <label>${esc(t('dv.riskPct'))}${num('risk.riskPct', s.risk?.riskPct ?? 1, { min: 0, max: 10, step: 0.1 })}</label>
        <label class="ind-check">${sw('risk.derivFilter', s.risk?.derivFilter !== false)}<span>${esc(t('dv.derivFilter'))}</span></label>
      </div>
    </fieldset>
    <fieldset class="ind-sec"><legend><span>${esc(t('rg.settingsTitle'))}</span></legend>
      <p class="muted ind-help">${esc(t('rg.settingsHelp'))}</p>
      <div class="ind-grid">
        <label class="ind-check">${sw('regime.enabled', !!s.regime?.enabled)}<span>${esc(t('rg.enabled'))}</span></label>
      </div>
    </fieldset>
    <fieldset class="ind-sec"><legend><span>${esc(t('zs.settingsTitle'))}</span></legend>
      <p class="muted ind-help">${esc(t('zs.settingsHelp'))}</p>
      <div class="ind-grid">
        <label>${esc(t('smcv2.minScore'))}${num('zone.minScore', s.zone?.minScore ?? 80, { min: 0, max: 100, step: 1 })}</label>
        <label>${esc(t('zs.minVol'))}${num('zone.minVolRatio', s.zone?.minVolRatio ?? 1.3, { min: 0, max: 5, step: 0.1 })}</label>
        <label>${esc(t('zs.minRR'))}${num('zone.minRR', s.zone?.minRR ?? 1, { min: 0, max: 5, step: 0.1 })}</label>
        <label class="ind-check">${sw('zone.htf', s.zone?.htf !== false)}<span>${esc(t('zs.htfOpt'))}</span></label>
        <label class="ind-check">${sw('zone.requireVp', s.zone?.requireVp !== false)}<span>${esc(t('zs.vpOpt'))}</span></label>
      </div>
    </fieldset>
    <fieldset class="ind-sec"><legend><span>${esc(t('qn.title'))}</span></legend>
      <p class="muted ind-help">${esc(t('qn.help'))}</p>
      <div class="ind-grid">
        <label class="ind-check">${sw('zone.quant', s.zone?.quant !== false)}<span>${esc(t('qn.quant'))}</span></label>
        <label class="ind-check">${sw('zone.regimeWeights', s.zone?.regimeWeights !== false)}<span>${esc(t('qn.regimeW'))}</span></label>
        <label class="ind-check">${sw('zone.flowGate', s.zone?.flowGate === true)}<span>${esc(t('qn.flowGate'))}</span></label>
        <label>${esc(t('qn.zGate'))}${num('zone.zGate', s.zone?.zGate ?? 0, { min: 0, max: 3, step: 0.25 })}</label>
        <label>${esc(t('qn.trail'))}${num('trailAtr', s.plan.trailAtr ?? 0, { min: 0, max: 6, step: 0.25 })}</label>
        <label>${esc(t('qn.dailyPct'))}${num('risk.dailyLossPct', s.risk?.dailyLossPct ?? 2, { min: 0, max: 20, step: 0.5 })}</label>
        <label>${esc(t('qn.dailyPts'))}${num('risk.dailyLossPts', s.risk?.dailyLossPts ?? 0, { min: 0, max: 1000000, step: 50 })}</label>
        <label>${esc(t('qn.monthlyPts'))}${num('risk.monthlyLossPts', s.risk?.monthlyLossPts ?? 0, { min: 0, max: 1000000, step: 50 })}</label>
        <label class="ind-check">${sw('risk.corrDynamic', s.risk?.corrDynamic !== false)}<span>${esc(t('qn.corr'))}</span></label>
        <label>${esc(t('qn.corrLimit'))}${num('risk.corrLimit', s.risk?.corrLimit ?? 0.75, { min: 0.3, max: 0.95, step: 0.05 })}</label>
      </div>
    </fieldset>
    <fieldset class="ind-sec"><legend><span>${esc(t('guard.title'))}</span></legend>
      <p class="muted ind-help">${esc(t('guard.help'))}</p>
      <div class="ind-grid">
        <label class="ind-check">${sw('risk.enabled', s.risk?.enabled !== false)}<span>${esc(t('guard.enabled'))}</span></label>
        <label>${esc(t('guard.dailyLossR'))}${num('risk.dailyLossR', s.risk?.dailyLossR ?? 3, { min: 0, max: 20, step: 0.5 })}</label>
        <label>${esc(t('guard.maxActive'))}${num('risk.maxActive', s.risk?.maxActive ?? 0, { min: 0, max: 20, step: 1 })}</label>
        <label>${esc(t('guard.maxCorrelated'))}${num('risk.maxCorrelated', s.risk?.maxCorrelated ?? 2, { min: 0, max: 10, step: 1 })}</label>
        <label>${esc(t('guard.newsMinutes'))}${num('risk.newsMinutes', s.risk?.newsMinutes ?? 30, { min: 0, max: 240, step: 5 })}</label>
        <label>${esc(t('guard.streakPause'))}${num('risk.streakPause', s.risk?.streakPause ?? 3, { min: 0, max: 20, step: 1 })}</label>
      </div>
    </fieldset>
    <fieldset class="ind-sec"><legend><span>${esc(t('settings.points'))}</span></legend>
      <p class="muted ind-help">${esc(t('settings.pointsHelp'))}</p>
      <table class="kv-table points-table"><tbody>
        ${INSTRUMENTS.map((i) => `<tr><td class="mono">${i.symbol}</td><td>${num(`point.${i.symbol}`, s.pointSizes[i.symbol], { min: 0.00001, step: 'any' })}</td>
          <td class="muted points-note">${esc(i.pointNote[getLang()])} → ${STOP_LOSS_POINTS} × = <span class="mono" data-dist="${i.symbol}"></span></td></tr>`).join('')}
      </tbody></table>
    </fieldset>
    <fieldset class="ind-sec"><legend><span>${esc(t('settings.tpPoints'))}</span></legend>
      <p class="muted ind-help">${esc(t('settings.tpPointsHelp', { sl: STOP_LOSS_POINTS, tp1: TARGET_POINTS[0], tp2: TARGET_POINTS[1], tp3: TARGET_POINTS[2] }))}</p>
    </fieldset>
    <fieldset class="ind-sec"><legend><span>${esc(t('settings.direction'))}</span></legend>
      <div class="ind-grid"><label><select class="select" name="direction">
        <option value="auto" ${s.plan.direction === 'auto' ? 'selected' : ''}>${esc(t('settings.dirAuto'))}</option>
        <option value="long" ${s.plan.direction === 'long' ? 'selected' : ''}>${esc(t('settings.dirLong'))}</option>
        <option value="short" ${s.plan.direction === 'short' ? 'selected' : ''}>${esc(t('settings.dirShort'))}</option></select></label>
        <label class="ind-check">${sw('chartClean', s.chartClean !== false)}<span>${esc(t('chart.cleanTip'))}</span></label>
        <label>${esc(t('settings.chartType'))}<select class="select" name="chartType">
          <option value="candles" ${s.chartType === 'candles' ? 'selected' : ''}>${esc(t('chart.candles'))}</option>
          <option value="line" ${s.chartType === 'line' ? 'selected' : ''}>${esc(t('chart.line'))}</option></select></label></div>
    </fieldset>
    <div class="ind-foot"><button type="button" class="btn btn-sm btn-ghost" data-restore>${icons.reset}<span>${esc(t('settings.restore'))}</span></button>
      <button type="button" class="btn btn-sm btn-primary" data-done>${icons.check}<span>${esc(t('common.save'))}</span></button></div>
  </form>`);

  const showDist = () => INSTRUMENTS.forEach((i) => {
    const v = Number(el.querySelector(`[name="point.${i.symbol}"]`).value);
    el.querySelector(`[data-dist="${i.symbol}"]`).textContent = v > 0 ? +(v * STOP_LOSS_POINTS).toFixed(6) : '—';
  });
  showDist();
  el.addEventListener('input', showDist);
  el.addEventListener('change', (e) => {
    const { name, value } = e.target;
    const cur = store.get('settings');
    if (['regime.enabled', 'zone.quant', 'zone.regimeWeights', 'zone.flowGate'].includes(name) && e.target.checked && !gate('quant')) { e.target.checked = false; return; }
    if (name.startsWith('point.')) {
      const v = Number(value);
      if (!(v > 0)) { e.target.classList.add('is-invalid'); return; }
      e.target.classList.remove('is-invalid');
      store.updateSettings('pointSizes', { ...cur.pointSizes, [name.slice(6)]: v });
    } else if (name === 'direction') store.updateSettings('plan', { direction: value });
    else if (name === 'stopMode') store.updateSettings('plan', { stopMode: value });
    else if (name === 'tp3GapPts') { const v = Number(value); if (Number.isFinite(v) && v >= 0) store.updateSettings('plan', { tp3GapPts: v }); }
    else if (name === 'tpGapPts') { const v = Number(value); if (Number.isFinite(v) && v >= 0) store.updateSettings('plan', { tpGapPts: v }); }
    else if (name === 'htfTrendHours') { const v = Number(value); if (Number.isFinite(v) && v >= 0) store.updateSettings('plan', { htfTrendHours: v }); }
    else if (name === 'atrMult') { const v = Number(value); if (v > 0) store.updateSettings('plan', { atrMult: v }); }
    else if (name === 'feePct') store.updateSettings('plan', { feePct: value === '' ? null : Math.max(0, Number(value) || 0) });
    else if (name === 'trendFilter') store.updateSettings('plan', { trendFilter: e.target.checked });
    else if (name === 'closeFirstTarget') store.updateSettings('plan', { closeFirstTarget: e.target.checked });
    else if (name === 'beAtR') store.updateSettings('plan', { beAtR: Math.max(0, Number(value) || 0) });
    else if (name === 'trailAtr') store.updateSettings('plan', { trailAtr: Math.max(0, Number(value) || 0) });
    else if (name === 'maxPerDay') store.updateSettings('plan', { maxPerDay: Math.max(0, Math.round(Number(value) || 0)) });
    else if (name === 'smc2.htfMode') store.updateSettings('smc2', { htfMode: ['both', 'h4', 'd1'].includes(value) ? value : 'both' });
    else if (name === 'chartType') store.updateSettings('chartType', value);
    else if (name === 'chartClean') store.updateSettings('chartClean', e.target.checked);
    else if (name.startsWith('smc2.') || name.startsWith('risk.') || name.startsWith('zone.') || name.startsWith('regime.') || name.startsWith('exec.') || name.startsWith('edh.')) {
      const parts = name.split('.');
      if (parts.length === 3 && parts[0] === 'edh') { // per-timeframe targets: edh.m1.t1Pips / edh.m5.t2Pips
        const cur = store.get('settings').edh?.[parts[1]] || {};
        const v3 = Math.max(0, Number(value) || 0);
        const lim3 = { t1Pips: (x) => Math.max(30, x), t2Pips: (x) => Math.min(80, Math.max(70, x)), slPips: (x) => Math.max(5, x) }[parts[2]] || ((x) => x);
        store.updateSettings('edh', { [parts[1]]: { ...cur, [parts[2]]: lim3(v3) } });
        return;
      }
      const [sec, key] = parts;
      const v = e.target.type === 'checkbox' ? e.target.checked : Math.max(0, Number(value) || 0);
      const lim = sec === 'edh' ? ({ t1Pips: (x) => Math.max(30, x), t2Pips: (x) => Math.min(80, Math.max(70, x)), slPips: (x) => Math.max(5, x), maxPerSide: (x) => Math.max(1, Math.round(x)), pivLen: (x) => Math.max(2, Math.round(x)), dispMult: (x) => Math.max(1, x), maxOb: (x) => Math.max(1, Math.round(x)), maxSw: (x) => Math.max(1, Math.round(x)), sweepHours: (x) => Math.max(1, x) }[key] || ((x) => x)) : (x) => x;
      store.updateSettings(sec, { [key]: key === 'minScore' ? Math.min(100, v) : typeof v === 'number' ? lim(v) : v });
    }
  });
  el.querySelector('[data-pro-preset]')?.addEventListener('click', () => {
    store.updateSettings('plan', { stopMode: 'atr', atrMult: 1.5, tpR: [1.5, 2.5, 4], beAtR: 1.2, trailAtr: 1.5 });
    store.updateSettings('exec', { killzone: true, atrBand: true });
    onClose?.(); toast(t('ex.presetDone'), 'success');
  });
  el.querySelector('[data-restore]').addEventListener('click', () => {
    const cur = store.get('settings');
    store.set('settings', { ...cur, pointSizes: structuredClone(DEFAULT_SETTINGS.pointSizes), plan: structuredClone(DEFAULT_SETTINGS.plan), smc2: structuredClone(DEFAULT_SETTINGS.smc2), zone: structuredClone(DEFAULT_SETTINGS.zone), regime: structuredClone(DEFAULT_SETTINGS.regime), exec: structuredClone(DEFAULT_SETTINGS.exec), edh: structuredClone(DEFAULT_SETTINGS.edh), risk: structuredClone(DEFAULT_SETTINGS.risk), chartType: 'candles' });
    onClose?.();
    toast(t('settings.saved'), 'success');
  });
  el.querySelector('[data-done]').addEventListener('click', () => { onClose?.(); toast(t('settings.saved'), 'success'); });
  return el;
}
