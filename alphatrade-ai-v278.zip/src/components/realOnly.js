// Results are shown only when they were computed on REAL market candles. When the feed fell back to generated
// (demo) data, no numbers are shown at all: a backtest on invented prices says nothing about the strategy.
import { esc } from '../utils/dom.js';
import { icons } from './icons.js';
import { t } from '../i18n/index.js';
import { describeError } from '../utils/http.js';

export const isReal = (ds) => ds?.mode === 'live';

export function realOnlyCard(ds) {
  const why = ds?.notice?.error ? describeError(ds.notice.error, t) : ds?.notice?.key ? t(ds.notice.key, { msg: '' }) : '';
  return `<div class="card real-only fade-in">
    <span class="ro-ic">${icons.alert}</span>
    <h2>${esc(t('real.title'))}</h2>
    <p class="muted">${esc(t('real.body'))}</p>
    ${why ? `<p class="ro-why">${esc(why)}</p>` : ''}
    <button type="button" class="btn btn-primary btn-sm" data-retry>${esc(t('real.retry'))}</button>
  </div>`;
}
