// Top navigation: logo, nav items, language selector, appearance toggle, account.
import { isAdmin } from '../config/admin.js';
import { ENFORCE, can, tier, navPlan, canNav, TIERS } from '../config/entitlements.js';
import { h, esc } from '../utils/dom.js';
import { icons, logoMark } from './icons.js';
import { t, getLang, setLang, LANGS } from '../i18n/index.js';
import { store } from '../state/store.js';
import { auth } from '../services/auth/index.js';
import { navigate } from '../router.js';
import { avatarInner, onAvatarChange } from '../services/profile.js';
import { secureChipHtml } from './trustBar.js';
import { onNotices, noticeState, markNoticesRead, refreshNotices, dismissBroadcast } from '../services/members.js';

export const NAV = [
  { id: 'home', route: '#/app', key: 'nav.home', icon: 'home' },
  { id: 'ai-signal', route: '#/app/ai-signal', key: 'nav.ai-signal', icon: 'sparkle' },
  { id: 'guide', route: '#/app/guide', key: 'nav.guide', icon: 'book' },
  { id: 'strategies', route: '#/app/strategies', key: 'nav.strategies', icon: 'sparkle' },
  { id: 'markets', route: '#/app/markets', key: 'nav.markets', icon: 'bars' },
  { id: 'indicators', route: '#/app/indicators', key: 'nav.indicators', icon: 'indicators' },
  { id: 'pricing', route: '#/app/pricing', key: 'nav.pricing', icon: 'crown' },
];
// Shown in the side drawer and the account menu (not in the top bar links).
const PROFILE = { id: 'profile', route: '#/app/profile', key: 'nav.profile', icon: 'user' };
// Strategy results (backtest): last item of the side drawer and in the account menu.
const PERF = { id: 'lab', route: '#/app/lab', key: 'nav.lab', icon: 'flask' };
const MONTHLY = { id: 'monthly', route: '#/app/monthly', key: 'nav.monthly', icon: 'trophy' };
const SIG = { id: 'signals', route: '#/app/signals', key: 'nav.signals', icon: 'bell' };
const item = (id, icon) => ({ id, route: `#/app/${id}`, key: `nav.${id}`, icon });
const byId = Object.fromEntries([...NAV, PROFILE, PERF, SIG].map((n) => [n.id, n]));
// Side drawer, grouped. Every tool has its own entry (and its own page).
// Side menu, by specialty. Every feature appears once, in the section where it logically belongs.
export const DRAWER_GROUPS = [
  // v278: 7 groups instead of 9 — results go with analysis, contests with the community; "about" moved to small links under the menu.
  { key: 'overview', items: [byId.home, byId.markets] },
  { key: 'ai', items: [item('ai-signal', 'sparkle'), item('alpha', 'brain'), item('council', 'layers'), item('liquidity', 'flame'), SIG, item('elite', 'crown')] },
  { key: 'analytics', items: [item('radar', 'radar'), byId.indicators, item('news', 'news'), item('lab', 'flask'), item('studio', 'fingerprint'), MONTHLY] },
  { key: 'trading', items: [item('risk', 'shield'), item('alerts', 'alarm'), item('journal', 'journal'), item('mt5', 'swap')] },
  { key: 'learning', items: [item('academy', 'bulb'), item('mentors', 'face'), byId.strategies, byId.guide] },
  { key: 'community', items: [item('rooms', 'chat'), item('contest', 'trophy'), item('support', 'mic'), item('live', 'pulse'), item('feedback', 'mail')] },
  { key: 'account', items: [PROFILE, byId.pricing, item('billing', 'calendar'), item('bank', 'wallet'), item('partners', 'trophy'), item('connect', 'bell')] },
  // Owners only: hidden for customers, and every one of these pages is refused by the server for anyone else.
  { key: 'owner', items: [{ ...item('admin-dashboard', 'grid'), admin: true }, { ...item('admin-stats', 'trend'), admin: true }, { ...item('admin-plans', 'gift'), admin: true }, { ...item('ai-key', 'lock'), admin: true }, { ...item('payments', 'card'), admin: true }, { ...item('rooms-admin', 'chat'), admin: true }, { ...item('partners-admin', 'trophy'), admin: true }] },
];

// v276: which plan opens a side-menu page (from NAV_RANK). Locked ones get a lock when plans are enforced.
function planBadge(id) {
  const p = navPlan(id); if (!p) return '';
  const locked = ENFORCE && !canNav(id);
  return `<em class="di-plan${locked ? ' is-locked' : ''}" title="${esc(t('ent.locked', { plan: t(`pricing.plans.${p}`) }))}">${locked ? icons.lock : ''}${esc(t(`ent.tier.${TIERS[p].name}`))}</em>`;
}

export function renderHeader(active) {
  const user = auth.current();
  const el = h(`<header class="topbar">
    <a class="brand" href="#/app" aria-label="AlphaTrade AI"><span class="logo-halo">${logoMark(34)}</span><span class="brand-name brand-glow">AlphaTrade <span class="brand-ai">AI</span></span></a>
    <span class="topbar-title" data-page-title></span>
    <nav class="nav" aria-label="${esc(t('nav.menu'))}">
      ${NAV.map((n) => `<a href="${n.route}" class="nav-item${n.id === active ? ' is-active' : ''}" data-nav="${n.id}" ${n.id === active ? 'aria-current="page"' : ''}>${esc(t(n.key))}</a>`).join('')}
    </nav>
    <div class="top-actions">
      ${secureChipHtml()}
      <div class="lang-select">
        <span class="lang-globe">${icons.globe}</span>
        <select aria-label="Language" data-lang-select>
          ${LANGS.map(([k, n]) => `<option value="${k}" ${getLang() === k ? 'selected' : ''}>${n}</option>`).join('')}
        </select>
        <span class="lang-chevron">${icons.chevronDown}</span>
      </div>
      <button class="btn btn-icon btn-ghost theme-btn" data-theme-toggle title="${esc(t('nav.theme'))}" aria-label="${esc(t('nav.theme'))}">${store.get('theme') === 'light' ? icons.sun : icons.moon}</button>
      <div class="nt-wrap">
        <button class="btn btn-icon btn-ghost nt-bell" data-bell aria-haspopup="true" aria-expanded="false" aria-label="${esc(t('navShort.notices'))}" title="${esc(t('navShort.notices'))}">${icons.bell}<span class="nt-badge" data-bell-n hidden></span></button>
        <div class="nt-panel card" data-bell-panel hidden role="dialog" aria-label="${esc(t('navShort.notices'))}">
          <div class="nt-head"><b>${esc(t('navShort.notices'))}</b><button type="button" class="btn btn-sm btn-ghost" data-bell-all>${esc(t('navShort.readAll'))}</button></div>
          <ul class="nt-list" data-bell-list></ul>
          <a class="nt-foot" href="#/app/connect">${esc(t('navShort.noticeSettings'))}</a>
        </div>
      </div>
      <div class="account">
        <button class="avatar" data-account data-avatar aria-haspopup="true" title="${esc(user?.email || '')}">${avatarInner(user)}</button>
        <div class="account-menu card" hidden>
          <div class="account-name" data-user-name>${esc(user?.name || '')}</div>
          <div class="muted mono" style="font-size:12px">${esc(user?.email || '')}</div>
          <a class="btn btn-sm" href="${PROFILE.route}" data-profile-link>${icons.user}<span>${esc(t(PROFILE.key))}</span></a>
          <a class="btn btn-sm" href="${SIG.route}" data-sig-link>${icons.bell}<span>${esc(t(SIG.key))}</span></a>
          <button class="btn btn-sm" data-signout>${icons.logout}<span>${esc(t('common.signOut'))}</span></button>
        </div>
      </div>
      <button class="btn btn-icon btn-ghost menu-btn" data-menu aria-label="${esc(t('nav.menu'))}" aria-expanded="false">${icons.menu}</button>
    </div>
  </header>`);

  el.querySelector('[data-lang-select]').addEventListener('change', (e) => setLang(e.target.value));
  el.querySelector('[data-theme-toggle]').addEventListener('click', () => {
    const next = store.get('theme') === 'light' ? 'dark' : 'light';
    store.set('theme', next);
    document.documentElement.dataset.theme = next;
    el.querySelector('[data-theme-toggle]').innerHTML = next === 'light' ? icons.sun : icons.moon;
  });
  const menu = el.querySelector('.account-menu');
  el.querySelector('[data-account]').addEventListener('click', (e) => { e.stopPropagation(); menu.hidden = !menu.hidden; });
  const docAbort = new AbortController();   // document-level listeners of this header, removed with it (login / logout / language switch rebuild the header)
  document.addEventListener('click', () => { menu.hidden = true; }, { signal: docAbort.signal });
  el.querySelectorAll('.account-menu [data-signout]').forEach((b) => b.addEventListener('click', async () => { await auth.signOut(); navigate('#/login'); }));
  // Side drawer (phones/tablets). It lives on <body>: the top bar's backdrop blur would trap a fixed child.
  document.querySelectorAll('.side-drawer, .drawer-backdrop').forEach((n) => n.remove());
  const short = (n) => t(`navShort.${n.id}`) || t(n.key);   // short sidebar labels; the full name stays as the tooltip
  const drawer = h(`<aside class="side-drawer sb" aria-label="${esc(t('nav.menu'))}" aria-hidden="true" inert>
    <i class="drawer-fx drawer-shine" aria-hidden="true"></i><i class="drawer-fx drawer-edge" aria-hidden="true"></i><i class="drawer-fx drawer-stars" aria-hidden="true"></i>
    <div class="drawer-head">
      <a class="drawer-brand" href="#/app"><span class="logo-halo">${logoMark(26)}</span><span class="brand-glow">AlphaTrade <span class="brand-ai">AI</span></span></a>
      <button class="btn btn-icon btn-ghost drawer-close" data-drawer-close aria-label="${esc(t('common.close'))}">${icons.close}</button>
    </div>
    <nav class="drawer-nav">
      ${(() => { let i = 0; return DRAWER_GROUPS.map((g) => ({ ...g, items: g.items.filter((n) => !n.admin || isAdmin()) })).filter((g) => g.items.length).map((g) => `<div class="drawer-group"><span class="drawer-gtitle">${esc(t(`tools.groups.${g.key}`))}</span>${g.items.map((n) => `<a href="${n.route}" class="drawer-item${n.id === active ? ' is-active' : ''}" data-nav="${n.id}" ${n.id === active ? 'aria-current="page"' : ''} title="${esc(t(n.key))}" style="--i:${i++}"><span class="di-ico">${icons[n.icon]}</span><span class="di-label">${esc(short(n))}</span>${planBadge(n.id)}<i class="di-chev" aria-hidden="true"></i></a>`).join('')}</div>`).join(''); })()}
    </nav>
    <div class="drawer-links"><a href="#/app/trust" data-nav="trust">${esc(t('nav.trust'))}</a><a href="#/app/legal" data-nav="legal">${esc(t('nav.legal'))}</a></div>
    <div class="drawer-foot">
      <a class="drawer-user" href="${PROFILE.route}"><span class="avatar avatar-sm" data-avatar>${avatarInner(user)}</span><span class="drawer-who"><b data-user-name>${esc(user?.name || '')}</b><span class="drawer-email mono">${esc(user?.email || '')}</span></span>${ENFORCE ? `<em class="drawer-plan">${esc(t(`ent.tier.${tier().name}`))}</em>` : ''}</a>
      <div class="sb-foot-row"><button class="btn btn-sm drawer-signout" data-signout title="${esc(t('common.signOut'))}">${icons.logout}<span>${esc(t('common.signOut'))}</span></button>
      <button class="btn btn-icon btn-sm sb-collapse" type="button" data-sb-collapse aria-label="${esc(t('navShort.collapse'))}" title="${esc(t('navShort.collapse'))}"><i class="sb-chev" aria-hidden="true"></i></button></div>
    </div>
  </aside>`);
  const backdrop = h('<div class="drawer-backdrop" hidden></div>');
  document.body.append(backdrop, drawer);

  const menuBtn = el.querySelector('[data-menu]');
  // Wide screens: the sidebar is docked next to the page and can be folded to icons only (remembered per device).
  const wide = window.matchMedia('(min-width: 1100px)');
  const rootEl = document.documentElement;
  let mini = false; try { mini = localStorage.getItem('ata:sb-mini') === '1'; } catch { /* storage off */ }
  const setMini = (v) => { mini = v; rootEl.classList.toggle('sb-mini', v); try { localStorage.setItem('ata:sb-mini', v ? '1' : '0'); } catch { /* */ } drawer.querySelector('[data-sb-collapse]').setAttribute('aria-expanded', String(!v)); };
  let wasDocked = false;
  const dock = () => {
    const on = wide.matches; const leaving = wasDocked && !on; wasDocked = on;
    rootEl.classList.toggle('sb-docked', on);
    // docked = always "open", so the original menu animations (entrance, glints, stars, breathing active row) run here too
    if (on) { drawer.classList.add('is-open'); drawer.removeAttribute('inert'); drawer.setAttribute('aria-hidden', 'false'); backdrop.hidden = true; rootEl.classList.remove('drawer-lock'); setMini(mini); }
    else { if (leaving) drawer.classList.remove('is-open'); drawer.setAttribute('aria-hidden', String(!drawer.classList.contains('is-open'))); drawer.toggleAttribute('inert', !drawer.classList.contains('is-open')); rootEl.classList.remove('sb-mini'); }
  };
  wide.addEventListener('change', dock, { signal: docAbort.signal });
  drawer.querySelector('[data-sb-collapse]').addEventListener('click', () => (wide.matches ? setMini(!mini) : setOpen(false)));
  const setOpen = (open) => {
    if (wide.matches) { if (open) setMini(!mini); return; }
    drawer.classList.toggle('is-open', open);
    drawer.setAttribute('aria-hidden', String(!open));
    drawer.toggleAttribute('inert', !open);
    backdrop.hidden = !open;
    requestAnimationFrame(() => backdrop.classList.toggle('is-open', open));
    menuBtn.setAttribute('aria-expanded', String(open));
    document.documentElement.classList.toggle('drawer-lock', open);
    if (open) drawer.querySelector('.drawer-item.is-active, .drawer-item')?.focus();
  };
  menuBtn.addEventListener('click', () => setOpen(!drawer.classList.contains('is-open')));
  dock();
  backdrop.addEventListener('click', () => setOpen(false));
  drawer.querySelector('[data-drawer-close]').addEventListener('click', () => setOpen(false));
  drawer.querySelectorAll('a').forEach((a) => a.addEventListener('click', () => { if (!wide.matches) setOpen(false); }));
  drawer.querySelectorAll('[data-signout]').forEach((b) => b.addEventListener('click', async () => { setOpen(false); await auth.signOut(); navigate('#/login'); }));
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && drawer.classList.contains('is-open')) { setOpen(false); menuBtn.focus(); } }, { signal: docAbort.signal });
  // Swipe the drawer back towards its edge to close it.
  let sx = null;
  drawer.addEventListener('touchstart', (e) => { sx = e.touches[0].clientX; }, { passive: true });
  drawer.addEventListener('touchend', (e) => {
    if (sx == null) return;
    const dx = e.changedTouches[0].clientX - sx;
    const rtl = document.documentElement.dir === 'rtl';
    if ((rtl ? -dx : dx) > 60) setOpen(false);
    sx = null;
  }, { passive: true });
  el._drawer = drawer;
  // ── message centre (bell): sign-in alerts, trial, plan ending, news, TradingView, owner broadcasts ──
  const bell = el.querySelector('[data-bell]'); const panel = el.querySelector('[data-bell-panel]');
  const ago = (ms) => { const m = Math.round((Date.now() - ms) / 60000); return m < 1 ? t('navShort.now') : m < 60 ? `${m}${t('navShort.min')}` : m < 1440 ? `${Math.round(m / 60)}${t('navShort.hr')}` : new Date(ms).toLocaleDateString(getLang() === 'ar' ? 'ar-EG-u-nu-latn' : 'en-GB', { month: 'short', day: 'numeric' }); };
  const ICON = { signin: 'shield', welcome: 'sparkle', trial: 'gift', expiry: 'calendar', referral: 'gift', newmember: 'user', news: 'news', tradingview: 'bolt', broadcast: 'bell', contest: 'trophy' };
  const paintBell = (st) => {
    const n = el.querySelector('[data-bell-n]'); n.hidden = !st.unread; n.textContent = st.unread > 9 ? '9+' : String(st.unread || '');
    bell.classList.toggle('has-new', Boolean(st.unread));
    el.querySelector('[data-bell-list]').innerHTML = st.items.length ? st.items.slice(0, 20).map((x) => `<li class="${x.read ? '' : 'is-new'} nt-k-${esc(x.kind)}"><a href="${esc(x.url || '#/app')}" data-nid="${esc(x.id)}"><span class="nt-ic">${icons[ICON[x.kind] || 'bell'] || icons.bell}</span><span class="nt-tx"><b>${esc(x.title)}</b><small>${esc(x.body)}</small></span><time>${esc(ago(x.at))}</time></a></li>`).join('') : `<li class="nt-empty">${esc(t('navShort.noNotices'))}</li>`;
    // owner announcement: a banner under the top bar until dismissed
    let bn = document.querySelector('.bc-banner');
    if (st.broadcast) {
      if (!bn) { bn = h('<div class="bc-banner" role="status"></div>'); el.after(bn); }
      bn.innerHTML = `${icons.bell}<span><b>${esc(st.broadcast.title)}</b> ${esc(st.broadcast.body)}</span><button type="button" class="btn btn-icon btn-ghost" aria-label="${esc(t('common.close'))}">${icons.close}</button>`;
      bn.querySelector('button').onclick = () => { dismissBroadcast(st.broadcast.id); bn.remove(); };
    } else bn?.remove();
  };
  const offNotices = onNotices(paintBell); paintBell(noticeState());
  bell.addEventListener('click', (e) => { e.stopPropagation(); panel.hidden = !panel.hidden; bell.setAttribute('aria-expanded', String(!panel.hidden)); menu.hidden = true; if (!panel.hidden) refreshNotices(); });
  panel.addEventListener('click', (e) => { e.stopPropagation(); const a = e.target.closest('[data-nid]'); if (a) { markNoticesRead(a.dataset.nid); panel.hidden = true; } });
  el.querySelector('[data-bell-all]').addEventListener('click', () => markNoticesRead());
  document.addEventListener('click', () => { panel.hidden = true; bell.setAttribute('aria-expanded', 'false'); }, { signal: docAbort.signal });
  // Keep every avatar in sync when the photo changes on the profile page.
  const offAvatar = onAvatarChange(() => document.querySelectorAll('[data-avatar]').forEach((a) => { a.innerHTML = avatarInner(auth.current()); }));
  el._cleanup = () => { offAvatar(); offNotices(); document.querySelector('.bc-banner')?.remove(); docAbort.abort(); drawer.remove(); backdrop.remove(); rootEl.classList.remove('sb-docked', 'sb-mini', 'drawer-lock'); };
  el.querySelector('[data-profile-link]').addEventListener('click', () => { menu.hidden = true; });
  return el;
}

export function setActiveNav(header, active) {
  const item = DRAWER_GROUPS.flatMap((g) => g.items).find((n) => n.id === active);
  const tt = header.querySelector('[data-page-title]'); if (tt) tt.textContent = item ? t(item.key) : '';

  header._drawer?.querySelectorAll('.drawer-item').forEach((a) => { const on = a.dataset.nav === active; a.classList.toggle('is-active', on); if (on) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current'); });
  header.querySelectorAll('.nav-item').forEach((a) => {
    const on = a.dataset.nav === active;
    a.classList.toggle('is-active', on);
    if (on) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current');
  });
}
