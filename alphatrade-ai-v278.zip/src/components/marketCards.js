// The market cards (one per instrument). Selecting one switches the chart symbol and all analysis.
import { h, esc, fmtNum, fmtPct } from '../utils/dom.js';
import { assetIcon } from './icons.js';
import { INSTRUMENTS } from '../config/instruments.js';
import { store } from '../state/store.js';
import { t } from '../i18n/index.js';
import { tweenNumber, flashDirection, replayClass } from '../utils/motion.js';

/** Live mini chart in each card: the last 40 price updates. */
function drawSpark(card, price) {
  if (!Number.isFinite(price)) return;
  const hist = card._hist || (card._hist = []);
  if (hist.at(-1) !== price) hist.push(price);
  if (hist.length > 40) hist.shift();
  const svg = card.querySelector('.mc-spark');
  if (!svg || hist.length < 2) return;
  const min = Math.min(...hist);
  const max = Math.max(...hist);
  const span = max - min || 1;
  const pts = hist.map((v, i) => `${((i / (hist.length - 1)) * 100).toFixed(1)},${(27 - ((v - min) / span) * 24).toFixed(1)}`).join(' ');
  svg.querySelector('polyline').setAttribute('points', pts);
  svg.querySelector('polygon').setAttribute('points', `0,30 ${pts} 100,30`);
  svg.classList.toggle('up', hist.at(-1) >= hist[0]);
  svg.classList.toggle('down', hist.at(-1) < hist[0]);
}

export function createMarketCards() {
  const el = h(`<section class="market-cards" aria-label="Markets">
    ${INSTRUMENTS.map((i, k) => `<button class="card market-card mc-enter" style="--k:${k}" data-symbol="${i.symbol}" aria-pressed="false">
      <i class="mc-ring" aria-hidden="true"></i><i class="mc-face" aria-hidden="true"></i><i class="mc-glow" aria-hidden="true"></i><i class="mc-shine" aria-hidden="true"></i>
      <svg class="mc-spark" viewBox="0 0 100 30" preserveAspectRatio="none" aria-hidden="true"><defs><linearGradient id="mcg${k}" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stop-color="currentColor" stop-opacity=".35"/><stop offset="1" stop-color="currentColor" stop-opacity="0"/></linearGradient></defs><polygon fill="url(#mcg${k})" points=""/><polyline fill="none" stroke="currentColor" stroke-width="1.6" vector-effect="non-scaling-stroke" points=""/></svg>
      <span class="mc-head"><span class="mc-icon">${assetIcon(i.icon, 26)}</span><span class="mc-sym mono">${i.symbol}</span><span class="mc-badge"></span></span>
      <span class="mc-row"><span class="mc-price mono">—</span><span class="mc-chg mono">—</span></span>
    </button>`).join('')}
  </section>`);

  const select = (sym) => el.querySelectorAll('.market-card').forEach((b) => {
    const on = b.dataset.symbol === sym;
    b.classList.toggle('is-active', on);
    b.setAttribute('aria-pressed', String(on));
  });
  el.addEventListener('click', (e) => {
    const b = e.target.closest('.market-card');
    if (b) store.set('symbol', b.dataset.symbol);
  });
  select(store.get('symbol'));
  const off = store.on('symbol', select);

  return {
    el,
    update(tickers) {
      for (const inst of INSTRUMENTS) {
        const tk = tickers[inst.symbol];
        const card = el.querySelector(`[data-symbol="${inst.symbol}"]`);
        if (!tk || !card) continue;
        // Not available with the current data plan: hide the card instead of showing an error.
        card.hidden = tk.mode === 'unavailable';
        if (card.hidden) continue;
        const price = card.querySelector('.mc-price');
        const chg = card.querySelector('.mc-chg');
        const badge = card.querySelector('.mc-badge');
        if (tk.mode === 'error') {
          price.textContent = '—';
          chg.textContent = '';
          badge.innerHTML = `<span class="badge badge-error" title="${esc(tk.error?.message || '')}">ERR</span>`;
          continue;
        }
        const prev = Number(price.dataset.v);
        // Values count smoothly to the new price instead of jumping (instant with reduced motion).
        tweenNumber(price, tk.price, (v) => fmtNum(v, inst.precision), 600);
        price.dataset.v = tk.price;
        if (Number.isFinite(prev) && prev !== tk.price) {
          flashDirection(price, tk.price > prev);
          card.classList.remove(tk.price > prev ? 'mc-down' : 'mc-up');
          replayClass(card, tk.price > prev ? 'mc-up' : 'mc-down'); // card glows green/red on each tick
        }
        drawSpark(card, tk.price);
        tweenNumber(chg, tk.changePct, (v) => fmtPct(v), 600);
        chg.className = `mc-chg mono ${tk.changePct >= 0 ? 'up' : 'down'}`;
        badge.innerHTML = tk.mode === 'demo'
          ? `<span class="badge badge-demo" title="${esc(t('status.demoBanner'))}">${esc(t('status.demo'))}</span>`
          : '';
        card.title = `${inst.symbol} · ${tk.source}${tk.mode === 'demo' ? ` · ${t('common.demo')}` : ''}`;
      }
    },
    destroy() { off(); },
  };
}
