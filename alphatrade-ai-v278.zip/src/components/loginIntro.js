// Full-screen welcome animation played right after a successful sign-in or sign-up.
// It lives on <body> (outside the routed #app), so the dashboard can render underneath it;
// when the steps finish, the overlay opens like an iris and reveals the dashboard.
import { esc } from '../utils/dom.js';
import { logoMark } from './icons.js';
import { t } from '../i18n/index.js';

let active = null;

/** True while the welcome animation is on screen; heavy work (AI training) should wait for it. */
export const introActive = () => Boolean(active);
export const introDone = () => (active ? active.done : Promise.resolve());

export function playLoginIntro(name = '', beforePlay) {
  if (active) return active.done;
  const reduce = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
  const steps = t('intro.steps');
  const el = document.createElement('div');
  el.className = `login-intro is-wait${reduce ? ' is-reduced' : ''}`;
  el.setAttribute('role', 'status');
  el.setAttribute('aria-live', 'polite');
  el.innerHTML = `
    <div class="li-bg"></div>
    <i class="li-ring li-r1"></i><i class="li-ring li-r2"></i><i class="li-ring li-r3"></i>
    <div class="li-floor"></div>
    <div class="li-rays"></div>
    <svg class="li-chart" viewBox="0 0 400 200" preserveAspectRatio="none" aria-hidden="true">
      <defs><linearGradient id="liCg" x1="0" y1="0" x2="1" y2="0"><stop offset="0" class="lg-a0"/><stop offset=".6" class="lg-a3"/><stop offset="1" class="lg-b"/></linearGradient>
        <linearGradient id="liCa" x1="0" y1="0" x2="0" y2="1"><stop offset="0" class="lg-a2" stop-opacity=".35"/><stop offset="1" class="lg-a2" stop-opacity="0"/></linearGradient></defs>
      <path class="li-area" d="M0 175 40 152 70 163 110 122 150 138 190 96 230 112 270 70 310 86 350 42 400 20V200H0Z" fill="url(#liCa)"/>
      <path class="li-line" d="M0 175 40 152 70 163 110 122 150 138 190 96 230 112 270 70 310 86 350 42 400 20" fill="none" stroke="url(#liCg)" stroke-width="2.6" stroke-linejoin="round" stroke-linecap="round" pathLength="100" vector-effect="non-scaling-stroke"/>
    </svg>
    <i class="li-scan"></i>
    <i class="li-c li-c1"></i><i class="li-c li-c2"></i><i class="li-c li-c3"></i><i class="li-c li-c4"></i>
    <div class="li-hud"><span>SECURE SESSION</span><span class="li-live">LIVE</span></div>
    <div class="li-particles">${Array.from({ length: 12 }, (_, i) => `<i style="--a:${i * 30}deg;--d:${(i % 6) * 0.05}s"></i>`).join('')}</div>
    <div class="li-particles li-p2">${Array.from({ length: 14 }, (_, i) => `<i style="--a:${i * 25.7}deg;--d:${(i % 5) * 0.04}s"></i>`).join('')}</div>
    <div class="li-core">
      <div class="li-logo"><span class="li-lock"></span><span class="li-orbit"></span>${logoMark(104)}</div>
      <h2 class="li-brand" aria-label="AlphaTrade AI">${[...'AlphaTrade'].map((c, i) => `<i style="--n:${i}">${c}</i>`).join('')} <span>${[...'AI'].map((c, i) => `<i style="--n:${10 + i}">${c}</i>`).join('')}</span></h2>
      <p class="li-hello">${esc(t('intro.welcome', { name: name || '' }).trim())}</p>
      <div class="li-stage"><ul class="li-steps">${steps.map((s, i) => `<li style="--i:${i}"><b class="li-check"><svg viewBox="0 0 24 24"><path d="m6 12.5 4 4 8-9" pathLength="1"/></svg></b><span>${esc(s)}</span></li>`).join('')}</ul><div class="li-granted"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="m5 12.5 4.5 4.5L19 7.5" pathLength="1"/></svg><span>${esc(t('intro.granted'))}</span></div></div>
      <div class="li-bar"><i></i></div>
      <div class="li-pct" aria-hidden="true"></div>
    </div>
    <button type="button" class="li-skip">${esc(t('intro.skip'))}</button>`;
  document.body.append(el);
  document.documentElement.classList.add('intro-lock');

  let finish;
  const done = new Promise((r) => { finish = r; });
  let closed = false;
  const close = () => {
    if (closed) return;
    closed = true;
    el.classList.add('is-leaving');
    setTimeout(() => {
      el.remove();
      document.documentElement.classList.remove('intro-lock');
      active = null;
      finish();
    }, reduce ? 250 : 900);
  };
  el.querySelector('.li-skip').addEventListener('click', close);
  active = { done };

  // The dashboard mounts underneath (charts, analysis) and blocks the main thread for up to
  // 1-2 s, which froze the animation mid-way. So the overlay first sits still and opaque while
  // the app mounts, and the animation only starts once frames are smooth again (max 2.5 s).
  let started = false;
  const go = () => {
    if (started || closed) return;
    started = true;
    el.classList.remove('is-wait');
    setTimeout(close, reduce ? 900 : 4500);
  };
  try { beforePlay?.(); } catch (e) { console.error(e); }
  if (reduce) go();
  else {
    const t0 = performance.now();
    let last = t0, calm = 0;
    const tick = (now) => {
      if (started || closed) return;
      calm = now - last < 34 ? calm + 1 : 0;
      last = now;
      if (calm >= 8 || now - t0 > 2500) go();
      else requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  }
  return done;
}
