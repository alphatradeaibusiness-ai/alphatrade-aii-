// Alpha AI assistant card with two modes: "Assistant" (market questions, answered ONLY from the dashboard's real
// snapshot) and "Technical support" (how to use the site). Both go through the site's AI gateway; nothing here is a
// canned answer — failures are shown as errors with their reason.
import { h, esc } from '../utils/dom.js';
import { icons, logoMark } from './icons.js';
import { t, getLang } from '../i18n/index.js';
import { checkAiHealth, sendAiMessage, sendSupportMessage } from '../services/ai/client.js';
import { onAiStatus } from '../services/ai/gateway.js';
import { aiErrorText } from './aiKeyCard.js';
import { describeError } from '../utils/http.js';
import { store } from '../state/store.js';
import { micButton } from '../services/voice.js';

const histories = { chat: [], support: [] }; // { role, content } — survives re-renders within the session
let health = null;
let mode = 'chat';

export function createAiAssistant({ getContext }) {
  const el = h(`<section class="card ai-card fade-in" style="animation-delay:460ms" aria-label="${esc(t('ai.title'))}">
    <div class="ai-head">
      <span class="ai-avatar logo-halo">${logoMark(26)}</span>
      <div class="ai-title"><b>${esc(t('ai.title'))}</b> <span class="brand-ai">${esc(t('ai.name'))}</span></div>
      <span class="ai-status" data-ai-status><span class="dot"></span><span>${esc(t('ai.checking'))}</span></span>
    </div>
    <div class="seg ai-modes" data-ai-modes role="tablist"><button type="button" data-v="chat" class="${mode === 'chat' ? 'is-on' : ''}">${esc(t('ai.modeChat'))}</button><button type="button" data-v="support" class="${mode === 'support' ? 'is-on' : ''}">${esc(t('ai.modeSupport'))}</button></div>
    <div class="ai-log" data-ai-log aria-live="polite"></div>
    <div class="ai-chips" data-ai-chips></div>
    <form class="ai-input" data-ai-form>
      <input type="text" name="q" maxlength="1000" autocomplete="off" placeholder="${esc(t('ai.placeholder'))}" aria-label="${esc(t('ai.placeholder'))}"/>
      <span data-ai-mic></span><button class="btn btn-primary ai-send" type="submit" aria-label="${esc(t('ai.send'))}"><span class="flip-rtl">${icons.send}</span></button>
    </form>
    <p class="ai-note" data-ai-note></p>
    <a class="ai-open-full" href="#/app/alpha">${icons.chat || ''}<span>${esc(getLang() === 'ar' ? 'افتح Alpha AI بشاشة كاملة' : 'Open Alpha AI full screen')}</span></a>
  </section>`);

  const log = el.querySelector('[data-ai-log]');
  const form = el.querySelector('[data-ai-form]');
  const input = form.q;
  el.querySelector('[data-ai-mic]').replaceWith(micButton(input, { lang: getLang, autoSend: () => form.requestSubmit(), label: 'Voice' }));
  const sendBtn = form.querySelector('button');
  let busy = false;

  const bubble = (role, text, cls = '') => {
    const b = h(`<div class="msg ${role} ${cls}"><div class="msg-body"></div></div>`);
    b.querySelector('.msg-body').textContent = text;
    log.append(b);
    log.scrollTop = log.scrollHeight;
    return b;
  };

  const history = () => histories[mode];
  function renderLog() {
    log.innerHTML = '';
    bubble('assistant', t(mode === 'support' ? 'ai.welcomeSupport' : 'ai.welcome'), 'welcome');
    history().forEach((m) => bubble(m.role, m.content));
  }

  function renderChips() {
    const sym = store.get('symbol');
    const chips = mode === 'support' ? [t('ai.sup1'), t('ai.sup2'), t('ai.sup3')] : [t('ai.s1'), t('ai.s2'), t('ai.s3', { symbol: sym })];
    el.querySelector('[data-ai-chips]').innerHTML = chips.map((c) => `<button type="button" class="chip">${esc(c)}</button>`).join('');
  }

  function renderStatus() {
    const st = el.querySelector('[data-ai-status]');
    if (!health) { st.innerHTML = `<span class="dot warn"></span><span>${esc(t('ai.checking'))}</span>`; return; }
    st.innerHTML = health.connected
      ? `<span class="dot ok"></span><span>${esc(t('ai.online'))}</span>`
      : `<span class="dot err"></span><span>${esc(t('ai.offline'))}</span>`;
    st.title = health.connected ? '' : t('ai.notConnected');
    const ctx = getContext?.();
    el.querySelector('[data-ai-note]').textContent = !health.connected
      ? (health.state === 'no_server' ? t('aiKey.line.noServer') : t('ai.notConnected'))
      : mode === 'support' ? t('ai.supportNote') : t('ai.contextNote', { mode: ctx?.mode === 'live' ? t('common.live') : t('common.demo') });
  }

  async function send(text) {
    const q = text.trim();
    if (!q || busy) return;
    busy = true;
    input.value = '';
    sendBtn.disabled = true;
    sendBtn.innerHTML = '<span class="spinner"></span>';
    const hist = history(); const m = mode;
    hist.push({ role: 'user', content: q });
    const userBubble = bubble('user', q);
    const typing = bubble('assistant', t('ai.thinking'), 'typing');
    try {
      const reply = m === 'support' ? await sendSupportMessage(hist, location.hash || '#/app', getLang()) : await sendAiMessage(hist, getContext?.(), getLang());
      typing.remove();
      hist.push({ role: 'assistant', content: reply });
      bubble('assistant', reply);
      if (!health?.connected) { health = { connected: true }; renderStatus(); }
    } catch (err) {
      typing.remove();
      hist.pop(); // do not keep an unanswered question in the context
      const errBubble = bubble('assistant', t('ai.error', { msg: err?.code && /^[a-z_]+$/.test(err.code) ? aiErrorText(err.code) : describeError(err, t) }), 'error');
      const retry = h(`<button type="button" class="btn btn-sm">${esc(t('common.retry'))}</button>`);
      retry.addEventListener('click', () => { errBubble.remove(); userBubble.remove(); send(q); });
      errBubble.append(retry);
    } finally {
      busy = false;
      sendBtn.disabled = false;
      sendBtn.innerHTML = `<span class="flip-rtl">${icons.send}</span>`;
      input.focus();
    }
  }

  form.addEventListener('submit', (e) => { e.preventDefault(); send(input.value); });
  el.querySelector('[data-ai-modes]').addEventListener('click', (e) => {
    const b = e.target.closest('[data-v]'); if (!b || busy) return;
    mode = b.dataset.v;
    el.querySelectorAll('[data-ai-modes] button').forEach((x) => x.classList.toggle('is-on', x === b));
    renderLog(); renderChips(); renderStatus();
  });
  el.querySelector('[data-ai-chips]').addEventListener('click', (e) => { const c = e.target.closest('.chip'); if (c) send(c.textContent); });

  renderLog();
  renderChips();
  renderStatus();
  checkAiHealth().then((hl) => { health = hl; renderStatus(); });
  // The owner saved / replaced / deleted the key: every open assistant updates at once.
  const offAi = onAiStatus((st) => { health = { connected: st.state === 'connected' || st.state === 'unchecked', state: st.state }; renderStatus(); });
  const off = store.on('symbol', renderChips);

  return { el, refresh: renderStatus, destroy: () => { off(); offAi(); } };
}
