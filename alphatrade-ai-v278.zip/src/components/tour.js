// First-visit tour: four short cards that point to the main parts of the app. Shown once per account, skippable.
import { esc } from '../utils/dom.js';
import { t } from '../i18n/index.js';
import { icons } from './icons.js';
import { storage } from '../utils/storage.js';
import { openModal } from './ui.js';

const STEPS = [['chart', 'candles', null], ['assistant', 'brain', null], ['signals', 'bolt', '#/app/signals'], ['safety', 'shield', '#/app/trust']];
const T = (k, p) => t(`lg.tour.${k}`, p);
const keyFor = (uid) => `tour:v1:${uid || 'guest'}`;

export const tourSeen = (uid) => Boolean(storage.get(keyFor(uid), false));
export const markTourSeen = (uid) => storage.set(keyFor(uid), true);

export function openTour(uid) {
  let i = 0;
  openModal(T('title'), (body, close) => {
    const done = () => { markTourSeen(uid); close(); };
    const draw = () => {
      const [k, ic, link] = STEPS[i]; const last = i === STEPS.length - 1;
      body.innerHTML = `<div class="tour">
        <div class="tour-ic">${icons[ic] || ''}</div>
        <h3>${esc(T(`${k}.h`))}</h3><p>${esc(T(`${k}.p`))}</p>
        <div class="tour-dots" aria-hidden="true">${STEPS.map((_, j) => `<span class="${j === i ? 'is-on' : ''}"></span>`).join('')}</div>
        <div class="tour-act">
          <button type="button" class="btn btn-ghost btn-sm" data-skip>${esc(T('skip'))}</button>
          <span class="tour-gap"></span>
          ${link ? `<a class="btn btn-ghost btn-sm" href="${link}" data-go>${esc(T('open'))}</a>` : ''}
          ${i ? `<button type="button" class="btn btn-ghost btn-sm" data-prev>${esc(T('prev'))}</button>` : ''}
          <button type="button" class="btn btn-primary btn-sm" data-next>${esc(last ? T('done') : T('next'))}</button>
        </div>
        <p class="tour-step">${esc(T('step', { n: i + 1, of: STEPS.length }))}</p></div>`;
      body.querySelector('[data-skip]').onclick = done;
      body.querySelector('[data-prev]')?.addEventListener('click', () => { i--; draw(); });
      body.querySelector('[data-next]').onclick = () => { if (last) done(); else { i++; draw(); } };
      body.querySelector('[data-go]')?.addEventListener('click', done);
      body.querySelector('[data-next]').focus();
    };
    draw();
  });
  // closing with ✕ / Escape also counts as seen
  markTourSeen(uid);
}

/** Open the tour once, a moment after the app is ready, unless another dialog is already open. */
export function maybeTour(uid) {
  if (!uid || tourSeen(uid) || document.querySelector('.modal-backdrop')) return;
  openTour(uid);
}
