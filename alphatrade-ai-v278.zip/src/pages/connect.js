// "Alerts & links": where alerts reach you (app, push, Telegram, e-mail), what you get, TradingView webhook, recent sign-ins.
import { h, esc } from '../utils/dom.js';
import { getLang } from '../i18n/index.js';
import { icons } from '../components/icons.js';
import { toast } from '../components/ui.js';
import { apiRequest } from '../services/ai/gateway.js';

const L = (ar, en) => (getLang() !== 'ar' ? en : ar);
const CCY = ['USD', 'EUR', 'GBP', 'JPY', 'CHF', 'CAD', 'AUD', 'NZD', 'CNY'];
const when = (ms) => new Date(ms).toLocaleString(getLang() === 'ar' ? 'ar-EG-u-nu-latn' : 'en-GB', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
const tog = (name, label, sub, on) => `<label class="sa-tog"><span>${esc(label)}${sub ? `<small>${esc(sub)}</small>` : ''}</span><input type="checkbox" role="switch" name="${name}" ${on ? 'checked' : ''}><i aria-hidden="true"></i></label>`;

export function renderConnect() {
  const el = h(`<section class="subpage connect page-enter">
    <header class="subpage-head"><h1>${esc(L('التنبيهات والربط', 'Alerts & links'))}</h1><p class="muted">${esc(L('كل تسجيل دخول لحسابك بيوصلك تنبيه. اختار وين بدك التنبيهات توصلك وشو بدك يوصلك.', 'Every sign-in to your account sends you an alert. Choose where alerts reach you and what you get.'))}</p></header>
    <div class="cn-grid" data-c><article class="card tool-card"><p class="muted">…</p></article></div></section>`);
  const box = el.querySelector('[data-c]');
  const paint = (c) => {
    const tg = c.telegram; const p = c.prefs;
    const tvUrl = `${c.base || location.origin}${c.tvPath}`;
    box.innerHTML = `
      <article class="card tool-card cn-card">
        <h2 class="card-title">${icons.shield || ''}<span>${esc(L('تنبيه تسجيل الدخول', 'Sign-in alerts'))}</span></h2>
        <p class="tool-note">${esc(L('أي حدا بيسجّل دخول لحسابك (حتى إنت) بيوصلك فورًا: بالجرس هون، وإشعار عالجهاز، وتليغرام إذا ربطته، وإيميل. إذا بيجي من جهاز جديد منكتبلك «جهاز جديد».', 'Anyone who signs in to your account (you too) triggers an alert right away: in the bell here, as a push, on Telegram if linked, and by e-mail. A new device is marked “new device”.'))}</p>
        <h4 class="sa-h">${esc(L('آخر تسجيلات الدخول', 'Recent sign-ins'))}</h4>
        ${c.logins.length ? `<ul class="cn-logins">${c.logins.map((x) => `<li><span class="nt-ic">${icons.shield || ''}</span><span><b>${esc(x.device)}</b>${x.newDevice ? ` <em class="badge badge-warn">${esc(L('جهاز جديد', 'new device'))}</em>` : ''}<small class="muted">${esc(when(x.at))} · <bdi dir="ltr">${esc(x.ip || "—")}</bdi></small></span></li>`).join('')}</ul>` : `<p class="muted">—</p>`}
        <p class="muted tool-note">${esc(L('مش إنت؟ غيّر كلمة المرور من الملف الشخصي فورًا، وشغّل المصادقة الثنائية بالبنك ← الأمان.', 'Not you? Change your password in Profile right away and turn on two-factor in Bank → Security.'))}</p>
        <a class="btn btn-sm" href="#/app/profile">${icons.lock || ''}<span>${esc(L('غيّر كلمة المرور', 'Change password'))}</span></a>
      </article>
      <article class="card tool-card cn-card">
        <h2 class="card-title">${icons.send || icons.bell}<span>${esc(L('تليغرام', 'Telegram'))}</span></h2>
        ${!tg.configured ? `<p class="muted">${esc(L('صاحب الموقع لسا ما ربط بوت تليغرام.', 'The site owner has not connected a Telegram bot yet.'))}</p>`
        : tg.linked ? `<p class="tool-note"><span class="badge badge-live">${esc(L('مربوط', 'Linked'))}</span> ${esc(L('التنبيهات بتوصلك على تليغرام.', 'Alerts reach you on Telegram.'))}</p><button type="button" class="btn btn-sm" data-tg-off>${esc(L('افصل تليغرام', 'Unlink Telegram'))}</button>`
        : `<p class="tool-note">${esc(L('اكبس الزر، بينفتح تليغرام، اكبس «Start». خلص.', 'Press the button, Telegram opens, press “Start”. Done.'))}</p><button type="button" class="btn btn-primary btn-sm" data-tg-on>${icons.send || ''}<span>${esc(L('اربط تليغرام', 'Link Telegram'))}</span></button>`}
      </article>
      <article class="card tool-card cn-card">
        <h2 class="card-title">${icons.bell || ''}<span>${esc(L('شو بدك يوصلك', 'What you get'))}</span></h2>
        <form data-prefs>
          ${tog('emailLogin', L('إيميل عند كل تسجيل دخول', 'E-mail on every sign-in'), c.mail ? '' : L('الإيميل مش مفعّل على الموقع لسا', 'E-mail is not set up on this site yet'), p.emailLogin)}
          ${tog('emailExpiry', L('تذكير قبل ما الاشتراك يخلص', 'Reminder before my plan ends'), '', p.emailExpiry)}
          ${tog('emailWeekly', L('تقرير أسبوعي بالإيميل', 'Weekly report by e-mail'), L('كل يوم اثنين، إذا عندك صفقات مسكّرة', 'Mondays, when you have closed trades'), p.emailWeekly)}
          ${tog('news', L('تنبيه قبل الأخبار القوية بـ 15 دقيقة', 'Alert 15 min before high-impact news'), L('من المفكرة الاقتصادية', 'From the economic calendar'), p.news)}
          <div class="sa-chips cn-ccy" ${p.news ? '' : 'hidden'}>${CCY.map((x) => `<label class="sa-chip"><input type="checkbox" name="ccy" value="${x}" ${p.newsCcy.includes(x) ? 'checked' : ''}><span>${x}</span></label>`).join('')}</div>
          <p class="muted tool-note cn-ccy" ${p.news ? '' : 'hidden'}>${esc(L('ما اخترت ولا عملة = كل العملات.', 'None selected = all currencies.'))}</p>
        </form>
      </article>
      <article class="card tool-card cn-card">
        <h2 class="card-title">${icons.bolt || ''}<span>${esc(L('تنبيهات TradingView', 'TradingView alerts'))}</span></h2>
        <p class="tool-note">${esc(L('بـ TradingView ← Alert ← Notifications ← Webhook URL، الزق هالرابط. أي تنبيه منك هناك بيوصلك هون وعلى تليغرام. الرابط سرّي: لا تشاركه.', 'In TradingView → Alert → Notifications → Webhook URL, paste this link. Your alerts there arrive here and on Telegram. The link is secret: do not share it.'))}</p>
        <div class="cn-url"><input class="input mono" dir="ltr" readonly value="${esc(tvUrl)}" data-tv><button type="button" class="btn btn-sm" data-tv-copy>${esc(L('انسخ', 'Copy'))}</button></div>
        <p class="muted tool-note" dir="ltr">{"ticker":"{{ticker}}","message":"{{strategy.order.action}} @ {{close}}"}</p>
        <button type="button" class="btn btn-sm btn-ghost" data-tv-new>${esc(L('رابط جديد (القديم بيوقف)', 'New link (the old one stops)'))}</button>
      </article>`;
    const f = box.querySelector('[data-prefs]');
    f.addEventListener('change', async () => {
      const v = { emailLogin: f.emailLogin.checked, emailExpiry: f.emailExpiry.checked, emailWeekly: f.emailWeekly.checked, news: f.news.checked, newsCcy: [...f.querySelectorAll('[name=ccy]:checked')].map((x) => x.value) };
      box.querySelectorAll('.cn-ccy').forEach((x) => { x.hidden = !v.news; });
      try { await apiRequest('PUT', '/api/me/prefs', v); toast(L('انحفظ', 'Saved'), 'success', 1500); } catch { toast(L('ما انحفظ، جرّب كمان مرة.', 'Not saved, try again.'), 'error'); }
    });
    box.querySelector('[data-tg-on]')?.addEventListener('click', async () => {
      try { const r = await apiRequest('POST', '/api/me/telegram/link', {}); window.open(r.url, '_blank', 'noopener'); toast(L('اكبس Start بتليغرام، وبعدين ارجع هون.', 'Press Start in Telegram, then come back.'), 'info', 7000); setTimeout(load, 12000); }
      catch { toast(L('ما قدرنا نجهّز الرابط.', 'Could not prepare the link.'), 'error'); }
    });
    box.querySelector('[data-tg-off]')?.addEventListener('click', async () => { await apiRequest('DELETE', '/api/me/telegram').catch(() => {}); load(); });
    box.querySelector('[data-tv-copy]').addEventListener('click', async () => { try { await navigator.clipboard.writeText(box.querySelector('[data-tv]').value); toast(L('انسخ', 'Copied'), 'success', 1500); } catch { box.querySelector('[data-tv]').select(); } });
    box.querySelector('[data-tv-new]').addEventListener('click', async () => { try { const r = await apiRequest('POST', '/api/me/tv/regenerate', {}); box.querySelector('[data-tv]').value = `${c.base || location.origin}${r.tvPath}`; toast(L('رابط جديد جاهز. حدّثه بـ TradingView.', 'New link ready. Update it in TradingView.'), 'success'); } catch { /* */ } });
  };
  const channel = async () => {
    let g; try { g = await apiRequest('GET', '/api/tg-gate/me'); } catch { return; } if (!g.enabled) return;
    const card = document.createElement('article'); card.className = 'card tool-card cn-card'; box.querySelector('[data-tgch]')?.remove(); card.dataset.tgch = '1';
    card.innerHTML = `<h2 class="card-title">${icons.send || ''}<span>${esc(L('قناة المشتركين على تلغرام', 'Subscribers’ Telegram channel'))}</span></h2>
      ${g.member ? `<p class="tool-note"><span class="badge badge-live">${esc(L('عضو', 'Member'))}</span> ${esc(L('إنت بالقناة. عضويتك مربوطة باشتراكك — إذا خلص الاشتراك بتنشال تلقائيًا.', 'You are in the channel. Membership follows your plan — it is removed automatically when the plan ends.'))}</p>` : ''}
      ${!g.linked ? `<p class="tool-note">${esc(L('١) اربط تليغرام من البطاقة اللي فوق. ٢) لازم يكون عندك اشتراك فعّال. ٣) بيطلعلك رابط القناة هون.', '1) Link Telegram in the card above. 2) You need an active plan. 3) The channel link appears here.'))}</p>`
        : !g.active ? `<p class="tool-note">${esc(L('القناة للمشتركين بس. اشترك وبيطلعلك رابط الدخول هون.', 'The channel is for subscribers only. Subscribe and the join link appears here.'))}</p><a class="btn btn-sm btn-primary" href="#/app/pricing">${esc(L('الباقات', 'Plans'))}</a>`
        : g.inviteLink && !g.member ? `<p class="tool-note">${esc(L('اضغط الرابط واطلب الانضمام — البوت بيتحقق من اشتراكك وبيقبلك خلال ثواني.', 'Open the link and request to join — the bot checks your plan and approves you in seconds.'))}</p><a class="btn btn-sm btn-primary" target="_blank" rel="noopener" href="${esc(g.inviteLink)}">✈️ ${esc(L('ادخل القناة', 'Join the channel'))}</a>` : ''}`;
    box.append(card);
  };
  const load = () => apiRequest('GET', '/api/me/connect').then((c) => { paint(c); channel(); }).catch(() => { box.innerHTML = `<article class="card tool-card"><p class="muted">${esc(L('الخدمة مش متاحة هلأ.', 'Not available right now.'))}</p></article>`; });
  load();
  return el;
}
