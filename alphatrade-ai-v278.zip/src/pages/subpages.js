// Secondary pages opened from the top navigation.
import { h, esc, fmtNum, fmtPct, fmtCompact } from '../utils/dom.js';
import { icons, assetIcon } from '../components/icons.js';
import { t } from '../i18n/index.js';
import { INSTRUMENTS, STOP_LOSS_POINTS } from '../config/instruments.js';
import { getTickers } from '../services/market/index.js';
import { describeError } from '../utils/http.js';
import { store } from '../state/store.js';
import { navigate } from '../router.js';
import { createIndicatorPanel } from '../components/indicatorPanel.js';

function shell(titleKey, sub = '') {
  return h(`<section class="subpage page-enter"><header class="subpage-head"><h1>${esc(t(titleKey))}</h1>${sub ? `<p class="muted">${esc(sub)}</p>` : ''}</header><div class="subpage-body"></div></section>`);
}

function steps(items, numbered = true) {
  return `<div class="step-grid">${items.map(([title, body], i) => `<article class="card step fade-in" style="animation-delay:${i * 40}ms">
    ${numbered ? `<span class="step-n mono">${i + 1}</span>` : `<span class="step-n">${icons.sparkle}</span>`}<h3>${esc(title)}</h3><p>${esc(body)}</p></article>`).join('')}</div>`;
}

export function renderGuide() {
  const el = shell('pages.guideTitle');
  el.querySelector('.subpage-body').innerHTML = steps(t('pages.guide'));
  return el;
}

export function renderStrategies() {
  const el = shell('pages.strategiesTitle', t('pages.strategiesNote'));
  const pts = INSTRUMENTS.map((i) => `<tr><td class="mono">${i.symbol}</td><td class="mono">${store.get('settings').pointSizes[i.symbol]}</td><td class="mono">${+(store.get('settings').pointSizes[i.symbol] * STOP_LOSS_POINTS).toFixed(6)}</td></tr>`).join('');
  el.querySelector('.subpage-body').innerHTML = `${steps(t('pages.strategies'), false)}
    <article class="card step"><h3>${esc(t('settings.points'))}</h3><p class="muted">${esc(t('settings.pointsHelp'))}</p>
    <table class="kv-table wide-table"><thead><tr><th>${esc(t('pages.colSymbol'))}</th><th>${esc(t('plan.point'))}</th><th>${STOP_LOSS_POINTS} × </th></tr></thead><tbody>${pts}</tbody></table></article>`;
  return el;
}

export function renderMarkets() {
  const el = shell('pages.marketsTitle', t('pages.marketsSub'));
  const body = el.querySelector('.subpage-body');
  body.innerHTML = `<div class="card table-card"><div class="table-scroll"><table class="kv-table wide-table markets-table">
    <thead><tr><th>${esc(t('pages.colSymbol'))}</th><th>${esc(t('pages.colPrice'))}</th><th>${esc(t('pages.colChange'))}</th><th>${esc(t('pages.colHigh'))}</th><th>${esc(t('pages.colLow'))}</th><th>${esc(t('pages.colVolume'))}</th><th>${esc(t('pages.colSource'))}</th><th></th></tr></thead>
    <tbody>${INSTRUMENTS.map((i) => `<tr data-row="${i.symbol}"><td><span class="sym-cell">${assetIcon(i.icon, 22)}<span class="mono">${i.symbol}</span></span></td><td colspan="7" class="muted">${esc(t('common.loading'))}</td></tr>`).join('')}</tbody>
  </table></div></div>`;
  getTickers().then((tk) => {
    for (const i of INSTRUMENTS) {
      const r = tk[i.symbol];
      const row = body.querySelector(`[data-row="${i.symbol}"]`);
      if (!row) continue;
      if (r?.mode === 'unavailable') { row.remove(); continue; }
      const cells = !r || r.mode === 'error'
        ? `<td colspan="6" class="down">${esc(r?.error ? describeError(r.error, t) : '—')}</td>`
        : `<td class="mono">${fmtNum(r.price, i.precision)}</td><td class="mono ${r.changePct >= 0 ? 'up' : 'down'}">${fmtPct(r.changePct)}</td>
           <td class="mono">${fmtNum(r.high, i.precision)}</td><td class="mono">${fmtNum(r.low, i.precision)}</td><td class="mono">${r.volume ? fmtCompact(r.volume) : '—'}</td>
           <td>${esc(r.source)} ${r.mode === 'demo' ? `<span class="badge badge-demo">${esc(t('status.demo'))}</span>` : `<span class="badge badge-live">${esc(t('common.live'))}</span>`}</td>`;
      row.innerHTML = `<td><span class="sym-cell">${assetIcon(i.icon, 22)}<span class="mono">${i.symbol}</span></span></td>${cells}<td><button class="btn btn-sm" data-open="${i.symbol}">${esc(t('pages.open'))}</button></td>`;
    }
  }).catch((err) => { body.prepend(h(`<div class="alert alert-error">${icons.alert}<div>${esc(describeError(err, t))}</div></div>`)); });
  body.addEventListener('click', (e) => {
    const b = e.target.closest('[data-open]');
    if (b) { store.set('symbol', b.dataset.open); navigate('#/app'); }
  });
  return el;
}

export function renderIndicators({ getDashboard }) {
  const el = shell('pages.indicatorsTitle', t('ind.title'));
  const an = getDashboard()?.getAnalysis();
  el.querySelector('.subpage-body').append(h('<div class="card ind-card"></div>'));
  el.querySelector('.ind-card').append(createIndicatorPanel({
    hasVolume: an ? an.hasVolume : undefined,
    onPickFrvp: () => { navigate('#/app'); setTimeout(() => getDashboard()?.startTool('frvp'), 80); },
    onPickFib: () => { navigate('#/app'); setTimeout(() => getDashboard()?.startTool('fib'), 80); },
  }));
  return el;
}
