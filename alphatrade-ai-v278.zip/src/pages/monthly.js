import { whileMounted, onUnmount } from './tools/common.js';
import { currentMonthTrades, monthKeyAt } from '../services/currentMonth.js';
// "Monthly pips" page: net points (pips) per calendar month for every strategy and the strongest one,
// chosen automatically. Backtest on the last 1000 candles of the chosen timeframe (1h / 4h reach back months).
import { h, esc } from '../utils/dom.js';
import { t, getLang } from '../i18n/index.js';
import { INSTRUMENTS, getInstrument, STOP_LOSS_POINTS, TARGET_POINTS } from '../config/instruments.js';
import { getHistory, isUnavailable } from '../services/market/index.js';
import { backtestClassic, backtestSmc, backtestZone, backtestEdh, backtestLbr, summarize, rulesFrom } from '../services/backtest.js';
import { lbrHistory } from '../services/lbrData.js';
import { stratName } from '../services/stratName.js';
import { store } from '../state/store.js';
import { isReal, realOnlyCard } from '../components/realOnly.js';
import { pipPoints } from '../services/pips.js';
import { KEYS, signPts } from '../components/monthlyCards.js';

const TFS = ['15m', '1h', '4h'];
const state = { symbol: null, tf: '4h', cap: null };

export function renderMonthly() {
  const ar = getLang() === 'ar';
  const list = INSTRUMENTS.filter((i) => !isUnavailable(i.symbol));
  const saved = store.get('symbol');
  if (!state.symbol || !list.some((i) => i.symbol === state.symbol)) state.symbol = list.some((i) => i.symbol === saved) ? saved : list[0]?.symbol;
  if (state.cap == null) state.cap = Number(store.get('settings').risk?.monthlyLossPts) > 0 ? Number(store.get('settings').risk.monthlyLossPts) : 1000;
  const el = h(`<section class="subpage perf monthly page-enter">
    <header class="subpage-head"><h1>${ar ? 'نتائج الشهر الحالي' : 'Current month results'}</h1><p class="muted">${ar ? 'نتائج محاكاة للشهر الحالي فقط، حسب تاريخ إغلاق الصفقة بتوقيت القدس. ليست أرباح حساب حقيقي.' : 'Current-month simulation only, by trade close date in Jerusalem time. Not actual account profit.'}</p></header>
    <div class="card perf-controls fade-in">
      <label class="perf-field"><span>${esc(t('perf.symbol'))}</span>
        <select class="select" data-symbol>${list.map((i) => `<option value="${i.symbol}" ${i.symbol === state.symbol ? 'selected' : ''}>${i.symbol}</option>`).join('')}</select></label>
      <div class="perf-field"><span>${esc(t('perf.timeframe'))}</span>
        <div class="seg" data-tfs>${TFS.map((tf) => `<button type="button" data-tf="${tf}" class="${tf === state.tf ? 'is-on' : ''}">${esc(t(`perf.tf.${tf}`))}</button>`).join('')}</div></div>
      <label class="perf-field"><span>${esc(t('mo.cap'))}</span><input class="input mono" type="number" min="0" step="100" value="${state.cap}" data-cap style="width:130px"/></label>
    </div>
    <div class="perf-source muted" data-source></div>
    <div data-body></div>
  </section>`);
  const body = el.querySelector('[data-body]');
  let token = 0;
  let renderedMonth = monthKeyAt();

  async function load() {
    const my = ++token;
    body.innerHTML = `<div class="card perf-loading"><span class="spinner"></span><span>${esc(t('perf.loading'))}</span></div>`;
    el.querySelector('[data-source]').textContent = '';
    const ds = await getHistory(state.symbol, state.tf, 1000);
    await new Promise((r) => setTimeout(r, 30));
    if (my !== token || !el.isConnected) return;
    if (!isReal(ds)) { body.innerHTML = realOnlyCard(ds); body.querySelector('[data-retry]')?.addEventListener('click', () => load()); return; }
    const inst = getInstrument(state.symbol);
    const st = store.get('settings');
    const pointSize = Number(st.pointSizes?.[state.symbol]) > 0 ? Number(st.pointSizes[state.symbol]) : inst.pointSize;
    const rules = { ...rulesFrom({ ...st, risk: { ...st.risk, monthlyLossPts: state.cap, monthlyLossBySymbol: {} } }, inst), forced: null, pointSize, slPoints: STOP_LOSS_POINTS, tpPoints: TARGET_POINTS, volumeKind: ds.volumeKind };
    // LBR is defined on 5-minute candles: it always runs on its own deep 5m history (Binance only), whatever timeframe is picked here.
    const lbrDs = await lbrHistory(state.symbol);
    if (my !== token || !el.isConnected) return;
    const runs = { classic: backtestClassic(ds.candles, rules), smc: backtestSmc(ds.candles, rules), zone: backtestZone(ds.candles, rules), edh: backtestEdh(ds.candles, rules), lbr: lbrDs ? backtestLbr(lbrDs.candles, { ...rules, volumeKind: lbrDs.volumeKind }) : { trades: [] } };
    const now = new Date();
    const key = monthKeyAt(now);
    const pp = pipPoints(inst);
    const period = new Intl.DateTimeFormat(ar ? 'ar' : 'en', { month: 'long', year: 'numeric', timeZone: 'Asia/Jerusalem' }).format(now);
    el.querySelector('[data-source]').textContent = `${state.symbol} · ${state.tf} · ${period}`;
    body.innerHTML = `<article class="card"><h2>${esc(period)}</h2><p class="muted">${ar ? 'المتاح من الشموع قد لا يغطي كامل الشهر؛ النتائج تخص هذه العينة فقط. الربح والخسارة بعد التكاليف المضبوطة بالموقع، والصفقات المفتوحة مستبعدة.' : 'Available candles may not cover the full month. Results cover this sample only, after configured costs; open trades excluded.'}</p><div class="current-month-grid">${KEYS.map(k => {
      const trades = currentMonthTrades(runs[k].trades, now);
      const total = summarize(trades).total;
      return `<section class="card"><h3>${esc(stratName(k))}</h3><b class="mono ${total.points < 0 ? 'down' : 'up'}">${signPts(total.points / pp)} ${ar ? 'بيب' : 'pips'}</b><p>${trades.length} ${ar ? 'صفقة مغلقة' : 'closed trades'}</p><p class="up">${ar ? 'ربح' : 'Gross wins'}: ${signPts(total.grossWin / pp)}</p><p class="down">${ar ? 'خسارة' : 'Gross losses'}: ${signPts(-total.grossLoss / pp)}</p><small>${ar ? 'نسبة النجاح' : 'Win rate'}: ${trades.length ? total.winRate.toFixed(1) + '%' : '—'}</small></section>`;
    }).join('')}</div><p class="muted">${ar ? 'لا تُجمع الأشهر السابقة مع هذا الشهر ولا تُحذف سجلاتها.' : 'Previous months are neither accumulated here nor deleted.'}</p></article>`;
    renderedMonth = key;

  }

  el.querySelector('[data-cap]').addEventListener('change', (e) => { state.cap = Math.max(0, Number(e.target.value) || 0); load(); });
  el.querySelector('[data-symbol]').addEventListener('change', (e) => { state.symbol = e.target.value; load(); });
  el.querySelector('[data-tfs]').addEventListener('click', (e) => {
    const b = e.target.closest('[data-tf]'); if (!b) return;
    state.tf = b.dataset.tf;
    el.querySelectorAll('[data-tf]').forEach((x) => x.classList.toggle('is-on', x === b));
    load();
  });
  whileMounted(el, () => { if (monthKeyAt() !== renderedMonth) { renderedMonth = monthKeyAt(); load(); } }, 1000);
  onUnmount(el, () => { ++token; });
  load();
  return el;
}
