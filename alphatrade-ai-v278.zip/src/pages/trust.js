// Trust Center: where the data comes from (with the live status of each market right now), how signals and the AI work and
// where they stop, what is stored about the user and how it is protected, the security measures that are switched on,
// the risk disclosure, this device's activity log and a short glossary. Every section opens with a one-line summary and
// explains each column / value it shows.
import { h, esc } from '../utils/dom.js';
import { t, getLang } from '../i18n/index.js';
import { icons } from '../components/icons.js';
import { INSTRUMENTS } from '../config/instruments.js';
import { getTickers } from '../services/market/index.js';
import { MIN_ACCURACY, MIN_TRADES, MIN_OOS_ACC, MIN_OOS_TRADES } from '../services/signals.js';
import { auditLog, clearAudit } from '../services/audit.js';
import { downloadText, csvText } from './tools/common.js';

const T = (k, p) => t(`tc.${k}`, p);
const fill = (s) => String(s).replace('{acc}', MIN_ACCURACY).replace('{n}', MIN_TRADES).replace('{oos}', MIN_OOS_ACC).replace('{m}', MIN_OOS_TRADES);
const SECTIONS = [['data', 'bars'], ['signals', 'bell'], ['ai', 'brain'], ['storage', 'lock'], ['security', 'shield'], ['risk', 'alert'], ['audit', 'journal'], ['glossary', 'info']];
const ic = (k) => icons[k] || icons.sparkle || '';
const head = (id, lead) => `<div class="tc-sec-head"><h2 class="card-title">${ic(SECTIONS.find((s) => s[0] === id)[1])}<span>${esc(T(`nav.${id}`))}</span></h2><p class="tc-lead"><b>${esc(T('inShort'))}:</b> ${esc(lead)}</p></div>`;
const dl = (pairs) => `<dl class="tc-dl">${pairs.map(([k, v]) => `<div><dt>${esc(fill(k))}</dt><dd>${esc(fill(v))}</dd></div>`).join('')}</dl>`;

export function renderTrust() {
  const storeRows = T('store.rows');
  const el = h(`<section class="subpage trust tc page-enter">
    <div class="subpage-head"><h1>${icons.shield}<span>${esc(t('trust.title'))}</span></h1><p class="muted">${esc(T('sub'))}</p><p class="tc-live"><span class="tc-dot"></span>${esc(T('updated'))}</p></div>

    <div class="tc-kpis fade-in">
      <div class="tc-kpi"><span>${ic('bars')}${esc(T('kpi.data'))}</span><b data-kpi-data>…</b></div>
      <div class="tc-kpi"><span>${ic('bell')}${esc(T('kpi.rule'))}</span><b>${esc(fill(T('kpi.ruleVal')))}</b></div>
      <div class="tc-kpi"><span>${ic('lock')}${esc(T('kpi.enc'))}</span><b class="mono">${esc(T('kpi.encVal'))}</b></div>
      <div class="tc-kpi"><span>${ic('journal')}${esc(T('kpi.log'))}</span><b data-kpi-log>…</b></div>
    </div>

    <nav class="tc-nav fade-in" aria-label="${esc(t('trust.title'))}">${SECTIONS.map(([id, icon]) => `<a href="#tc-${id}" data-jump="${id}">${ic(icon)}<span>${esc(T(`nav.${id}`))}</span></a>`).join('')}</nav>

    <article class="card tool-card tc-sec fade-in" id="tc-data">${head('data', T('data.lead'))}
      ${dl(T('data.sources'))}
      <h3 class="tc-h3">${esc(T('data.legendTitle'))}</h3>
      <div class="tc-legend">${['live', 'demo', 'unavailable'].map((m) => `<div><span class="badge ${m === 'live' ? 'badge-live' : m === 'demo' ? 'badge-demo' : 'badge-error'}">${esc(t(`trust.mode.${m}`))}</span><p>${esc(T(`data.legend.${m}`))}</p></div>`).join('')}</div>
      <div class="tc-status-head"><h3 class="tc-h3">${esc(t('trust.statusTitle'))}</h3><div class="seg" data-filter>${['all', 'live', 'demo', 'unavailable'].map((m, i) => `<button type="button" data-v="${m}" class="${i ? '' : 'is-on'}">${esc(m === 'all' ? T('data.all') : t(`trust.mode.${m}`))}</button>`).join('')}</div></div>
      <p class="muted tool-note" data-sum></p>
      <div data-status><p class="muted">${esc(t('common.loading'))}</p></div>
      <p class="muted tool-note">${esc(t('trust.statusNote'))}</p>
    </article>

    <article class="card tool-card tc-sec fade-in" id="tc-signals">${head('signals', T('sig.lead'))}
      <h3 class="tc-h3">${esc(T('sig.rulesTitle'))}</h3>
      <div class="table-scroll"><table class="kv-table tc-table tc-stack"><thead><tr><th>${esc(T('sig.cols.rule'))}</th><th>${esc(T('sig.cols.value'))}</th><th>${esc(T('sig.cols.why'))}</th></tr></thead>
        <tbody>${T('sig.rules').map(([a, b, c]) => `<tr><td data-l="${esc(T('sig.cols.rule'))}"><b>${esc(a)}</b></td><td data-l="${esc(T('sig.cols.value'))}" class="mono tc-val">${esc(fill(b))}</td><td data-l="${esc(T('sig.cols.why'))}">${esc(c)}</td></tr>`).join('')}</tbody></table></div>
      <h3 class="tc-h3">${esc(T('sig.stepsTitle'))}</h3>
      <ol class="tc-steps">${T('sig.steps').map((x) => `<li>${esc(x)}</li>`).join('')}</ol>
      <p class="muted tool-note">${esc(T('sig.note'))}</p>
    </article>

    <article class="card tool-card tc-sec fade-in" id="tc-ai">${head('ai', T('ai.lead'))}
      <div class="tc-two"><div class="tc-yes"><h3 class="tc-h3">✓ ${esc(T('ai.doesTitle'))}</h3><ul>${T('ai.does').map((x) => `<li>${esc(x)}</li>`).join('')}</ul></div>
        <div class="tc-no"><h3 class="tc-h3">✗ ${esc(T('ai.doesntTitle'))}</h3><ul>${T('ai.doesnt').map((x) => `<li>${esc(x)}</li>`).join('')}</ul></div></div>
    </article>

    <article class="card tool-card tc-sec fade-in" id="tc-storage">${head('storage', T('store.lead'))}
      <div class="table-scroll"><table class="kv-table tc-table tc-store tc-stack"><thead><tr><th>${esc(T('store.cols.item'))}</th><th>${esc(T('store.cols.where'))}</th><th>${esc(T('store.cols.protect'))}</th><th>${esc(T('store.cols.who'))}</th></tr></thead>
        <tbody>${storeRows.map((r) => `<tr><td data-l="${esc(T('store.cols.item'))}"><b>${esc(r[0])}</b></td><td data-l="${esc(T('store.cols.where'))}">${esc(r[1])}</td><td data-l="${esc(T('store.cols.protect'))}">${esc(r[2])}</td><td data-l="${esc(T('store.cols.who'))}">${esc(r[3])}</td></tr>`).join('')}</tbody></table></div>
      <p class="muted tool-note">${esc(T('store.note'))}</p>
    </article>

    <article class="card tool-card tc-sec fade-in" id="tc-security">${head('security', T('sec.lead'))}
      <div class="tc-grid">${T('sec.items').map(([a, b]) => `<div class="tc-tile"><b>${ic('shield')}${esc(a)}</b><p>${esc(b)}</p></div>`).join('')}</div>
    </article>

    <article class="card tool-card tc-sec trust-risk fade-in" id="tc-risk">${head('risk', T('risk.lead'))}
      <ul class="tc-risk">${T('risk.items').map((x) => `<li>${esc(x)}</li>`).join('')}</ul>
    </article>

    <article class="card tool-card tc-sec fade-in" id="tc-audit">${head('audit', T('audit.lead'))}
      <dl class="tc-dl tc-dl-cols">${['when', 'action', 'details'].map((k) => { const [a, b] = T(`audit.cols.${k}`).split(' — '); return `<div><dt>${esc(a)}</dt><dd>${esc(b || '')}</dd></div>`; }).join('')}</dl>
      <p class="muted tool-note">${esc(t('trust.auditSub'))}</p>
      <div data-audit></div>
      <p class="muted tool-note">${esc(T('audit.csvNote'))}</p>
    </article>

    <article class="card tool-card tc-sec fade-in" id="tc-glossary">${head('glossary', T('glossaryLead'))}
      <div class="tc-gloss">${T('glossary').map(([a, b]) => `<details><summary>${esc(a)}</summary><p>${esc(b)}</p></details>`).join('')}</div>
    </article>
  </section>`);
  const $ = (s) => el.querySelector(s);

  // In-page navigation without touching the router's hash.
  el.querySelectorAll('[data-jump]').forEach((a) => a.addEventListener('click', (e) => { e.preventDefault(); el.querySelector(`#tc-${a.dataset.jump}`)?.scrollIntoView({ behavior: 'smooth', block: 'start' }); }));

  // Live data status, straight from the market layer (the same call the dashboard uses).
  let rows = []; let filter = 'all';
  const drawStatus = () => {
    const shown = filter === 'all' ? rows : rows.filter((r) => r.mode === filter);
    $('[data-status]').innerHTML = `<div class="table-scroll"><table class="kv-table tc-table"><thead><tr><th>${esc(T('data.cols.symbol'))}</th><th>${esc(T('data.cols.type'))}</th><th>${esc(T('data.cols.source'))}</th><th>${esc(T('data.cols.refresh'))}</th><th>${esc(T('data.cols.state'))}</th></tr></thead><tbody>
      ${shown.map((r) => `<tr><td class="mono"><b>${esc(r.symbol)}</b></td><td>${esc(T(`data.type.${r.type}`) || r.type)}</td><td>${esc(r.source)}</td><td>${esc(T(`data.refresh.${r.provider === 'binance' ? 'stream' : 'poll'}`))}</td>
        <td><span class="badge ${r.mode === 'live' ? 'badge-live' : r.mode === 'demo' ? 'badge-demo' : 'badge-error'}">${esc(t(`trust.mode.${r.mode}`))}</span></td></tr>`).join('') || `<tr><td colspan="5" class="muted">—</td></tr>`}
      </tbody></table></div>`;
  };
  $('[data-filter]').addEventListener('click', (e) => {
    const b = e.target.closest('[data-v]'); if (!b) return; filter = b.dataset.v;
    $('[data-filter]').querySelectorAll('button').forEach((x) => x.classList.toggle('is-on', x === b)); drawStatus();
  });
  getTickers().then((tk) => {
    rows = INSTRUMENTS.map((i) => { const x = tk[i.symbol] || {}; return { symbol: i.symbol, type: i.type, provider: i.provider, source: x.source || (i.provider === 'binance' ? 'Binance' : 'Twelve Data'), mode: x.mode || 'unavailable' }; });
    const n = (m) => rows.filter((r) => r.mode === m).length;
    $('[data-sum]').textContent = T('data.summary', { l: n('live'), d: n('demo'), u: n('unavailable') });
    $('[data-kpi-data]').textContent = T('kpi.dataOf', { l: n('live'), t: rows.length });
    drawStatus();
  }).catch(() => { $('[data-status]').innerHTML = `<p class="down">${esc(t('trust.statusFail'))}</p>`; $('[data-kpi-data]').textContent = '—'; });

  const when = (ms) => new Date(ms).toLocaleString(getLang() === 'ar' ? 'ar-EG-u-nu-latn' : 'en-GB', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit' });
  const actName = (a) => { const k = `trust.act.${String(a).replace(/\./g, '_')}`; const v = t(k); return v === k ? a : v; };
  let actFilter = '';
  const drawAudit = () => {
    const log = auditLog();
    $('[data-kpi-log]').textContent = T('kpi.logVal', { n: log.length });
    const acts = [...new Set(log.map((e) => e.action))];
    const shown = actFilter ? log.filter((e) => e.action === actFilter) : log;
    $('[data-audit]').innerHTML = log.length ? `<div class="tc-audit-bar"><label class="tc-field"><span>${esc(T('audit.filter'))}</span><select class="select" data-act><option value="">${esc(T('audit.any'))}</option>${acts.map((a) => `<option value="${esc(a)}" ${a === actFilter ? 'selected' : ''}>${esc(actName(a))}</option>`).join('')}</select></label>
      <div class="trust-actions"><button type="button" class="btn btn-sm" data-a-csv>${icons.download || ''}<span>CSV</span></button><button type="button" class="btn btn-sm btn-ghost" data-a-clear>${esc(t('trust.clear'))}</button></div></div>
      <div class="table-scroll"><table class="kv-table tc-table"><thead><tr><th>${esc(t('trust.when'))}</th><th>${esc(t('trust.action'))}</th><th>${esc(t('trust.details'))}</th></tr></thead><tbody>
      ${shown.slice(0, 100).map((e) => `<tr><td class="mono">${esc(when(e.at))}</td><td><b>${esc(actName(e.action))}</b></td><td class="mono trust-det">${esc(Object.entries(e.details || {}).map(([k, v]) => `${k}: ${v}`).join(' · ') || '—')}</td></tr>`).join('')}
      </tbody></table></div>`
      : `<p class="muted">${esc(t('trust.auditEmpty'))}</p>`;
    $('[data-act]')?.addEventListener('change', (e) => { actFilter = e.target.value; drawAudit(); });
    $('[data-a-csv]')?.addEventListener('click', () => downloadText('alphatrade-audit-log.csv', [['time', 'action', 'details']].concat(log.map((e) => [new Date(e.at).toISOString(), csvText(e.action), csvText(JSON.stringify(e.details))])).map((r) => r.join(',')).join('\n')));
    $('[data-a-clear]')?.addEventListener('click', () => { if (window.confirm(t('trust.clearConfirm'))) { clearAudit(); actFilter = ''; drawAudit(); } });
  };
  drawAudit();
  return el;
}
