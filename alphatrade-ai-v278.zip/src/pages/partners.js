// v255 ALPHA PARTNER CLUB — partner dashboard (rank, benefits, referral center, earnings, progression, history) and the
// owners' control panel (program switch, 100 levels, 9 ranks & benefits, 7-plan commission matrix, financial protection,
// payouts, commissions review, partners, audit, CSV export). Every number shown comes from the server (server/partners.js);
// this page never calculates or confirms money — the preview in the matrix editor is labelled as a preview.
import { h, esc, fmtNum } from '../utils/dom.js';
import { icons } from '../components/icons.js';
import { getLocale, getLang } from '../i18n/index.js';
import { tx } from '../i18n/tx.js';
import { apiRequest, apiBlobUrl } from '../services/ai/gateway.js';
import { toast } from '../components/ui.js';
import { RANKS, PRICE_TIERS, rankOfLevel } from '../config/partnerRanks.js';
import { errText } from './community.js';
import '../styles/partners.css';

const L = (ar, en) => tx({ ar, en });
const $usd = (c) => `\u2066${c < 0 ? '−' : ''}$${fmtNum(Math.abs(c || 0) / 100, 2)}\u2069`;   // isolated LTR, also inside RTL text
const date = (t) => (t ? new Date(t).toLocaleDateString(getLocale(), { year: 'numeric', month: 'short', day: 'numeric' }) : '—');
const rk = (id) => RANKS.find((r) => r.id === id) || RANKS[0];
const rname = (id) => tx(rk(id).name);
const ERR = {
  program_disabled: ['البرنامج مش مفعّل حاليًا من الإدارة.', 'The program is not enabled by the owners yet.'], payout_open: ['عندك طلب سحب مفتوح.', 'You already have an open payout request.'],
  payout_details: ['اكتب طريقة وبيانات استلام صحيحة.', 'Enter a valid payout method and account.'], below_minimum: ['الرصيد المتاح أقل من الحد الأدنى للسحب.', 'Available balance is below the minimum payout.'],
  invalid_config: ['الإعدادات انرفضت (أو رابط القناة مش t.me): عمولة التجديد لازم تكون أقل من العميل الجديد، وكل مستوى لازم أكبر من اللي قبله.', 'Settings refused: renewal commission must be lower than new, and each level must be higher than the previous one.'], reason_required: ['اكتب السبب.', 'Enter a reason.'], reference_required: ['اكتب مرجع الدفع (رقم الحوالة/العملية).', 'Enter the payment reference.'],
  bad_state: ['الحالة ما بتسمح بهالإجراء.', 'Not allowed in the current state.'], forbidden: ['لأصحاب المنصة بس.', 'Owners only.'], partner_inactive: ['حساب الشريك موقوف.', 'Partner account is suspended.'], no_secret: ['التخزين المشفّر مش مضبوط على السيرفر (AI_KEY_SECRET).', 'Encrypted storage is not set on the server (AI_KEY_SECRET).'],
};
const err = (e) => { const c = e?.code || e; const x = ERR[c]; return x ? L(x[0], x[1]) : errText(c); };
const KIND = { new: ['عميل جديد', 'New customer'], renewal: ['تجديد', 'Renewal'], rank_bonus: ['مكافأة رتبة', 'Rank bonus'], level_reward: ['مكافأة مستوى', 'Level reward'], promo: ['مكافأة ترويجية', 'Promo bonus'], clawback: ['استرجاع', 'Clawback'], adjustment: ['تعديل', 'Adjustment'] };
const STATUS = { pending: ['قيد الحجز', 'On hold'], review: ['قيد المراجعة', 'In review'], approved: ['معتمدة', 'Approved'], rejected: ['مرفوضة', 'Rejected'], reversed: ['ملغاة (استرداد)', 'Reversed (refund)'], paid: ['مدفوعة', 'Paid'], none: ['بدون عمولة', 'No commission'], requested: ['مطلوب', 'Requested'] };
const kind = (k) => L(...(KIND[k] || [k, k])); const st = (s) => `<span class="pc-st is-${esc(s)}">${esc(L(...(STATUS[s] || [s, s])))}</span>`;

function badge(id, size = 64, label = '') {
  const r = rk(id); const g = `pcg${id}${size}`;
  return `<svg class="pc-badge" viewBox="0 0 100 100" width="${size}" height="${size}" style="width:${size}px;height:${size}px" aria-label="${esc(rname(id))}"><defs><linearGradient id="${g}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${r.metal[1]}"/><stop offset=".55" stop-color="${r.color}"/><stop offset="1" stop-color="${r.metal[0]}"/></linearGradient></defs>
    <polygon points="50,4 91,27 91,73 50,96 9,73 9,27" fill="url(#${g})" stroke="rgba(255,255,255,.55)" stroke-width="2"/><polygon points="50,16 80,33 80,67 50,84 20,67 20,33" fill="rgba(5,10,25,.55)"/>
    <text x="50" y="${label ? 52 : 58}" text-anchor="middle" font-size="${id === 'legend' ? 22 : 24}" font-weight="900" fill="${r.metal[1]}" font-family="system-ui">${id === 'legend' ? 'α' : esc(rk(id).name.en[0])}</text>${label ? `<text x="50" y="70" text-anchor="middle" font-size="13" font-weight="800" fill="#fff" font-family="system-ui">${esc(label)}</text>` : ''}</svg>`;
}


/* ── v256 showcase (dashboard header like the reference design; every number is the server's) ── */
const EMBLEM = {
  core: '<polygon points="50,30 66,39 66,57 50,66 34,57 34,39" fill="none" stroke="currentColor" stroke-width="5"/><circle cx="50" cy="48" r="6" fill="currentColor"/>',
  star: '<path d="M50 27l6.5 13.5 14.5 2-10.5 10 2.6 14.5L50 60l-13.1 7 2.6-14.5-10.5-10 14.5-2z" fill="currentColor"/>',
  crown: '<path d="M30 60l-4-24 13 11 11-16 11 16 13-11-4 24z" fill="currentColor"/><rect x="30" y="62" width="40" height="6" rx="2" fill="currentColor"/>',
  gem: '<path d="M34 40l8-10h16l8 10-16 26z" fill="currentColor"/><path d="M34 40h32M42 30l8 10 8-10M50 40v26" stroke="rgba(0,0,0,.35)" stroke-width="2" fill="none"/>',
  wings: '<path d="M50 30l5 10 11 1.6-8 7.6 2 11L50 55l-10 5.2 2-11-8-7.6 11-1.6z" fill="currentColor"/><path d="M18 40c8 2 12 8 14 16-6-1-11-6-14-16zM82 40c-8 2-12 8-14 16 6-1 11-6 14-16z" fill="currentColor" opacity=".8"/>',
};
const EMB_OF = { core: 'core', bronze: 'star', silver: 'star', gold: 'crown', platinum: 'star', diamond: 'gem', master: 'wings', elite: 'wings', legend: 'crown' };
function shield(id, size = 80, { glow = false, locked = false } = {}) {
  const r = rk(id); const g = `sh${id}${size}${Math.random().toString(36).slice(2, 6)}`;
  return `<svg class="pc-shield${glow ? ' is-glow' : ''}${locked ? ' is-locked' : ''}" viewBox="0 0 100 112" style="width:${size}px;height:${size * 1.12}px;--c:${r.color}" aria-label="${esc(rname(id))}">
    <defs><linearGradient id="${g}a" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${r.metal[1]}"/><stop offset=".45" stop-color="${r.color}"/><stop offset="1" stop-color="${r.metal[0]}"/></linearGradient>
      <linearGradient id="${g}b" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#1b2550"/><stop offset="1" stop-color="#060b1c"/></linearGradient>
      <linearGradient id="${g}s" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#fff" stop-opacity="0"/><stop offset=".5" stop-color="#fff" stop-opacity=".55"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></linearGradient>
      <clipPath id="${g}c"><path d="M50 4l40 14v34c0 27-17 46-40 56C27 98 10 79 10 52V18z"/></clipPath></defs>
    ${id === 'legend' || id === 'gold' ? `<path d="M14 70c-8-10-9-24-4-36M86 70c8-10 9-24 4-36" stroke="${r.metal[1]}" stroke-width="3" fill="none" stroke-linecap="round" opacity=".8"/>` : ''}
    <path d="M50 4l40 14v34c0 27-17 46-40 56C27 98 10 79 10 52V18z" fill="url(#${g}a)"/>
    <path d="M50 14l31 11v27c0 21-13 36-31 44-18-8-31-23-31-44V25z" fill="url(#${g}b)"/>
    <g style="color:${r.metal[1]}" transform="translate(0,4)">${EMBLEM[EMB_OF[id]]}</g>
    <g clip-path="url(#${g}c)"><rect class="pc-shine" x="-60" y="0" width="40" height="112" fill="url(#${g}s)" transform="skewX(-18)"/></g>
    ${id === 'gold' || id === 'legend' ? `<rect x="24" y="80" width="52" height="15" rx="4" fill="url(#${g}a)"/><text x="50" y="91.5" text-anchor="middle" font-size="10" font-weight="900" fill="#1a1205" font-family="system-ui">${id === 'gold' ? 'GOLD' : 'LEGEND'}</text>` : ''}</svg>`;
}
function animate(el) {
  const reduce = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
  el.querySelectorAll('[data-count]').forEach((n) => {
    const to = Number(n.dataset.count); const fmt = (v) => (n.dataset.money ? $usd(Math.round(v)) : n.dataset.pct ? `${(Math.round(v * 10) / 10).toFixed(1)}%` : fmtNum(Math.round(v), 0));
    if (reduce || !to) { n.textContent = fmt(to); return; }
    const t0 = performance.now(); const D = 1100; const step = (t) => { const k = Math.min(1, (t - t0) / D); n.textContent = fmt(to * (1 - (1 - k) ** 3)); if (k < 1) requestAnimationFrame(step); }; requestAnimationFrame(step);
  });
  requestAnimationFrame(() => el.querySelectorAll('[data-w]').forEach((b) => { b.style.width = `${b.dataset.w}%`; }));
}

/** v258 earnings growth chart: cumulative REAL earnings since joining (smooth steps, glowing nodes, animated draw). */
function growthChart(d) {
  const W = 720, H = 260, P = { l: 34, r: 34, t: 44, b: 34 };
  const t0 = d.joinedAt || Date.now(), t1 = Math.max(Date.now(), t0 + 86_400_000);
  // one node per day (the last running total of that day), at most 14 nodes
  const byDay = new Map(); for (const g of d.growth || []) byDay.set(new Date(g.t).toISOString().slice(0, 10), g);
  let pts = [...byDay.values()]; if (pts.length > 14) { const step = pts.length / 13; pts = [...Array.from({ length: 13 }, (_, i) => pts[Math.floor(i * step)]), pts.at(-1)]; }
  const maxV = Math.max(1, ...pts.map((x) => x.cents));
  // evenly spaced steps (each step is labelled with its real date), like a progress path
  const raw = [{ v: 0, t: t0 }, ...pts.map((g) => ({ v: g.cents, t: g.t }))]; raw.push({ v: raw.at(-1).v, t: t1, end: true });
  const span = W - P.l - P.r; const Y = (v) => H - P.b - (Math.max(0, v) / maxV) * (H - P.t - P.b);
  const nodes = raw.map((n, i) => ({ ...n, x: P.l + (i / (raw.length - 1)) * span, y: Y(n.v) }));
  const endV = nodes.at(-1).v;
  let path = `M${nodes[0].x.toFixed(1)} ${nodes[0].y.toFixed(1)}`;
  for (let i = 1; i < nodes.length; i++) { const a = nodes[i - 1], b = nodes[i]; const xm = a.x + (b.x - a.x) * 0.55; path += ` C${xm.toFixed(1)} ${a.y.toFixed(1)} ${(a.x + (b.x - a.x) * 0.75).toFixed(1)} ${b.y.toFixed(1)} ${b.x.toFixed(1)} ${b.y.toFixed(1)}`; }
  const area = `${path} L${nodes.at(-1).x.toFixed(1)} ${H - P.b} L${nodes[0].x.toFixed(1)} ${H - P.b} Z`;
  const lbl = nodes.length <= 6 ? nodes.slice(1) : nodes.slice(1).filter((_, i, arr) => i % Math.ceil(arr.length / 5) === 0 || i === arr.length - 1);
  const dots = Array.from({ length: 46 }, (_, i) => { const n = nodes[1 + (i % Math.max(1, nodes.length - 1))] || nodes[0]; const x = P.l + ((i * 97) % (W - P.l - P.r)); const yTop = Y(maxV * (0.25 + ((i * 37) % 70) / 100)) || P.t; return `<circle cx="${x}" cy="${Math.min(H - P.b - 10, yTop + ((i * 13) % 40))}" r="${(i % 3) * 0.5 + 0.6}" style="--d:${(i % 9) * 0.4}s" />`; void n; }).join('');
  const shortD = (t) => new Date(t).toLocaleDateString(getLocale(), { month: 'short', day: 'numeric' });
  const mid = nodes.slice(1, -1).filter((n) => n.v !== 0 || true);
  const id = `gc${Math.random().toString(36).slice(2, 7)}`;
  return `<section class="pcx-card pcx-growth"><h3>📈 ${L('مخطط نمو الأرباح', 'Earnings growth')}<button type="button" class="pcx-min" data-gmin aria-label="toggle">—</button></h3>
    <div class="pcx-gbody">${pts.length ? '' : `<p class="pcx-gnote">${L('المنحنى بيطلع مع أول عمولة حقيقية إلك.', 'The curve rises with your first real commission.')}</p>`}
    <svg class="pcx-gsvg" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" role="img" aria-label="${esc(L('نمو الأرباح', 'Earnings growth'))}">
      <defs><linearGradient id="${id}s" x1="0" x2="1"><stop offset="0" stop-color="#fb7185"/><stop offset=".3" stop-color="#a3e635"/><stop offset=".7" stop-color="#4ade80"/><stop offset="1" stop-color="#67e8f9"/></linearGradient>
        <linearGradient id="${id}f" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#22c55e" stop-opacity=".45"/><stop offset=".6" stop-color="#0ea5e9" stop-opacity=".28"/><stop offset="1" stop-color="#1e3a8a" stop-opacity=".1"/></linearGradient>
        <linearGradient id="${id}v" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff" stop-opacity="0"/><stop offset="1" stop-color="#03060f" stop-opacity=".55"/></linearGradient>
        <filter id="${id}g" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="3.2" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs>
      ${nodes.slice(1).map((n) => `<line x1="${n.x}" x2="${n.x}" y1="${P.t - 10}" y2="${H - P.b}" class="pcx-gv"/>`).join('')}
      <path d="${area}" fill="url(#${id}f)" class="pcx-garea"/><path d="${area}" fill="url(#${id}v)" opacity=".6"/>
      <g class="pcx-gdots">${dots}</g>
      <path d="${path}" fill="none" stroke="url(#${id}s)" stroke-width="4" stroke-linecap="round" filter="url(#${id}g)" class="pcx-gline" pathLength="1"/>
      ${mid.map((n, i) => `<g class="pcx-gnode" style="--d:${0.5 + (i / Math.max(1, mid.length)) * 1.3}s"><circle cx="${n.x}" cy="${n.y}" r="9" fill="${n.x < W * 0.35 ? '#a3e635' : n.x < W * 0.7 ? '#4ade80' : '#67e8f9'}" opacity=".25"/><circle cx="${n.x}" cy="${n.y}" r="4.5" fill="#ecfeff"/><title>${shortD(n.t)} · ${$usd(n.v)}</title></g>`).join('')}
      <g class="pcx-gnode" style="--d:.2s"><circle cx="${nodes[0].x}" cy="${nodes[0].y}" r="9" fill="#fb7185" opacity=".3"/><rect x="${nodes[0].x - 4.5}" y="${nodes[0].y - 4.5}" width="9" height="9" rx="1.5" transform="rotate(45 ${nodes[0].x} ${nodes[0].y})" fill="#fda4af"/></g>
      <g class="pcx-gnode is-end" style="--d:1.9s"><circle cx="${nodes.at(-1).x}" cy="${nodes.at(-1).y}" r="13" fill="#bae6fd" opacity=".25"/><circle cx="${nodes.at(-1).x}" cy="${nodes.at(-1).y}" r="7" fill="#e0f2fe" stroke="#38bdf8" stroke-width="3"/></g>
      <g class="pcx-gtag" style="--d:.4s"><rect x="${nodes[0].x - 4}" y="${nodes[0].y - 40}" width="70" height="24" rx="12"/><text x="${nodes[0].x + 31}" y="${nodes[0].y - 24}">${L('البداية', 'Start')}</text></g>
      <g class="pcx-gtag is-end" style="--d:2s"><rect x="${nodes.at(-1).x - 150}" y="${Math.max(4, nodes.at(-1).y - 42)}" width="150" height="24" rx="12"/><text x="${nodes.at(-1).x - 75}" y="${Math.max(4, nodes.at(-1).y - 42) + 16}">${L('المستوى الحالي', 'Current level')} · ${$usd(endV)}</text></g>
      ${lbl.map((n) => `<text x="${n.x}" y="${H - 10}" class="pcx-gx">${n.end ? L('اليوم', 'Today') : esc(shortD(n.t))}</text>`).join('')}
    </svg></div></section>`;
}

function showcase(d, r, link) {
  const E = d.earnings; const nextR = d.nextRank ? rk(d.nextRank.id) : null; const curIdx = RANKS.findIndex((x) => x.id === r.id);
  const lastUp = (d.rankHistory || []).filter((x) => x.to > x.from).at(-1); const upRank = lastUp && rankOfLevel(lastUp.to).id !== rankOfLevel(lastUp.from).id && Date.now() - lastUp.at < 14 * 86_400_000 ? rankOfLevel(lastUp.to).id : null;
  const pctToRank = nextR ? Math.max(0, Math.min(100, Math.round(((d.qualified - (d.ranks[curIdx]?.req || 0)) / Math.max(1, d.nextRank.req - (d.ranks[curIdx]?.req || 0))) * 100))) : 100;
  const bn = (k) => tx(d.benefitNames[k] || { ar: k, en: k });
  const shown = d.benefits.unlocked.filter((b) => !['dashboard', 'link', 'coupon'].includes(b)).slice(0, 5);
  const evIcon = { new: '🎁', renewal: '🔄', rank_bonus: '🏆', level_reward: '⭐', promo: '✨', clawback: '↩️', adjustment: '⚙️' };
  return `<div class="pcx">
    <header class="pcx-banner"><div class="pcx-crown">${shield('legend', 54)}</div><div class="pcx-title"><h1><span>ALPHA</span> PARTNER CLUB</h1><p>${L('شارك • اكبر • اربح', 'Refer • Grow • Earn')}</p></div>
      <svg class="pcx-chart" viewBox="0 0 260 90" aria-hidden="true"><defs><linearGradient id="pcxg" x1="0" x2="1"><stop offset="0" stop-color="#22d3ee" stop-opacity=".1"/><stop offset="1" stop-color="#38bdf8"/></linearGradient></defs>
        ${[0, 1, 2, 3, 4, 5].map((i) => `<rect class="pcx-bar" style="--i:${i}" x="${120 + i * 22}" y="${70 - i * 10}" width="14" height="${20 + i * 10}" rx="2" fill="url(#pcxg)"/>`).join('')}
        <path class="pcx-line" d="M0 80 C60 76 90 60 130 54 S200 30 250 8" fill="none" stroke="#7dd3fc" stroke-width="3"/><path d="M238 6l14 2-6 12" fill="none" stroke="#7dd3fc" stroke-width="3"/></svg>
      <div class="pcx-slogan">${L('نجاحك<br>هو نجاحنا', 'Your Success<br>Our Success')}</div></header>
    <div class="pcx-row3">
      <section class="pcx-card pcx-rank" style="--c:${r.color}"><h3>🏆 ${L('رتبتك الحالية', 'Your current rank')}<a href="#" data-jump="#pc-path" class="pcx-go">→</a></h3>
        <div class="pcx-rank-b">${shield(r.id, 104, { glow: true })}<div><b class="pcx-rname">${esc(rname(r.id))}</b><span class="pcx-lv">${L('المستوى', 'Level')} ${d.level} / 100</span>
          <div class="pcx-bar2"><i data-w="${d.progressPct}"></i></div><span class="pcx-pct">${d.progressPct}%</span>
          <small class="pcx-left">👥 ${nextR ? L(`باقي ${d.nextRank.left} إحالة لرتبة ${esc(tx(nextR.name))}`, `${d.nextRank.left} more referrals to reach ${esc(tx(nextR.name))}`) : L('أعلى رتبة! 🎉', 'Top rank! 🎉')}</small></div></div></section>
      <section class="pcx-card pcx-earn"><h3>📊 ${L('أرباحك', 'Your earnings')}<a href="#" data-jump="#pc-earn" class="pcx-go">→</a></h3>
        <b class="pcx-big" data-count="${E.lifetime}" data-money="1">${$usd(0)}</b><span class="pcx-cap">${L('إجمالي الأرباح', 'Total earnings')}</span>
        <div class="pcx-split"><div><b data-count="${E.newLifetime}" data-money="1">${$usd(0)}</b><small>${L('عملاء جدد', 'New customers')}</small></div><div><b data-count="${E.renewalLifetime}" data-money="1">${$usd(0)}</b><small>${L('تجديدات', 'Renewals')}</small></div><div><b class="is-av" data-count="${E.available}" data-money="1">${$usd(0)}</b><small>${L('رصيد متاح', 'Available balance')}</small></div></div></section>
      <section class="pcx-card pcx-ref"><h3>🔗 ${L('مركز الإحالة', 'Your referral center')}</h3>
        <div class="pcx-copy"><span>🔗</span><input dir="ltr" readonly value="${esc(link)}"><button type="button" data-copy="${esc(link)}" title="copy">⧉</button></div>
        <a class="pcx-tg" target="_blank" rel="noopener" href="https://t.me/share/url?url=${encodeURIComponent(link)}&text=${encodeURIComponent(L(`انضم لـ AlphaTrade AI عن طريقي — كوبون: ${d.code}`, `Join AlphaTrade AI with my link — coupon: ${d.code}`))}">✈️ ${L('شارك على تلغرام', 'Share on Telegram')}</a>
        <div class="pcx-copy is-code"><span>🏷️</span><input dir="ltr" readonly value="${esc(d.code)}"><button type="button" data-copy="${esc(d.code)}" title="copy">⧉</button></div>
        <div class="pcx-kpis"><div><i>👆</i><b data-count="${d.referral.clicks}">0</b><small>${L('نقرات', 'Clicks')}</small></div><div><i>👥</i><b data-count="${d.referral.registrations}">0</b><small>${L('تسجيلات', 'Registrations')}</small></div><div><i>✅</i><b data-count="${d.referral.paying}">0</b><small>${L('عملاء دافعين', 'Paid customers')}</small></div><div><i>🎯</i><b data-count="${d.referral.conversionPct}" data-pct="1">0%</b><small>${L('التحويل', 'Conversion')}</small></div></div></section>
    </div>
    ${growthChart(d)}
    <section class="pcx-card pcx-track"><h3>⭐ ${L('مسار رتبك', 'Your rank progression')}<a href="#" data-jump="#pc-path" class="pcx-go">${L('كل الرتب', 'View all ranks')} →</a></h3>
      <div class="pcx-line2"><i data-w="${Math.round((curIdx / (RANKS.length - 1)) * 100)}"></i></div>
      <div class="pcx-steps">${RANKS.map((x, i) => `<div class="pcx-step${i < curIdx ? ' is-done' : ''}${i === curIdx ? ' is-cur' : ''}" style="--c:${x.color};--d:${i * 70}ms">${shield(x.id, i === curIdx ? 66 : 54, { glow: i === curIdx, locked: i > curIdx })}<b>${esc(tx(x.name))}</b><small>${x.from}${x.to !== x.from ? `–${x.to}` : ''}</small>${i === curIdx ? `<em>${L('رتبتك', 'Current rank')}</em>` : ''}</div>`).join('')}</div></section>
    <div class="pcx-row3 pcx-low">
      <section class="pcx-card pcx-bens"><h3>💎 ${L('مزايا رتبتك', 'Your rank benefits')}</h3><ul>${shown.map((b) => `<li>✔ ${esc(bn(b))}</li>`).join('') || `<li>✔ ${esc(bn('commission'))}</li>`}</ul><div class="pcx-crownart">${shield(r.id, 64)}</div>
        <a href="#" data-jump="#pc-bens" class="pcx-btn">${L('كل المزايا', 'View all benefits')} →</a></section>
      <section class="pcx-card pcx-act"><h3>🕒 ${L('آخر النشاط', 'Recent activity')}<a href="#" data-jump="#pc-hist" class="pcx-go">${L('الكل', 'View all')} →</a></h3>
        ${d.history.length ? `<table><thead><tr><th>${L('التاريخ', 'Date')}</th><th>${L('الحدث', 'Event')}</th><th>${L('الخطة', 'Plan')}</th><th>${L('العمولة', 'Amount')}</th><th>${L('الحالة', 'Status')}</th></tr></thead><tbody>${d.history.slice(0, 5).map((x, i) => `<tr style="--d:${i * 80}ms"><td>${date(x.at)}</td><td>${evIcon[x.kind] || '•'} ${esc(kind(x.kind))}</td><td>${$usd(x.listCents)}</td><td class="${x.amountCents >= 0 ? 'up' : 'down'}">\u2066${x.amountCents >= 0 ? '+' : ''}${$usd(x.amountCents)}\u2069</td><td>${st(x.status)}</td></tr>`).join('')}</tbody></table>`
          : `<div class="pcx-empty">🚀 ${L('لسا ما في نشاط. شارك رابطك وأول عميل دافع بيبيّن هون.', 'No activity yet. Share your link — your first paying customer shows up here.')}</div>`}</section>
      <section class="pcx-card pcx-cong${upRank ? ' is-up' : ''}" style="--c:${rk(upRank || nextR?.id || r.id).color}"><div class="pcx-rocket">🚀</div><div class="pcx-spark"></div>
        ${upRank ? `<h4>${L('مبروك!', 'Congratulations!')}</h4><p>${L(`وصلت رتبة ${esc(rname(upRank))}!`, `You've reached ${esc(rname(upRank))} Rank!`)}</p>`
          : nextR ? `<h4>${L('الهدف الجاي', 'Next goal')}</h4><p>${L(`رتبة ${esc(tx(nextR.name))} — باقي ${d.nextRank.left} عميل (${pctToRank}%)`, `${esc(tx(nextR.name))} rank — ${d.nextRank.left} to go (${pctToRank}%)`)}</p>`
          : `<h4>${L('أسطورة ألفا!', 'Alpha Legend!')}</h4><p>${L('وصلت القمة.', 'You reached the top.')}</p>`}
        <a href="#" data-jump="#pc-path" class="pcx-btn is-gold">${L('التفاصيل', 'View details')} →</a></section>
    </div></div>`;
}

/* ───────────────────────── partner dashboard ───────────────────────── */
export function renderPartners() {
  const root = h(`<section class="subpage tool pc page-enter"><div data-body><div class="perf-loading"><span class="spinner"></span></div></div></section>`);
  const body = root.querySelector('[data-body]');
  async function load() {
    try { const d = await apiRequest('GET', '/api/partners/me'); body.replaceChildren(d.gated ? gated(d) : d.joined ? dash(d) : intro(d)); import('../services/partnerGate.js').then((m) => m.refreshPartnerGate({ fresh: false })).catch(() => {}); }
    catch (e) { body.innerHTML = `<div class="alert alert-error">${icons.alert}<div>${esc(err(e))}</div></div>`; }
  }
  function gated(g) {
    const why = { tg_not_linked: L('حسابك مش مربوط بتلغرام لسا.', 'Your account is not linked to Telegram yet.'), not_member: L('حساب التلغرام المربوط مش عضو بالقناة.', 'Your linked Telegram account is not a member of the channel.'), check_failed: L('ما قدرنا نتحقق هلّق — جرّب كمان شوي.', 'Could not verify right now — try again shortly.'), telegram_not_configured: L('القناة لسا مش مضبوطة من الإدارة.', 'The channel is not set up by the owners yet.') }[g.reason] || '';
    const el = h(`<div class="pc-wrap"><section class="pc-hero pc-gate"><div class="pc-hero-t"><small>ALPHA PARTNER CLUB</small><h1>${L('حصري لأعضاء قناة التلغرام', 'Exclusive to our Telegram channel members')}</h1>
      <p>${L('النادي مفتوح بس للي منضمين لقناتنا على تلغرام. خطوتين وبتفتحلك القائمة:', 'The club is open only to members of our Telegram channel. Two steps and it unlocks:')}</p>
      <ol class="pc-steps"><li class="${g.tgLinked ? 'is-ok' : ''}"><b>1</b><div><strong>${L('اربط حسابك بتلغرام', 'Link your account to Telegram')}</strong><small>${L('من «الإشعارات والربط» ← اربط تليغرام ← Start.', 'In “Notifications & connect” → Link Telegram → Start.')}</small></div><a class="btn btn-sm" href="#/app/connect">${g.tgLinked ? '✔' : L('اربط', 'Link')}</a></li>
        <li class="${g.reason === 'not_member' ? '' : g.tgLinked && g.allowed ? 'is-ok' : ''}"><b>2</b><div><strong>${L('انضم للقناة بنفس حساب التلغرام', 'Join the channel with the same Telegram account')}</strong><small>${L('لازم يكون نفس الحساب اللي ربطته.', 'It must be the account you linked.')}</small></div>${g.inviteUrl ? `<a class="btn btn-sm btn-primary" target="_blank" rel="noopener" href="${esc(g.inviteUrl)}">✈️ ${L('ادخل القناة', 'Open channel')}</a>` : ''}</li></ol>
      ${why ? `<p class="pc-note">${icons.info} ${esc(why)}</p>` : ''}
      <button type="button" class="btn btn-primary" data-recheck>${L('تحقّقت — افتح النادي', 'Done — check again')}</button></div><div class="pc-hero-b">${badge('legend', 130)}</div></section></div>`);
    el.querySelector('[data-recheck]').addEventListener('click', async (e) => { e.currentTarget.disabled = true; const m = await import('../services/partnerGate.js'); const st = await m.refreshPartnerGate({ fresh: true }); if (st?.allowed) { toast(L('أهلاً بك بالنادي!', 'Welcome to the club!'), 'success'); load(); } else { toast(L('لسا ما لقيناك بالقناة.', 'We could not find you in the channel yet.'), 'error'); e.currentTarget.disabled = false; } });
    return el;
  }
  function intro(d) {
    const el = h(`<div class="pc-wrap">
      <section class="pc-hero"><div class="pc-hero-t"><small>ALPHA PARTNER CLUB</small><h1>${L('نادي ألفا للشركاء', 'Alpha Partner Club')}</h1>
        <p>${L('شارك رابطك أو كوبونك. لما حدا يشترك ويدفع عن طريقك، بتاخد عمولة على اشتراكه، وعمولة أقل على كل تجديد. كل ما زاد عدد عملائك الدافعين بتطلع رتبتك وبتتحسّن شروطك.', 'Share your link or coupon. When someone subscribes and pays through you, you earn a commission on that purchase and a smaller one on every renewal. More paying customers → higher rank → better terms.')}</p>
        <p class="pc-note">${icons.info} ${L('ما في دخل ثابت ولا مضمون: العمولة بس على مدفوعات حقيقية مؤكدة، وبعد فترة الحجز.', 'No fixed or guaranteed income: commissions only on real, confirmed payments, after the holding period.')}</p>
        <button type="button" class="btn btn-primary btn-lg" data-join ${d.enabled ? '' : 'disabled'}>${icons.plus}<span>${L('انضم للنادي', 'Join the club')}</span></button>${d.enabled ? '' : `<p class="pc-note">${L('البرنامج لسا مش مفعّل من الإدارة.', 'The owners have not enabled the program yet.')}</p>`}</div>
        <div class="pc-hero-b">${badge('legend', 150)}</div></section>
      <section class="pc-card"><h2>${icons.trophy} ${L('الرتب التسعة', 'The nine ranks')}</h2><div class="pc-ranks">${d.ranks.map((r) => `<div class="pc-rank" style="--c:${r.color}">${badge(r.id, 46)}<div><b>${esc(tx(r.name))}</b><small>${L('مستويات', 'Levels')} ${r.from}${r.to !== r.from ? `–${r.to}` : ''} · ${r.req} ${L('عميل دافع', 'paying customers')}</small></div></div>`).join('')}</div></section></div>`);
    el.querySelector('[data-join]').addEventListener('click', async () => { try { await apiRequest('POST', '/api/partners/join', {}); toast(L('أهلاً فيك بالنادي!', 'Welcome to the club!'), 'success'); load(); } catch (e) { toast(err(e), 'error'); } });
    return el;
  }
  function dash(d) {
    const r = rk(d.rank); const link = `${location.origin}/?pref=${encodeURIComponent(d.code)}`; const E = d.earnings; const bn = (k) => tx(d.benefitNames[k] || { ar: k, en: k });
    const nextRank = d.nextRank ? rk(d.nextRank.id) : null; const unlockedSet = new Set(d.benefits.unlocked);
    const future = []; for (const x of d.ranks) if (x.from > r.to) for (const b of x.benefits) if (!unlockedSet.has(b) && !future.some((f) => f.b === b)) future.push({ b, rank: x.id });
    const el = h(`<div class="pc-wrap">
      ${d.status !== 'active' ? `<div class="alert alert-error">${icons.alert}<div>${L('حساب الشريك موقوف. تواصل مع الدعم.', 'Your partner account is suspended. Contact support.')}</div></div>` : ''}
      ${!d.enabled ? `<div class="alert">${icons.info}<div>${L('البرنامج موقوف مؤقتًا من الإدارة — ما في عمولات جديدة هلّق.', 'The program is paused by the owners — no new commissions now.')}</div></div>` : ''}
      ${showcase(d, r, link)}
      <div class="pc-grid2 pc-one" id="pc-earn">
        <section class="pc-card"><h2>${icons.wallet} ${L('تفاصيل الأرباح والسحب', 'Earnings details & payouts')}</h2>
          <div class="pc-money"><div class="is-main"><small>${L('رصيد متاح للسحب', 'Available balance')}</small><b>${$usd(E.available)}</b></div><div><small>${L('قيد الحجز/المراجعة', 'Pending')}</small><b>${$usd(E.pending)}</b></div><div><small>${L('بطلب سحب', 'In payout')}</small><b>${$usd(E.inPayout)}</b></div><div><small>${L('مدفوع', 'Paid')}</small><b>${$usd(E.paid)}</b></div></div>
          <table class="pc-t"><tr><td>${L('عملاء جدد هالشهر', 'New customers this month')}</td><td>${$usd(E.monthNew)}</td></tr><tr><td>${L('تجديدات هالشهر', 'Renewals this month')}</td><td>${$usd(E.monthRenewal)}</td></tr><tr><td>${L('مكافآت وتعديلات هالشهر', 'Bonuses & adjustments this month')}</td><td>${$usd(E.monthBonus)}</td></tr>
            <tr class="is-b"><td>${L('مجموع هالشهر', 'This month total')}</td><td>${$usd(E.monthTotal)}</td></tr><tr><td>${L('الشهر الماضي', 'Last month')}</td><td>${$usd(E.prevMonthTotal)}</td></tr><tr><td>${L('مدى الحياة — عملاء جدد / تجديد / مكافآت', 'Lifetime — new / renewal / bonuses')}</td><td>${$usd(E.newLifetime)} / ${$usd(E.renewalLifetime)} / ${$usd(E.bonusLifetime + E.promoLifetime)}</td></tr><tr class="is-b"><td>${L('أرباح مدى الحياة', 'Lifetime earnings')}</td><td>${$usd(E.lifetime)}</td></tr></table>
          <p class="pc-sub">${L('موعد الدفع الجاي', 'Next payout date')}: <b>${date(d.nextPayoutAt)}</b> · ${L('الحد الأدنى', 'minimum')} ${$usd(d.benefits.minPayoutCents)} · ${L('فترة الحجز', 'holding')} ${d.benefits.holdDays} ${L('يوم', 'days')}</p>
          <form class="pc-payout" data-po><select class="input input-sm" name="method"><option value="paypal">PayPal</option><option value="bank">${L('حوالة بنكية', 'Bank transfer')}</option><option value="usdt">USDT</option><option value="other">${L('غير', 'Other')}</option></select>
            <input class="input input-sm" name="account" maxlength="200" placeholder="${esc(L('الإيميل / IBAN / عنوان المحفظة', 'E-mail / IBAN / wallet'))}" value="${esc(d.payoutMethod?.account || '')}"><button class="btn btn-sm btn-primary" ${E.available >= d.benefits.minPayoutCents ? '' : 'disabled'}>${L('اطلب سحب', 'Request payout')}</button></form>
          ${d.payouts.length ? `<details><summary>${L('سجل السحوبات', 'Payout history')} (${d.payouts.length})</summary><table class="pc-t">${d.payouts.map((p) => `<tr><td>${date(p.at)}</td><td>${$usd(p.cents)}</td><td>${st(p.status)}</td><td>${p.reference ? `<small class="mono">${esc(p.reference)}</small>` : p.reason ? `<small>${esc(p.reason)}</small>` : ''}</td></tr>`).join('')}</table></details>` : ''}
        </section>
      </div>
      <section class="pc-card" id="pc-bens"><h2>${icons.crown} ${L('كل المزايا', 'All benefits')}</h2>
        <div class="pc-bens">${d.benefits.unlocked.map((b) => `<span class="pc-ben is-on">${icons.check} ${esc(bn(b))}${b === 'multiplier' ? ` ×${d.benefits.multiplier}` : b === 'shorter_hold' ? ` (${d.benefits.holdDays}${L('ي', 'd')})` : b === 'coupon_discount' ? ` (${d.benefits.couponDiscountPct}%)` : ''}</span>`).join('')}
        ${future.map((f) => `<span class="pc-ben">${icons.lock} ${esc(bn(f.b))} <small>· ${esc(rname(f.rank))}</small></span>`).join('')}</div></section>
      <section class="pc-card" id="pc-path"><h2>${icons.trend} ${L('مسار الرتب — 100 مستوى', 'Rank path — 100 levels')}</h2>
        <div class="pc-path">${d.ranks.map((x) => { const lv = d.levels.filter((l) => l.rank === x.id); const on = lv.filter((l) => l.unlocked).length;
          return `<div class="pc-seg${on ? ' is-on' : ''}${x.id === r.id ? ' is-cur' : ''}" style="--c:${x.color}">${badge(x.id, 38)}<div class="pc-seg-t"><b>${esc(tx(x.name))}</b><small>${x.from}${x.to !== x.from ? `–${x.to}` : ''} · ${x.req}+</small></div>
            <div class="pc-dots">${lv.map((l) => `<i class="${l.unlocked ? 'on' : ''}${l.level === d.level ? ' cur' : ''}" title="${L('مستوى', 'Level')} ${l.level}: ${l.req} ${L('عميل', 'customers')}${l.rewardCents ? ` · ${$usd(l.rewardCents)}` : ''}"></i>`).join('')}</div></div>`; }).join('')}</div></section>
      ${d.statsPlus ? `<section class="pc-card"><h2>${icons.bars} ${L('إحصائيات إضافية', 'Additional statistics')}</h2><div class="pc-bars">${Object.entries(d.statsPlus.byMonth).sort().slice(-12).map(([m, v]) => { const t = v.new + v.renewal + v.bonus; const mx = Math.max(1, ...Object.values(d.statsPlus.byMonth).map((x) => x.new + x.renewal + x.bonus)); return `<div title="${m}: ${$usd(t)}"><i style="height:${(t / mx) * 100}%"><em style="height:${t ? (v.new / t) * 100 : 0}%"></em></i><small>${m.slice(5)}</small></div>`; }).join('') || `<p class="pc-sub">—</p>`}</div><p class="pc-sub"><span class="pc-k1"></span> ${L('عملاء جدد', 'new')} <span class="pc-k2"></span> ${L('تجديد ومكافآت', 'renewal & bonuses')} · ${Object.entries(d.statsPlus.byProduct).map(([k, v]) => `${esc(k)}: ${v}`).join(' · ')}</p></section>` : ''}
      ${d.analytics ? `<section class="pc-card"><h2>${icons.radar} ${L('تحليلات متقدمة', 'Advanced analytics')}</h2><table class="pc-t"><tr><th></th><th>${L('تسجيلات', 'Registrations')}</th><th>${L('دافعين', 'Paying')}</th><th>${L('تحويل', 'Conversion')}</th></tr>${['link', 'coupon'].map((k) => { const s = d.analytics.bySource[k]; return `<tr><td>${k === 'link' ? L('الرابط', 'Link') : L('الكوبون', 'Coupon')}</td><td>${s.regs}</td><td>${s.paying}</td><td>${s.regs ? Math.round((s.paying / s.regs) * 100) : 0}%</td></tr>`; }).join('')}</table>
        <div class="pc-spark">${Object.entries(d.analytics.clicksByDay).sort().slice(-30).map(([dd, n]) => `<i title="${dd}: ${n}" style="height:${Math.min(100, n * 8)}%"></i>`).join('')}</div><small class="pc-sub">${L('النقرات اليومية (آخر 30 يوم)', 'Daily clicks (last 30 days)')}</small></section>` : ''}
      <section class="pc-card" id="pc-hist"><h2>${icons.journal} ${L('سجل الإحالات', 'Referral history')}</h2>${d.history.length ? `<div class="pc-scroll"><table class="pc-t pc-hist"><thead><tr><th>${L('العميل', 'Customer')}</th><th>${L('الخطة', 'Plan')}</th><th>${L('التاريخ', 'Date')}</th><th>${L('الدفع', 'Payment')}</th><th>${L('النوع', 'Type')}</th><th>${L('العمولة', 'Commission')}</th><th>${L('الحالة', 'Status')}</th></tr></thead><tbody>
        ${d.history.map((x) => `<tr><td class="mono">${esc(x.customer)}</td><td>${esc(x.product)} <small>${$usd(x.listCents)}</small></td><td>${date(x.at)}</td><td>${x.payment === 'paid' ? L('مدفوع', 'paid') : x.payment === 'refund' ? L('مسترد', 'refunded') : L('اعتراض', 'chargeback')}</td><td>${esc(kind(x.kind))}</td><td>${$usd(x.amountCents)}</td><td>${st(x.status)}</td></tr>`).join('')}</tbody></table></div>` : `<p class="pc-sub">${L('لسا ما في مشتريات عن طريقك. شارك رابطك!', 'No purchases through you yet. Share your link!')}</p>`}</section>
      ${d.legends.length ? `<section class="pc-card pc-legends"><h2>${badge('legend', 30)} ${L('أساطير ألفا', 'Alpha Legends')}</h2><p>${d.legends.map(esc).join(' · ')}</p></section>` : ''}
      <p class="pc-note">${icons.info} ${L('العمولات بتنحسب على السيرفر من مدفوعات Stripe المؤكدة بس. العميل اللي بيسترد فلوسه بتنلغى عمولته وما بينحسب بالرتبة. ما في دخل مضمون.', 'Commissions are calculated on the server from confirmed Stripe payments only. A refunded purchase cancels its commission and does not count for rank. No income is guaranteed.')}</p>
    </div>`);
    animate(el);
    el.querySelector('[data-gmin]')?.addEventListener('click', (e) => { const c = e.currentTarget.closest('.pcx-growth'); c.classList.toggle('is-min'); e.currentTarget.textContent = c.classList.contains('is-min') ? '+' : '—'; });
    el.addEventListener('click', (e) => { const j = e.target.closest('[data-jump]'); if (j) { e.preventDefault(); el.querySelector(j.dataset.jump)?.scrollIntoView({ behavior: 'smooth', block: 'start' }); } });
    el.addEventListener('click', (e) => { const c = e.target.closest('[data-copy]'); if (c) navigator.clipboard?.writeText(c.dataset.copy).then(() => toast(L('انتسخ ✔', 'Copied ✔'), 'success')).catch(() => toast(c.dataset.copy)); });
    el.querySelector('[data-po]').addEventListener('submit', async (e) => { e.preventDefault(); const f = e.currentTarget; try { await apiRequest('POST', '/api/partners/payout', { method: f.method.value, account: f.account.value }); toast(L('انبعت طلب السحب — الإدارة بتراجعه.', 'Payout requested — the owners will review it.'), 'success'); load(); } catch (x) { toast(err(x), 'error'); } });
    return el;
  }
  load();
  return root;
}

/* ───────────────────────── owners' control panel ───────────────────────── */
const ATABS = [['over', 'نظرة عامة', 'Overview', 'grid'], ['matrix', 'مصفوفة العمولات', 'Commission matrix', 'bars'], ['ranks', 'الرتب والمزايا', 'Ranks & benefits', 'crown'], ['levels', 'المستويات (100)', 'Levels (100)', 'trend'], ['finance', 'الحماية المالية والسحب', 'Protection & payouts', 'shield'], ['coms', 'العمولات', 'Commissions', 'wallet'], ['pays', 'السحوبات', 'Payouts', 'card'], ['people', 'الشركاء', 'Partners', 'user'], ['audit', 'السجل والتصدير', 'Audit & export', 'journal']];
export function renderPartnersAdmin() {
  const root = h(`<section class="subpage tool pc pc-admin page-enter"><div class="pc-ah"><h1>${icons.shield} ${L('إدارة نادي ألفا للشركاء', 'Alpha Partner Club — admin')}</h1><small>${L('كل شي هون بيتطبّق على السيرفر، وما بيلمس المدفوعات المسجّلة قبل.', 'Everything here is applied on the server and never changes money already recorded.')}</small></div>
    <nav class="rm-tabs pc-tabs">${ATABS.map(([id, a, b, ic], i) => `<button type="button" class="rm-tab${i ? '' : ' is-on'}" data-t="${id}">${icons[ic]}<span>${esc(L(a, b))}</span></button>`).join('')}</nav><div data-body></div></section>`);
  const body = root.querySelector('[data-body]'); let D = null; let tab = 'over'; let mRank = 'core';
  const save = async (patch, msg = L('انحفظ ✔', 'Saved ✔')) => { try { const r = await apiRequest('POST', '/api/partners/admin/config', patch); toast(r.warnings?.length ? `${msg} — ${L('تنبيه', 'warning')}: ${r.warnings.slice(0, 3).join(', ')}` : msg, r.warnings?.length ? 'info' : 'success', 6000); await load(); } catch (e) { toast(`${err(e)}${e?.details ? ` ${e.details.slice(0, 4).join(', ')}` : ''}`, 'error', 8000); } };
  const act = async (b) => { try { await apiRequest('POST', '/api/partners/admin/act', b); toast('✔', 'success'); await load(); } catch (e) { toast(err(e), 'error'); } };
  async function load() { try { D = await apiRequest('GET', '/api/partners/admin'); draw(); } catch (e) { body.innerHTML = `<div class="alert alert-error">${icons.alert}<div>${esc(err(e))}</div></div>`; } }
  root.querySelector('.pc-tabs').addEventListener('click', (e) => { const b = e.target.closest('[data-t]'); if (!b) return; tab = b.dataset.t; root.querySelectorAll('[data-t]').forEach((x) => x.classList.toggle('is-on', x === b)); load(); });
  const preview = (t, pct, fixed, mult) => { const f = D.config.finance; const com = Math.round((Math.round((t * pct) / 100) + fixed) * mult); const net = t - Math.round((t * f.taxPct) / 100) - (Math.round((t * f.feePct) / 100) + f.feeFixedCents) - Math.round((t * f.otherPct) / 100); const m = net > 0 ? ((net - com) / net) * 100 : 0; return { com, net, m, bad: com > 0 && (m < f.minMarginPct || com > (t * f.maxCommissionPct) / 100) }; };
  function draw() {
    const c = D.config; const T = D.totals;
    const views = {
      over: () => `<div class="pc-wrap"><section class="pc-card"><h2>${L('حالة البرنامج', 'Program status')}</h2><label class="pc-switch"><input type="checkbox" data-en ${c.enabled ? 'checked' : ''}> <b>${c.enabled ? L('مفعّل', 'Enabled') : L('موقوف', 'Disabled')}</b></label>
        <div class="pc-stats">${[[T.partners, L('شركاء', 'Partners')], [T.referrals, L('إحالات', 'Referrals')], [T.paying, L('عملاء دافعين', 'Paying')], [$usd(T.pending), L('قيد الحجز', 'On hold')], [T.review, L('للمراجعة', 'To review')], [$usd(T.approved), L('معتمد غير مدفوع', 'Approved unpaid')], [$usd(T.paid), L('مدفوع', 'Paid')], [T.payoutsOpen, L('سحوبات مفتوحة', 'Open payouts')]].map(([v, t]) => `<div><b>${v}</b><small>${esc(t)}</small></div>`).join('')}</div></section>
        <section class="pc-card"><h2>✈️ ${L('ربط قناة تلغرام', 'Telegram channel')}</h2>
          <p class="pc-sub">${L('بينشر رسالة بقناتك فيها زر «🏆 ALPHA PARTNER CLUB» بيفتح النادي، وبيثبّتها فوق القناة — فكل واحد بيدخل القناة بيشوفها. كمان بيحط زر قائمة بالبوت اسمه ALPHA PARTNER CLUB. البوت لازم يكون أدمن بالقناة (صلاحية نشر وتثبيت)، والقناة والبوت مضبوطين من «الإشعارات والربط».', 'Posts a message with a “🏆 ALPHA PARTNER CLUB” button in your channel and pins it, so everyone entering the channel sees it. Also sets the bot’s menu button. The bot must be a channel admin (post + pin); channel and bot come from “Notifications & connect”.')}</p>
          ${c.telegram ? `<p class="pc-sub">${L('آخر نشر', 'Last post')}: ${new Date(c.telegram.at).toLocaleString(getLocale())} · ${c.telegram.pinned ? L('مثبّتة ✔', 'pinned ✔') : L('مش مثبّتة', 'not pinned')} · ${c.telegram.menu ? L('زر القائمة ✔', 'menu button ✔') : L('بدون زر قائمة', 'no menu button')}</p>` : ''}
          <div class="pc-row pc-gaterow"><label class="pc-switch"><input type="checkbox" data-gate ${c.gate?.telegram !== false ? 'checked' : ''}> <b>${L('القائمة بس لأعضاء القناة', 'Menu only for channel members')}</b></label>
            <input class="input input-sm" data-invite dir="ltr" placeholder="https://t.me/your_channel" value="${esc(c.gate?.inviteUrl || '')}"><button type="button" class="btn btn-sm" data-savegate>${L('احفظ', 'Save')}</button></div>
          <p class="pc-sub">${L('العضوية بتنفحص على السيرفر عن طريق البوت (لازم يكون أدمن بالقناة) لحساب التلغرام اللي العضو ربطه بالموقع. المالكين بيشوفوها دايمًا.', 'Membership is checked on the server through the bot (must be a channel admin) for the Telegram account the member linked. Owners always see it.')}</p>
          <div class="pc-row"><select class="input input-sm" data-tglang><option value="ar">العربية</option><option value="en">English</option></select><label class="pc-switch"><input type="checkbox" data-tgpin checked> ${L('ثبّت الرسالة', 'Pin the message')}</label><label class="pc-switch"><input type="checkbox" data-tgmenu checked> ${L('زر قائمة البوت', 'Bot menu button')}</label>
            <button type="button" class="btn btn-primary" data-tgpost>✈️ ${L('انشر بالقناة', 'Post to channel')}</button></div></section>
        <section class="pc-card"><h2>${L('الخطط الموجودة مقابل نقاط الأسعار السبعة', 'Existing plans vs the seven price points')}</h2><table class="pc-t">${D.catalogue.map((p) => `<tr><td>${esc(p.id)}</td><td>${$usd(p.cents)}</td><td>${p.inMatrix ? `<span class="up">✔ ${L('بالمصفوفة', 'in matrix')}</span>` : `<span class="down">${L('مش بالمصفوفة → بتروح للمراجعة', 'not in matrix → goes to review')}</span>`}</td></tr>`).join('')}</table>
        <p class="pc-sub">${L('المصفوفة بتدعم: ', 'The matrix supports: ')}${PRICE_TIERS.map($usd).join(' · ')}. ${L('الأسعار 750 و850 و1000 مش موجودة كخطط حاليًا — إذا عملتها من "الخطط والكوبونات" بتشتغل عمولتها مباشرة. الاشتراك بالقناة ($25) والإضافات ما إلهم عمولة.', '$750, $850 and $1000 are not existing plans today — once you set a plan to one of these prices, its commission works at once. The channel subscription ($25) and add-ons earn no commission.')}</p></section></div>`,
      matrix: () => { const mult = c.ranks[mRank].benefits.includes('multiplier') ? c.ranks[mRank].multiplier : 1;
        return `<div class="pc-wrap"><section class="pc-card"><h2>${L('مصفوفة العمولات', 'Commission matrix')} — <select class="input input-sm" data-mr>${RANKS.map((r) => `<option value="${r.id}"${r.id === mRank ? ' selected' : ''}>${esc(tx(r.name))}</option>`).join('')}</select></h2>
        <p class="pc-sub">${L('ولا رقم مضبوط افتراضيًا — إنت بتحدد. التجديد لازم يكون أقل من العميل الجديد (السيرفر بيرفض غير هيك). المعاينة تقريبية؛ الحساب الرسمي على السيرفر وقت الدفع.', 'Nothing is set by default — you decide. Renewal must stay lower than new (the server refuses otherwise). The preview is approximate; the official calculation runs on the server at payment time.')} ${L('مضاعف الرتبة الفعّال', 'Effective rank multiplier')}: ×${mult}</p>
        <div class="pc-scroll"><table class="pc-t pc-mx"><thead><tr><th>${L('الخطة', 'Plan')}</th><th>${L('جديد %', 'New %')}</th><th>${L('جديد ثابت $', 'New fixed $')}</th><th>${L('تجديد %', 'Renewal %')}</th><th>${L('تجديد ثابت $', 'Renewal fixed $')}</th><th>${L('معاينة: جديد / تجديد / هامش', 'Preview: new / renewal / margin')}</th></tr></thead><tbody>
        ${PRICE_TIERS.map((t) => { const m = c.matrix[mRank][t]; const pn = preview(t, m.newPct, m.newFixedCents, mult), pr = preview(t, m.renPct, m.renFixedCents, mult);
          return `<tr data-tier="${t}"><td><b>${$usd(t)}</b></td><td><input class="input input-sm" type="number" step="0.1" min="0" max="100" data-k="newPct" value="${m.newPct}"></td><td><input class="input input-sm" type="number" step="0.01" min="0" data-k="newFixedCents" value="${m.newFixedCents / 100}"></td><td><input class="input input-sm" type="number" step="0.1" min="0" max="100" data-k="renPct" value="${m.renPct}"></td><td><input class="input input-sm" type="number" step="0.01" min="0" data-k="renFixedCents" value="${m.renFixedCents / 100}"></td>
            <td class="${pn.bad ? 'down' : ''}">${$usd(pn.com)} / ${$usd(pr.com)} / ${Math.round(pn.m)}%${pn.bad ? ` ⚠ ${L('للمراجعة', 'review')}` : ''}</td></tr>`; }).join('')}</tbody></table></div>
        <div class="pc-row"><button type="button" class="btn btn-primary" data-savemx>${L('احفظ هالرتبة', 'Save this rank')}</button><button type="button" class="btn btn-ghost" data-copydown>${L('انسخ قيمها لكل الرتب الأعلى', 'Copy to all higher ranks')}</button></div></section></div>`; },
      ranks: () => `<div class="pc-wrap">${RANKS.map((r) => { const x = c.ranks[r.id]; return `<section class="pc-card pc-rk" data-rk="${r.id}" style="--c:${r.color}"><h2>${badge(r.id, 34)} ${esc(tx(r.name))} <small>${L('مستويات', 'levels')} ${r.from}–${r.to}</small></h2>
        <div class="pc-form"><label>${L('مضاعف العمولة', 'Commission multiplier')}<input class="input input-sm" type="number" step="0.05" min="0" max="10" data-k="multiplier" value="${x.multiplier}"></label><label>${L('مكافأة الوصول $', 'Achievement bonus $')}<input class="input input-sm" type="number" step="0.01" min="0" data-k="bonusCents" value="${x.bonusCents / 100}"></label>
          <label>${L('فترة حجز خاصة (يوم)', 'Own holding period (days)')}<input class="input input-sm" type="number" min="0" data-k="holdDays" value="${x.holdDays ?? ''}" placeholder="${c.finance.holdDays}"></label><label>${L('حد سحب أدنى خاص $', 'Own minimum payout $')}<input class="input input-sm" type="number" step="0.01" min="0" data-k="minPayoutCents" value="${x.minPayoutCents == null ? '' : x.minPayoutCents / 100}" placeholder="${c.payout.minPayoutCents / 100}"></label>
          <label>${L('خصم كوبون خاص %', 'Own coupon discount %')}<input class="input input-sm" type="number" step="0.5" min="0" max="90" data-k="couponDiscountPct" value="${x.couponDiscountPct ?? ''}" placeholder="${c.coupon.discountPct}"></label></div>
        <div class="pc-bens">${Object.entries(D.benefitNames).map(([k, n]) => `<label class="pc-ben${x.benefits.includes(k) ? ' is-on' : ''}"><input type="checkbox" data-b="${k}" ${x.benefits.includes(k) ? 'checked' : ''}> ${esc(tx(n))}</label>`).join('')}</div>
        <p class="pc-sub">${L('القيم الخاصة (المضاعف، الحجز، الحد الأدنى، الخصم، المكافأة) بتشتغل بس إذا الميزة تبعها مفعّلة.', 'Own values (multiplier, holding, minimum, discount, bonus) apply only when their benefit is switched on.')}</p></section>`; }).join('')}<div class="pc-row pc-sticky"><button type="button" class="btn btn-primary" data-saverk>${L('احفظ كل الرتب', 'Save all ranks')}</button></div></div>`,
      levels: () => `<div class="pc-wrap"><section class="pc-card"><h2>${L('المستويات المئة', 'The 100 levels')}</h2><p class="pc-sub">${L('العدد = عملاء دافعين مؤكدين (مدى الحياة، بدون المستردين والمحتالين). لازم يكون كل مستوى أكبر من اللي قبله.', 'Count = verified paying customers (lifetime, refunds and fraud excluded). Each level must be higher than the previous one.')}</p>
        <div class="pc-scroll pc-lvls"><table class="pc-t"><thead><tr><th>${L('مستوى', 'Level')}</th><th>${L('الرتبة', 'Rank')}</th><th>${L('عملاء مطلوبين', 'Customers needed')}</th><th>${L('مكافأة $', 'Reward $')}</th></tr></thead><tbody>${c.levels.map((l) => `<tr data-lv="${l.level}" style="--c:${rk(l.rank).color}"><td><b>${l.level}</b></td><td><span class="pc-dot"></span>${esc(rname(l.rank))}</td><td><input class="input input-sm" type="number" min="0" data-k="req" value="${l.req}"></td><td><input class="input input-sm" type="number" min="0" step="0.01" data-k="rewardCents" value="${l.rewardCents / 100}"></td></tr>`).join('')}</tbody></table></div>
        <div class="pc-row"><button type="button" class="btn btn-primary" data-savelv>${L('احفظ المستويات', 'Save levels')}</button></div></section></div>`,
      finance: () => { const f = c.finance; const inp = (k, v, step = '0.1', lbl) => `<label>${esc(lbl)}<input class="input input-sm" type="number" step="${step}" min="0" data-f="${k}" value="${v}"></label>`;
        return `<div class="pc-wrap"><section class="pc-card"><h2>${icons.shield} ${L('الحماية المالية', 'Financial protection')}</h2>
        <p class="pc-sub">${L('صافي الإيراد = المدفوع − الضرائب − رسوم الدفع − تكاليف تانية. إذا العمولة كسرت الحد الأدنى للهامش أو سقف العمولة: ما بتتغيّر، بس بتروح للمراجعة مع الشرح.', 'Net revenue = collected − taxes − processing fees − other costs. If a commission breaks the minimum margin or a cap, it is not changed — it goes to review with the explanation.')}</p>
        <div class="pc-form">${inp('taxPct', f.taxPct, '0.1', L('ضرائب %', 'Taxes %'))}${inp('feePct', f.feePct, '0.1', L('رسوم الدفع %', 'Processing fee %'))}${inp('feeFixedCents', f.feeFixedCents / 100, '0.01', L('رسوم ثابتة $', 'Fixed fee $'))}${inp('otherPct', f.otherPct, '0.1', L('تكاليف تانية %', 'Other costs %'))}${inp('minMarginPct', f.minMarginPct, '1', L('أدنى هامش للتطبيق %', 'Minimum app margin %'))}${inp('maxCommissionPct', f.maxCommissionPct, '1', L('أقصى عمولة % من المدفوع', 'Max commission % of payment'))}${inp('holdDays', f.holdDays, '1', L('فترة الحجز (يوم)', 'Holding period (days)'))}</div>
        <label class="pc-switch"><input type="checkbox" data-f="autoApprove" ${f.autoApprove ? 'checked' : ''}> ${L('اعتماد تلقائي بعد فترة الحجز (إلا اللي للمراجعة)', 'Auto-approve after holding (except items in review)')}</label>
        <h3>${L('سقف العمولة لكل خطة ($، فاضي = بدون سقف)', 'Commission cap per plan ($, empty = none)')}</h3><div class="pc-form">${PRICE_TIERS.map((t) => `<label>${$usd(t)}<input class="input input-sm" type="number" step="0.01" min="0" data-cap="${t}" value="${f.maxCommissionCents[t] == null ? '' : f.maxCommissionCents[t] / 100}"></label>`).join('')}</div>
        <h3>${L('السحب والكوبون', 'Payouts & coupon')}</h3><div class="pc-form">${inp('p_min', c.payout.minPayoutCents / 100, '0.01', L('الحد الأدنى للسحب $', 'Minimum payout $'))}${inp('p_day', c.payout.day, '1', L('يوم الدفع بالشهر (1–28)', 'Payout day of month (1–28)'))}${inp('c_pct', c.coupon.discountPct, '0.5', L('خصم كوبون الشريك % (0 = بدون خصم، ربط بس)', 'Partner coupon discount % (0 = tracking only)'))}</div>
        <h3>${L('الإشعارات', 'Notifications')}</h3><div class="pc-bens">${Object.keys(c.notify).map((k) => `<label class="pc-ben${c.notify[k] ? ' is-on' : ''}"><input type="checkbox" data-n="${k}" ${c.notify[k] ? 'checked' : ''}> ${esc(k)}</label>`).join('')}</div>
        <div class="pc-row"><button type="button" class="btn btn-primary" data-savefin>${L('احفظ', 'Save')}</button></div></section></div>`; },
      coms: () => { const items = D.commissions; return `<div class="pc-wrap"><section class="pc-card"><h2>${L('العمولات', 'Commissions')} <select class="input input-sm" data-cf><option value="">${L('الكل', 'All')}</option>${Object.keys(STATUS).map((s) => `<option value="${s}">${esc(L(...STATUS[s]))}</option>`).join('')}</select></h2>
        <div class="pc-scroll"><table class="pc-t pc-coms"><thead><tr><th>${L('التاريخ', 'Date')}</th><th>${L('الشريك', 'Partner')}</th><th>${L('النوع', 'Type')}</th><th>${L('مدفوع', 'Collected')}</th><th>${L('صافي', 'Net')}</th><th>${L('العمولة', 'Commission')}</th><th>${L('للتطبيق', 'App keeps')}</th><th>${L('هامش', 'Margin')}</th><th>${L('الحالة', 'Status')}</th><th></th></tr></thead><tbody>
        ${items.map((x) => `<tr data-cs="${x.status}"><td>${date(x.createdAt)}</td><td><small class="mono">${esc((D.partners.find((p) => p.uid === x.partner) || {}).code || x.partner)}</small></td><td>${esc(kind(x.kind))}${x.customer ? ` <small class="mono">${esc(x.customer)}</small>` : ''}</td><td>${x.collectedCents != null ? $usd(x.collectedCents) : '—'}</td><td>${x.netCents != null ? $usd(x.netCents) : '—'}</td><td><b>${$usd(x.amountCents)}</b>${x.multiplier && x.multiplier !== 1 ? ` <small>×${x.multiplier}</small>` : ''}</td><td>${x.appRemainCents != null ? $usd(x.appRemainCents) : '—'}</td><td>${x.marginPct != null ? `${x.marginPct}%` : '—'}</td>
          <td>${st(x.status)}${x.issues?.length ? `<div class="pc-iss">${x.issues.map((i) => `⚠ ${esc(tx(i))}`).join('<br>')}</div>` : x.note ? `<div class="pc-iss">${esc(x.note)}</div>` : ''}${x.reason ? `<div class="pc-iss">${esc(x.reason)}</div>` : ''}</td>
          <td class="pc-acts">${['pending', 'review'].includes(x.status) ? `<button type="button" class="btn btn-sm" data-a="approve" data-id="${x.id}">${L('اعتمد', 'Approve')}</button>` : ''}${['pending', 'review', 'approved'].includes(x.status) && !x.payoutId ? `<button type="button" class="btn btn-sm btn-ghost" data-a="reject" data-id="${x.id}">${L('ارفض', 'Reject')}</button>` : ''}${x.paymentId && !x.refunded ? `<button type="button" class="btn btn-sm btn-ghost" data-a="refund" data-pid="${x.paymentId}">${L('استرداد', 'Refund')}</button><button type="button" class="btn btn-sm btn-ghost" data-a="chargeback" data-pid="${x.paymentId}">${L('اعتراض', 'Chargeback')}</button>` : ''}</td></tr>`).join('') || `<tr><td colspan="10" class="pc-sub">${L('لسا ما في عمولات.', 'No commissions yet.')}</td></tr>`}</tbody></table></div></section></div>`; },
      pays: () => `<div class="pc-wrap"><section class="pc-card"><h2>${L('طلبات السحب', 'Payout requests')}</h2><p class="pc-sub">${L('"مدفوع" بس بعد ما تحوّل فعلاً وتكتب مرجع العملية. المنصة ما بتبعت فلوس لحالها.', 'Mark “paid” only after you actually sent the money and typed its reference. The platform never sends money by itself.')}</p>
        <div class="pc-scroll"><table class="pc-t"><thead><tr><th>${L('التاريخ', 'Date')}</th><th>${L('الشريك', 'Partner')}</th><th>${L('المبلغ', 'Amount')}</th><th>${L('الطريقة', 'Method')}</th><th>${L('الحساب', 'Account')}</th><th>${L('الحالة', 'Status')}</th><th></th></tr></thead><tbody>
        ${D.payouts.map((p) => `<tr><td>${date(p.at)}</td><td><small class="mono">${esc((D.partners.find((x) => x.uid === p.partner) || {}).code || '')}</small></td><td><b>${$usd(p.cents)}</b></td><td>${esc(p.method)}</td><td><small class="mono">${esc(p.account || '')}</small></td><td>${st(p.status)}${p.reference ? `<br><small class="mono">${esc(p.reference)}</small>` : ''}</td>
          <td class="pc-acts">${p.status === 'requested' ? `<button type="button" class="btn btn-sm" data-a="payout_approve" data-id="${p.id}">${L('وافق', 'Approve')}</button>` : ''}${p.status === 'approved' ? `<button type="button" class="btn btn-sm btn-primary" data-a="payout_paid" data-id="${p.id}">${L('انبعت (مع مرجع)', 'Sent (with reference)')}</button>` : ''}${['requested', 'approved'].includes(p.status) ? `<button type="button" class="btn btn-sm btn-ghost" data-a="payout_reject" data-id="${p.id}">${L('ارفض', 'Reject')}</button>` : ''}</td></tr>`).join('') || `<tr><td colspan="7" class="pc-sub">—</td></tr>`}</tbody></table></div></section></div>`,
      people: () => `<div class="pc-wrap"><section class="pc-card"><h2>${L('الشركاء', 'Partners')} (${D.partners.length})</h2><div class="pc-scroll"><table class="pc-t"><thead><tr><th>${L('الكود', 'Code')}</th><th>${L('الاسم', 'Name')}</th><th>${L('الرتبة', 'Rank')}</th><th>${L('دافعين', 'Paying')}</th><th>${L('نقرات/تسجيل', 'Clicks/regs')}</th><th>${L('رصيد', 'Balance')}</th><th>${L('مدى الحياة', 'Lifetime')}</th><th>${L('الحالة', 'Status')}</th><th></th></tr></thead><tbody>
        ${D.partners.map((p) => `<tr><td class="mono">${esc(p.code)}</td><td>${esc(p.name)}</td><td>${badge(p.rank, 22)} ${esc(rname(p.rank))} · ${p.level}</td><td>${p.qualified}</td><td>${p.clicks}/${p.regs}</td><td>${$usd(p.balance)}</td><td>${$usd(p.lifetime)}</td><td>${esc(p.status)}</td>
          <td class="pc-acts"><button type="button" class="btn btn-sm btn-ghost" data-a="${p.status === 'suspended' ? 'unsuspend' : 'suspend'}" data-uid="${esc(p.uid)}">${p.status === 'suspended' ? L('فعّل', 'Unsuspend') : L('أوقف', 'Suspend')}</button><button type="button" class="btn btn-sm btn-ghost" data-a="promo" data-uid="${esc(p.uid)}">${L('مكافأة/تعديل', 'Bonus/adjust')}</button><button type="button" class="btn btn-sm btn-ghost" data-a="recalc" data-uid="${esc(p.uid)}">${L('أعد الحساب', 'Recalc')}</button></td></tr>`).join('') || `<tr><td colspan="9" class="pc-sub">—</td></tr>`}</tbody></table></div></section>
        <section class="pc-card"><h2>${L('مراجعة الإحالات', 'Referral attribution')}</h2><div class="pc-scroll"><table class="pc-t"><thead><tr><th>${L('العميل', 'Customer')}</th><th>${L('الشريك', 'Partner')}</th><th>${L('عن طريق', 'Via')}</th><th>${L('دفع', 'Paid')}</th><th>${L('علامات', 'Flags')}</th><th></th></tr></thead><tbody>
        ${D.referrals.slice().reverse().map((r) => `<tr><td class="mono">${esc(r.ref)}</td><td class="mono">${esc((D.partners.find((x) => x.uid === r.partner) || {}).code || '')}</td><td>${esc(r.via)}</td><td>${r.paidAt ? date(r.paidAt) : '—'}${r.void ? ` <span class="down">${L('ملغى', 'void')}</span>` : ''}</td><td>${(r.flags || []).map(esc).join(', ')}</td><td>${r.void ? '' : `<button type="button" class="btn btn-sm btn-ghost" data-a="void_referral" data-customer="${esc(r.ref)}">${L('ألغِ (احتيال)', 'Void (fraud)')}</button>`}</td></tr>`).join('') || `<tr><td colspan="6" class="pc-sub">—</td></tr>`}</tbody></table></div></section></div>`,
      audit: () => `<div class="pc-wrap"><section class="pc-card"><h2>${L('تصدير التقارير (CSV)', 'Export reports (CSV)')}</h2><div class="pc-row">${[['commissions', 'العمولات', 'Commissions'], ['monthly', 'التقرير الشهري', 'Monthly report'], ['payouts', 'السحوبات', 'Payouts']].map(([t, a, b]) => `<button type="button" class="btn" data-exp="${t}">${icons.download}<span>${esc(L(a, b))}</span></button>`).join('')}</div></section>
        <section class="pc-card"><h2>${L('سجل التدقيق', 'Audit log')} <span class="${D.audit.check.ok ? 'up' : 'down'}">${D.audit.check.ok ? `✔ ${L('السلسلة سليمة', 'chain intact')} (${D.audit.check.n})` : `✕ ${L('في تلاعب عند', 'tampering at')} #${D.audit.check.seq}`}</span></h2>
        <div class="pc-scroll"><table class="pc-t">${D.audit.tail.map((a) => `<tr><td>#${a.seq}</td><td>${new Date(a.at).toLocaleString(getLocale())}</td><td>${esc(a.type)}</td><td><small class="mono">${esc(JSON.stringify(a.data).slice(0, 140))}</small></td><td><small class="mono">${esc(a.hash.slice(0, 10))}</small></td></tr>`).join('')}</table></div></section></div>`,
    };
    body.innerHTML = views[tab]();
  }
  body.addEventListener('change', (e) => {
    if (e.target.matches('[data-en]')) save({ enabled: e.target.checked });
    if (e.target.matches('[data-mr]')) { mRank = e.target.value; draw(); }
    if (e.target.matches('[data-cf]')) { const v = e.target.value; body.querySelectorAll('[data-cs]').forEach((r) => { r.hidden = Boolean(v) && r.dataset.cs !== v; }); }
  });
  body.addEventListener('click', async (e) => {
    const t = e.target;
    if (t.closest('[data-savemx]') || t.closest('[data-copydown]')) {
      const row = {}; body.querySelectorAll('[data-tier]').forEach((tr) => { const o = {}; tr.querySelectorAll('[data-k]').forEach((i) => { o[i.dataset.k] = i.dataset.k.endsWith('Cents') ? Math.round(Number(i.value || 0) * 100) : Number(i.value || 0); }); row[tr.dataset.tier] = o; });
      const matrix = { [mRank]: row }; if (t.closest('[data-copydown]')) { const idx = RANKS.findIndex((r) => r.id === mRank); for (const r of RANKS.slice(idx + 1)) matrix[r.id] = row; }
      return save({ matrix });
    }
    if (t.closest('[data-saverk]')) { const ranks = {}; body.querySelectorAll('[data-rk]').forEach((s) => { const o = { benefits: [...s.querySelectorAll('[data-b]:checked')].map((i) => i.dataset.b) }; s.querySelectorAll('[data-k]').forEach((i) => { const v = i.value.trim(); o[i.dataset.k] = v === '' ? null : i.dataset.k.endsWith('Cents') ? Math.round(Number(v) * 100) : Number(v); }); if (o.multiplier == null) o.multiplier = 1; if (o.bonusCents == null) o.bonusCents = 0; ranks[s.dataset.rk] = o; }); return save({ ranks }); }
    if (t.closest('[data-savelv]')) { const levels = [...body.querySelectorAll('[data-lv]')].map((tr) => ({ req: Number(tr.querySelector('[data-k="req"]').value), rewardCents: Math.round(Number(tr.querySelector('[data-k="rewardCents"]').value || 0) * 100) })); return save({ levels }); }
    if (t.closest('[data-savefin]')) { const v = (k) => Number(body.querySelector(`[data-f="${k}"]`)?.value || 0); const caps = {}; body.querySelectorAll('[data-cap]').forEach((i) => { caps[i.dataset.cap] = i.value === '' ? null : Math.round(Number(i.value) * 100); });
      const notify = {}; body.querySelectorAll('[data-n]').forEach((i) => { notify[i.dataset.n] = i.checked; });
      return save({ finance: { taxPct: v('taxPct'), feePct: v('feePct'), feeFixedCents: Math.round(v('feeFixedCents') * 100), otherPct: v('otherPct'), minMarginPct: v('minMarginPct'), maxCommissionPct: v('maxCommissionPct'), holdDays: v('holdDays'), autoApprove: body.querySelector('[data-f="autoApprove"]').checked, maxCommissionCents: caps }, payout: { minPayoutCents: Math.round(v('p_min') * 100), day: v('p_day') }, coupon: { discountPct: v('c_pct') }, notify }); }
    if (t.closest('[data-savegate]')) return save({ gate: { telegram: body.querySelector('[data-gate]').checked, inviteUrl: body.querySelector('[data-invite]').value.trim() } });
    if (t.closest('[data-tgpost]')) {
      const btn = t.closest('[data-tgpost]'); btn.disabled = true;
      try { const r = await apiRequest('POST', '/api/partners/admin/telegram', { lang: body.querySelector('[data-tglang]').value, pin: body.querySelector('[data-tgpin]').checked, menu: body.querySelector('[data-tgmenu]').checked }, 30000);
        const bits = [L('انتشرت ✔', 'Posted ✔'), r.pin ? (r.pin.ok ? L('وتثبّتت ✔', 'pinned ✔') : `${L('التثبيت فشل', 'pin failed')}: ${r.pin.error}`) : '', r.menu ? (r.menu.ok ? L('زر القائمة ✔', 'menu button ✔') : `${L('زر القائمة', 'menu button')}: ${r.menu.error === 'https_required' ? L('بدّه رابط https', 'needs https') : r.menu.error}`) : ''].filter(Boolean);
        toast(bits.join(' · '), r.pin?.ok === false || r.menu?.ok === false ? 'info' : 'success', 8000); await load(); }
      catch (x) { toast(x.code === 'telegram_not_configured' ? L('اضبط بوت التلغرام ورقم القناة من «الإشعارات والربط» أول.', 'Set the Telegram bot and channel id in “Notifications & connect” first.') : `${L('التلغرام رفض', 'Telegram refused')} (${x.code || x.status}) — ${L('تأكد إن البوت أدمن بالقناة.', 'make sure the bot is a channel admin.')}`, 'error', 9000); }
      btn.disabled = false; return;
    }
    const ex = t.closest('[data-exp]'); if (ex) { try { const u = await apiBlobUrl(`/api/partners/admin/export?type=${ex.dataset.exp}`); const a = document.createElement('a'); a.href = u; a.download = `partners-${ex.dataset.exp}.csv`; a.click(); setTimeout(() => URL.revokeObjectURL(u), 5000); } catch (x) { toast(err(x), 'error'); } return; }
    const b = t.closest('[data-a]'); if (!b) return; const a = b.dataset.a;
    if (a === 'reject') { const reason = window.prompt(L('سبب الرفض (بيبيّن للشريك)', 'Rejection reason (shown to the partner)')); if (!reason) return; return act({ action: 'reject', id: b.dataset.id, reason }); }
    if (a === 'refund' || a === 'chargeback') { if (!window.confirm(L('تأكيد: هالدفعة انستردت فعلاً؟ العمولة بتنلغى (أو بتنسحب إذا كانت مدفوعة).', 'Confirm this payment was really refunded? The commission is reversed (or clawed back if already paid).'))) return; return act({ action: 'refund', paymentId: b.dataset.pid, kind: a }); }
    if (a === 'payout_paid') { const reference = window.prompt(L('مرجع الدفع (رقم الحوالة / المعاملة) — بعد ما تبعت فعلاً', 'Payment reference (transfer / transaction id) — only after you actually sent it')); if (!reference) return; return act({ action: 'payout_paid', id: b.dataset.id, reference }); }
    if (a === 'payout_reject') { const reason = window.prompt(L('السبب', 'Reason')); if (!reason) return; return act({ action: 'payout_reject', id: b.dataset.id, reason }); }
    if (a === 'suspend') { const reason = window.prompt(L('سبب الإيقاف', 'Suspension reason')); if (reason == null) return; return act({ action: 'suspend', uid: b.dataset.uid, reason }); }
    if (a === 'promo') { const v = Number(window.prompt(L('المبلغ بالدولار (سالب = خصم/تعديل)', 'Amount in $ (negative = deduction)'))); if (!v) return; const note = window.prompt(L('ملاحظة', 'Note')) || ''; return act({ action: 'promo', uid: b.dataset.uid, cents: Math.round(v * 100), note }); }
    if (a === 'void_referral') { const reason = window.prompt(L('سبب الإلغاء', 'Reason')); if (!reason) return; return act({ action: 'void_referral', customer: b.dataset.customer, reason }); }
    return act({ action: a, id: b.dataset.id, uid: b.dataset.uid });
  });
  load();
  return root;
}
void getLang;
