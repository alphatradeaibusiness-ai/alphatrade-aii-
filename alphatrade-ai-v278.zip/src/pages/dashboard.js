// Dashboard (right side of the reference): market cards, chart, analysis column, pressure + AI.
import { h, fmtNum } from '../utils/dom.js';
import { t } from '../i18n/index.js';
import { store } from '../state/store.js';
import { getCandles, getTickers, isUnavailable } from '../services/market/index.js';
import { computeAnalysis, aiContext } from '../services/analysis.js';
import { marketConfig, TIMEFRAMES } from '../config/market.js';
import { INSTRUMENTS, getInstrument } from '../config/instruments.js';
import { openBinanceStream } from '../services/market/binanceStream.js';
import { describeError } from '../utils/http.js';
import { createMarketCards } from '../components/marketCards.js';
import { createChartPanel } from '../components/chartPanel.js';
import { introActive, introDone } from '../components/loginIntro.js';
import { gateTrade, confirmCfg } from '../services/gate.js';
import { aiEnabled, aiProposal, stickyProposal, prefetchHistory } from '../services/aiLive.js';
import { aiForAnalysisAsync } from '../services/aiAsync.js';
import { prefetchHtf } from '../services/htfData.js';
import { createSideCards } from '../components/sideCards.js';
import { createSynthesisCard } from '../components/synthesisCard.js';
import { createAnalysisProgress } from '../components/analysisProgress.js';
import { createNewsTicker } from '../components/newsTicker.js';
import { createPressureCard } from '../components/pressureCard.js';
import { createAiAssistant } from '../components/aiAssistant.js';
import { createAssistPanel } from '../components/smcAssistPanel.js';
import { createIndicatorPanel, createSettingsPanel } from '../components/indicatorPanel.js';
import { openModal, toast } from '../components/ui.js';
import { notify, describe, signalState, guardFor } from '../services/signals.js';
import { storage } from '../utils/storage.js';

// Survive re-renders (language switch) so the screen repaints instantly.
const datasetCache = new Map();
let tickerCache = null;
const noticed = new Set();

export function createDashboard({ onDemoChange } = {}) {
  const el = h(`<div class="dashboard"></div>`);
  let dataset = null;
  let analysis = null;
  let seq = 0;
  let timer = null;
  let tickerDemo = [];
  const proposals = new Map(); // fixed AI suggestions per symbol|timeframe
  let stream = null;      // Binance WebSocket (crypto prices every second)
  let streamKey = '';
  let liveTimer = null;   // throttles analysis refreshes to one per second
  let lastLiveRun = 0;
  const BINANCE_SYMBOLS = INSTRUMENTS.filter((i) => i.provider === 'binance').map((i) => i.symbol);

  const openIndicators = () => openModal(t('ind.title'), (body, close) => {
    body.append(createIndicatorPanel({
      hasVolume: analysis ? analysis.hasVolume : undefined,
      onPickFrvp: () => { close(); startTool('frvp'); },
      onPickFib: () => { close(); startTool('fib'); },
    }));
  }, { wide: true });
  const openSettings = () => openModal(t('settings.title'), (body, close) => body.append(createSettingsPanel({ onClose: close })), { wide: true });

  const cards = createMarketCards();
  let tickN = 0; const onScreen = new Set();
  const seen = typeof IntersectionObserver === 'function' ? new IntersectionObserver((es) => { for (const e of es) { const sym = e.target.dataset.symbol; if (e.isIntersecting) onScreen.add(sym); else onScreen.delete(sym); } }) : null;
  if (seen) cards.el.querySelectorAll('.market-card').forEach((c) => seen.observe(c));
  const chartPanel = createChartPanel({
    onOpenIndicators: openIndicators,
    onOpenSettings: openSettings,
    onFibPicked: (pts) => store.updateSettings('fib', { mode: 'manual', enabled: true, symbol: store.get('symbol'), ...pts }),
    onFrvpPicked: ({ from, to }) => store.updateSettings('frvp', { enabled: true, from, to, symbol: store.get('symbol') }),
  });
  const side = createSideCards({
    onOpenSettings: openSettings,
    // Close the current trade and open a new one at the current price.
  });
  const pressure = createPressureCard();
  const ai = createAiAssistant({ getContext: () => aiContext(analysis) });
  pressure.syncWith(chartPanel.chart.chart);

  const main = h('<div class="dash-main"></div>');
  const synth = createSynthesisCard();   // one combined reading (trend, higher timeframes, momentum, volatility, SMC, news risk)
  const progress = createAnalysisProgress();   // stages of the full analysis for the selected asset
  const ticker = createNewsTicker();           // calendar + headlines that concern the selected asset, with their impact
  // SMC / ICT trade assistant: first card of the side column (beside the chart on desktop, under it on phones).
  const assist = createAssistPanel({ getChart: () => chartPanel.chart, onTimeframe: (tf) => store.set('timeframe', tf) });
  side.el.prepend(assist.el, progress.el, synth.el);
  assist.init();
  main.append(chartPanel.el, side.el);
  const bottom = h('<div class="dash-bottom"></div>');
  bottom.append(pressure.el, ai.el);
  el.append(cards.el, ticker.el, main, bottom);

  function emitDemo() {
    const demo = new Set(tickerDemo);
    if (dataset?.mode === 'demo' && !isUnavailable(dataset.symbol)) demo.add(dataset.symbol);
    const total = tickerCache ? Object.values(tickerCache).filter((x) => x.mode !== 'unavailable').length : 0;
    // Why each symbol fell back to demo (provider error), so the banner can say it.
    const reasons = [...demo].map((s) => {
      const err = tickerCache?.[s]?.error || (dataset?.symbol === s ? dataset.notice?.error : null);
      return err ? `${s}: ${describeError(err, t)}` : null;
    }).filter(Boolean);
    onDemoChange?.([...demo], demo.size > 0 && demo.size >= total, reasons);
  }

  // A trade that appears on the chart (real data only) is pushed to the phone once.
  function notifyPlan(an) {
    const p = an?.plan;
    if (!p || p.fromSignal || an.mode !== 'live') return;
    // Only a strategy/timeframe that has PROVEN >= 62% (and passes the newest-40% check) may push to the phone from the chart.
    if (!signalState().combos[`${an.symbol}|${an.tf}|${p.strategy}`]?.qualified) return;
    const key = `${an.symbol}|${an.tf}|${p.strategy}|${p.direction}|${p.openedTime}|${p.entry}`;
    const seen = storage.get('chart-notified', []);
    if (seen.includes(key) || signalState().signals.some((x) => x.symbol === an.symbol && x.tf === an.tf && x.strategy === p.strategy && x.openTime === p.openTime)) return;
    // Ignore a trade that opened long ago (first load after a day away).
    const age = Date.now() / 1000 - Number(p.openedTime || 0);
    storage.set('chart-notified', [key, ...seen].slice(0, 80));
    if (age > 4 * (TIMEFRAMES.find((x) => x.id === an.tf)?.seconds || 3600)) return;
    const inst = getInstrument(an.symbol);
    guardFor(an.symbol, p.direction).then((g) => { if (g.ok) deliver(); });
    function deliver() {
    notify(t(p.status === 'pending' ? 'sig.chartPending' : 'sig.chartNew'), describe({
      symbol: an.symbol, tf: an.tf, strategy: p.strategy, direction: p.direction, precision: inst.precision, pointSize: p.pointSize || 1,
      entry: p.entry, stop: p.initialStop ?? p.stop, targets: p.targets, hits: p.hits || 0, accuracy: 0, score: p.score ?? null,
    }, true), key);
    }
  }

  // A candle that just CLOSED through a Fibonacci line: "sell" below it, "buy" above it — once per break.
  function notifyFibBreak(an) {
    const s = store.get('settings').fib;
    if (!an?.fibSig || an.mode !== 'live' || !s.enabled || s.notify === false || s.signals === false || !dataset) return;
    const sec = TIMEFRAMES.find((x) => x.id === an.tf)?.seconds || 3600;
    for (const b of an.fibSig.breaks) {
      if (b.live || Date.now() / 1000 - Number(b.time) > 3 * sec || !(s.levels?.includes(b.ratio) ?? true)) continue;
      const key = `${an.symbol}|${an.tf}|${b.ratio}|${b.time}`;
      const seen = storage.get('fib-notified', []);
      if (seen.includes(key)) continue;
      storage.set('fib-notified', [key, ...seen].slice(0, 80));
      const inst = getInstrument(an.symbol);
      const price = fmtNum(b.price, inst.precision);
      notify(t(b.dir === 'sell' ? 'fs.notifySell' : 'fs.notifyBuy', { sym: an.symbol, tf: t(`perf.tfShort.${an.tf}`) }), t(b.dir === 'sell' ? 'fs.closedBelow' : 'fs.closedAbove', { r: b.ratio.toFixed(3), p: price }) + (b.htfAgrees === false ? ` · ${t('fs.againstHtf')}` : ''), key);
    }
  }

  // SMC v2 needs the real 4h and Daily candles (the chart's 500 candles are too short on 1m–15m).
  function ensureHtf() {
    if (!dataset || !['smc', 'edh', 'classic'].includes(store.get('settings').strategy) || dataset.mode !== 'live') return;
    const sym = dataset.symbol; const tf = dataset.tf;
    const sec = TIMEFRAMES.find((x) => x.id === tf)?.seconds || 3600;
    prefetchHtf(sym, sec).then((fresh) => { if (fresh && dataset && dataset.symbol === sym && dataset.tf === tf) recompute(); });
  }

  let aiWaiting = false;
  // AI engine result for the current chart; deeper history loads in the background, then re-runs.
  function attachAi(prefetch = true) {
    if (!analysis || !dataset) return;
    // Training the AI model takes 1-2 s on a phone. While the welcome animation plays, skip it
    // (it used to freeze the animation) and run once the animation has finished.
    if (introActive()) {
      analysis.ai = null; analysis.proposal = null;
      if (!aiWaiting) { aiWaiting = true; introDone().then(() => setTimeout(() => { aiWaiting = false; if (el.isConnected) recompute(); }, 120)); }
      return;
    }
    const on = aiEnabled(store.get('settings')) && dataset.mode === 'live';
    // Trained in a Web Worker: the page stays responsive; when the new result is in, the panels refresh.
    analysis.ai = on ? aiForAnalysisAsync(dataset, analysis, () => { if (el.isConnected) recompute(); }) : null;
    const pkey = `${dataset.symbol}|${dataset.tf}`;
    analysis.proposal = on ? stickyProposal(proposals.get(pkey), aiProposal(dataset, analysis), dataset.candles) : null;
    // The AI idea passes the same strict confirmation as a strategy trade; otherwise nothing is drawn (NO TRADE).
    if (analysis.proposal && confirmCfg(store.get('settings')).enabled) {
      const g = gateTrade({ symbol: dataset.symbol, tf: dataset.tf, mode: dataset.mode, candles: dataset.candles, trade: { ...analysis.proposal, openTime: analysis.proposal.openedTime + 1 }, strategy: 'ai', feePct: Number(store.get('settings').plan?.feePct) || 0, cfg: confirmCfg(store.get('settings')), at: 'open' });
      if (g.verdict === 'trade') analysis.gate = g; else { analysis.gate = { ...g, rejected: true }; analysis.proposal = null; }
    }
    if (analysis.proposal) proposals.set(pkey, analysis.proposal); else proposals.delete(pkey);
    if (on && prefetch) {
      const sym = dataset.symbol; const tf = dataset.tf;
      prefetchHistory(sym, tf).then((fresh) => { if (fresh && dataset && dataset.symbol === sym && dataset.tf === tf) recompute(); });
    }
  }

  function recompute() {
    if (!dataset) return;
    analysis = computeAnalysis(dataset, store.get('settings'));
    if (!analysis) { chartPanel.showError(t('chart.noData'), () => load()); return; }
    attachAi();
    chartPanel.setAnalysis(analysis);
    notifyPlan(analysis);
    notifyFibBreak(analysis);
    side.update(analysis); assist.update(dataset); synth.update(analysis, dataset); progress.update(analysis, dataset); ticker.update(analysis.symbol);
    pressure.update(analysis, chartPanel.chart.chart.timeScale().getVisibleLogicalRange());
    ai.refresh();
  }

  async function load({ quiet = false } = {}) {
    const symbol = store.get('symbol');
    const tf = store.get('timeframe');
    const key = `${symbol}|${tf}`;
    const my = ++seq;
    const cached = datasetCache.get(key);
    if (!quiet) {
      if (cached) applyDataset(cached, false);
      else chartPanel.showLoading(symbol);
    }
    try {
      const ds = await getCandles(symbol, tf);
      // First chart render (analysis + drawing ≈ 0.5 s on a phone) waits for the welcome animation to finish,
      // so the animation plays smoothly; the data itself is already loading underneath.
      if (introActive()) await introDone();
      if (my !== seq) return; // a newer request superseded this one
      if (!ds.candles.length) { chartPanel.showError(t('chart.noData'), () => load()); return; }
      datasetCache.set(key, ds);
      applyDataset(ds, quiet || Boolean(cached));
      if (ds.notice && !noticed.has(`${key}|${ds.notice.key}`)) {
        noticed.add(`${key}|${ds.notice.key}`);
        toast(t(ds.notice.key, { msg: ds.notice.error ? describeError(ds.notice.error, t) : '' }), 'info', 6000);
      }
    } catch (err) {
      if (my !== seq) return;
      if (quiet && dataset) { toast(t('chart.loadError', { msg: describeError(err, t) }), 'error'); return; }
      chartPanel.showError(t('chart.loadError', { msg: describeError(err, t) }), () => load());
    }
  }

  /* ───────── Real-time stream ───────── */
  const streamLive = () => Boolean(stream && stream.isOpen());

  function ensureStream() {
    if (!marketConfig.streaming || marketConfig.mode === 'demo') return;
    const liveCrypto = tickerCache && BINANCE_SYMBOLS.some((s) => tickerCache[s]?.mode === 'live');
    if (!liveCrypto && dataset?.mode !== 'live') return; // Binance unreachable → stay on demo/polling
    const sym = store.get('symbol');
    const tf = TIMEFRAMES.find((x) => x.id === store.get('timeframe'));
    const klineFor = dataset?.mode === 'live' && dataset.symbol === sym && getInstrument(sym).provider === 'binance' ? { symbol: sym, interval: tf.binance } : null;
    const key = klineFor ? `${klineFor.symbol}|${klineFor.interval}` : 'tickers';
    if (stream && key === streamKey) return;
    stream?.close();
    streamKey = key;
    stream = openBinanceStream({ symbols: BINANCE_SYMBOLS, kline: klineFor, onTicker, onKline, onTrade });
  }

  let lastTradeAt = 0; // while trades flow, the 1 s ticker and kline must not pull the price back
  const tradesFlowing = () => Date.now() - lastTradeAt < 3000;

  function onTicker(tk) {
    if (!tickerCache) tickerCache = {};
    tickerCache[tk.symbol] = { ...tickerCache[tk.symbol], ...tk, mode: 'live', source: 'Binance', error: null };
    cards.update({ [tk.symbol]: tickerCache[tk.symbol] });
    // Move the forming candle with the latest trade price every second.
    if (dataset?.mode === 'live' && dataset.symbol === tk.symbol && !tradesFlowing()) {
      const last = dataset.candles[dataset.candles.length - 1];
      if (last) {
        last.close = tk.price;
        if (tk.price > last.high) last.high = tk.price;
        if (tk.price < last.low) last.low = tk.price;
        scheduleLive(last);
      }
    }
  }

  function onKline(k) {
    if (!dataset || dataset.mode !== 'live' || dataset.symbol !== k.symbol) return;
    const tf = TIMEFRAMES.find((x) => x.id === dataset.tf);
    if (!tf || tf.binance !== k.interval) return;
    const cs = dataset.candles;
    const last = cs[cs.length - 1];
    const bar = { time: k.time, open: k.open, high: k.high, low: k.low, close: k.close, volume: k.volume, buyVolume: k.buyVolume };
    if (last && last.time === bar.time) {
      if (tradesFlowing()) Object.assign(last, { open: bar.open, volume: bar.volume, buyVolume: bar.buyVolume, high: Math.max(last.high, bar.high), low: Math.min(last.low, bar.low) });
      else Object.assign(last, bar);
    }
    else if (!last || bar.time > last.time) { cs.push(bar); if (cs.length > marketConfig.candleLimit + 200) cs.shift(); }
    else {
      // The trade stream already opened the next candle, so the exchange's FINAL values for the one before arrive late:
      // apply them now (otherwise it would be corrected abruptly by the next refresh = a visible jump).
      for (let j = cs.length - 2; j >= Math.max(0, cs.length - 4); j--) {
        if (cs[j].time === bar.time) {
          if (cs[j].close !== bar.close || cs[j].high !== bar.high || cs[j].low !== bar.low || cs[j].open !== bar.open) { Object.assign(cs[j], bar); chartPanel.refreshBars(dataset); }
          break;
        }
      }
      return;
    }
    scheduleLive(cs[cs.length - 1]);
  }

  /* ───────── Real-time candle: every trade moves the forming candle at once; the screen is painted
     once per animation frame with a very short ease (≈ 70 ms) so the candle glides instead of jumping. ───────── */
  let clockOffset = 0;        // exchange time minus this device's clock (ms)
  let haveOffset = false;
  let shown = null;           // what is currently drawn: { ds, time, close, high, low }
  let raf = 0;
  const tfSeconds = () => TIMEFRAMES.find((x) => x.id === dataset?.tf)?.seconds || 0;

  function onTrade(tr) {
    if (!dataset || dataset.mode !== 'live' || dataset.symbol !== tr.symbol || !Number.isFinite(tr.price)) return;
    lastTradeAt = Date.now();
    const off = tr.time - Date.now();
    clockOffset = haveOffset ? clockOffset * 0.9 + off * 0.1 : off;
    haveOffset = true;
    const sec = tfSeconds();
    const cs = dataset.candles;
    let last = cs[cs.length - 1];
    if (!last || !sec) return;
    const slot = Math.floor(tr.time / 1000 / sec) * sec;
    if (slot > last.time) { // the next candle has started: open it now, the kline stream confirms it a moment later
      last = { time: slot, open: tr.price, high: tr.price, low: tr.price, close: tr.price, volume: 0, buyVolume: 0 };
      cs.push(last);
      if (cs.length > marketConfig.candleLimit + 200) cs.shift();
    } else if (slot < last.time) return;
    last.close = tr.price;
    if (tr.price > last.high) last.high = tr.price;
    if (tr.price < last.low) last.low = tr.price;
    scheduleLive(last);
  }

  const fmtLeft = (sec) => {
    const s = Math.max(0, Math.ceil(sec));
    const h = Math.floor(s / 3600); const m = Math.floor((s % 3600) / 60); const r = s % 60;
    const p = (n) => String(n).padStart(2, '0');
    return h ? `${p(h)}:${p(m)}:${p(r)}` : `${p(m)}:${p(r)}`;
  };

  function frame() {
    raf = 0;
    // Stopped while nothing is on screen; kick() restarts it (new data, page shown again, tab visible again).
    if (!el.isConnected || document.hidden || !dataset || dataset.mode !== 'live') { if (dataset?.mode !== 'live') chartPanel.setCountdown(null); return; }
    if (el.closest('[hidden]')) return;   // another page is open: do not paint an invisible chart (onShow() repaints on return)
    const cs = dataset.candles;
    const last = cs[cs.length - 1];
    if (!last) { idleUntilNextSecond(); return; }
    const prec = getInstrument(dataset.symbol).precision;
    const step = 1 / 10 ** prec;
    if (!shown || shown.ds !== dataset || shown.time !== last.time) shown = { ds: dataset, time: last.time, close: last.close, high: last.high, low: last.low, dirty: true };
    let moved = shown.dirty;
    shown.dirty = false;
    if (shown.close !== last.close) {
      const d = last.close - shown.close;
      shown.close = Math.abs(d) < step / 2 ? last.close : shown.close + d * (tradesFlowing() ? 0.45 : 0.12); // ≈ 70 ms with the trade stream, ≈ 350 ms when polled
      moved = true;
    }
    if (shown.high !== last.high || shown.low !== last.low) { shown.high = last.high; shown.low = last.low; moved = true; }
    if (moved) chartPanel.paintBar(dataset, { ...last, close: shown.close, high: Math.max(last.high, shown.close), low: Math.min(last.low, shown.close) });
    const sec = tfSeconds();
    if (sec) {
      const left = last.time + sec - (Date.now() + clockOffset) / 1000;
      chartPanel.setCountdown(fmtLeft(left), left <= 10 ? 2 : left <= 30 ? 1 : 0, shown.close);
    }
    // Every frame only while the price is gliding; otherwise wake once per second for the countdown.
    // (A permanent 60 fps loop forced the browser to run a full main-thread frame all the time, on every page.)
    if (shown.close !== last.close) raf = requestAnimationFrame(frame);
    else idleUntilNextSecond();
  }
  let idleTimer = 0;
  function idleUntilNextSecond() {
    clearTimeout(idleTimer);
    idleTimer = setTimeout(() => { idleTimer = 0; kick(); }, 1005 - ((Date.now() + clockOffset) % 1000));
  }
  function kick() {
    if (raf || !el.isConnected || document.hidden || el.closest('[hidden]')) return;
    clearTimeout(idleTimer); idleTimer = 0;
    raf = requestAnimationFrame(frame);
  }
  const onVisible = () => {
    if (!document.hidden) kick();
    else { cancelAnimationFrame(raf); raf = 0; clearTimeout(idleTimer); idleTimer = 0; }
  };
  document.addEventListener('visibilitychange', onVisible);
  kick();

  function scheduleLive(bar) {
    dataset.fetchedAt = Date.now();
    kick();   // new price: paint it on the next frame
    if (liveTimer) { liveTimer.bar = bar; return; }
    // Keep a steady one-second cadence: run as soon as a second has passed since the last refresh.
    const wait = Math.max(0, 1000 - (Date.now() - lastLiveRun));
    liveTimer = { bar, id: setTimeout(() => {
      const b = liveTimer.bar;
      liveTimer = null;
      lastLiveRun = Date.now();
      if (!el.isConnected || !dataset) return;
      analysis = computeAnalysis(dataset, store.get('settings'));
      // Hidden behind another page: keep the chart alerts working, skip the AI and the invisible panels (onShow() refreshes them).
      if (el.closest('[hidden]')) { notifyPlan(analysis); notifyFibBreak(analysis); return; }
      attachAi(false);
      notifyPlan(analysis);
      notifyFibBreak(analysis);
      chartPanel.liveUpdate(dataset, analysis);
      side.update(analysis); synth.update(analysis, dataset); progress.update(analysis, dataset); ticker.update(analysis.symbol);
      pressure.update(analysis, chartPanel.chart.chart.timeScale().getVisibleLogicalRange());
    }, wait) };
  }

  function applyDataset(ds, keepRange) {
    const prev = shown && dataset && dataset.symbol === ds.symbol && dataset.tf === ds.tf ? shown : null;
    dataset = ds;
    analysis = computeAnalysis(ds, store.get('settings'));
    attachAi();
    ensureHtf();
    notifyPlan(analysis);
    chartPanel.setData(ds, analysis, { keepRange });
    // A polled refresh (gold / indices / no stream) brings a new last price: glide from what was on screen instead of snapping.
    const lastBar = ds.candles[ds.candles.length - 1];
    if (prev && lastBar && prev.time === lastBar.time && prev.close !== lastBar.close) {
      shown = { ds, time: lastBar.time, close: prev.close, high: lastBar.high, low: lastBar.low, dirty: true };
      chartPanel.paintBar(ds, { ...lastBar, close: prev.close, high: Math.max(lastBar.high, prev.close), low: Math.min(lastBar.low, prev.close) });
    }
    side.update(analysis); synth.update(analysis, dataset); progress.update(analysis, dataset); ticker.update(analysis.symbol);
    pressure.update(analysis, chartPanel.chart.chart.timeScale().getVisibleLogicalRange());
    ai.refresh();
    emitDemo();
    ensureStream();
    kick();
  }

  let tickerLoading = false;
  async function loadTickers() {
    if (tickerLoading) return;
    tickerLoading = true;
    try {
      // While the stream is open, crypto prices arrive every second; poll only the other providers.
      // v243: the cards on screen and the open chart every second; the rest of the strip every 10 s (so the price hub
      // and the upstream only work for what someone is actually looking at).
      tickN += 1;
      const pool = streamLive() ? INSTRUMENTS.filter((i) => i.provider !== 'binance').map((i) => i.symbol) : INSTRUMENTS.map((i) => i.symbol);
      const hot = new Set([...onScreen, store.get('symbol')]);
      const symbols = tickN % 10 === 1 || !onScreen.size ? pool : pool.filter((x) => hot.has(x));
      if (!symbols.length) return;
      const fresh = await getTickers(symbols);
      if (!el.isConnected) return;
      tickerCache = { ...(tickerCache || {}), ...fresh };
      cards.update(tickerCache);
      tickerDemo = Object.values(tickerCache).filter((x) => x.mode === 'demo').map((x) => x.symbol);
      const hidden = Object.values(tickerCache).filter((x) => x.mode === 'unavailable').map((x) => x.symbol);
      chartPanel.setUnavailable(hidden);
      // If the open chart is one of them, move to the first available symbol.
      if (hidden.includes(store.get('symbol'))) store.set('symbol', INSTRUMENTS.find((i) => !hidden.includes(i.symbol)).symbol);
      emitDemo();
      ensureStream();
    } catch (err) {
      if (el.isConnected) toast(describeError(err, t), 'error');
    } finally { tickerLoading = false; }
  }

  function startTool(tool) {
    const btn = chartPanel.el.querySelector(`[data-tool="${tool}"]`);
    if (btn && chartPanel.chart.tool !== tool) btn.click();
    chartPanel.el.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }

  function tick() {
    if (document.hidden || !el.isConnected || el.closest('[hidden]')) return;
    loadTickers();
    // Streamed symbols update themselves; others (and a broken stream) are polled.
    const streamed = streamLive() && streamKey.startsWith(`${dataset?.symbol}|`);
    if (dataset && dataset.mode === 'live' && !streamed) load({ quiet: true });
  }

  const offs = [
    store.on('symbol', () => load()),
    store.on('timeframe', () => load()),
    store.on('settings', () => { ensureHtf(); recompute(); }),
    store.on('theme', () => { chartPanel.refreshTheme(); pressure.refreshTheme(); recompute(); }),
    store.on('palette', () => { chartPanel.refreshTheme(); pressure.refreshTheme(); recompute(); }),
  ];

  if (tickerCache) cards.update(tickerCache);
  loadTickers();
  load();
  timer = setInterval(tick, marketConfig.refreshSeconds * 1000);

  return {
    el,
    openIndicators,
    startTool,
    getAnalysis: () => analysis,
    onShow() { requestAnimationFrame(() => recompute()); if (shown) shown.dirty = true; kick(); },
    destroy() {
      clearInterval(timer);
      cancelAnimationFrame(raf); clearTimeout(idleTimer);
      document.removeEventListener('visibilitychange', onVisible);
      stream?.close();
      if (liveTimer) clearTimeout(liveTimer.id);
      offs.forEach((off) => off());
      cards.destroy(); seen?.disconnect();
      ai.destroy();
      assist.destroy();
      chartPanel.destroy();
      pressure.destroy();
    },
  };
}
