// Academy: six short lessons with a 3-question check each; progress is kept on this device (and synced with the account).
import { h, esc } from '../utils/dom.js';
import { getLang } from '../i18n/index.js';

import { storage } from '../utils/storage.js';
import { LESSONS } from './academyContent.js';

const L = (ar, en) => (getLang() !== 'ar' ? en : ar);
const done = () => storage.get('academy-done', {}) || {};

export function renderAcademy() {
  const lessons = LESSONS[getLang() !== 'ar' ? 'en' : 'ar'];
  const el = h(`<section class="subpage academy page-enter">
    <header class="subpage-head"><h1>${esc(L('الأكاديمية', 'Academy'))}</h1><p class="muted">${esc(L('دروس قصيرة وعملية عن إدارة المخاطر وSMC وICT، وبآخر كل درس 3 أسئلة. تعليم بس — مش نصيحة مالية.', 'Short, practical lessons on risk, SMC and ICT, each with a 3-question check. Education only — not financial advice.'))}</p></header>
    <div data-a></div></section>`);
  const box = el.querySelector('[data-a]');
  const list = () => {
    const d = done(); const n = lessons.filter((x) => d[x.id]).length;
    box.innerHTML = `<div class="ac-progress"><span>${esc(L(`خلّصت ${n} من ${lessons.length}`, `${n} of ${lessons.length} done`))}</span><div class="sa-progress"><span style="width:${Math.round((n / lessons.length) * 100)}%"></span></div></div>
      <div class="ac-grid">${lessons.map((x, i) => `<button type="button" class="card ac-card ${d[x.id] ? 'is-done' : ''}" data-l="${x.id}"><span class="ac-num">${d[x.id] ? '✓' : i + 1}</span><b>${esc(x.title)}</b><small class="muted">${esc(L(`${x.min} دقايق · 3 أسئلة`, `${x.min} min · 3 questions`))}</small></button>`).join('')}</div>`;
    box.querySelectorAll('[data-l]').forEach((b) => b.addEventListener('click', () => open(b.dataset.l)));
  };
  const open = (id) => {
    const x = lessons.find((y) => y.id === id); const answers = [];
    box.innerHTML = `<article class="card tool-card ac-lesson">
      <button type="button" class="btn btn-sm btn-ghost" data-back>${esc(L('← كل الدروس', '← All lessons'))}</button>
      <h2>${esc(x.title)}</h2>
      <ol class="ac-points">${x.points.map((p) => `<li>${esc(p)}</li>`).join('')}</ol>
      <h3 class="sa-h">${esc(L('اختبر حالك', 'Check yourself'))}</h3>
      ${x.quiz.map((q, qi) => `<div class="ac-q" data-q="${qi}"><p><b>${qi + 1}.</b> ${esc(q.q)}</p><div class="ac-opts">${q.a.map((a, ai) => `<button type="button" class="btn btn-sm" data-a="${ai}">${esc(a)}</button>`).join('')}</div><p class="ac-why" hidden></p></div>`).join('')}
      <p class="ac-result" hidden></p></article>`;
    box.querySelector('[data-back]').addEventListener('click', list);
    box.querySelectorAll('[data-q]').forEach((qe) => qe.addEventListener('click', (e) => {
      const b = e.target.closest('[data-a]'); if (!b || qe.classList.contains('is-answered')) return;
      const qi = Number(qe.dataset.q); const q = x.quiz[qi]; const ok = Number(b.dataset.a) === q.ok; answers[qi] = ok;
      qe.classList.add('is-answered'); b.classList.add(ok ? 'is-ok' : 'is-no'); qe.querySelector(`[data-a="${q.ok}"]`).classList.add('is-ok');
      const w = qe.querySelector('.ac-why'); w.hidden = false; w.textContent = `${ok ? L('صح ✓', 'Correct ✓') : L('مش هيك ✗', 'Not quite ✗')} — ${q.why}`;
      if (answers.filter((v) => v !== undefined).length === x.quiz.length) {
        const score = answers.filter(Boolean).length; const r = box.querySelector('.ac-result'); r.hidden = false;
        if (score === x.quiz.length) { const d = done(); d[x.id] = Date.now(); storage.set('academy-done', d); r.textContent = L('ممتاز! الدرس خلص ✓', 'Great! Lesson complete ✓'); r.className = 'ac-result up'; }
        else { r.innerHTML = `${esc(L(`${score} من ${x.quiz.length}. اقرا النقاط مرة تانية وجرّب.`, `${score} of ${x.quiz.length}. Read the points again and retry.`))} <button type="button" class="btn btn-sm" data-retry>${esc(L('جرّب كمان مرة', 'Try again'))}</button>`; r.querySelector('[data-retry]').addEventListener('click', () => open(id)); }
      }
    }));
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };
  list();
  return el;
}
