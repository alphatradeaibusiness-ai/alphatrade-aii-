// Profile page: photo, name and password.
import { h, esc } from '../utils/dom.js';
import { icons } from '../components/icons.js';
import { t, getLang, setLang, LANGS } from '../i18n/index.js';
import { tx } from '../i18n/tx.js';
import { auth, validate } from '../services/auth/index.js';
import { authErrorMessage } from '../services/auth/errors.js';
import { authConfig } from '../config/auth.js';
import { getAvatar, setAvatar, resizeImage, avatarInner } from '../services/profile.js';
import { toast } from '../components/ui.js';
import { renderHistory } from '../components/smcAssistPanel.js';
import { accountDataHtml, bindAccountData } from '../components/accountData.js';
import { faceCard } from '../components/faceCard.js';
import { getTradingStyle, setTradingStyle } from '../services/tradingStyle.js';

function pwField(name, labelKey, autocomplete) {
  return `<div class="field-wrap">
    <label class="field"><span class="visually-hidden">${esc(t(labelKey))}</span>
      <span class="field-icon">${icons.lock}</span>
      <input name="${name}" type="password" placeholder="${esc(t(labelKey))}" autocomplete="${autocomplete}"/>
      <button type="button" class="field-action" data-toggle-pw aria-label="show/hide">${icons.eye}</button>
    </label>
    <p class="field-error" data-error-for="${name}" role="alert"></p>
  </div>`;
}

export function renderProfile() {
  const user = auth.current() || {};
  const providerKey = auth.mode === 'local' ? 'local' : user.provider || 'password';
  const providerName = t(`profile.providers.${providerKey}`);
  const canPw = auth.canChangePassword();

  const el = h(`<section class="subpage profile page-enter">
    <header class="subpage-head"><h1>${esc(t('profile.title'))}</h1><p class="muted">${esc(t('profile.sub'))}</p></header>
    <div class="profile-grid">
      <article class="card profile-card profile-photo fade-in">
        <h2 class="card-title">${esc(t('profile.photo'))}</h2>
        <div class="pp-wrap">
          <button type="button" class="pp-avatar" data-pick aria-label="${esc(t('profile.change'))}">
            <span class="pp-img">${avatarInner(user)}</span>
            <span class="pp-cam">${icons.camera}</span>
          </button>
          <div class="pp-name">${esc(user.name || '')}</div>
          <div class="muted mono pp-email">${esc(user.email || '')}</div>
        </div>
        <input type="file" accept="image/*" data-file hidden/>
        <div class="pp-actions">
          <button type="button" class="btn btn-primary btn-sm" data-pick>${icons.camera}<span>${esc(t('profile.change'))}</span></button>
          <button type="button" class="btn btn-sm btn-ghost" data-remove ${getAvatar(user) ? '' : 'hidden'}>${icons.trash}<span>${esc(t('profile.remove'))}</span></button>
        </div>
        <p class="muted pp-hint">${esc(t('profile.photoHint'))}</p>
      </article>

      <article class="card profile-card fade-in" style="animation-delay:60ms">
        <h2 class="card-title">${esc(t('profile.info'))}</h2>
        <form class="auth-form" data-name-form novalidate>
          <div class="field-wrap">
            <label class="field"><span class="visually-hidden">${esc(t('profile.name'))}</span><span class="field-icon">${icons.user}</span>
              <input name="name" type="text" maxlength="60" autocomplete="name" placeholder="${esc(t('profile.name'))}" value="${esc(user.name || '')}"/></label>
            <p class="field-error" data-error-for="name" role="alert"></p>
          </div>
          <dl class="kv-list">
            <div><dt>${esc(t('profile.email'))}</dt><dd class="mono">${esc(user.email || '')}</dd></div>
            <div><dt>${esc(t('profile.via'))}</dt><dd>${esc(providerName)}</dd></div>
          </dl>
          <button class="btn btn-primary" type="submit"><span data-label>${esc(t('profile.saveName'))}</span></button>
        </form>
      </article>

      <article class="card profile-card fade-in" style="animation-delay:120ms">
        <h2 class="card-title">${esc(t('profile.password'))}</h2>
        ${canPw ? `<form class="auth-form" data-pw-form novalidate>
          ${pwField('current', 'profile.current', 'current-password')}
          ${pwField('password', 'profile.next', 'new-password')}
          ${pwField('confirm', 'profile.confirm', 'new-password')}
          <div data-form-msg></div>
          <button class="btn btn-primary" type="submit"><span data-label>${esc(t('profile.updatePassword'))}</span></button>
        </form>` : `<div class="alert alert-info">${icons.info}<div>${esc(t('profile.noPassword', { provider: providerName }))}</div></div>`}
      </article>
    </div>
  </section>`);

  const $ = (s) => el.querySelector(s);

  // Photo
  const file = $('[data-file]');
  el.querySelectorAll('[data-pick]').forEach((b) => b.addEventListener('click', () => file.click()));
  file.addEventListener('change', async () => {
    const f = file.files[0];
    file.value = '';
    if (!f) return;
    try {
      const url = await resizeImage(f, 256);
      setAvatar(user, url);
      $('.pp-img').innerHTML = avatarInner(user);
      $('[data-remove]').hidden = false;
      toast(t('profile.photoSaved'), 'success');
    } catch (e) {
      toast(t(e.message === 'size' ? 'profile.photoSize' : e.message === 'type' ? 'profile.photoType' : 'profile.photoRead'), 'error');
    }
  });
  $('[data-remove]').addEventListener('click', () => {
    setAvatar(user, null);
    $('.pp-img').innerHTML = avatarInner(user);
    $('[data-remove]').hidden = true;
    toast(t('profile.photoRemoved'), 'info');
  });

  // Show/hide password
  el.querySelectorAll('[data-toggle-pw]').forEach((b) => b.addEventListener('click', () => {
    const input = b.parentElement.querySelector('input');
    const show = input.type === 'password';
    input.type = show ? 'text' : 'password';
    b.innerHTML = show ? icons.eyeOff : icons.eye;
  }));

  const setErr = (form, name, key, params) => {
    const p = form.querySelector(`[data-error-for="${name}"]`);
    if (!p) return;
    p.textContent = key ? t(`auth.err.${key}`, params) : '';
    p.closest('.field-wrap').querySelector('.field').classList.toggle('has-error', Boolean(key));
  };
  const busy = (form, on, labelKey) => {
    const b = form.querySelector('[type=submit]');
    b.disabled = on;
    b.querySelector('[data-label]').textContent = t(on ? 'profile.saving' : labelKey);
  };

  // Name
  const nameForm = $('[data-name-form]');
  nameForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const name = nameForm.name.value.trim();
    setErr(nameForm, 'name', name ? null : 'nameRequired');
    if (!name) return;
    busy(nameForm, true, 'profile.saveName');
    try {
      await auth.updateName(name);
      $('.pp-name').textContent = name;
      document.querySelectorAll('[data-user-name]').forEach((n) => { n.textContent = name; });
      toast(t('profile.nameSaved'), 'success');
    } catch (err) { toast(authErrorMessage(err, t), 'error'); }
    busy(nameForm, false, 'profile.saveName');
  });

  // Password
  const pwForm = $('[data-pw-form]');
  if (pwForm) {
    pwForm.addEventListener('input', (e) => setErr(pwForm, e.target.name, null));
    pwForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const v = Object.fromEntries(new FormData(pwForm));
      ['current', 'password', 'confirm'].forEach((n) => setErr(pwForm, n, null));
      pwForm.querySelector('[data-form-msg]').innerHTML = '';
      if (!v.current) { setErr(pwForm, 'current', 'passwordRequired'); return; }
      const errs = validate({ password: v.password, confirm: v.confirm }, 'reset');
      if (errs.password) { setErr(pwForm, 'password', errs.password, { n: authConfig.minPasswordLength }); return; }
      if (errs.confirm) { setErr(pwForm, 'confirm', errs.confirm); return; }
      if (v.password === v.current) { setErr(pwForm, 'password', 'samePassword'); return; }
      busy(pwForm, true, 'profile.updatePassword');
      try {
        await auth.changePassword(v.current, v.password);
        pwForm.reset();
        toast(t('profile.passwordSaved'), 'success');
      } catch (err) {
        if (err?.code === 'wrongPassword') setErr(pwForm, 'current', 'wrongPassword');
        else pwForm.querySelector('[data-form-msg]').innerHTML = `<div class="alert alert-error">${icons.alert}<div>${esc(authErrorMessage(err, t))}</div></div>`;
      }
      busy(pwForm, false, 'profile.updatePassword');
    });
  }
  // Language of the whole app (also auto-detected from the browser on the first visit / at sign-up).
  const langCard = h(`<article class="card profile-card fade-in"><h2 class="card-title">${icons.globe}<span>${esc(tx({ ar: 'لغة التطبيق', en: 'App language', he: 'שפת האפליקציה', es: 'Idioma de la app', zh: '应用语言' }))}</span></h2>
    <div class="seg profile-langs" role="radiogroup">${LANGS.map(([k, n]) => `<button type="button" data-set-lang="${k}" class="${getLang() === k ? 'is-on' : ''}" role="radio" aria-checked="${getLang() === k}">${n}</button>`).join('')}</div>
    <p class="muted">${esc(tx({ ar: 'بتتغيّر كل القوائم والأزرار والرسائل فورًا. اتجاه الصفحة بيتغيّر لحاله للعربي والعبري.', en: 'Menus, buttons and messages change at once. The page direction switches automatically for Arabic and Hebrew.', he: 'התפריטים, הכפתורים וההודעות משתנים מיד. כיוון העמוד מתחלף אוטומטית לערבית ועברית.', es: 'Los menús, botones y mensajes cambian al instante. La dirección cambia sola para árabe y hebreo.', zh: '菜单、按钮和消息立即切换。阿拉伯语和希伯来语自动从右到左显示。' }))}</p></article>`);
  langCard.addEventListener('click', (e) => { const b = e.target.closest('[data-set-lang]'); if (b) setLang(b.dataset.setLang); });
  el.append(langCard);
  // v249: trading style — «توصية AI» follows only this choice
  const TS = () => [['scalp', icons.bolt || '', tx({ ar: 'سكالب', en: 'Scalping', he: 'סקאלפינג', es: 'Scalping', zh: '短线' }), tx({ ar: 'صفقات سريعة على فريم 1–15 دقيقة.', en: 'Quick trades on 1–15 minute charts.', he: 'עסקאות מהירות בגרפים של 1–15 דקות.', es: 'Operaciones rápidas en gráficos de 1–15 minutos.', zh: '1–15 分钟图表上的快速交易。' })],
    ['swing', icons.trend || '', tx({ ar: 'سوينغ', en: 'Swing', he: 'סווינג', es: 'Swing', zh: '波段' }), tx({ ar: 'صفقات على فريم ساعة لـ يوم.', en: 'Trades on 1h–1D charts.', he: 'עסקאות בגרפים של שעה עד יום.', es: 'Operaciones en gráficos de 1h–1D.', zh: '1 小时至日线图表上的交易。' })]];
  const styleCard = h(`<article class="card profile-card fade-in" data-trading-style><h2 class="card-title">${icons.crosshair || ''}<span>${esc(tx({ ar: 'أسلوب التداول', en: 'Trading style', he: 'סגנון מסחר', es: 'Estilo de trading', zh: '交易风格' }))}</span></h2>
    <div class="seg profile-langs" role="radiogroup">${TS().map(([k, , n]) => `<button type="button" data-set-style="${k}" class="${getTradingStyle() === k ? 'is-on' : ''}" role="radio" aria-checked="${getTradingStyle() === k}">${esc(n)}</button>`).join('')}</div>
    <p class="muted" data-style-note></p></article>`);
  const styleNote = () => {
    const v = getTradingStyle(); const d = TS().find((x) => x[0] === v);
    styleCard.querySelector('[data-style-note]').textContent = d ? `${d[3]} ${tx({ ar: 'توصيات AI بتلتزم بهالأسلوب بس.', en: 'AI recommendations follow this style only.', he: 'המלצות ה-AI עוקבות אחרי הסגנון הזה בלבד.', es: 'Las recomendaciones de IA siguen solo este estilo.', zh: 'AI 推荐只遵循此风格。' })}`
      : tx({ ar: 'اختار أسلوبك، وتوصيات AI رح تلتزم فيه بس.', en: 'Choose your style; AI recommendations will follow it only.', he: 'בחר את הסגנון שלך; המלצות ה-AI יעקבו רק אחריו.', es: 'Elige tu estilo; las recomendaciones de IA solo lo seguirán.', zh: '选择你的风格；AI 推荐将只遵循它。' });
  };
  styleNote();
  styleCard.addEventListener('click', (e) => {
    const b = e.target.closest('[data-set-style]'); if (!b) return;
    setTradingStyle(b.dataset.setStyle);
    styleCard.querySelectorAll('[data-set-style]').forEach((x) => { const on = x === b; x.classList.toggle('is-on', on); x.setAttribute('aria-checked', String(on)); });
    styleNote(); toast(tx({ ar: 'انحفظ أسلوب التداول.', en: 'Trading style saved.', he: 'סגנון המסחר נשמר.', es: 'Estilo de trading guardado.', zh: '交易风格已保存。' }), 'success');
  });
  el.append(styleCard);
  // The user's SMC / ICT assistant trades (kept in their account when the server is reachable).
  const hist = h(`<article class="card profile-card sa-profile fade-in"><h2 class="card-title">${icons.crosshair}<span>${esc(t('sa.history.title'))}</span></h2><div data-sa-hist-full></div></article>`);
  el.append(hist);
  renderHistory(hist.querySelector('[data-sa-hist-full]'));
  el.append(faceCard());
  const data = h(accountDataHtml()); el.append(data); bindAccountData(data);
  return el;
}
