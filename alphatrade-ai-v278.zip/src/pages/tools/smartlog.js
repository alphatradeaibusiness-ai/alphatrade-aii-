// Smart trade log: analyses closed trades automatically — either the platform strategies' real
// trades (last 1000 real candles per asset/timeframe, with the user's current settings) or the
// user's own journal — and shows strengths, weaknesses, diagnostics, a "what if" and one-tap fixes.
import { esc, fmtNum } from '../../utils/dom.js';
import { icons } from '../../components/icons.js';
import { t, getLang } from '../../i18n/index.js';
import { storage } from '../../utils/storage.js';
import { store } from '../../state/store.js';
import { INSTRUMENTS, getInstrument, STOP_LOSS_POINTS, TARGET_POINTS } from '../../config/instruments.js';
import { getHistory, isUnavailable } from '../../services/market/index.js';
import { backtestClassic, backtestSmc, rulesFrom } from '../../services/backtest.js';
import { setStrategy } from '../../services/strategy.js';
import { ema, atr } from '../../indicators/index.js';
import { analyzeTrades, MIN_SEG } from '../../services/tradeInsights.js';
import { tradeResult } from './journal.js';
import { toolPage, pointSizeOf, whileMounted, loading, dateStr, signed, lineSvg } from './common.js';
import { toast } from '../../components/ui.js';
import { reviewTrades } from '../../services/ai/client.js';
import { reviewContext } from '../../services/ai/reviewContext.js';
import { aiErrorText } from '../../components/aiKeyCard.js';

const TFS = ['15m', '1h', '4h'];
const DIM_KEYS = ['strategy', 'symbol', 'tf', 'direction', 'session', 'weekday', 'volatility', 'trend', 'afterLoss'];
const pause = (ms) => new Promise((r) => setTimeout(r, ms));

/** Platform trades for one dataset, normalised for the analyser (entry volatility and trend added). */
function platformTrades(ds, settings) {
  const inst = getInstrument(ds.symbol);
  const c = ds.candles;
  const rules = { ...rulesFrom(settings, inst), forced: null, pointSize: pointSizeOf(ds.symbol), slPoints: STOP_LOSS_POINTS, tpPoints: TARGET_POINTS, volumeKind: ds.volumeKind, openOnLast: false };
  const idx = new Map(c.map((x, i) => [x.time, i]));
  const a = atr(c, 14);
  const e200 = ema(c.map((x) => x.close), 200);
  const out = [];
  for (const strategy of ['classic', 'smc']) {
    const run = (strategy === 'smc' ? backtestSmc : backtestClassic)(c, rules);
    for (const tr of run.trades) {
      const i = idx.get(tr.openTime);
      const price = c[i]?.close;
      out.push({
        symbol: ds.symbol, tf: ds.tf, strategy, direction: tr.direction, openTime: tr.openTime * 1000, closeTime: tr.closeTime * 1000,
        r: tr.r, hits: tr.hits, source: 'platform',
        atrPct: i != null && a[i] ? (a[i] / price) * 100 : null,
        withTrend: i != null && e200[i] != null ? (tr.direction === 'long') === (price > e200[i]) : null,
      });
    }
  }
  return out;
}

/** Journal trades → analyser shape (trades without a stop have no R and are left out). */
function journalTrades() {
  return storage.get('journal', []).map((x) => {
    const r = tradeResult(x);
    return { symbol: x.symbol, tf: x.tf || null, strategy: x.strategy, direction: x.direction, openTime: x.openedAt || x.closedAt, closeTime: x.closedAt, r: r.r, hits: null, source: x.source };
  });
}

export function renderSmartlog() {
  const el = toolPage('smartlog', 'brain');
  const avail = INSTRUMENTS.filter((i) => !isUnavailable(i.symbol));
  const saved = storage.get('smartlog', {});
  const jCount = journalTrades().filter((x) => Number.isFinite(x.r)).length;
  const st = {
    source: saved.source || 'journal',   // your own trades by default; the backtest view is opt-in and labelled as such strategy: saved.strategy || 'all', dim: saved.dim || 'symbol',
    symbols: saved.symbols?.length ? saved.symbols : avail.filter((i) => i.type === 'crypto').map((i) => i.symbol),
  };
  const save = () => storage.set('smartlog', st);
  const body = el.querySelector('[data-body]');
  body.innerHTML = `
    <div class="card perf-controls fade-in">
      <div class="perf-field"><span>${esc(t('tools.smartlog.source'))}</span><div class="seg" data-src>
        <button type="button" data-v="platform" class="${st.source === 'platform' ? 'is-on' : ''}">${esc(t('tools.smartlog.srcPlatform'))}</button>
        <button type="button" data-v="journal" class="${st.source === 'journal' ? 'is-on' : ''}">${esc(t('tools.smartlog.srcJournal'))} (${jCount})</button></div></div>
      <div class="perf-field"><span>${esc(t('perf.strategy'))}</span><div class="seg" data-strat>${['all', 'classic', 'smc'].map((s) => `<button type="button" data-v="${s}" class="${st.strategy === s ? 'is-on' : ''}">${s === 'smc' ? 'SMC' : esc(t(s === 'all' ? 'tools.common.all' : 'perf.classic'))}</button>`).join('')}</div></div>
      <div class="perf-field sl-syms" ${st.source === 'platform' ? '' : 'hidden'}><span>${esc(t('tools.autotest.symbols'))}</span><div class="chips" data-syms>${avail.map((i) => `<button type="button" class="chip ${st.symbols.includes(i.symbol) ? 'is-on' : ''}" data-v="${i.symbol}">${i.symbol}</button>`).join('')}</div></div>
      <button type="button" class="btn btn-sm btn-ghost" data-run>${icons.refresh}<span>${esc(t('tools.smartlog.reanalyze'))}</span></button>
    </div>
    <div class="sl-status muted" data-status></div>
    <div class="tool-body" data-out>${loading()}</div>`;
  const $ = (s) => body.querySelector(s);
  let raw = [];
  let token = 0;

  const segClick = (sel, key, after) => $(sel).addEventListener('click', (e) => {
    const b = e.target.closest('[data-v]'); if (!b) return;
    st[key] = b.dataset.v; save();
    $(sel).querySelectorAll('button').forEach((x) => x.classList.toggle('is-on', x === b));
    after();
  });
  segClick('[data-src]', 'source', () => { $('.sl-syms').hidden = st.source !== 'platform'; load(); });
  segClick('[data-strat]', 'strategy', () => draw());
  $('[data-syms]').addEventListener('click', (e) => {
    const b = e.target.closest('[data-v]'); if (!b) return;
    st.symbols = st.symbols.includes(b.dataset.v) ? st.symbols.filter((x) => x !== b.dataset.v) : [...st.symbols, b.dataset.v];
    b.classList.toggle('is-on'); save(); load();
  });
  $('[data-run]').addEventListener('click', () => load());

  // Human labels for every group.
  const label = (dim, key) => {
    if (dim === 'symbol') return key;
    if (dim === 'tf') return t(`perf.tfShort.${key}`);
    if (dim === 'strategy') return key === 'smc' ? 'SMC' : key === 'classic' ? t('perf.classic') : t('tools.journal.other');
    if (dim === 'direction') return t(key === 'long' ? 'common.long' : 'common.short');
    if (dim === 'weekday') return new Date(Date.UTC(2024, 0, 7 + Number(key))).toLocaleDateString(getLang() === 'ar' ? 'ar-EG' : 'en-GB', { weekday: 'long', timeZone: 'UTC' });
    return t(`tools.smartlog.k.${dim}.${key}`);
  };
  const groupName = (g) => `${t(`tools.smartlog.dim.${g.dim}`)}: ${label(g.dim, g.key)}`;
  const R = (v, d = 2) => signed(v, d, 'R');

  function actionsFor(res) {
    // One-tap fixes for weaknesses the settings can change.
    const acts = [];
    const plan = store.get('settings').plan;
    const dirW = res.weaknesses.find((w) => w.dim === 'direction');
    if (dirW && st.source === 'platform') {
      const other = dirW.key === 'long' ? 'short' : 'long';
      const g = res.dims.direction.find((x) => x.key === other);
      if (g && g.avgR > 0) acts.push({ id: 'dir', text: t('tools.smartlog.act.dir', { d: label('direction', other) }), run: () => store.updateSettings('plan', { direction: other }) });
    }
    const stratRows = res.dims.strategy;
    if (stratRows.length === 2 && st.strategy === 'all') {
      const [best, worst] = stratRows;
      if (best.n >= MIN_SEG && best.avgR > 0 && worst.avgR < 0 && store.get('settings').strategy !== best.key) acts.push({ id: 'strat', text: t('tools.smartlog.act.strat', { s: label('strategy', best.key) }), run: () => setStrategy(best.key) });
    }
    if (st.source === 'platform') {
      if (res.diag.some((d) => d.key === 'stopTight') && plan.stopMode === 'atr' && plan.atrMult < 3) {
        const v = Math.min(3, (Number(plan.atrMult) || 2) + 0.5);
        acts.push({ id: 'atr', text: t('tools.smartlog.act.atr', { v }), run: () => store.updateSettings('plan', { atrMult: v }) });
      }
      if (res.diag.some((d) => d.key === 'tp3Rare') && plan.stopMode === 'atr' && (plan.tpR?.[2] ?? 3.5) > 2.5) acts.push({ id: 'tp', text: t('tools.smartlog.act.tp'), run: () => store.updateSettings('plan', { tpR: [0.8, 1.6, 2.5] }) });
    }
    if (plan.direction !== 'auto' && !dirW) acts.push({ id: 'auto', text: t('tools.smartlog.act.auto'), run: () => store.updateSettings('plan', { direction: 'auto' }) });
    return acts;
  }

  function draw() {
    const list = raw.filter((x) => st.strategy === 'all' || x.strategy === st.strategy);
    const out = $('[data-out]');
    if (list.length < MIN_SEG) {
      out.innerHTML = `<div class="card sig-empty">${icons.brain}<span>${esc(st.source === 'journal' ? t('tools.smartlog.needJournal', { n: MIN_SEG }) : t('tools.smartlog.needData'))}</span></div>
        ${st.source === 'journal' ? `<a class="btn btn-sm" href="#/app/journal">${icons.journal}<span>${esc(t('nav.journal'))}</span></a>` : ''}`;
      return;
    }
    const res = analyzeTrades(list);
    const o = res.overall;
    const acts = actionsFor(res);
    const gCard = (g, good) => `<li class="sl-ins ${good ? 'good' : 'bad'}"><span class="sl-ins-ico">${good ? icons.check : icons.alert}</span><div>
      <b>${esc(groupName(g))}</b><span>${esc(t('tools.smartlog.insLine', { wr: fmtNum(g.winRate, 0), n: g.n }))} · ${R(g.avgR)} ${esc(t('tools.smartlog.perTrade'))} · ${esc(t('tools.smartlog.net'))} ${R(g.netR, 1)}</span>
      <small class="muted">${esc(t(good ? 'tools.smartlog.vsGood' : 'tools.smartlog.vsBad', { d: fmtNum(Math.abs(g.avgR - o.avgR), 2) }))}</small></div></li>`;
    const outcomeKeys = list.some((x) => x.hits != null) ? ['sl', 'tp1be', 'tp2be', 'tp3'] : ['loss', 'small', 'win'];
    const tzOff = -new Date().getTimezoneOffset() / 60;
    const maxAbs = Math.max(0.3, ...res.hours.filter((h) => h.n >= 2).map((h) => Math.abs(h.avgR)));
    const rows = res.dims[st.dim] || [];
    const maxRow = Math.max(0.2, ...rows.map((g) => Math.abs(g.avgR)));
    const eq = []; let acc = 0;
    [...res.trades].sort((a, b) => a.closeTime - b.closeTime).forEach((x) => eq.push(acc += x.r));

    out.innerHTML = `
      <article class="card sl-score fade-in grade-${res.grade || 'na'}">
        <div class="sl-grade"><b>${res.grade || '—'}</b><span class="muted">${esc(t('tools.smartlog.grade'))}</span><i style="--p:${res.score.toFixed(0)}"></i></div>
        <div class="sl-summary"><h2>${esc(t(`tools.smartlog.verdict.${res.grade || 'na'}`))}</h2>
          <p class="muted">${esc(t('tools.smartlog.summary', { n: o.n, wr: fmtNum(o.winRate, 1), aw: fmtNum(o.avgWin, 2), al: fmtNum(o.avgLoss, 2) }))}</p>
          <div class="kpi-row">
            <div class="mini-kpi ${o.avgR >= 0 ? 'good' : 'bad'}"><span>${esc(t('tools.smartlog.expectancy'))}</span><b>${R(o.avgR)}</b><small>${esc(t('tools.smartlog.perTrade'))}</small></div>
            <div class="mini-kpi ${o.netR >= 0 ? 'good' : 'bad'}"><span>${esc(t('tools.smartlog.net'))}</span><b>${R(o.netR, 1)}</b><small>${o.n} ${esc(t('perf.trades'))}</small></div>
            <div class="mini-kpi"><span>${esc(t('tools.journal.pf'))}</span><b class="mono">${Number.isFinite(o.pf) ? fmtNum(o.pf, 2) : '∞'}</b><small>${esc(t('tools.journal.winRate'))} ${fmtNum(o.winRate, 1)}%</small></div>
            <div class="mini-kpi"><span>${esc(t('tools.smartlog.maxDD'))}</span><b class="mono down"><bdi>−${fmtNum(o.maxDD, 1)}R</bdi></b><small>${esc(t('tools.journal.streak'))} ${o.lossStreak}</small></div>
          </div></div>
      </article>
      <div class="tool-grid">
        <article class="card tool-card fade-in sl-col good"><h2 class="card-title">${icons.trophy}<span>${esc(t('tools.smartlog.strengths'))}</span></h2>
          ${res.strengths.length ? `<ul class="sl-list">${res.strengths.map((g) => gCard(g, true)).join('')}</ul>` : `<p class="muted">${esc(t('tools.smartlog.noStrengths'))}</p>`}</article>
        <article class="card tool-card fade-in sl-col bad"><h2 class="card-title">${icons.alert}<span>${esc(t('tools.smartlog.weaknesses'))}</span></h2>
          ${res.weaknesses.length ? `<ul class="sl-list">${res.weaknesses.map((g) => gCard(g, false)).join('')}</ul>` : `<p class="muted">${esc(t('tools.smartlog.noWeak'))}</p>`}</article>
      </div>
      <article class="card tool-card fade-in sl-reco"><h2 class="card-title">${icons.sparkle}<span>${esc(t('tools.smartlog.reco'))}</span></h2>
        <ul class="tool-list">
          ${res.weaknesses.slice(0, 3).map((g) => `<li>${esc(t('tools.smartlog.avoid', { g: groupName(g) }))}</li>`).join('')}
          ${res.strengths.slice(0, 2).map((g) => `<li>${esc(t('tools.smartlog.focus', { g: groupName(g) }))}</li>`).join('')}
          ${res.diag.map((d) => `<li>${esc(t(`tools.smartlog.diag.${d.key}`, { v: fmtNum(d.v, d.key === 'longStreak' ? 0 : d.key === 'tilt' || d.key === 'bigLosses' ? 2 : 0) }))}</li>`).join('')}
          ${!res.weaknesses.length && !res.diag.length ? `<li>${esc(t('tools.smartlog.allGood'))}</li>` : ''}
        </ul>
        ${acts.length ? `<div class="tool-actions">${acts.map((a, i) => `<button type="button" class="btn btn-sm btn-primary" data-act="${i}">${icons.check}<span>${esc(a.text)}</span></button>`).join('')}</div>` : ''}
        ${res.whatIf ? `<div class="sl-whatif"><b>${esc(t('tools.smartlog.whatIf'))}</b><span>${esc(t('tools.smartlog.whatIfLine', { g: res.whatIf.skip.map(groupName).join(' + ') }))}</span>
          <div class="sl-wi-row"><span>${esc(t('tools.smartlog.now'))} ${R(res.whatIf.before.netR, 1)} · ${fmtNum(res.whatIf.before.winRate, 0)}%</span><span class="sl-arrow">→</span><span>${esc(t('tools.smartlog.after'))} ${R(res.whatIf.after.netR, 1)} · ${fmtNum(res.whatIf.after.winRate, 0)}% · ${res.whatIf.after.n} ${esc(t('perf.trades'))}</span></div>
          <small class="muted">${esc(t('tools.smartlog.whatIfNote'))}</small></div>` : ''}
      </article>
      <div class="tool-grid">
        <article class="card tool-card fade-in"><h2 class="card-title">${icons.bars}<span>${esc(t('tools.smartlog.outcomes'))}</span></h2>
          <div class="sl-outbar">${outcomeKeys.map((k) => { const v = (res.outcomes[k] || 0) / o.n * 100; return v ? `<i class="o-${k}" style="flex:${v}" title="${esc(t(`tools.smartlog.out.${k}`))}"></i>` : ''; }).join('')}</div>
          <ul class="t-legend sl-outleg">${outcomeKeys.map((k) => `<li><i class="o-${k}"></i><span>${esc(t(`tools.smartlog.out.${k}`))}</span><b class="mono">${fmtNum((res.outcomes[k] || 0) / o.n * 100, 0)}%</b></li>`).join('')}</ul></article>
        <article class="card tool-card fade-in"><h2 class="card-title">${icons.calendar}<span>${esc(t('tools.smartlog.hours'))}</span></h2>
          <div class="sl-hours">${res.hours.map((hh) => { const loc = (hh.h + tzOff + 24) % 24; const a = hh.n >= 2 ? Math.min(1, Math.abs(hh.avgR) / maxAbs) : 0; return `<span class="sl-h" style="--a:${a.toFixed(2)};--c:${hh.avgR >= 0 ? '34,197,94' : '240,68,79'};order:${Math.floor(loc)}" title="${String(Math.floor(loc)).padStart(2, '0')}:00 · ${hh.n} · ${fmtNum(hh.avgR, 2)}R"><b>${String(Math.floor(loc)).padStart(2, '0')}</b><small>${hh.n || ''}</small></span>`; }).join('')}</div>
          <p class="muted tool-note">${esc(t('tools.smartlog.hoursNote'))}</p></article>
      </div>
      <article class="card tool-card fade-in"><h2 class="card-title">${icons.grid}<span>${esc(t('tools.smartlog.breakdown'))}</span></h2>
        <div class="chips" data-dims>${DIM_KEYS.filter((d) => res.dims[d].length).map((d) => `<button type="button" class="chip ${st.dim === d ? 'is-on' : ''}" data-v="${d}">${esc(t(`tools.smartlog.dim.${d}`))}</button>`).join('')}</div>
        <div class="table-scroll"><table class="kv-table perf-table sl-table"><thead><tr><th></th><th>${esc(t('perf.trades'))}</th><th>${esc(t('tools.journal.winRate'))}</th><th>${esc(t('tools.smartlog.expectancy'))}</th><th>${esc(t('tools.smartlog.net'))}</th></tr></thead><tbody>
          ${rows.map((g) => `<tr class="${g.n < MIN_SEG ? 'is-thin' : ''}"><td><b>${esc(label(g.dim, g.key))}</b></td><td class="mono">${g.n}</td><td class="mono">${fmtNum(g.winRate, 0)}%</td>
            <td><span class="sl-bar ${g.avgR >= 0 ? 'pos' : 'neg'}"><i style="width:${(Math.abs(g.avgR) / maxRow * 100).toFixed(0)}%"></i></span>${R(g.avgR)}</td><td>${R(g.netR, 1)}</td></tr>`).join('')}
        </tbody></table></div>
        <p class="muted tool-note">${esc(t('tools.smartlog.thin', { n: MIN_SEG }))}</p></article>
      <article class="card tool-card fade-in"><h2 class="card-title">${icons.trend}<span>${esc(t('tools.smartlog.curve'))}</span></h2>${lineSvg(eq)}</article>
      <article class="card tool-card fade-in sl-ai"><h2 class="card-title">${icons.sparkle}<span>${esc(t('tools.smartlog.aiTitle'))}</span></h2>
        <div class="tool-actions"><button type="button" class="btn btn-sm btn-primary" data-ai-review>${icons.sparkle}<span>${esc(t('tools.smartlog.aiBtn'))}</span></button></div>
        <div class="syn-ai-out" data-ai-out aria-live="polite"></div>
        <p class="muted tool-note">${esc(t('tools.smartlog.aiNote'))}</p></article>
      <p class="muted tool-note">${esc(t(st.source === 'platform' ? 'tools.smartlog.notePlatform' : 'tools.smartlog.noteJournal'))}</p>`;
    out.querySelector('[data-ai-review]').addEventListener('click', async (e) => {
      const btn = e.currentTarget; const box = out.querySelector('[data-ai-out]');
      btn.disabled = true; box.className = 'syn-ai-out muted'; box.textContent = t('tools.smartlog.aiBusy');
      try { box.className = 'syn-ai-out'; box.textContent = await reviewTrades(reviewContext(res, { source: st.source, strategy: st.strategy }), getLang()); }
      catch (err) { box.className = 'syn-ai-out down'; box.textContent = err?.code && /^[a-z_]+$/.test(err.code) ? aiErrorText(err.code) : String(err?.message || err); }
      finally { btn.disabled = false; }
    });
    out.querySelector('[data-dims]')?.addEventListener('click', (e) => { const b = e.target.closest('[data-v]'); if (!b) return; st.dim = b.dataset.v; save(); draw(); });
    out.querySelectorAll('[data-act]').forEach((b) => b.addEventListener('click', () => { acts[Number(b.dataset.act)].run(); toast(t('tools.smartlog.applied'), 'success'); setTimeout(load, 300); }));
  }

  async function load() {
    const my = ++token;
    $('[data-out]').innerHTML = loading();
    if (st.source === 'journal') {
      raw = journalTrades();
      const missing = raw.filter((x) => !Number.isFinite(x.r)).length;
      $('[data-status]').textContent = missing ? t('tools.smartlog.noStop', { n: missing }) : '';
      draw();
      return;
    }
    const settings = store.get('settings');
    const next = []; const skipped = [];
    const jobs = st.symbols.flatMap((s) => TFS.map((tf) => [s, tf]));
    for (let k = 0; k < jobs.length; k++) {
      const [s, tf] = jobs[k];
      $('[data-status]').innerHTML = `<span class="spinner"></span> ${esc(t('tools.smartlog.loading', { s, tf: t(`perf.tfShort.${tf}`), k: k + 1, n: jobs.length }))}`;
      try {
        const ds = await getHistory(s, tf, 1000);
        if (my !== token) return;
        if (ds.mode !== 'live') { skipped.push(`${s} ${tf}`); continue; }
        await pause(20);
        next.push(...platformTrades(ds, settings));
      } catch { skipped.push(`${s} ${tf}`); }
    }
    if (my !== token || !el.isConnected) return;
    raw = next;
    $('[data-status]').textContent = `${t('tools.smartlog.updated', { time: dateStr(Date.now(), { hour: '2-digit', minute: '2-digit' }) })}${skipped.length ? ` · ${t('tools.autotest.skipped', { s: skipped.join(', ') })}` : ''}`;
    draw();
  }
  load();
  whileMounted(el, () => { if (st.source === 'platform') load(); }, 10 * 60_000);
  return el;
}
