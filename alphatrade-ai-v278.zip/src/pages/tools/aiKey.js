// "AI key" page: the site's one AI setting (owner only; the server decides who the owner is).
import { esc } from '../../utils/dom.js';
import { icons } from '../../components/icons.js';
import { t } from '../../i18n/index.js';
import { toolPage } from './common.js';
import { aiKeyCardHtml, bindAiKeyCard } from '../../components/aiKeyCard.js';
import { notifyCardHtml, bindNotifyCard } from '../../components/notifyCard.js';
import { tgGateCardHtml, bindTgGateCard } from '../../components/tgGateCard.js';
import { marketKeyCardHtml, bindMarketKeyCard } from '../../components/marketKeyCard.js';
import { payKeyCardHtml, bindPayKeyCard } from '../../components/payKeyCard.js';

export function renderAiKey() {
  const el = toolPage('aiKey', 'lock');
  const body = el.querySelector('[data-body]');
  body.innerHTML = `${aiKeyCardHtml()}
    ${marketKeyCardHtml()}
    ${payKeyCardHtml()}
    ${notifyCardHtml()}
    ${tgGateCardHtml()}
    <article class="card tool-card fade-in"><h2 class="card-title">${icons.sparkle}<span>${esc(t('aiKey.whereTitle'))}</span></h2>
      <ul class="tool-list">${['chat', 'support', 'explain', 'images'].map((k) => `<li>${esc(t(`aiKey.where.${k}`))}</li>`).join('')}</ul>
      <p class="muted tool-note">${esc(t('aiKey.noLiveData'))}</p>
      <p class="muted tool-note">${esc(t('aiKey.howGet'))}</p>
    </article>`;
  bindAiKeyCard(body);
  bindMarketKeyCard(body);
  bindPayKeyCard(body);
  bindNotifyCard(body); bindTgGateCard(body);
  return el;
}
