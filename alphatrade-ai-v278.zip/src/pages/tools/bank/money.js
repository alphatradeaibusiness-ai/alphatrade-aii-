// Planning tab: monthly budgets per category, subscriptions (detected from card charges or added by hand) and automatic saving rules.
import { icons } from '../../../components/icons.js';
import { bankApi } from '../../../services/bank/api.js';
import { dateStr } from '../common.js';
import { T, Tx, esc, CATEGORIES, catName, opts, field, input, badge, fd, amt, card, empty } from './ui.js';

export async function moneyTab(p, B) {
  const [bud, subs, rules, pockets] = await Promise.all([bankApi.budgets().catch(() => ({ items: [], month: '' })), bankApi.subs().catch(() => ({ items: [] })), bankApi.rules().catch(() => ({ items: [] })), bankApi.pockets().catch(() => ({ items: [] }))]);
  if (!B.alive() || B.st.tab !== 'money') return;
  const pk = (id) => pockets.items.find((x) => x.id === id);
  p.innerHTML = `${card(`${T('bd.title')} · ${bud.month}`, icons.bars, `${bud.items.length ? `<ul class="bank-budgets">${bud.items.map((b) => `<li><div class="bank-budget-head"><b>${esc(catName(b.category))}</b> <span class="mono">${amt(b.spent, 'USD')} / ${amt(b.amount, 'USD')}</span> ${b.block ? `<span class="badge badge-demo">${esc(T('bd.blocking'))}</span>` : ''}
        <button class="btn btn-sm btn-ghost" data-bdel="${esc(b.category)}" title="${esc(T('delete'))}">${icons.trash}</button></div>
        <div class="bank-progress ${b.pct >= 100 ? 'is-over' : b.pct >= 80 ? 'is-near' : ''}"><i style="width:${Math.min(100, b.pct)}%"></i></div><small class="muted">${b.pct}%</small></li>`).join('')}</ul>` : empty(T('bd.none'))}
      <form class="bank-form" data-bud>${field(T('lb.category'), `<select class="select" name="category">${opts(CATEGORIES.filter((c) => !['income', 'transfers', 'savings', 'investing'].includes(c)), 'groceries', catName)}</select>`)}
        ${field(`${T('bd.monthly')} (USD)`, input('amount', { mono: true, req: true, mode: 'decimal', ph: '400' }))}<label class="bank-check"><input type="checkbox" name="block"/> ${esc(T('bd.block'))}</label>
        <button class="btn btn-sm btn-primary" type="submit">${icons.check}<span>${esc(T('save'))}</span></button></form><p class="muted tool-note">${esc(T('bd.note'))}</p>`)}
    ${card(T('sb.title'), icons.refresh, `${subs.items.length ? `<div class="table-scroll"><table class="kv-table"><thead><tr><th>${esc(T('vc.merchant'))}</th><th>${esc(T('amount'))}</th><th>${esc(T('every'))}</th><th>${esc(T('sb.next'))}</th><th>${esc(T('status'))}</th><th></th></tr></thead><tbody>${subs.items.map((s) => `<tr><td>${esc(s.merchant)} <small class="muted">${esc(T(`sb.src.${s.source}`))}</small></td>
        <td class="mono">${amt(s.amount, s.currency)}${s.priceUp ? ` <span class="badge badge-error">${esc(T('sb.priceUp'))}</span>` : ''}</td><td>${esc(Tx(`ev.${s.every}`, s.every))}</td><td class="mono">${s.nextDue ? esc(dateStr(s.nextDue, { month: 'short', day: 'numeric' })) : '—'}</td><td>${badge(s.status)}</td>
        <td class="bank-row-actions">${s.status === 'active' ? `<button class="btn btn-sm" data-sa="block" data-id="${esc(s.id)}">${esc(T('sb.stop'))}</button><button class="btn btn-sm btn-ghost" data-sa="ignore" data-id="${esc(s.id)}">${esc(T('sb.ignore'))}</button>` : ''}${s.status === 'blocked' ? `<button class="btn btn-sm" data-sa="unblock" data-id="${esc(s.id)}">${esc(T('sb.resume'))}</button>` : ''}<button class="btn btn-sm btn-ghost" data-sa="delete" data-id="${esc(s.id)}">${icons.trash}</button></td></tr>`).join('')}</tbody></table></div>` : empty(T('sb.none'))}
      <details class="bank-details"><summary>${esc(T('sb.add'))}</summary><form class="bank-form" data-sub>${field(T('vc.merchant'), input('merchant', { max: 40, req: true }))}${field(T('amount'), input('amount', { mono: true, req: true, mode: 'decimal' }))}
        ${field(T('currency'), `<select class="select" name="currency">${opts(['USD', 'EUR'])}</select>`)}${field(T('every'), `<select class="select" name="every">${opts(['weekly', 'monthly', 'yearly'], 'monthly', (x) => Tx(`ev.${x}`, x))}</select>`)}
        ${field(T('sb.next'), input('nextDue', { type: 'date' }))}<button class="btn btn-sm btn-primary" type="submit">${icons.plus}<span>${esc(T('sb.addBtn'))}</span></button></form></details>
      <p class="muted tool-note">${esc(T('sb.note'))}</p>`)}
    ${card(T('ru.title'), icons.piggy, `${rules.items.length ? `<ul class="bank-list">${rules.items.map((r) => `<li><b>${esc(T(`ru.kind.${r.kind}`))}</b> → ${esc(pk(r.pocketId)?.name || '—')}
        <small class="muted">${r.kind === 'roundup' ? esc(T('ru.toN', { n: r.roundTo / 100 })) : r.kind === 'percent' ? `${r.pctBp / 100}%` : `${amt(r.amount, r.currency)} · ${esc(Tx(`ev.${r.every}`, r.every))}`} · ${esc(T('ru.today'))}: ${amt(r.savedToday, r.currency)} / ${amt(r.dailyCap, r.currency)}${r.floor ? ` · ${esc(T('ru.floor'))}: ${amt(r.floor, r.currency)}` : ''}</small>
        ${badge(r.status === 'paused' ? 'cancelled' : 'active')}<span class="bank-row-actions">${r.status === 'active' ? `<button class="btn btn-sm" data-ra="pause" data-id="${esc(r.id)}">${esc(T('pause'))}</button>` : `<button class="btn btn-sm" data-ra="resume" data-id="${esc(r.id)}">${esc(T('resume'))}</button>`}<button class="btn btn-sm btn-ghost" data-ra="delete" data-id="${esc(r.id)}">${icons.trash}</button></span></li>`).join('')}</ul>` : empty(T('ru.none'))}
      ${pockets.items.length ? `<form class="bank-form" data-rule>${field(T('ru.kindL'), `<select class="select" name="kind">${opts(['roundup', 'percent', 'fixed'], 'roundup', (k) => T(`ru.kind.${k}`))}</select>`)}
        ${field(T('pk.pocket'), `<select class="select" name="pocketId">${pockets.items.map((x) => `<option value="${esc(x.id)}" data-cur="${x.currency}">${esc(x.name)} (${x.currency})</option>`).join('')}</select>`)}
        <span class="bank-sub" data-k="roundup">${field(T('ru.roundTo'), `<select class="select" name="roundTo">${opts(['1', '2', '5', '10'], '1')}</select>`)}</span>
        <span class="bank-sub" data-k="percent" hidden>${field(T('ru.pct'), input('pct', { mono: true, ph: '10', mode: 'decimal' }))}</span>
        <span class="bank-sub" data-k="fixed" hidden>${field(T('amount'), input('amount', { mono: true, mode: 'decimal' }))}${field(T('every'), `<select class="select" name="every">${opts(['daily', 'weekly', 'monthly'], 'weekly', (x) => Tx(`ev.${x}`, x))}</select>`)}</span>
        ${field(`${T('dailyCap')} (${T('optional')})`, input('dailyCap', { mono: true, mode: 'decimal' }))}${field(`${T('ru.floor')} (${T('optional')})`, input('floor', { mono: true, mode: 'decimal' }))}
        <button class="btn btn-sm btn-primary" type="submit">${icons.plus}<span>${esc(T('ru.create'))}</span></button></form>` : `<p class="muted">${esc(T('ru.needPocket'))}</p>`}
      <p class="muted tool-note">${esc(T('ru.note'))}</p>`)}`;
  const reload = () => moneyTab(p, B);
  p.querySelector('[data-bud]').addEventListener('submit', async (e) => { e.preventDefault(); const v = fd(e.target); if (await B.act(e.target.querySelector('button'), () => bankApi.setBudget({ category: v.category, amount: v.amount, block: Boolean(v.block) }), T('bd.saved'))) reload(); });
  p.querySelectorAll('[data-bdel]').forEach((b) => b.addEventListener('click', async () => { if (await B.act(b, () => bankApi.deleteBudget(b.dataset.bdel))) reload(); }));
  p.querySelector('[data-sub]').addEventListener('submit', async (e) => { e.preventDefault(); const v = fd(e.target); if (await B.act(e.target.querySelector('button'), () => bankApi.addSub(v), T('sb.added'))) reload(); });
  p.querySelectorAll('[data-sa]').forEach((b) => b.addEventListener('click', async () => { if (b.dataset.sa === 'block' && !window.confirm(T('sb.confirmStop'))) return; if (await B.act(b, () => bankApi.subAction(b.dataset.id, b.dataset.sa))) reload(); }));
  p.querySelectorAll('[data-ra]').forEach((b) => b.addEventListener('click', async () => { if (await B.act(b, () => bankApi.ruleAction(b.dataset.id, b.dataset.ra))) reload(); }));
  const rf = p.querySelector('[data-rule]');
  if (rf) {
    const sync = () => { rf.querySelectorAll('[data-k]').forEach((s) => { s.hidden = s.dataset.k !== rf.kind.value; }); };
    rf.kind.addEventListener('change', sync); sync();
    rf.addEventListener('submit', async (e) => {
      e.preventDefault(); const v = fd(rf);
      const body = { kind: v.kind, pocketId: v.pocketId, ...(v.kind === 'roundup' ? { roundTo: Number(v.roundTo) } : {}), ...(v.kind === 'percent' ? { pct: Number(v.pct) } : {}), ...(v.kind === 'fixed' ? { amount: v.amount, every: v.every } : {}), ...(v.dailyCap ? { dailyCap: v.dailyCap } : {}), ...(v.floor ? { floor: v.floor } : {}) };
      if (await B.act(rf.querySelector('button[type=submit]'), () => bankApi.createRule(body), T('ru.created'))) reload();
    });
  }
}
