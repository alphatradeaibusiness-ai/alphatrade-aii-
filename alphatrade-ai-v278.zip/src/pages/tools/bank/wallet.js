// Wallet tab: balances (spendable / in pockets / in the vault), pockets, the time-locked vault, the currency converter and the
// transaction history with the user's own labels.
import { icons } from '../../../components/icons.js';
import { bankApi } from '../../../services/bank/api.js';
import { dateStr } from '../common.js';
import { T, Tx, esc, fmtMinor, CURRENCIES, CURS, CATEGORIES, catName, opts, field, input, badge, fd, amt, card, empty } from './ui.js';

const TX_TYPES = ['deposit', 'withdrawal', 'withdrawal_hold', 'withdrawal_release', 'card_hold', 'card_purchase', 'card_release', 'card_refund', 'card_fee', 'card_fee_refund', 'invest_buy', 'invest_sell', 'sandbox_credit', 'pocket_in', 'pocket_out', 'vault_in', 'vault_out', 'auto_save', 'fx_out', 'fx_in', 'cashback'];

export function walletTab(p, B) {
  const { st } = B; const ws = st.wallet.wallets; const kyc = st.wallet.kyc;
  p.innerHTML = `<div class="bank-balances">${ws.map((w) => `<article class="card bank-bal"><span class="muted">${w.currency}</span>
      <b class="mono bank-amt" data-bal="${w.currency}">${fmtMinor(w.available, w.currency)}</b>
      <small class="muted">${[w.held ? `${esc(T('held'))}: ${fmtMinor(w.held, w.currency)}` : '', w.pendingDeposits ? `${esc(T('pending'))}: ${fmtMinor(w.pendingDeposits, w.currency)}` : '',
        w.pockets ? `${esc(T('w.inPockets'))}: ${fmtMinor(w.pockets, w.currency)}` : '', w.vault ? `${esc(T('w.inVault'))}: ${fmtMinor(w.vault, w.currency)}` : ''].filter(Boolean).join(' · ')}</small></article>`).join('')}</div>
    <p class="muted tool-note"><span class="bank-live-dot"></span>${esc(T('liveNote'))} · ${esc(T('kycTier', { n: kyc.tier }))}</p>
    ${st.info.mode === 'sandbox' ? `<form class="card bank-form" data-fund>${field(T('currency'), `<select class="select" name="currency">${opts(CURS)}</select>`)}${field(T('amount'), input('amount', { mono: true, ph: '100', req: true, mode: 'decimal' }))}
      <button class="btn btn-sm btn-primary" type="submit">${icons.plus}<span>${esc(T('addTest'))}</span></button></form>` : ''}
    <div class="bank-grid2"><div data-pockets></div><div data-vault></div></div>
    <div data-convert></div>
    <article class="card tool-card"><div class="tool-head"><h2 class="card-title">${icons.journal}<span>${esc(T('history'))}</span></h2>
      <div class="bank-filters"><select class="select" data-ftype><option value="">${esc(T('allTypes'))}</option>${opts(TX_TYPES, st.hist.type, (x) => Tx(`tx.${x}`, x))}</select>
      <select class="select" data-fcur><option value="">${esc(T('allCurrencies'))}</option>${opts(CURS, st.hist.currency)}</select>
      <select class="select" data-fcat><option value="">${esc(T('lb.allCats'))}</option>${opts(CATEGORIES, st.hist.category, catName)}</select></div></div>
      <div class="table-scroll"><table class="kv-table bank-hist"><thead><tr><th>${esc(T('when'))}</th><th>${esc(T('type'))}</th><th>${esc(T('amount'))}</th><th>${esc(T('status'))}</th><th>${esc(T('lb.label'))}</th></tr></thead><tbody data-hbody></tbody></table></div>
      <div class="tool-actions"><button class="btn btn-sm" data-more hidden>${esc(T('loadMore'))}</button></div></article>`;

  const q = () => ({ limit: 20, type: st.hist.type, currency: st.hist.currency, category: st.hist.category });
  const labelCell = (x) => { const l = x.label; if (!l) return ''; return [l.category ? `<span class="badge badge-demo">${esc(catName(l.category))}</span>` : '', ...(l.tags || []).map((g) => `<span class="bank-tag">#${esc(g)}</span>`), l.note ? `<small class="muted">${esc(l.note)}</small>` : ''].join(' '); };
  const rowHtml = (x) => `<tr data-txn="${esc(x.id)}"><td class="mono">${esc(dateStr(x.created_at))}</td><td>${esc(Tx(`tx.${x.type}`, x.type))}${x.meta?.merchant ? ` · <small class="muted">${esc(x.meta.merchant)}</small>` : ''}</td>
    <td class="mono ${x.effect > 0 ? 'up' : x.effect < 0 ? 'down' : ''}">${x.effect > 0 ? '+' : x.effect < 0 ? '−' : ''}${fmtMinor(Math.abs(x.effect || x.amount), x.currency)} ${x.currency}</td><td>${badge(x.status)}</td>
    <td><span data-lcell>${labelCell(x)}</span> <button class="btn btn-sm btn-ghost" data-edit title="${esc(T('lb.edit'))}">${icons.text}</button></td></tr>`;
  const fillRows = () => {
    p.querySelector('[data-hbody]').innerHTML = st.hist.items.length ? st.hist.items.map(rowHtml).join('') : `<tr><td colspan="5" class="muted">${esc(T('noTx'))}</td></tr>`;
    p.querySelector('[data-more]').hidden = !st.hist.next;
  };
  const reload = async () => { const h = await bankApi.history(q()); st.hist = { ...st.hist, items: h.items, next: h.next }; fillRows(); };
  reload().catch(() => fillRows());
  B.histReload = () => { if (!p.querySelector('[data-lform]')) reload().catch(() => {}); };   // live updates, but never while a label is being edited
  p.querySelector('[data-ftype]').addEventListener('change', (e) => { st.hist.type = e.target.value; reload(); });
  p.querySelector('[data-fcur]').addEventListener('change', (e) => { st.hist.currency = e.target.value; reload(); });
  p.querySelector('[data-fcat]').addEventListener('change', (e) => { st.hist.category = e.target.value; reload(); });
  p.querySelector('[data-more]').addEventListener('click', async () => { const h = await bankApi.history({ ...q(), before: st.hist.next }); st.hist = { ...st.hist, items: [...st.hist.items, ...h.items], next: h.next }; fillRows(); });
  p.querySelector('[data-fund]')?.addEventListener('submit', async (e) => { e.preventDefault(); const f = fd(e.target); if (await B.act(e.target.querySelector('button'), () => bankApi.fund({ currency: f.currency, amount: f.amount }), T('funded'))) { reload(); pockets(p.querySelector('[data-pockets]'), B); } });
  // label editor (inline row under the transaction)
  p.querySelector('[data-hbody]').addEventListener('click', (e) => {
    const b = e.target.closest('[data-edit]'); if (!b) return;
    const tr = b.closest('tr'); const id = tr.dataset.txn; const x = st.hist.items.find((i) => i.id === id); if (!x) return;
    p.querySelector('[data-lform]')?.closest('tr')?.remove();
    tr.insertAdjacentHTML('afterend', `<tr><td colspan="5"><form class="bank-form bank-inline" data-lform>
      ${field(T('lb.category'), `<select class="select" name="category"><option value="">—</option>${opts(CATEGORIES, x.label?.category, catName)}</select>`)}
      ${field(T('lb.tags'), input('tags', { max: 80, ph: 'trip, gift', value: (x.label?.tags || []).join(', ') }))}${field(T('lb.note'), input('note', { max: 200, value: x.label?.note || '' }), true)}
      <button class="btn btn-sm btn-primary" type="submit">${icons.check}<span>${esc(T('save'))}</span></button><small class="muted">${esc(T('lb.private'))}</small></form></td></tr>`);
    const f = p.querySelector('[data-lform]');
    f.addEventListener('submit', async (ev) => {
      ev.preventDefault(); const v = fd(f);
      const tags = String(v.tags || '').split(/[,\s#]+/).map((s) => s.trim()).filter(Boolean).slice(0, 5);
      if (await B.act(f.querySelector('button'), () => bankApi.label(id, { category: v.category || null, tags, note: v.note || null }), T('lb.saved'))) reload();
    });
  });
  pockets(p.querySelector('[data-pockets]'), B);
  vault(p.querySelector('[data-vault]'), B);
  convert(p.querySelector('[data-convert]'), B);
}

async function pockets(el, B) {
  const r = await bankApi.pockets().catch(() => ({ items: [] })); if (!B.alive()) return;
  el.innerHTML = card(T('pk.title'), icons.piggy, `<p class="muted tool-note">${esc(T('pk.note'))}</p>
    ${r.items.length ? `<ul class="bank-pockets">${r.items.map((x) => `<li class="bank-pocket is-${esc(x.color)}"><div><b>${esc(x.name)}</b> <span class="mono">${amt(x.balance, x.currency)}</span>
      ${x.goal ? `<div class="bank-progress" title="${Math.min(100, Math.floor((x.balance / x.goal) * 100))}%"><i style="width:${Math.min(100, Math.floor((x.balance / x.goal) * 100))}%"></i></div><small class="muted">${esc(T('pk.goal'))}: ${amt(x.goal, x.currency)}</small>` : ''}</div>
      <div class="bank-row-actions"><button class="btn btn-sm btn-ghost" data-pdel="${esc(x.id)}" title="${esc(T('pk.delete'))}">${icons.trash}</button></div></li>`).join('')}</ul>` : empty(T('pk.none'))}
    ${r.items.length ? `<form class="bank-form" data-pmove>${field(T('pk.pocket'), `<select class="select" name="pocketId">${r.items.map((x) => `<option value="${esc(x.id)}">${esc(x.name)} (${x.currency})</option>`).join('')}</select>`)}
      ${field(T('pk.direction'), `<select class="select" name="direction"><option value="in">${esc(T('pk.in'))}</option><option value="out">${esc(T('pk.out'))}</option></select>`)}
      ${field(T('amount'), input('amount', { mono: true, req: true, mode: 'decimal', ph: '50' }))}<button class="btn btn-sm btn-primary" type="submit">${icons.swap}<span>${esc(T('pk.move'))}</span></button></form>` : ''}
    <details class="bank-details"><summary>${esc(T('pk.new'))}</summary><form class="bank-form" data-pnew>${field(T('pk.name'), input('name', { max: 30, req: true, ph: T('pk.namePh') }))}
      ${field(T('currency'), `<select class="select" name="currency">${opts(CURS)}</select>`)}${field(`${T('pk.goal')} (${T('optional')})`, input('goal', { mono: true, mode: 'decimal' }))}
      ${field(T('pk.color'), `<select class="select" name="color">${opts(['violet', 'blue', 'teal', 'green', 'amber', 'rose', 'slate'], 'violet', (c) => Tx(`color.${c}`, c))}</select>`)}
      <button class="btn btn-sm btn-primary" type="submit">${icons.plus}<span>${esc(T('pk.create'))}</span></button></form></details>`);
  el.querySelector('[data-pnew]')?.addEventListener('submit', async (e) => { e.preventDefault(); const v = fd(e.target); if (await B.act(e.target.querySelector('button'), () => bankApi.createPocket(v), T('pk.created'))) pockets(el, B); });
  el.querySelector('[data-pmove]')?.addEventListener('submit', async (e) => { e.preventDefault(); const v = fd(e.target); if (await B.act(e.target.querySelector('button'), () => bankApi.movePocket(v), T('pk.moved'))) pockets(el, B); });
  el.querySelectorAll('[data-pdel]').forEach((b) => b.addEventListener('click', async () => { if (!window.confirm(T('confirmDel'))) return; if (await B.act(b, () => bankApi.deletePocket(b.dataset.pdel), T('pk.deleted'))) pockets(el, B); }));
}

async function vault(el, B) {
  const v = await bankApi.vault().catch(() => null); if (!B.alive() || !v) return;
  const open = v.releases.filter((r) => ['locked', 'awaiting_approvals'].includes(r.status));
  el.innerHTML = card(T('vt.title'), icons.vault, `<p class="muted tool-note">${esc(T('vt.note', { h: v.delayHours }))}</p>
    <ul class="bank-list">${v.balances.filter((b) => b.balance || b.releasing).map((b) => `<li><b class="mono">${amt(b.balance, b.currency)}</b>${b.releasing ? ` <small class="muted">${esc(T('vt.releasing'))}: ${fmtMinor(b.releasing, b.currency)}</small>` : ''}</li>`).join('') || `<li class="muted">${esc(T('vt.empty'))}</li>`}</ul>
    <form class="bank-form" data-vform>${field(T('currency'), `<select class="select" name="currency">${opts(CURS)}</select>`)}${field(T('amount'), input('amount', { mono: true, req: true, mode: 'decimal' }))}
      <button class="btn btn-sm btn-primary" type="submit" data-vin>${icons.lock}<span>${esc(T('vt.lock'))}</span></button><button class="btn btn-sm" type="button" data-vout>${icons.refresh}<span>${esc(T('vt.release'))}</span></button></form>
    ${open.length ? `<ul class="bank-list">${open.map((r) => `<li>${amt(r.amount, r.currency)} ${badge(r.status)} <small class="muted">${esc(T('vt.unlockAt', { t: dateStr(r.unlockAt) }))}</small> <button class="btn btn-sm btn-ghost" data-vcancel="${esc(r.id)}">${esc(T('cancel'))}</button></li>`).join('')}</ul>` : ''}
    <p class="muted tool-note">${esc(T('vt.custody'))}</p>`);
  const f = el.querySelector('[data-vform]');
  f.addEventListener('submit', async (e) => { e.preventDefault(); const x = fd(f); if (await B.act(f.querySelector('[data-vin]'), () => bankApi.vaultIn(x), T('vt.locked'))) vault(el, B); });
  el.querySelector('[data-vout]').addEventListener('click', async (e) => {
    const x = fd(f); if (!x.amount) return f.reportValidity();
    if (!window.confirm(T('vt.confirm', { h: v.delayHours }))) return;
    if (await B.act(e.currentTarget, () => B.secure('vault_release', x, (passkey) => bankApi.vaultOut({ ...x, passkey })), T('vt.started'))) vault(el, B);
  });
  el.querySelectorAll('[data-vcancel]').forEach((b) => b.addEventListener('click', async () => { if (await B.act(b, () => bankApi.vaultCancel(b.dataset.vcancel), T('cancelled'))) vault(el, B); }));
}

async function convert(el, B) {
  const sandbox = B.st.info.mode === 'sandbox';
  el.innerHTML = card(T('fx.title'), icons.swap, `<form class="bank-form" data-fx>${field(T('fx.from'), `<select class="select" name="from">${opts(CURS, 'USD')}</select>`)}
      ${field(T('amount'), input('amount', { mono: true, req: true, mode: 'decimal', value: '100' }))}${field(T('fx.to'), `<select class="select" name="to">${opts(CURS, 'EUR')}</select>`)}
      <button class="btn btn-sm" type="button" data-calc>${icons.refresh}<span>${esc(T('fx.calc'))}</span></button>
      ${sandbox ? `<button class="btn btn-sm btn-primary" type="submit">${icons.swap}<span>${esc(T('fx.convert'))}</span></button>` : ''}</form>
    <p class="bank-fx-out mono" data-out aria-live="polite"></p><p class="muted tool-note">${esc(T(sandbox ? 'fx.noteSandbox' : 'fx.noteLive'))}</p>`);
  const f = el.querySelector('[data-fx]'); const out = el.querySelector('[data-out]');
  const calc = async () => {
    const v = fd(f); if (!v.amount) return;
    try { const r = await bankApi.calc(v); out.innerHTML = `${esc(v.amount)} ${esc(v.from)} ≈ <b>${fmtMinor(r.result, r.to)} ${esc(r.to)}</b> <small class="muted">· ${esc(T('fx.indicative'))} · ${esc(Object.values(r.sources || {}).join(', '))}</small>`; }
    catch (e) { out.textContent = B.errText(e); }
  };
  el.querySelector('[data-calc]').addEventListener('click', calc);
  f.addEventListener('change', calc);
  f.addEventListener('submit', async (e) => {
    e.preventDefault(); const v = fd(f); if (v.from === v.to) return;
    if (!window.confirm(T('fx.confirm', { a: v.amount, f: v.from, t: v.to }))) return;
    const r = await B.act(f.querySelector('[type=submit]'), () => bankApi.convert(v), T('fx.done'));
    if (r && r.receive != null) out.innerHTML = `${esc(T('fx.received'))}: <b>${fmtMinor(r.receive, v.to)} ${esc(v.to)}</b>`;
  });
  calc();
}
export { CURRENCIES };
