// Support tab: encrypted tickets with the owner's support desk, and the notification centre (opened from the bell).
import { icons } from '../../../components/icons.js';
import { bankApi } from '../../../services/bank/api.js';
import { dateStr } from '../common.js';
import { tradeAlert } from '../../../services/tradeMessages.js';
import { getLang } from '../../../i18n/index.js';
import { T, Tx, esc, fmtMinor, catName, opts, field, input, badge, fd, card, empty } from './ui.js';

const TOPICS = ['card', 'transfer', 'deposit', 'withdrawal', 'kyc', 'security', 'invest', 'other'];

export async function supportTab(p, B, openId = null) {
  const r = await bankApi.tickets().catch(() => ({ items: [] })); if (!B.alive() || B.st.tab !== 'support') return;
  p.innerHTML = `<div class="alert alert-info">${icons.shield}<div>${esc(T('su.never'))}</div></div>
    ${card(T('su.new'), icons.chat, `<form class="bank-form" data-tnew>${field(T('su.topic'), `<select class="select" name="topic">${opts(TOPICS, 'other', (x) => T(`su.t.${x}`))}</select>`)}
      ${field(T('su.subject'), input('subject', { max: 80, req: true }))}${field(`${T('su.txn')} (${T('optional')})`, input('txnRef', { max: 40, mono: true }))}
      <label class="tf-field tf-wide"><span>${esc(T('su.message'))}</span><textarea class="input" name="body" rows="4" maxlength="2000" required></textarea></label>
      <button class="btn btn-sm btn-primary" type="submit">${icons.send}<span>${esc(T('su.send'))}</span></button></form><p class="muted tool-note">${esc(T('su.note'))}</p>`)}
    ${card(T('su.mine'), icons.journal, r.items.length ? `<ul class="bank-list">${r.items.map((x) => `<li><button class="btn btn-sm btn-ghost" data-topen="${esc(x.id)}">${icons.chat}<span>${esc(x.subject || '—')}</span></button> ${badge(x.status)} <small class="muted">${esc(T(`su.t.${x.topic}`))} · ${esc(dateStr(x.updatedAt))}</small></li>`).join('')}</ul><div data-thread></div>` : empty(T('su.none')))}`;
  p.querySelector('[data-tnew]').addEventListener('submit', async (e) => { e.preventDefault(); const v = fd(e.target); if (!v.txnRef) delete v.txnRef; const t = await B.act(e.target.querySelector('button'), () => bankApi.newTicket(v), T('su.sent')); if (t) supportTab(p, B, t.id); });
  const show = async (id) => {
    const t = await bankApi.ticket(id).catch(() => null); const out = p.querySelector('[data-thread]'); if (!t || !out) return;
    out.innerHTML = `<div class="bank-thread"><h3 class="bank-h">${esc(t.subject || '')} ${badge(t.status)}</h3>${t.messages.map((m) => `<div class="bank-msg is-${esc(m.author)}"><small class="muted">${esc(T(`su.a.${m.author}`))} · ${esc(dateStr(m.at))}</small><p>${esc(m.body || '')}</p></div>`).join('')}
      ${t.status !== 'closed' ? `<form class="bank-form" data-treply><label class="tf-field tf-wide"><span>${esc(T('su.reply'))}</span><textarea class="input" name="body" rows="3" maxlength="2000" required></textarea></label>
        <button class="btn btn-sm btn-primary" type="submit">${icons.send}<span>${esc(T('su.send'))}</span></button><button class="btn btn-sm btn-ghost" type="button" data-tclose>${esc(T('su.close'))}</button></form>` : ''}</div>`;
    out.querySelector('[data-treply]')?.addEventListener('submit', async (e) => { e.preventDefault(); const v = fd(e.target); if (await B.act(e.target.querySelector('button'), () => bankApi.replyTicket(id, v.body), T('su.sent'))) show(id); });
    out.querySelector('[data-tclose]')?.addEventListener('click', async (e) => { if (await B.act(e.currentTarget, () => bankApi.closeTicket(id))) supportTab(p, B); });
  };
  p.querySelectorAll('[data-topen]').forEach((b) => b.addEventListener('click', () => show(b.dataset.topen)));
  if (openId) show(openId);
}

/** Notification centre: the latest 50, newest first; opening it marks them read. */
export async function notificationsPane(p, B) {
  const r = await bankApi.notifications().catch(() => ({ items: [] })); if (!B.alive()) return;
  const text = (n) => {
    const pr = n.params || {};
    const tk = { trade_target: 'tp', trade_done: 'final', trade_stopped: 'sl', trade_breakeven: 'be' }[n.kind];
    const tm = tk && tradeAlert(tk, { symbol: pr.symbol, direction: pr.direction === 'short' ? 'short' : 'long', n: n.kind === 'trade_breakeven' ? Number(pr.hits) || 0 : Number(pr.n) || 0, price: pr.price, entry: pr.entry, stop: pr.stop }, getLang());
    if (tm) return `${tm.title} ${tm.body}`;
    return T(`nk.${n.kind}`, { amt: pr.amount != null && pr.currency ? `${fmtMinor(pr.amount, pr.currency)} ${pr.currency}` : '', merchant: pr.merchant || '', category: catName(pr.category || ''), pts: pr.pts ?? '', tier: pr.tier ?? '', result: Tx(`st.${pr.result}`, pr.result || ''), symbol: pr.symbol || '', n: pr.n ?? '', r: pr.r ?? '' });
  };
  p.innerHTML = card(T('nt.centre'), icons.bell, r.items.length ? `<ul class="bank-notifs">${r.items.map((n) => `<li class="${n.read ? '' : 'is-unread'}"><span>${esc(text(n))}</span><small class="muted mono">${esc(dateStr(n.created_at))}</small></li>`).join('')}</ul>` : empty(T('nt.empty')));
  if (r.unread) { await bankApi.markRead().catch(() => {}); B.setUnread(0); }
}
