// Rewards tab: points balance, how points are earned, cashback, history.
import { icons } from '../../../components/icons.js';
import { bankApi } from '../../../services/bank/api.js';
import { dateStr } from '../common.js';
import { T, Tx, esc, field, input, fd, card, empty } from './ui.js';

export async function rewardsTab(p, B) {
  const r = await bankApi.rewards().catch(() => null); if (!B.alive() || B.st.tab !== 'rewards' || !r) return;
  p.innerHTML = `<div class="bank-balances"><article class="card bank-bal"><span class="muted">${esc(T('rw.points'))}</span><b class="mono bank-amt">${r.points.toLocaleString('en-US')}</b>
      <small class="muted">${r.expiringIn30Days ? esc(T('rw.expiring', { n: r.expiringIn30Days })) : esc(T('rw.validFor'))}</small></article>
    <article class="card bank-bal"><span class="muted">${esc(T('rw.worth'))}</span><b class="mono bank-amt">$${((Math.floor(r.points / r.rate.points) * r.rate.usd)).toFixed(2)}</b><small class="muted">${esc(T('rw.rate', { p: r.rate.points, u: r.rate.usd }))}</small></article></div>
    ${card(T('rw.how'), icons.gift, `<ul class="bank-list"><li>${esc(T('rw.earnCard', { n: r.earnRules.perUsd }))}</li><li>${esc(T('rw.earnKyc', { a: r.earnRules.kyc1, b: r.earnRules.kyc2 }))}</li><li>${esc(T('rw.earnPasskey', { n: r.earnRules.passkey }))}</li></ul>
      <p class="muted tool-note">${esc(T('rw.noTrading'))}</p>`)}
    ${card(T('rw.redeem'), icons.download, r.cashbackAvailable ? `<form class="bank-form" data-redeem>${field(T('rw.pointsToUse'), input('points', { mono: true, req: true, mode: 'numeric', value: String(r.rate.points) }))}
      <button class="btn btn-sm btn-primary" type="submit" ${r.points < r.rate.points ? 'disabled' : ''}>${icons.check}<span>${esc(T('rw.redeemBtn'))}</span></button></form>` : `<p class="muted">${esc(T('rw.cashbackOff'))}</p>`)}
    ${card(T('rw.history'), icons.journal, r.history.length ? `<div class="table-scroll"><table class="kv-table"><tbody>${r.history.map((h) => `<tr><td class="mono">${esc(dateStr(h.at))}</td><td>${esc(Tx(`rw.t.${h.type}`, h.type))}${h.reason ? ` · <small class="muted">${esc(Tx(`rw.r.${h.reason}`, h.reason))}</small>` : ''}</td><td class="mono ${['points_earn'].includes(h.type) ? 'up' : 'down'}">${h.type === 'points_earn' ? '+' : '−'}${h.amount}</td></tr>`).join('')}</tbody></table></div>` : empty(T('rw.none')))}`;
  const f = p.querySelector('[data-redeem]');
  f?.addEventListener('submit', async (e) => {
    e.preventDefault(); const v = fd(f); const points = Number(v.points);
    if (!window.confirm(T('rw.confirm', { p: points, u: (points / r.rate.points) * r.rate.usd }))) return;
    if (await B.act(f.querySelector('button'), () => B.secure('redeem', { points }, (passkey) => bankApi.redeem({ points, passkey })), T('rw.done'))) rewardsTab(p, B);
  });
}
