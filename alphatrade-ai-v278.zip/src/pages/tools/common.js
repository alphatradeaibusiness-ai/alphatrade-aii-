// Shared bits for the tool pages (risk, calendar, portfolio, journal, radar, alerts, auto test,
// correlation, strategies explained, news).
import { h, esc, fmtNum } from '../../utils/dom.js';
import { icons } from '../../components/icons.js';
import { t, getLang } from '../../i18n/index.js';
import { store } from '../../state/store.js';
import { getInstrument } from '../../config/instruments.js';

export function toolPage(id, icon, extraClass = '') {
  return h(`<section class="subpage tool tool-${id} ${extraClass} page-enter">
    <header class="tool-hero card fade-in"><span class="tool-ico">${icons[icon]}</span>
      <div><h1>${esc(t(`tools.${id}.title`))}</h1><p class="muted">${esc(t(`tools.${id}.sub`))}</p></div><span class="tool-mark" aria-hidden="true">${icons[icon]}</span></header>
    <div class="tool-body" data-body></div>
  </section>`);
}

export const pointSizeOf = (symbol) => {
  const v = Number(store.get('settings').pointSizes?.[symbol]);
  return v > 0 ? v : getInstrument(symbol).pointSize || 1;
};

export const locale = () => (getLang() === 'ar' ? 'ar-EG-u-nu-latn' : 'en-GB');
export const dateStr = (ms, opts = { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }) => new Date(ms).toLocaleString(locale(), opts);

/** Signed number wrapped in an LTR isolate so "+12.5" never flips inside Arabic text. */
export const signed = (v, d = 2, suffix = '') => `<bdi class="mono ${v > 0 ? 'up' : v < 0 ? 'down' : ''}">${v > 0 ? '+' : v < 0 ? '−' : ''}${fmtNum(Math.abs(v), d)}${suffix}</bdi>`;
export const money = (v, d = 2) => `<bdi class="mono">${v < 0 ? '−' : ''}$${fmtNum(Math.abs(v), d)}</bdi>`;
export const signedMoney = (v, d = 2) => `<bdi class="mono ${v > 0 ? 'up' : v < 0 ? 'down' : ''}">${v > 0 ? '+' : v < 0 ? '−' : ''}$${fmtNum(Math.abs(v), d)}</bdi>`;

export const uid = () => `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}`;
export const num = (v) => { const n = Number(String(v ?? '').replace(/,/g, '').trim()); return Number.isFinite(n) ? n : NaN; };

/** Equity / line chart as an SVG string (values in order). */
export function lineSvg(values, { height = 170, color = null } = {}) {
  if (!values.length) return '';
  const pts = [0, ...values];
  const min = Math.min(0, ...pts);
  const max = Math.max(0, ...pts);
  const span = max - min || 1;
  const W = 600;
  const x = (i) => (i / Math.max(1, pts.length - 1)) * W;
  const y = (v) => 8 + (1 - (v - min) / span) * (height - 16);
  const d = pts.map((v, i) => `${i ? 'L' : 'M'}${x(i).toFixed(1)},${y(v).toFixed(1)}`).join('');
  const up = pts.at(-1) >= 0;
  const c = color || (up ? 'var(--green)' : 'var(--red)');
  return `<svg class="equity" viewBox="0 0 ${W} ${height}" preserveAspectRatio="none" style="color:${c}">
    <defs><linearGradient id="lg${values.length}" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stop-color="currentColor" stop-opacity=".28"/><stop offset="1" stop-color="currentColor" stop-opacity="0"/></linearGradient></defs>
    <line class="eq-zero" x1="0" x2="${W}" y1="${y(0)}" y2="${y(0)}"/>
    <path class="eq-area" d="${d}L${W},${y(0)}L0,${y(0)}Z" fill="url(#lg${values.length})"/>
    <path class="eq-line" d="${d}" pathLength="1" fill="none" stroke="currentColor" stroke-width="2.2" vector-effect="non-scaling-stroke"/>
  </svg>`;
}

const DONUT_COLORS = ['#d97706', '#22c55e', '#3b82f6', '#f59e0b', '#ec4899', '#14b8a6', '#f0444f', '#94a3b8', '#eab308'];
export const donutColor = (i) => DONUT_COLORS[i % DONUT_COLORS.length];

/** A text cell for CSV export: quoted, and a leading = + - @ (a spreadsheet formula) is neutralised with an apostrophe. */
export const csvText = (v) => { let x = String(v ?? ''); if (/^[=+\-@\t\r]/.test(x)) x = `'${x}`; return `"${x.replace(/"/g, '""')}"`; };

export function downloadText(name, text, type = 'text/csv') {
  const blob = new Blob([`﻿${text}`], { type: `${type};charset=utf-8` });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = name;
  document.body.append(a);
  a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 500);
}

// Cleanups of elements that are on screen now. The app shell calls runUnmount() when it swaps a page out, so timers and
// listeners stop at once (the isConnected checks below remain as a safety net for elements removed some other way).
const cleanups = new Set();   // { el, fn }
const register = (el, fn) => { const c = { el, fn }; cleanups.add(c); return () => cleanups.delete(c); };
/** Runs and forgets the cleanups of every registered element inside `root` (or `root` itself). */
export function runUnmount(root) {
  for (const c of [...cleanups]) if (root === c.el || root?.contains?.(c.el)) { cleanups.delete(c); try { c.fn(); } catch { /* keep going */ } }
}

/** Calls fn every ms while the element is on the page; stops by itself afterwards. */
export function whileMounted(el, fn, ms) {
  let unreg = () => {};
  const id = setInterval(() => { if (!el.isConnected) { clearInterval(id); unreg(); return; } if (!document.hidden) fn(); }, ms);
  unreg = register(el, () => clearInterval(id));
  return () => { clearInterval(id); unreg(); };
}

export const loading = () => `<div class="perf-loading"><span class="spinner"></span><span>${esc(t('common.loading'))}</span></div>`;
export const errorBox = (msg, retry = true) => `<div class="alert alert-error">${icons.alert}<div>${esc(msg)}</div>${retry ? `<button type="button" class="btn btn-sm" data-retry>${icons.refresh}<span>${esc(t('tools.common.retry'))}</span></button>` : ''}</div>`;

/** Runs fn once the element has left the page (immediately when the app shell swaps the page; otherwise checked every second). */
export function onUnmount(el, fn) {
  let done = false;
  const once = () => { if (done) return; done = true; clearInterval(id); unreg(); fn(); };
  const id = setInterval(() => { if (!el.isConnected) once(); }, 1000);
  const unreg = register(el, once);
}
