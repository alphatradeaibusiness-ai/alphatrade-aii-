// "Payments" page (owner only): connect Stripe with one secret key, and see subscriptions and revenue.
import { h, esc } from '../../utils/dom.js';
import { toast } from '../../components/ui.js';
import { getLang, t } from '../../i18n/index.js';
import { icons } from '../../components/icons.js';
import { toolPage } from './common.js';
import { payKeyCardHtml, bindPayKeyCard } from '../../components/payKeyCard.js';
import { apiRequest } from '../../services/ai/gateway.js';

const L = (ar, en) => (getLang() !== 'ar' ? en : ar);
const usd = (c) => `$${(c / 100).toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 2 })}`;
const day = (ms) => new Date(ms).toLocaleDateString(getLang() === 'ar' ? 'ar-EG-u-nu-latn' : 'en-GB', { month: 'short', day: 'numeric' });
const pname = (id) => (['monthly', 'quarterly', 'semiannual', 'annual', 'prime', 'apex', 'max'].includes(id) ? t(`pricing.plans.${id}`) : id === 'channel' ? L('القناة', 'Channel') : id);

export function renderPayments() {
  const el = toolPage('payments', 'card');
  const body = el.querySelector('[data-body]');
  body.innerHTML = `${payKeyCardHtml()}<article class="card tool-card fade-in" data-rev><h2 class="card-title">${icons.bars || ''}<span>${esc(L('الاشتراكات والإيرادات', 'Subscriptions & revenue'))}</span></h2><p class="muted">…</p></article>`;
  bindPayKeyCard(body);
  const bc = h(`<article class="card tool-card fade-in"><h2 class="card-title">${icons.bell || ''}<span>${esc(L('رسالة لكل المستخدمين', 'Message to all users'))}</span></h2>
    <form class="ad-form" data-bc><label class="field"><span>${esc(L('العنوان', 'Title'))}</span><input class="input" name="title" maxlength="120" required></label>
    <label class="field"><span>${esc(L('الرسالة', 'Message'))}</span><textarea class="input" name="body" rows="3" maxlength="600" required></textarea></label>
    <label class="sa-tog"><span>${esc(L('ابعتها كمان كإشعار وتليغرام', 'Also send as push and Telegram'))}</span><input type="checkbox" role="switch" name="push"><i aria-hidden="true"></i></label>
    <button class="btn btn-primary btn-sm" type="submit">${icons.send || ''}<span>${esc(L('ابعت', 'Send'))}</span></button></form>
    <p class="muted tool-note">${esc(L('بتظهر بالجرس عند الكل، وكشريط فوق الصفحة لأسبوعين أو لحد ما يسكّروه.', 'Shows in everyone’s bell and as a banner on top for two weeks or until closed.'))}</p></article>`);
  body.append(bc);
  bc.querySelector('[data-bc]').addEventListener('submit', async (e) => {
    e.preventDefault(); const f = e.target; const b = f.querySelector('[type=submit]'); b.disabled = true;
    try { const r = await apiRequest('POST', '/api/admin/broadcast', { title: f.title.value, body: f.body.value, push: f.push.checked }); toast(L(`انبعتت لـ ${r.sent} مستخدم`, `Sent to ${r.sent} users`), 'success'); f.reset(); }
    catch { toast(L('ما انبعتت.', 'Not sent.'), 'error'); }
    b.disabled = false;
  });
  const rev = body.querySelector('[data-rev]');
  apiRequest('GET', '/api/billing/admin/summary', undefined, 15000).then((r) => {
    const kpi = (label, value, sub = '') => `<div class="rv-kpi"><small>${esc(label)}</small><b class="mono">${value}</b>${sub ? `<span>${esc(sub)}</span>` : ''}</div>`;
    rev.innerHTML = `<h2 class="card-title">${icons.bars || ''}<span>${esc(L('الاشتراكات والإيرادات', 'Subscriptions & revenue'))}</span></h2>
      <div class="rv-kpis">${kpi(L('إيراد هالشهر', 'This month'), usd(r.live.month))}${kpi(L('كل الإيرادات', 'All time'), usd(r.live.total), L(`${r.live.count} دفعة`, `${r.live.count} payments`))}${kpi(L('مشتركين فعّالين', 'Active subscribers'), r.activeTotal)}${kpi(L('دفعات تجريبية', 'Test payments'), usd(r.test.total), L('مش مصاري حقيقية', 'not real money'))}</div>
      ${r.activeTotal ? `<p class="tool-note">${Object.entries(r.active).map(([k, n]) => `<b>${esc(pname(k))}</b> ${n}`).join(' · ')}</p>` : ''}
      <h4 class="sa-h">${esc(L('بيخلصوا خلال 7 أيام', 'Ending within 7 days'))}</h4>
      ${r.expiring.length ? `<ul class="tool-list">${r.expiring.map((x) => `<li><span class="mono">${esc(x.ref)}…</span> · ${esc(pname(x.product))} · ${esc(day(x.until))}</li>`).join('')}</ul>` : `<p class="muted">${esc(L('ولا واحد.', 'None.'))}</p>`}
      <h4 class="sa-h">${esc(L('آخر الدفعات', 'Latest payments'))}</h4>
      ${r.recent.length ? `<ul class="tool-list">${r.recent.map((p) => `<li>${esc(day(p.at))} · ${esc(pname(p.product))} · <b class="mono">${usd(p.cents)}</b> ${p.email ? `<small class="muted">${esc(p.email)}</small>` : ''}${p.live ? '' : ` <small class="badge badge-warn">${esc(L('تجريبي', 'test'))}</small>`}</li>`).join('')}</ul>` : `<p class="muted">${esc(L('لسا ما في دفعات.', 'No payments yet.'))}</p>`}`;
  }).catch(() => { rev.hidden = true; });
  return el;
}
