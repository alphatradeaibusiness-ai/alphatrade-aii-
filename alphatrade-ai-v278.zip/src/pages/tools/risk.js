// Risk management: position size from account balance, risk % and stop distance; profit at each
// target (partial thirds, like the strategy), daily loss limit, losing-streak table and expectancy.
import { esc, fmtNum } from '../../utils/dom.js';
import { icons } from '../../components/icons.js';
import { t } from '../../i18n/index.js';
import { storage } from '../../utils/storage.js';
import { store } from '../../state/store.js';
import { INSTRUMENTS, getInstrument } from '../../config/instruments.js';
import { rulesFrom } from '../../services/backtest.js';
import { toolPage, pointSizeOf, money, num } from './common.js';
import { guardPanelHtml } from '../../components/guardPanel.js';
import { onSignals, signalState } from '../../services/signals.js';
import { toast } from '../../components/ui.js';

// Contract size of one standard lot (units of the asset). Crypto is traded in coins.
const LOT = { metal: 100, index: 1, crypto: 1 };

const DEF = { balance: 1000, riskPct: 1, dailyPct: 3, leverage: 10, symbol: 'BTCUSDT', direction: 'long', entry: '', stop: '', tp1: '', tp2: '', tp3: '', winRate: 50 };

export function renderRisk({ getDashboard } = {}) {
  const el = toolPage('risk', 'shield');
  const st = { ...DEF, ...storage.get('risk', {}) };
  if (!INSTRUMENTS.some((i) => i.symbol === st.symbol)) st.symbol = DEF.symbol;
  const body = el.querySelector('[data-body]');
  const field = (k, label, extra = '') => `<label class="tf-field"><span>${esc(t(`tools.risk.${label}`))}</span><input class="input mono" inputmode="decimal" data-k="${k}" value="${esc(st[k])}" ${extra}></label>`;
  body.innerHTML = `
    <article class="card tool-card fade-in rc-guard" data-rc-guard></article>
    <div class="tool-grid">
      <article class="card tool-card fade-in">
        <h2 class="card-title">${icons.wallet}<span>${esc(t('tools.risk.account'))}</span></h2>
        <div class="tf-grid">
          ${field('balance', 'balance')}${field('riskPct', 'riskPct')}${field('dailyPct', 'dailyPct')}${field('leverage', 'leverage')}
        </div>
        <div class="risk-gauge" data-gauge></div>
      </article>
      <article class="card tool-card fade-in">
        <h2 class="card-title">${icons.crosshair}<span>${esc(t('tools.risk.trade'))}</span></h2>
        <div class="tf-grid">
          <label class="tf-field"><span>${esc(t('tools.common.symbol'))}</span><select class="select" data-k="symbol">${INSTRUMENTS.map((i) => `<option ${i.symbol === st.symbol ? 'selected' : ''}>${i.symbol}</option>`).join('')}</select></label>
          <div class="tf-field"><span>${esc(t('tools.common.direction'))}</span><div class="seg" data-dir><button type="button" data-v="long" class="${st.direction === 'long' ? 'is-on' : ''}">${esc(t('common.long'))}</button><button type="button" data-v="short" class="${st.direction === 'short' ? 'is-on' : ''}">${esc(t('common.short'))}</button></div></div>
          ${field('entry', 'entry')}${field('stop', 'stop')}${field('tp1', 'tp1')}${field('tp2', 'tp2')}${field('tp3', 'tp3')}
        </div>
        <div class="tool-actions"><button type="button" class="btn btn-sm btn-primary" data-fill>${icons.sparkle}<span>${esc(t('tools.risk.fromChart'))}</span></button></div>
      </article>
    </div>
    <article class="card tool-card fade-in" data-out></article>
    <div class="tool-grid">
      <article class="card tool-card fade-in"><h2 class="card-title">${icons.alert}<span>${esc(t('tools.risk.streakTitle'))}</span></h2><div data-streak></div></article>
      <article class="card tool-card fade-in"><h2 class="card-title">${icons.trend}<span>${esc(t('tools.risk.expTitle'))}</span></h2>
        <div class="tf-grid">${field('winRate', 'winRate')}</div><div data-exp></div></article>
    </div>
    <article class="card tool-card fade-in"><h2 class="card-title">${icons.check}<span>${esc(t('tools.risk.rulesTitle'))}</span></h2>
      <ul class="tool-list">${t('tools.risk.rules').map((r) => `<li>${esc(r)}</li>`).join('')}</ul></article>`;

  const $ = (s) => body.querySelector(s);
  const save = () => storage.set('risk', st);

  function calc() {
    const inst = getInstrument(st.symbol);
    const ps = pointSizeOf(st.symbol);
    const p = inst.precision;
    const balance = num(st.balance);
    const riskPct = num(st.riskPct);
    const entry = num(st.entry);
    const stop = num(st.stop);
    const lev = Math.max(1, num(st.leverage) || 1);
    const riskUsd = balance * riskPct / 100;
    const dailyUsd = balance * num(st.dailyPct) / 100;
    const perDay = riskUsd > 0 ? Math.floor(dailyUsd / riskUsd) : 0;
    $('[data-gauge]').innerHTML = Number.isFinite(riskUsd) && riskUsd > 0 ? `
      <div class="rg-row"><span>${esc(t('tools.risk.riskUsd'))}</span>${money(riskUsd)}</div>
      <div class="rg-row"><span>${esc(t('tools.risk.dailyUsd'))}</span>${money(dailyUsd)}</div>
      <div class="rg-row"><span>${esc(t('tools.risk.perDay'))}</span><b class="mono">${perDay}</b></div>
      <div class="rg-bar ${riskPct > 2 ? 'hot' : riskPct > 1 ? 'warm' : ''}"><i style="width:${Math.min(100, riskPct / 5 * 100)}%"></i></div>
      <p class="muted rg-note">${esc(riskPct > 2 ? t('tools.risk.tooHigh') : riskPct > 1 ? t('tools.risk.medium') : t('tools.risk.safe'))}</p>` : '';

    const out = $('[data-out]');
    const dir = st.direction === 'long' ? 1 : -1;
    const dist = (entry - stop) * dir;
    if (!(entry > 0) || !(stop > 0) || !(balance > 0) || !(riskPct > 0)) {
      out.innerHTML = `<h2 class="card-title">${icons.ruler}<span>${esc(t('tools.risk.result'))}</span></h2><p class="muted">${esc(t('tools.risk.fill'))}</p>`;
    } else if (dist <= 0) {
      out.innerHTML = `<h2 class="card-title">${icons.ruler}<span>${esc(t('tools.risk.result'))}</span></h2><div class="alert alert-error">${icons.alert}<div>${esc(t(st.direction === 'long' ? 'tools.risk.stopBelow' : 'tools.risk.stopAbove'))}</div></div>`;
    } else {
      const fee = rulesFrom(store.get('settings'), inst).feePct / 100;
      const units = riskUsd / (dist + entry * fee); // fees included in the risk
      const lots = units / (LOT[inst.type] || 1);
      const notional = units * entry;
      const margin = notional / lev;
      const tps = [st.tp1, st.tp2, st.tp3].map(num).filter((v) => v > 0 && (v - entry) * dir > 0);
      const rows = tps.map((tp, k) => {
        const d = (tp - entry) * dir;
        return `<tr><td>TP${k + 1}</td><td class="mono">${fmtNum(tp, p)}</td><td class="mono"><bdi>${fmtNum(d / ps, 0)}</bdi></td><td class="mono">${fmtNum(d / dist, 2)}R</td><td class="mono up">${money(units * d)}</td><td class="mono up">${money(units * d / tps.length)}</td></tr>`;
      }).join('');
      const partial = tps.reduce((a, tp) => a + units * (tp - entry) * dir / tps.length, 0);
      const warn = margin > balance ? `<div class="alert alert-error">${icons.alert}<div>${esc(t('tools.risk.marginWarn'))}</div></div>` : '';
      out.innerHTML = `<h2 class="card-title">${icons.ruler}<span>${esc(t('tools.risk.result'))}</span></h2>${warn}
        <div class="kpi-row">
          <div class="mini-kpi glow"><span>${esc(t('tools.risk.size'))}</span><b class="mono">${fmtNum(units, units < 10 ? 4 : 2)}</b><small>${esc(inst.base)}</small></div>
          ${inst.type !== 'crypto' ? `<div class="mini-kpi"><span>${esc(t('tools.risk.lots'))}</span><b class="mono">${fmtNum(lots, 2)}</b><small>${esc(t('tools.risk.lotNote', { n: LOT[inst.type] }))}</small></div>` : ''}
          <div class="mini-kpi"><span>${esc(t('tools.risk.riskUsd'))}</span><b class="mono down">${money(riskUsd)}</b><small><bdi>${fmtNum(dist / ps, 0)}</bdi> ${esc(t('sig.pts'))}</small></div>
          <div class="mini-kpi"><span>${esc(t('tools.risk.notional'))}</span><b class="mono">${money(notional, 0)}</b><small>${esc(t('tools.risk.margin'))} ${money(margin, 0)} (×${lev})</small></div>
          ${tps.length ? `<div class="mini-kpi"><span>${esc(t('tools.risk.allTps'))}</span><b class="mono up">${money(partial)}</b><small>${fmtNum(partial / riskUsd, 2)}R</small></div>` : ''}
        </div>
        ${rows ? `<div class="table-scroll"><table class="kv-table perf-table"><thead><tr><th></th><th>${esc(t('tools.risk.price'))}</th><th>${esc(t('sig.pts'))}</th><th>R</th><th>${esc(t('tools.risk.fullProfit'))}</th><th>${esc(t('tools.risk.thirdProfit'))}</th></tr></thead><tbody>${rows}</tbody></table></div>` : ''}
        <p class="muted tool-note">${esc(t('tools.risk.feeNote', { f: fmtNum(fee * 100, 2) }))}</p>`;
    }

    // Losing streak: balance after N losses in a row at the same risk %.
    let b = balance;
    const streak = [];
    for (let n = 1; n <= 10; n++) { b *= 1 - riskPct / 100; if ([1, 2, 3, 5, 7, 10].includes(n)) streak.push([n, b]); }
    $('[data-streak]').innerHTML = balance > 0 && riskPct > 0 ? `<table class="kv-table perf-table"><thead><tr><th>${esc(t('tools.risk.losses'))}</th><th>${esc(t('tools.risk.balanceAfter'))}</th><th>${esc(t('tools.risk.drawdown'))}</th></tr></thead><tbody>
      ${streak.map(([n, v]) => `<tr><td class="mono">${n}</td><td class="mono">${money(v)}</td><td class="mono down"><bdi>−${fmtNum((1 - v / balance) * 100, 1)}%</bdi></td></tr>`).join('')}</tbody></table>
      <p class="muted tool-note">${esc(t('tools.risk.streakNote'))}</p>` : '';

    // Expectancy with the plan's average win (partial thirds at TP1..TP3 ≈ (1+2+3.5)/3 R by default).
    const tpR = rulesFrom(store.get('settings'), inst).tpR;
    const avgWin = tpR.reduce((a, r) => a + r, 0) / tpR.length;
    const wr = Math.min(100, Math.max(0, num(st.winRate))) / 100;
    const exp = wr * avgWin - (1 - wr);
    const be = 1 / (1 + avgWin) * 100;
    $('[data-exp]').innerHTML = `<div class="kpi-row">
      <div class="mini-kpi"><span>${esc(t('tools.risk.avgWin'))}</span><b class="mono">${fmtNum(avgWin, 2)}R</b></div>
      <div class="mini-kpi ${exp >= 0 ? 'good' : 'bad'}"><span>${esc(t('tools.risk.expectancy'))}</span><b class="mono ${exp >= 0 ? 'up' : 'down'}"><bdi>${exp >= 0 ? '+' : '−'}${fmtNum(Math.abs(exp), 2)}R</bdi></b><small>${Number.isFinite(riskUsd) ? money(exp * riskUsd) : ''} / ${esc(t('tools.risk.perTrade'))}</small></div>
      <div class="mini-kpi"><span>${esc(t('tools.risk.breakEven'))}</span><b class="mono">${fmtNum(be, 1)}%</b></div></div>
      <p class="muted tool-note">${esc(t('tools.risk.expNote'))}</p>`;
  }

  body.addEventListener('input', (e) => {
    const k = e.target.dataset.k;
    if (!k) return;
    st[k] = e.target.value;
    save(); calc();
  });
  $('[data-dir]').addEventListener('click', (e) => {
    const b = e.target.closest('[data-v]');
    if (!b) return;
    st.direction = b.dataset.v;
    $('[data-dir]').querySelectorAll('button').forEach((x) => x.classList.toggle('is-on', x === b));
    save(); calc();
  });
  $('[data-fill]').addEventListener('click', () => {
    const a = getDashboard?.()?.getAnalysis?.();
    const plan = a?.plan;
    if (!plan) { toast(t('tools.risk.noPlan'), 'info'); return; }
    const p = getInstrument(a.symbol).precision;
    Object.assign(st, { symbol: a.symbol, direction: plan.direction, entry: plan.entry.toFixed(p), stop: (plan.initialStop ?? plan.stop).toFixed(p), tp1: plan.targets[0].toFixed(p), tp2: plan.targets[1].toFixed(p), tp3: plan.targets[2].toFixed(p) });
    body.querySelectorAll('[data-k]').forEach((x) => { x.value = st[x.dataset.k]; });
    $('[data-dir]').querySelectorAll('button').forEach((x) => x.classList.toggle('is-on', x.dataset.v === st.direction));
    save(); calc();
    toast(t('tools.risk.filled', { s: a.symbol }), 'success');
  });
  calc();
  // Risk Control Center: the live guard (same panel as the signals channel) above the position-size calculator.
  const paintGuard = () => {
    const g = el.querySelector('[data-rc-guard]'); if (!g) return;
    const html = `${guardPanelHtml(signalState(), { settingsLink: true })}<button type="button" class="btn btn-sm" data-rc-edit>${esc(t('rc.edit'))}</button>`;
    if (html === g._html) return;   // the channel ticks every second; repaint only on a real change
    g._html = html; g.innerHTML = html;
    g.querySelector('[data-rc-edit]').addEventListener('click', () => getDashboard?.()?.openIndicators?.());
  };
  paintGuard();
  const offSig = onSignals(() => { if (!el.isConnected) { offSig(); return; } paintGuard(); });
  return el;
}
