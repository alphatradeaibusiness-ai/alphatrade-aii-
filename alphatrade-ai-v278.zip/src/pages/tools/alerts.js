// Custom alerts page: create price / % change alerts, see their distance to the live price,
// pause or delete them, and the history of alerts that fired.
import { esc, fmtNum, fmtPct } from '../../utils/dom.js';
import { alertSlotOk } from '../../components/gate.js';
import { icons } from '../../components/icons.js';
import { t } from '../../i18n/index.js';
import { INSTRUMENTS, getInstrument } from '../../config/instruments.js';
import { getTickers } from '../../services/market/index.js';
import { alertState, onAlerts, addAlert, removeAlert, toggleAlert, clearLog, describeAlert, ALERT_KINDS } from '../../services/alerts.js';
import { enableNotifications, notifyPermission } from '../../services/signals.js';
import { toolPage, num, dateStr } from './common.js';
import { toast } from '../../components/ui.js';

export function renderAlerts() {
  const el = toolPage('alerts', 'alarm');
  const body = el.querySelector('[data-body]');
  body.innerHTML = `
    <div class="card sig-notify fade-in" data-perm></div>
    <article class="card tool-card fade-in"><h2 class="card-title">${icons.plus}<span>${esc(t('tools.alerts.new'))}</span></h2>
      <form class="tf-grid" data-form>
        <label class="tf-field"><span>${esc(t('tools.common.symbol'))}</span><select class="select" name="symbol">${INSTRUMENTS.map((i) => `<option>${i.symbol}</option>`).join('')}</select></label>
        <label class="tf-field"><span>${esc(t('tools.alerts.kind'))}</span><select class="select" name="kind">${ALERT_KINDS.map((k) => `<option value="${k}">${esc(t(`tools.alerts.k.${k}`))}</option>`).join('')}</select></label>
        <label class="tf-field"><span data-vlabel>${esc(t('tools.alerts.price'))}</span><input class="input mono" name="level" inputmode="decimal" required></label>
        <label class="tf-field tf-wide"><span>${esc(t('tools.alerts.note'))}</span><input class="input" name="note" maxlength="80" placeholder="${esc(t('tools.alerts.notePh'))}"></label>
        <label class="tf-check"><input type="checkbox" name="repeat"><span>${esc(t('tools.alerts.repeat'))}</span></label>
        <div class="tf-field tf-end"><button class="btn btn-primary" type="submit">${icons.alarm}<span>${esc(t('tools.alerts.create'))}</span></button></div>
      </form>
      <p class="muted tool-note" data-now></p>
    </article>
    <article class="card tool-card fade-in"><h2 class="card-title">${icons.alarm}<span>${esc(t('tools.alerts.mine'))}</span></h2><div data-list></div></article>
    <article class="card tool-card fade-in"><div class="tool-head"><h2 class="card-title">${icons.bell}<span>${esc(t('tools.alerts.history'))}</span></h2><button type="button" class="btn btn-sm btn-ghost" data-clear>${esc(t('tools.alerts.clear'))}</button></div><div data-log></div></article>
    <p class="muted tool-note">${esc(t('tools.alerts.note2'))}</p>`;
  const $ = (s) => body.querySelector(s);
  const form = $('[data-form]');
  let quote = null;

  const drawPerm = () => {
    const p = notifyPermission();
    $('[data-perm]').innerHTML = p === 'granted' ? `<span class="badge badge-live">${esc(t('sig.notifOn'))}</span><span class="muted">${esc(t('tools.alerts.permOn'))}</span>`
      : p === 'unsupported' ? `<span class="badge badge-muted">${esc(t('sig.notifNo'))}</span><span class="muted">${esc(t('sig.iosHelp'))}</span>`
        : `<span class="muted">${esc(t('tools.alerts.permAsk'))}</span><button type="button" class="btn btn-sm btn-primary" data-enable>${icons.bell}<span>${esc(t('sig.enable'))}</span></button>`;
    $('[data-enable]')?.addEventListener('click', async () => { await enableNotifications(); drawPerm(); });
  };
  drawPerm();

  const drawNow = () => {
    const inst = getInstrument(form.symbol.value);
    const pct = form.kind.value.startsWith('chg');
    $('[data-vlabel]').textContent = t(pct ? 'tools.alerts.pct' : 'tools.alerts.price');
    form.level.placeholder = pct ? '2.5' : quote ? quote.price.toFixed(inst.precision) : '';
    $('[data-now]').innerHTML = quote ? `${esc(t('tools.alerts.nowPrice'))}: <bdi class="mono">${fmtNum(quote.price, inst.precision)}</bdi> · 24h <bdi class="mono ${quote.changePct >= 0 ? 'up' : 'down'}">${fmtPct(quote.changePct)}</bdi>` : '';
  };
  const loadQuote = async () => {
    quote = null; drawNow();
    try { const tk = await getTickers([form.symbol.value]); const q = tk[form.symbol.value]; if (q && Number.isFinite(q.price)) quote = q; } catch { /* ignore */ }
    drawNow();
  };
  form.symbol.addEventListener('change', loadQuote);
  form.kind.addEventListener('change', drawNow);
  loadQuote();

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    let v = num(form.level.value);
    if (!Number.isFinite(v) || (!form.kind.value.startsWith('chg') && v <= 0)) { toast(t('tools.common.invalid'), 'error'); return; }
    if (form.kind.value === 'chgDown') v = Math.abs(v);
    if (notifyPermission() === 'default') { await enableNotifications(); drawPerm(); }
    if (!alertSlotOk()) return;
    addAlert({ symbol: form.symbol.value, kind: form.kind.value, value: v, repeat: form.repeat.checked, note: form.note.value });
    form.level.value = ''; form.note.value = '';
    toast(t('tools.alerts.created'), 'success');
  });
  $('[data-list]').addEventListener('click', (e) => {
    const d = e.target.closest('[data-del]'); if (d) { removeAlert(d.dataset.del); return; }
    const tg = e.target.closest('[data-toggle]'); if (tg) toggleAlert(tg.dataset.toggle);
  });
  $('[data-clear]').addEventListener('click', clearLog);

  function draw(st) {
    $('[data-list]').innerHTML = st.alerts.length ? `<div class="al-list">${st.alerts.map((a) => {
      const inst = getInstrument(a.symbol);
      const q = st.prices[a.symbol];
      let dist = '';
      if (q && (a.kind === 'above' || a.kind === 'below')) {
        const d = (a.value - q.price) / q.price * 100;
        dist = `<small class="muted">${esc(t('tools.alerts.dist'))} <bdi class="mono">${fmtPct(d)}</bdi> · ${esc(t('tools.alerts.nowPrice'))} <bdi class="mono">${fmtNum(q.price, inst.precision)}</bdi></small>`;
      } else if (q) dist = `<small class="muted">24h <bdi class="mono">${fmtPct(q.changePct)}</bdi></small>`;
      const status = !a.active ? (a.triggeredAt && !a.repeat ? 'done' : 'paused') : 'on';
      return `<div class="al-row is-${status}"><span class="al-ico">${icons.alarm}</span>
        <div class="al-main"><b>${esc(describeAlert(a))}</b>${a.note ? `<span class="muted">${esc(a.note)}</span>` : ''}${dist}
          <small class="muted">${a.repeat ? esc(t('tools.alerts.repeating')) : esc(t('tools.alerts.once'))}${a.count ? ` · ${esc(t('tools.alerts.fired', { n: a.count, time: dateStr(a.triggeredAt) }))}` : ''}</small></div>
        <span class="badge ${status === 'on' ? 'badge-live' : 'badge-muted'}">${esc(t(`tools.alerts.st.${status}`))}</span>
        <button type="button" class="btn btn-sm btn-ghost" data-toggle="${a.id}">${esc(t(a.active ? 'tools.alerts.pause' : 'tools.alerts.resume'))}</button>
        <button type="button" class="btn btn-icon btn-ghost btn-sm" data-del="${a.id}" aria-label="${esc(t('tools.common.delete'))}">${icons.trash}</button></div>`;
    }).join('')}</div>` : `<div class="sig-empty">${icons.alarm}<span>${esc(t('tools.alerts.empty'))}</span></div>`;
    $('[data-log]').innerHTML = st.log.length ? `<ul class="al-log">${st.log.slice(0, 30).map((l) => `<li><span class="mono muted">${esc(dateStr(l.at))}</span><b>${esc(l.title)}</b><span class="muted">${esc(l.body).replace(/\n/g, ' · ')}</span></li>`).join('')}</ul>` : `<p class="muted">${esc(t('tools.alerts.noHistory'))}</p>`;
  }
  draw(alertState());
  const off = onAlerts((st) => { if (!el.isConnected) { off(); return; } draw(st); });
  return el;
}
