// Alpha Market Correlation (v233): how markets move together, measured on real candles with shared timestamps.
// Returns correlation (Pearson, log returns) over 200 candles, the established relation vs the last 50 (breakdown),
// and a divergence check on the last 20. DXY is read from Yahoo Finance (DX-Y.NYB) as a reference series.
import { esc, fmtNum } from '../../utils/dom.js';
import { storage } from '../../utils/storage.js';
import { getHistory } from '../../services/market/index.js';
import { fetchYahooCandles } from '../../services/market/yahoo.js';
import { correlate, cleanCandles } from '../../services/radarPro.js';
import { L, marketSelect, tfSeg } from './radarText.js';
import { whileMounted, loading } from './common.js';

const PAIRS = [['XAUUSD', 'DXY'], ['US100', 'SPX500'], ['BTCUSDT', 'ETHUSDT'], ['EURUSD', 'DXY']];
const NAME = { DXY: 'DXY', XAUUSD: 'GOLD', SPX500: 'US500' };
async function series(sym, tf) {
  if (sym === 'DXY') { try { return { candles: cleanCandles(await fetchYahooCandles('DX-Y.NYB', tf, 320)), src: 'Yahoo Finance' }; } catch { return { error: 'dxy' }; } }
  const ds = await getHistory(sym, tf, 320).catch(() => null);
  if (!ds || ds.mode !== 'live') return { error: 'noLive' };
  return { candles: cleanCandles(ds.candles), src: ds.source };
}

export function mountCorr(el, body) {
  const st = { tf: '1h', a: 'XAUUSD', b: 'XAGUSD', ...(storage.get('radar-corr', {}) || {}) };
  body.innerHTML = `<div class="card rp-controls">${tfSeg('tf', st.tf, ['1h', '4h', '1D'])}<span class="muted rp-small">${esc(L('200 شمعة · الشموع اللي إلها نفس الوقت بس', '200 candles · shared timestamps only'))}</span></div>
    <div class="rp-corr" data-pairs>${loading()}</div>
    <div class="card rp-controls rp-custom"><b>${esc(L('قارن أي سوقين', 'Compare any two markets'))}</b>${marketSelect('a', st.a)}<span>↔</span>${marketSelect('b', st.b)}<button type="button" class="btn btn-sm" data-cmp>${esc(L('قارن', 'Compare'))}</button></div>
    <div data-custom></div>
    <p class="muted tool-note">${esc(L('الارتباط بيقيس قديش السوقين بيتحركوا مع بعض: +1 مع بعض تماماً، −1 عكس بعض تماماً، 0 ما في علاقة. «انكسار الارتباط» يعني آخر 50 شمعة تصرّفت غير عن قبل. «تباعد» يعني بآخر 20 شمعة السوقين تحرّكوا عكس علاقتهم المعتادة. هاد وصف لعلاقة تاريخية، مش إشارة دخول.', 'Correlation measures how two markets move together: +1 fully together, −1 fully opposite, 0 unrelated. “Breakdown” means the last 50 candles behaved differently from before. “Divergence” means over the last 20 candles they moved against their usual relation. It describes a historical relationship, not an entry signal.'))}</p>`;
  const $ = (s) => body.querySelector(s);
  const keep = () => storage.set('radar-corr', { tf: st.tf, a: $('[data-a]').value, b: $('[data-b]').value });
  $('[data-tf]').addEventListener('click', (e) => { const b = e.target.closest('[data-v]'); if (!b) return; st.tf = b.dataset.v; keep(); $('[data-tf]').querySelectorAll('button').forEach((x) => { x.classList.toggle('is-on', x === b); x.setAttribute('aria-pressed', String(x === b)); }); run(); custom(); });
  $('[data-cmp]').addEventListener('click', () => { keep(); custom(); });

  const card = (a, b, res, srcA, srcB) => {
    const na = NAME[a] || a, nb = NAME[b] || b;
    if (res.error) return `<article class="card rp-pair is-missing"><header><b>${esc(na)} / ${esc(nb)}</b></header><p>${esc(res.error === 'dxy' ? L('مؤشر الدولار (DXY) مش متاح من مصدر البيانات هلّق (Yahoo).', 'The dollar index (DXY) is not available from the data source right now (Yahoo).') : L('ما في بيانات حيّة لأحد السوقين هلّق.', 'No live data for one of the two markets right now.'))}</p></article>`;
    if (res.insufficient) return `<article class="card rp-pair is-missing"><header><b>${esc(na)} / ${esc(nb)}</b></header><p>${esc(L(`بيانات مش كافية: ${res.n} شمعة مشتركة بس (لازم 60 على الأقل).`, `Insufficient data: only ${res.n} shared candles (60 needed).`))}</p></article>`;
    const pct = Math.round(Math.abs(res.r) * 100);
    const S = { strong: L('قوي', 'Strong'), moderate: L('متوسط', 'Moderate'), weak: L('ضعيف', 'Weak'), none: L('ما في علاقة', 'None') };
    return `<article class="card rp-pair is-${res.sign}">
      <header><b>${esc(na)} / ${esc(nb)}</b><span class="rp-r mono">${res.r > 0 ? '+' : ''}${fmtNum(res.r, 2)}</span></header>
      <div class="rp-cbar" aria-label="${esc(`${res.r}`)}"><i style="${res.r >= 0 ? `left:50%;width:${pct / 2}%` : `right:50%;width:${pct / 2}%`}"></i><b></b></div>
      <p><span class="rp-tag">${esc(res.sign === 'positive' ? L('ارتباط موجب', 'Positive') : L('ارتباط سالب', 'Negative'))}</span><span class="rp-tag">${esc(L('القوة: ', 'Strength: '))}${esc(S[res.strength])}</span>
        ${res.breakdown ? `<span class="rp-tag is-warn">${esc(L(`انكسار: آخر 50 شمعة ${fmtNum(res.recent, 2)} مقابل ${fmtNum(res.base, 2)} قبل`, `Breakdown: last 50 ${fmtNum(res.recent, 2)} vs ${fmtNum(res.base, 2)} before`))}</span>` : ''}
        ${res.divergence ? `<span class="rp-tag is-warn">${esc(L(`تباعد بآخر 20 شمعة: ${na} ${res.move.a > 0 ? '+' : ''}${res.move.a}% · ${nb} ${res.move.b > 0 ? '+' : ''}${res.move.b}%`, `Divergence over 20 candles: ${na} ${res.move.a > 0 ? '+' : ''}${res.move.a}% · ${nb} ${res.move.b > 0 ? '+' : ''}${res.move.b}%`))}</span>` : ''}</p>
      <small class="muted">${res.n} ${esc(L('عائد مشترك', 'shared returns'))} · ${esc([srcA, srcB].filter(Boolean).join(' / '))}</small></article>`;
  };
  async function pair(a, b) {
    const [A, B] = await Promise.all([series(a, st.tf), series(b, st.tf)]);
    if (A.error || B.error) return { res: { error: A.error === 'dxy' || B.error === 'dxy' ? 'dxy' : 'noLive' } };
    return { res: correlate(A.candles, B.candles), srcA: A.src, srcB: B.src };
  }
  let token = 0;
  async function run() {
    const my = ++token; $('[data-pairs]').innerHTML = loading();
    const out = [];
    for (const [a, b] of PAIRS) { const r = await pair(a, b); if (my !== token || !el.isConnected) return; out.push(card(a, b, r.res, r.srcA, r.srcB)); }
    $('[data-pairs]').innerHTML = out.join('');
  }
  async function custom() {
    const a = $('[data-a]').value, b = $('[data-b]').value; if (a === b) { $('[data-custom]').innerHTML = `<p class="muted">${esc(L('اختار سوقين مختلفين.', 'Pick two different markets.'))}</p>`; return; }
    $('[data-custom]').innerHTML = loading(); const r = await pair(a, b); if (!el.isConnected) return;
    $('[data-custom]').innerHTML = `<div class="rp-corr">${card(a, b, r.res, r.srcA, r.srcB)}</div>`;
  }
  run();
  whileMounted(el, run, 5 * 60_000);
}
