// Economic calendar (Forex Factory, this week): filters by impact and currency, grouped by day in
// the user's local time, countdown to the next high-impact release, and the instruments it moves.
import { esc } from '../../utils/dom.js';
import { icons } from '../../components/icons.js';
import { t } from '../../i18n/index.js';
import { storage } from '../../utils/storage.js';
import { getCalendar, CCY_IMPACT } from '../../services/news.js';
import { alertState, setNewsAlerts } from '../../services/alerts.js';
import { enableNotifications, notifyPermission } from '../../services/signals.js';
import { toolPage, dateStr, whileMounted, loading, errorBox, locale } from './common.js';
import { describeError } from '../../utils/http.js';

const CCYS = ['USD', 'EUR', 'GBP', 'JPY', 'CNY', 'CHF', 'AUD', 'CAD', 'NZD'];
const IMPACTS = ['High', 'Medium', 'Low', 'Holiday'];

export function renderCalendar() {
  const el = toolPage('cal', 'calendar');
  const f = { impacts: ['High', 'Medium'], ccys: [], range: 'week', ...storage.get('cal-filter', {}) };
  const body = el.querySelector('[data-body]');
  body.innerHTML = `
    <div class="card cal-next fade-in" data-next></div>
    <div class="card perf-controls fade-in">
      <div class="perf-field"><span>${esc(t('tools.cal.impact'))}</span><div class="chips" data-imp>${IMPACTS.map((i) => `<button type="button" class="chip imp-${i.toLowerCase()} ${f.impacts.includes(i) ? 'is-on' : ''}" data-v="${i}"><i></i>${esc(t(`tools.cal.imp.${i}`))}</button>`).join('')}</div></div>
      <div class="perf-field"><span>${esc(t('tools.cal.currency'))}</span><div class="chips" data-ccy>${CCYS.map((c) => `<button type="button" class="chip ${f.ccys.includes(c) ? 'is-on' : ''}" data-v="${c}">${c}</button>`).join('')}</div></div>
      <div class="perf-field"><span>${esc(t('tools.cal.range'))}</span><div class="seg" data-range>${['today', 'next', 'week'].map((r) => `<button type="button" data-v="${r}" class="${f.range === r ? 'is-on' : ''}">${esc(t(`tools.cal.r.${r}`))}</button>`).join('')}</div></div>
    </div>
    <div class="card cal-alert fade-in" data-alert></div>
    <div data-list>${loading()}</div>
    <p class="muted tool-note">${esc(t('tools.cal.source'))} <a href="https://www.forexfactory.com/calendar" target="_blank" rel="noopener">Forex Factory</a> · ${esc(t('tools.cal.tz', { tz: Intl.DateTimeFormat().resolvedOptions().timeZone }))}</p>`;
  const $ = (s) => body.querySelector(s);
  let data = null;

  const saveF = () => storage.set('cal-filter', f);
  const toggle = (arr, v) => (arr.includes(v) ? arr.filter((x) => x !== v) : [...arr, v]);
  $('[data-imp]').addEventListener('click', (e) => { const b = e.target.closest('[data-v]'); if (!b) return; f.impacts = toggle(f.impacts, b.dataset.v); b.classList.toggle('is-on'); saveF(); draw(); });
  $('[data-ccy]').addEventListener('click', (e) => { const b = e.target.closest('[data-v]'); if (!b) return; f.ccys = toggle(f.ccys, b.dataset.v); b.classList.toggle('is-on'); saveF(); draw(); });
  $('[data-range]').addEventListener('click', (e) => { const b = e.target.closest('[data-v]'); if (!b) return; f.range = b.dataset.v; $('[data-range]').querySelectorAll('button').forEach((x) => x.classList.toggle('is-on', x === b)); saveF(); draw(); });

  function drawAlert() {
    const n = alertState().news;
    $('[data-alert]').innerHTML = `<div class="cal-alert-row">${icons.alarm}<div><b>${esc(t('tools.cal.alertTitle'))}</b><p class="muted">${esc(t('tools.cal.alertSub'))}</p></div>
      <label class="switch"><input type="checkbox" data-news-on ${n.enabled ? 'checked' : ''}><span></span></label></div>
      <div class="cal-alert-opts ${n.enabled ? '' : 'is-off'}">
        <label class="tf-field"><span>${esc(t('tools.cal.before'))}</span><select class="select" data-news-min>${[5, 10, 15, 30, 60].map((m) => `<option value="${m}" ${Number(n.minutes) === m ? 'selected' : ''}>${m} ${esc(t('tools.common.min'))}</option>`).join('')}</select></label>
        <label class="tf-field"><span>${esc(t('tools.cal.impact'))}</span><select class="select" data-news-imp><option value="High" ${n.impact === 'High' ? 'selected' : ''}>${esc(t('tools.cal.imp.High'))}</option><option value="Medium" ${n.impact === 'Medium' ? 'selected' : ''}>${esc(t('tools.cal.highMed'))}</option></select></label>
        <label class="tf-field"><span>${esc(t('tools.cal.currency'))}</span><select class="select" data-news-ccy><option value="USD" ${n.ccys?.join() === 'USD' ? 'selected' : ''}>USD</option><option value="" ${!n.ccys?.length ? 'selected' : ''}>${esc(t('tools.cal.allCcy'))}</option></select></label>
      </div>`;
    $('[data-news-on]').addEventListener('change', async (e) => {
      if (e.target.checked && notifyPermission() === 'default') await enableNotifications();
      setNewsAlerts({ enabled: e.target.checked }); drawAlert();
    });
    $('[data-news-min]').addEventListener('change', (e) => setNewsAlerts({ minutes: Number(e.target.value) }));
    $('[data-news-imp]').addEventListener('change', (e) => setNewsAlerts({ impact: e.target.value }));
    $('[data-news-ccy]').addEventListener('change', (e) => setNewsAlerts({ ccys: e.target.value ? [e.target.value] : [] }));
  }
  drawAlert();

  const countdown = (ms) => {
    if (ms <= 0) return t('tools.cal.now');
    const m = Math.floor(ms / 60000);
    const d = Math.floor(m / 1440); const hh = Math.floor((m % 1440) / 60); const mm = m % 60;
    return d ? t('tools.cal.inDH', { d, h: hh }) : hh ? t('tools.cal.inHM', { h: hh, m: mm }) : t('tools.cal.inM', { m: Math.max(1, mm) });
  };

  function drawNext() {
    if (!data) return;
    const now = Date.now();
    const next = data.events.find((e) => e.impact === 'High' && e.time > now - 60_000);
    $('[data-next]').innerHTML = next ? `<span class="cal-next-ico">${icons.bolt}</span>
      <div class="cal-next-main"><span class="muted">${esc(t('tools.cal.nextHigh'))}</span><b>${esc(next.title)}</b>
      <span class="cal-meta"><span class="ccy">${esc(next.country)}</span> ${esc(dateStr(next.time, { weekday: 'short', hour: '2-digit', minute: '2-digit' }))}${next.forecast ? ` · ${esc(t('tools.cal.forecast'))} <bdi class="mono">${esc(next.forecast)}</bdi>` : ''}</span></div>
      <div class="cal-count"><b>${esc(countdown(next.time - now))}</b><span class="muted">${(CCY_IMPACT[next.country] || []).map((s) => `<span class="mini-sym">${s}</span>`).join('')}</span></div>`
      : `<span class="muted">${esc(t('tools.cal.noHigh'))}</span>`;
  }

  function draw() {
    if (!data) return;
    drawNext();
    const now = Date.now();
    const today = new Date(); today.setHours(0, 0, 0, 0);
    const tomorrow = today.getTime() + 864e5;
    let list = data.events.filter((e) => f.impacts.includes(e.impact) && (!f.ccys.length || f.ccys.includes(e.country)));
    if (f.range === 'today') list = list.filter((e) => e.time >= today.getTime() && e.time < tomorrow);
    if (f.range === 'next') list = list.filter((e) => e.time >= now - 30 * 60_000).slice(0, 15);
    if (!list.length) { $('[data-list]').innerHTML = `<div class="card sig-empty">${icons.calendar}<span>${esc(t('tools.cal.empty'))}</span></div>`; return; }
    const days = new Map();
    for (const e of list) {
      const k = new Date(e.time).toDateString();
      if (!days.has(k)) days.set(k, []);
      days.get(k).push(e);
    }
    const nextId = list.find((e) => e.time > now)?.id;
    $('[data-list]').innerHTML = [...days.entries()].map(([k, evs]) => {
      const d = new Date(k);
      const isToday = d.getTime() === today.getTime();
      return `<article class="card cal-day fade-in ${isToday ? 'is-today' : ''}"><h3>${esc(d.toLocaleDateString(locale(), { weekday: 'long', day: 'numeric', month: 'long' }))}${isToday ? ` <span class="badge badge-live">${esc(t('tools.cal.today'))}</span>` : ''}</h3>
        <div class="cal-rows">${evs.map((e) => `<div class="cal-row imp-${e.impact.toLowerCase()} ${e.time < now ? 'is-past' : ''} ${e.id === nextId ? 'is-next' : ''}">
          <span class="cal-time mono">${esc(new Date(e.time).toLocaleTimeString(locale(), { hour: '2-digit', minute: '2-digit' }))}</span>
          <span class="cal-imp" title="${esc(t(`tools.cal.imp.${e.impact}`))}"><i></i></span>
          <span class="ccy">${esc(e.country)}</span>
          <span class="cal-title">${esc(e.title)}${(CCY_IMPACT[e.country] || []).length && e.impact === 'High' ? `<small class="cal-affects">${(CCY_IMPACT[e.country] || []).map((s) => `<span class="mini-sym">${s}</span>`).join('')}</small>` : ''}</span>
          <span class="cal-nums"><span><small>${esc(t('tools.cal.actual'))}</small><bdi class="mono">${esc(e.actual || '—')}</bdi></span><span><small>${esc(t('tools.cal.forecast'))}</small><bdi class="mono">${esc(e.forecast || '—')}</bdi></span><span><small>${esc(t('tools.cal.previous'))}</small><bdi class="mono">${esc(e.previous || '—')}</bdi></span></span>
        </div>`).join('')}</div></article>`;
    }).join('');
  }

  async function load(force = false) {
    try {
      const r = await getCalendar({ force });
      data = r;
      draw();
      if (r.stale) $('[data-list]').insertAdjacentHTML('afterbegin', `<p class="muted tool-note">${esc(t('tools.common.stale', { time: dateStr(r.at) }))}</p>`);
    } catch (err) {
      $('[data-list]').innerHTML = errorBox(`${t('tools.cal.failed')} (${describeError(err, t)})`);
      $('[data-next]').innerHTML = `<span class="muted">${esc(t('tools.cal.failedShort'))}</span>`;
      $('[data-retry]')?.addEventListener('click', () => { $('[data-list]').innerHTML = loading(); load(true); });
    }
  }
  load();
  whileMounted(el, drawNext, 30_000);
  whileMounted(el, () => load(), 10 * 60_000);
  return el;
}
