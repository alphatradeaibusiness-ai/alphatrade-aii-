// Stability report (Lab → Stability): does a strategy hold up on every stretch of the loaded history, with fixed rules and fees?
// Nothing is optimised here (unlike Auto optimisation), so there is no selection bias in the result.
import { esc, fmtNum } from '../../utils/dom.js';
import { icons } from '../../components/icons.js';
import { t } from '../../i18n/index.js';
import { storage } from '../../utils/storage.js';
import { store } from '../../state/store.js';
import { INSTRUMENTS, getInstrument, STOP_LOSS_POINTS, TARGET_POINTS } from '../../config/instruments.js';
import { getHistory, isUnavailable } from '../../services/market/index.js';
import { rulesFrom } from '../../services/backtest.js';
import { walkForward, FOLDS, MIN_TRADES_TOTAL } from '../../services/walkForward.js';
import { toolPage, pointSizeOf, signed } from './common.js';

const TFS = ['15m', '1h', '4h'];
const STRATS = ['classic', 'smc', 'zone'];   // EDH is not run here: it needs its own daily data and is left untouched
const pause = (ms) => new Promise((r) => setTimeout(r, ms));

export function renderWalkForward() {
  const el = toolPage('walkforward', 'shield');
  const avail = INSTRUMENTS.filter((i) => !isUnavailable(i.symbol));
  const saved = storage.get('walkforward', {});
  const st = { symbols: saved.symbols?.length ? saved.symbols : avail.filter((i) => i.type === 'crypto').slice(0, 2).map((i) => i.symbol), tfs: saved.tfs?.length ? saved.tfs : ['1h'], strats: saved.strats?.length ? saved.strats : STRATS.slice() };
  const body = el.querySelector('[data-body]');
  body.innerHTML = `
    <div class="card perf-controls fade-in">
      <div class="perf-field"><span>${esc(t('tools.autotest.symbols'))}</span><div class="chips" data-syms>${avail.map((i) => `<button type="button" class="chip ${st.symbols.includes(i.symbol) ? 'is-on' : ''}" data-v="${i.symbol}">${i.symbol}</button>`).join('')}</div></div>
      <div class="perf-field"><span>${esc(t('tools.autotest.tfs'))}</span><div class="chips" data-tfs>${TFS.map((tf) => `<button type="button" class="chip ${st.tfs.includes(tf) ? 'is-on' : ''}" data-v="${tf}">${esc(t(`perf.tfShort.${tf}`))}</button>`).join('')}</div></div>
      <div class="perf-field"><span>${esc(t('tools.walkforward.strats'))}</span><div class="chips" data-strats>${STRATS.map((s) => `<button type="button" class="chip ${st.strats.includes(s) ? 'is-on' : ''}" data-v="${s}">${esc(t(`tools.walkforward.s.${s}`))}</button>`).join('')}</div></div>
      <button type="button" class="btn btn-primary" data-run>${icons.shield}<span>${esc(t('tools.walkforward.run'))}</span></button>
    </div>
    <div class="card at-progress fade-in" data-prog hidden><div class="at-bar"><i data-bar></i></div><span class="muted" data-ptext></span></div>
    <div data-out></div>
    <article class="card tool-card fade-in"><h2 class="card-title">${icons.info}<span>${esc(t('tools.walkforward.howTitle'))}</span></h2>
      <ul class="tool-list">${t('tools.walkforward.how').map((x) => `<li>${esc(x)}</li>`).join('')}</ul></article>`;
  const $ = (s) => body.querySelector(s);
  const save = () => storage.set('walkforward', st);
  const toggle = (key, v, b) => { st[key] = st[key].includes(v) ? st[key].filter((x) => x !== v) : [...st[key], v]; b.classList.toggle('is-on'); save(); };
  $('[data-syms]').addEventListener('click', (e) => { const b = e.target.closest('[data-v]'); if (b) toggle('symbols', b.dataset.v, b); });
  $('[data-tfs]').addEventListener('click', (e) => { const b = e.target.closest('[data-v]'); if (b) toggle('tfs', b.dataset.v, b); });
  $('[data-strats]').addEventListener('click', (e) => { const b = e.target.closest('[data-v]'); if (b) toggle('strats', b.dataset.v, b); });
  const R = (v, d = 2) => signed(v, d, 'R');

  const cell = (f) => `<i class="wf-cell ${f.n < 3 ? 'none' : f.netR > 0 ? 'pos' : 'neg'}" title="${esc(`${f.n} · ${R(f.netR, 1)}`)}"></i>`;
  function show(rows, skipped) {
    if (!rows.length) { $('[data-out]').innerHTML = `<div class="card sig-empty">${icons.shield}<span>${esc(t('tools.walkforward.empty'))}${skipped.length ? ` ${esc(t('tools.autotest.skipped', { s: skipped.join(', ') }))}` : ''}</span></div>`; return; }
    $('[data-out]').innerHTML = `<article class="card tool-card fade-in"><div class="table-scroll"><table class="kv-table perf-table"><thead><tr>
      <th>${esc(t('perf.option'))}</th><th>${esc(t('perf.trades'))}</th><th>${esc(t('tools.walkforward.avg'))}</th><th>${esc(t('tools.walkforward.net'))}</th><th>t</th><th>${esc(t('tools.walkforward.foldsCol', { n: FOLDS }))}</th><th>${esc(t('tools.walkforward.verdict'))}</th></tr></thead><tbody>
      ${rows.map((r) => `<tr><td><b class="mono">${esc(r.symbol)}</b> · ${esc(t(`perf.tfShort.${r.tf}`))} · ${esc(t(`tools.walkforward.s.${r.strategy}`))}</td>
        <td class="mono">${r.total.n}</td><td class="mono">${R(r.total.avgR)}</td><td class="mono">${R(r.total.netR, 1)}</td><td class="mono">${r.verdict === 'insufficient' ? '—' : fmtNum(r.t, 1)}</td>
        <td><span class="wf-cells">${r.folds.map(cell).join('')}</span> <small class="muted">${r.positiveFolds}/${r.usedFolds}</small></td>
        <td><span class="badge ${r.verdict === 'stable' ? 'badge-live' : r.verdict === 'negative' ? 'badge-error' : 'badge-demo'}">${esc(t(`tools.walkforward.v.${r.verdict}`))}</span></td></tr>`).join('')}
      </tbody></table></div>
      <p class="muted tool-note">${esc(t('tools.walkforward.legend', { min: MIN_TRADES_TOTAL }))}${skipped.length ? ` · ${esc(t('tools.autotest.skipped', { s: skipped.join(', ') }))}` : ''}</p></article>`;
  }

  let running = false;
  async function run() {
    if (running || !st.symbols.length || !st.tfs.length || !st.strats.length) return;
    running = true; $('[data-run]').disabled = true;
    const prog = $('[data-prog]'); prog.hidden = false;
    const jobs = st.symbols.flatMap((s) => st.tfs.map((tf) => [s, tf]));
    const rows = []; const skipped = []; const settings = store.get('settings');
    for (let k = 0; k < jobs.length; k++) {
      const [s, tf] = jobs[k];
      $('[data-ptext]').textContent = t('tools.autotest.progress', { s, tf: t(`perf.tfShort.${tf}`), k: k + 1, n: jobs.length });
      $('[data-bar]').style.width = `${(k / jobs.length) * 100}%`;
      try {
        const ds = await getHistory(s, tf, 1000);
        if (ds.mode !== 'live') { skipped.push(`${s} ${tf}`); continue; }   // demo candles prove nothing
        const inst = getInstrument(s);
        const rules = { ...rulesFrom(settings, inst), forced: null, pointSize: pointSizeOf(s), slPoints: STOP_LOSS_POINTS, tpPoints: TARGET_POINTS, volumeKind: ds.volumeKind, openOnLast: false };
        for (const strategy of st.strats) {
          await pause(20);
          const res = walkForward(ds.candles, strategy, rules);
          if (res) rows.push({ symbol: s, tf, strategy, ...res });
        }
      } catch { skipped.push(`${s} ${tf}`); }
      if (!el.isConnected) { running = false; return; }
    }
    $('[data-bar]').style.width = '100%';
    show(rows, skipped);
    setTimeout(() => { prog.hidden = true; }, 600);
    $('[data-run]').disabled = false; running = false;
  }
  $('[data-run]').addEventListener('click', run);
  return el;
}
