// Integrated news: Forex Factory headlines (refreshed every 2 minutes, filterable by market),
// today's high-impact releases from the Forex Factory calendar, and X (Twitter): the live timeline
// of the accounts that break market news first plus live searches per instrument.
import { esc } from '../../utils/dom.js';
import { icons, assetIcon } from '../../components/icons.js';
import { t, getLang } from '../../i18n/index.js';
import { storage } from '../../utils/storage.js';
import { store } from '../../state/store.js';
import { getFFNews, getCalendar, X_ACCOUNTS, X_SEARCHES, xSearchUrl, CCY_IMPACT } from '../../services/news.js';
import { toolPage, loading, errorBox, dateStr, whileMounted, locale } from './common.js';
import { describeError } from '../../utils/http.js';
import { imagesForHeadlines } from '../../services/smartImages.js';

const TOPICS = {
  all: null,
  usd: /\b(fed|fomc|powell|usd|dollar|treasur|yields?|cpi|pce|nfp|payrolls?|jobs|jobless|unemployment|gdp|ism|retail sales|inflation|tariff|trump|white house)\b/i,
  gold: /\b(gold|xau|bullion|precious|safe[- ]haven|geopolit|war|iran|israel|russia|ukraine|oil)\b/i,
  crypto: /\b(bitcoin|btc|crypto|ether(eum)?|eth|solana|binance|bnb|etf|stablecoin|sec)\b/i,
  stocks: /\b(stocks?|equit|nasdaq|s&p|dow|spx|ndx|earnings|nvidia|apple|tesla|microsoft|wall street)\b/i,
  eur: /\b(ecb|lagarde|euro|eur|eurozone|germany|boe|bailey|pound|gbp|uk|boj|ueda|yen|jpy|china|pboc)\b/i,
};
let widgetsPromise = null;
function loadXWidgets() {
  if (window.twttr?.widgets) return Promise.resolve(window.twttr);
  if (!widgetsPromise) {
    widgetsPromise = new Promise((resolve, reject) => {
      const s = document.createElement('script');
      s.src = 'https://platform.twitter.com/widgets.js';
      s.async = true; s.charset = 'utf-8';
      s.onload = () => (window.twttr?.widgets ? resolve(window.twttr) : setTimeout(() => (window.twttr?.widgets ? resolve(window.twttr) : reject(new Error('x'))), 800));
      s.onerror = () => { widgetsPromise = null; reject(new Error('x')); };
      document.head.append(s);
    });
  }
  return widgetsPromise;
}

const agoText = (n) => {
  if (n.time == null) return n.ago || '';
  const m = Math.max(0, Math.round((Date.now() - n.time) / 60000));
  const rtf = new Intl.RelativeTimeFormat(getLang() === 'ar' ? 'ar-u-nu-latn' : 'en', { numeric: 'auto', style: 'short' });
  return m < 60 ? rtf.format(-m, 'minute') : m < 1440 ? rtf.format(-Math.round(m / 60), 'hour') : rtf.format(-Math.round(m / 1440), 'day');
};
const trUrl = (text) => `https://translate.google.com/?sl=auto&tl=${getLang() === 'ar' ? 'ar' : 'en'}&text=${encodeURIComponent(text)}&op=translate`;

export function renderNews() {
  const el = toolPage('news', 'news');
  const st = { tab: 'ff', topic: 'all', x: X_ACCOUNTS[0].handle, ...storage.get('news', {}) };
  const seen = new Set(storage.get('news-seen', []));
  const body = el.querySelector('[data-body]');
  body.innerHTML = `
    <div class="news-tabs seg fade-in" data-tabs>
      <button type="button" data-v="ff" class="${st.tab === 'ff' ? 'is-on' : ''}"><span class="ff-dot">FF</span>${esc(t('tools.news.ff'))}</button>
      <button type="button" data-v="x" class="${st.tab === 'x' ? 'is-on' : ''}">${icons.xlogo}${esc(t('tools.news.x'))}</button>
    </div>
    <div class="card news-strip fade-in" data-strip></div>
    <div data-pane></div>
    <p class="muted tool-note">${esc(t('tools.news.note'))}</p>`;
  const $ = (s) => body.querySelector(s);
  let ff = null; let cal = null; let ffErr = null;

  $('[data-tabs]').addEventListener('click', (e) => {
    const b = e.target.closest('[data-v]'); if (!b) return;
    st.tab = b.dataset.v; storage.set('news', st);
    $('[data-tabs]').querySelectorAll('button').forEach((x) => x.classList.toggle('is-on', x === b));
    pane();
  });

  // Next high-impact release (always visible).
  function strip() {
    if (!cal) return;
    const now = Date.now();
    const next = cal.events.filter((e) => e.impact === 'High' && e.time > now).slice(0, 3);
    $('[data-strip]').innerHTML = next.length ? `<span class="ns-label">${icons.bolt}${esc(t('tools.news.upcoming'))}</span>${next.map((e) => {
      const m = Math.round((e.time - now) / 60000);
      return `<a class="ns-item" href="#/app/calendar"><span class="ccy">${esc(e.country)}</span><b>${esc(e.title)}</b><span class="muted mono">${m < 60 ? t('tools.cal.inM', { m: Math.max(1, m) }) : esc(dateStr(e.time, { weekday: 'short', hour: '2-digit', minute: '2-digit' }))}</span></a>`;
    }).join('')}` : `<span class="muted">${esc(t('tools.cal.noHigh'))}</span>`;
  }

  function ffPane() {
    const topics = Object.keys(TOPICS);
    const head = `<div class="card perf-controls fade-in news-controls"><div class="chips" data-topics>${topics.map((k) => `<button type="button" class="chip ${st.topic === k ? 'is-on' : ''}" data-v="${k}">${esc(t(`tools.news.topic.${k}`))}</button>`).join('')}</div>
      <button type="button" class="btn btn-sm btn-ghost" data-refresh>${icons.refresh}<span>${esc(t('tools.news.refresh'))}</span></button></div>`;
    if (ffErr && !ff) return `${head}${errorBox(`${t('tools.news.failed')} (${describeError(ffErr, t)})`)}<div class="news-fallback card"><a class="btn" href="https://www.forexfactory.com/news" target="_blank" rel="noopener">${icons.external}<span>${esc(t('tools.news.openFF'))}</span></a></div>`;
    if (!ff) return `${head}${loading()}`;
    const rx = TOPICS[st.topic];
    const items = ff.items.filter((n) => !rx || rx.test(n.title));
    return `${head}${ff.stale ? `<p class="muted tool-note">${esc(t('tools.common.stale', { time: dateStr(ff.at) }))}</p>` : ''}
      <div class="news-list">${items.length ? items.map((n, i) => `<article class="card news-item ${seen.has(n.id) ? '' : 'is-new'} ${n.isX ? 'is-x' : ''}" style="--i:${Math.min(i, 12)}">
        <div class="ni-meta">${n.isX ? `<span class="ni-src x">${icons.xlogo}${esc(n.source)}</span>` : n.source ? `<span class="ni-src">${esc(n.source)}</span>` : '<span class="ni-src">Forex Factory</span>'}
          <span class="muted">${esc(agoText(n))}</span>${seen.has(n.id) ? '' : `<span class="badge badge-live">${esc(t('tools.news.new'))}</span>`}</div>
        <span class="news-topic-art" title="${getLang() === 'ar' ? 'رسم توضيحي لموضوع الخبر' : 'Topic illustration'}">${assetIcon(/gold|xau|bullion/i.test(n.title) ? 'xau' : /ether|eth/i.test(n.title) ? 'eth' : /bitcoin|crypto|btc/i.test(n.title) ? 'btc' : 'us100', 48)}</span><img class="ni-img" data-ni-img="${esc(n.id)}" alt="" hidden/>
        <a class="ni-title" href="${esc(n.url)}" target="_blank" rel="noopener" dir="auto">${esc(n.title)}</a>
        <div class="ni-actions"><a href="${esc(n.url)}" target="_blank" rel="noopener">${icons.external}${esc(t('tools.news.read'))}</a>${getLang() === 'ar' ? `<a href="${esc(trUrl(n.title))}" target="_blank" rel="noopener">${icons.globe}${esc(t('tools.news.translate'))}</a>` : ''}</div>
      </article>`).join('') : `<div class="card sig-empty">${icons.news}<span>${esc(t('tools.news.noTopic'))}</span></div>`}</div>
      <p class="muted tool-note">${esc(t('tools.news.updated', { time: dateStr(ff.at, { hour: '2-digit', minute: '2-digit' }) }))} · <a href="https://www.forexfactory.com/news" target="_blank" rel="noopener">forexfactory.com/news</a></p>`;
  }

  function xPane() {
    const acc = X_ACCOUNTS.find((a) => a.handle === st.x) || X_ACCOUNTS[0];
    return `<div class="card perf-controls fade-in"><div class="perf-field"><span>${esc(t('tools.news.accounts'))}</span><div class="chips" data-xacc>${X_ACCOUNTS.map((a) => `<button type="button" class="chip ${a.handle === acc.handle ? 'is-on' : ''}" data-v="${a.handle}"><bdi dir="ltr">@${a.handle}</bdi></button>`).join('')}</div></div></div>
      <div class="x-grid">
        <article class="card x-timeline fade-in"><div class="x-head">${icons.xlogo}<b>${esc(acc.name)}</b><bdi class="muted" dir="ltr">@${esc(acc.handle)}</bdi><a class="btn btn-sm" href="https://x.com/${acc.handle}" target="_blank" rel="noopener">${icons.external}<span>${esc(t('tools.news.openX'))}</span></a></div>
          <div class="x-embed" data-embed>${loading()}</div></article>
        <article class="card tool-card fade-in"><h2 class="card-title">${icons.search}<span>${esc(t('tools.news.liveSearch'))}</span></h2>
          <div class="x-searches">${X_SEARCHES.map((s) => `<a class="x-search" href="${esc(xSearchUrl(s.q))}" target="_blank" rel="noopener">${icons.xlogo}<b>${esc(s.label)}</b><span class="muted mono" dir="ltr">${esc(s.q)}</span></a>`).join('')}</div>
          <p class="muted tool-note">${esc(t('tools.news.xNote'))}</p></article>
      </div>`;
  }

  function calPane() {
    if (!cal) return loading();
    const now = Date.now();
    const start = new Date(); start.setHours(0, 0, 0, 0);
    const list = cal.events.filter((e) => e.time >= start.getTime() && e.time < start.getTime() + 864e5 && (e.impact === 'High' || e.impact === 'Medium'));
    return `<div class="news-list">${list.length ? list.map((e) => `<article class="card news-item cal-news imp-${e.impact.toLowerCase()} ${e.time < now ? 'is-past' : ''}">
      <div class="ni-meta"><span class="cal-imp"><i></i></span><span class="ccy">${esc(e.country)}</span><span class="mono muted">${esc(new Date(e.time).toLocaleTimeString(locale(), { hour: '2-digit', minute: '2-digit' }))}</span>${e.time < now ? `<span class="badge badge-muted">${esc(t('tools.news.released'))}</span>` : ''}</div>
      <b class="ni-title" dir="auto">${esc(e.title)}</b>
      <div class="ni-actions"><span>${esc(t('tools.cal.forecast'))} <bdi class="mono">${esc(e.forecast || '—')}</bdi></span><span>${esc(t('tools.cal.previous'))} <bdi class="mono">${esc(e.previous || '—')}</bdi></span>${(CCY_IMPACT[e.country] || []).map((s) => `<span class="mini-sym">${s}</span>`).join('')}</div></article>`).join('') : `<div class="card sig-empty">${icons.calendar}<span>${esc(t('tools.news.noToday'))}</span></div>`}</div>
      <a class="btn btn-sm" href="#/app/calendar">${icons.calendar}<span>${esc(t('tools.news.fullCal'))}</span></a>`;
  }

  function mountX() {
    const box = $('[data-embed]');
    if (!box) return;
    const acc = X_ACCOUNTS.find((a) => a.handle === st.x) || X_ACCOUNTS[0];
    const theme = store.get('theme') === 'light' ? 'light' : 'dark';
    const fallback = () => {
      if (!box.isConnected || box.querySelector('iframe[style*="height"]')?.offsetHeight > 120) return;
      box.innerHTML = `<div class="x-fallback">${icons.xlogo}<p>${esc(t('tools.news.xBlocked'))}</p><a class="btn btn-primary" href="https://x.com/${acc.handle}" target="_blank" rel="noopener">${icons.external}<span>${esc(t('tools.news.openX'))} <bdi dir="ltr">@${esc(acc.handle)}</bdi></span></a></div>`;
    };
    loadXWidgets().then((tw) => {
      if (!box.isConnected) return;
      box.innerHTML = `<a class="twitter-timeline" data-theme="${theme}" data-height="640" data-dnt="true" data-chrome="noheader nofooter transparent" data-lang="${getLang()}" href="https://twitter.com/${acc.handle}">@${acc.handle}</a>`;
      tw.widgets.load(box);
      setTimeout(fallback, 9000);
    }).catch(fallback);
  }

  function pane() {
    const p = $('[data-pane]');
    p.innerHTML = st.tab === 'x' ? xPane() : ffPane();
    p.querySelector('[data-topics]')?.addEventListener('click', (e) => { const b = e.target.closest('[data-v]'); if (!b) return; st.topic = b.dataset.v; storage.set('news', st); pane(); });
    p.querySelector('[data-refresh]')?.addEventListener('click', () => loadFF(true));
    p.querySelector('[data-retry]')?.addEventListener('click', () => { ffErr = null; pane(); loadFF(true); });
    p.querySelector('[data-xacc]')?.addEventListener('click', (e) => { const b = e.target.closest('[data-v]'); if (!b) return; st.x = b.dataset.v; storage.set('news', st); pane(); });
    if (st.tab === 'x') mountX();
    if (st.tab === 'ff' && ff) smartImages();
    // Headlines shown once are no longer "new" next time.
    if (st.tab === 'ff' && ff) setTimeout(() => { ff.items.forEach((n) => seen.add(n.id)); storage.set('news-seen', [...seen].slice(-300)); }, 1500);
  }

  // AI Smart Images: a matching picture from the user's library next to each headline (cached; never blocks the list).
  let siRun = 0;
  async function smartImages() {
    const run = ++siRun;
    let map;
    try { map = await imagesForHeadlines(ff.items); } catch { return; }   // no key / network: the list simply stays without images
    if (run !== siRun || !el.isConnected) return;
    for (const [id, im] of map) {
      const img = body.querySelector(`[data-ni-img="${CSS.escape(id)}"]`);
      if (img) { img.src = im.data; img.alt = im.desc?.alt || ''; img.hidden = false; img.closest('.news-item')?.classList.add('has-img'); }
    }
  }

  async function loadFF(force = false) {
    try { ff = await getFFNews({ force }); ffErr = null; } catch (err) { ffErr = err; }
    if (el.isConnected && st.tab === 'ff') pane();
  }
  async function loadCal() {
    try { cal = await getCalendar(); } catch { cal = { events: [] }; }
    if (!el.isConnected) return;
    strip();
  }
  pane();
  loadFF();
  loadCal();
  whileMounted(el, () => loadFF(), 2 * 60_000);
  whileMounted(el, strip, 1000);
  return el;
}
