// Digital bank page. Tabs: wallet (pockets, vault, converter, labelled history), deposit, withdraw (incl. cross-border), cards
// (virtual Visa + physical request), invest (plans, sell, tax report), money (budgets, subscriptions, saving rules), insights
// (insights, dashboard, Open Banking), rewards, security (passkeys, freeze, co-signers, notifications), support, identity,
// and the owner's desk. Everything is decided on the server; this page only shows state and sends requests. Personal data
// typed here goes to the server once and is never kept in the browser.
import { icons } from '../../components/icons.js';
import { toast } from '../../components/ui.js';
import { auth } from '../../services/auth/index.js';
import { getLang } from '../../i18n/index.js';
import { toolPage, onUnmount, dateStr } from './common.js';
import { bankApi, startBankStream, downloadTaxCsv, downloadComplianceCsv } from '../../services/bank/api.js';
import { signFor, passkeysSupported } from '../../services/bank/passkey.js';
import { parseCommand, listenOnce, voiceSupported, normName } from '../../services/bank/voice.js';
import { T, Tx, esc, fmtMinor, CURRENCIES, CURS, errText, opts, field, input, badge, fd, amt, card, empty } from './bank/ui.js';
import { walletTab } from './bank/wallet.js';
import { cardsTab } from './bank/cards.js';
import { moneyTab } from './bank/money.js';
import { insightsTab } from './bank/insights.js';
import { rewardsTab } from './bank/rewards.js';
import { securityTab } from './bank/security.js';
import { supportTab, notificationsPane } from './bank/support.js';

const TABS = ['wallet', 'deposit', 'withdraw', 'cards', 'invest', 'money', 'insights', 'rewards', 'security', 'support', 'identity'];

export function renderBank() {
  const el = toolPage('bank', 'wallet');
  const body = el.querySelector('[data-body]');
  const st = { tab: 'wallet', info: null, owner: false, wallet: null, hist: { items: [], next: null, type: '', currency: '', category: '' }, stopStream: null, busy: false, unread: 0 };
  let alive = true; onUnmount(el, () => { alive = false; st.stopStream?.(); });

  const user = auth.current();
  if (!user || user.provider === 'local') { body.innerHTML = `<div class="card sig-empty">${icons.lock}<span>${esc(T('needSignin'))}</span></div>`; return el; }
  body.innerHTML = `<div class="perf-loading"><span class="spinner"></span></div>`;

  /** Runs an action: disables the button, shows the server's reason on failure, re-reads the wallet on success. */
  async function act(btn, fn, okMsg) {
    if (st.busy) return false; st.busy = true; btn?.setAttribute('disabled', '');
    try { const r = await fn(); if (okMsg) toast(okMsg, 'success'); await reloadWallet(false); return r ?? true; }
    catch (e) { toast(errText(e), 'error'); return false; }
    finally { st.busy = false; btn?.removeAttribute('disabled'); }
  }
  /** Sensitive actions: when the user has a passkey, the device signs a challenge bound to exactly these params first. */
  async function secure(purpose, params, run) {
    if (!st.info?.passkeys) return run(undefined);
    if (!passkeysSupported()) throw Object.assign(new Error('x'), { code: 'passkey_unsupported' });
    return run(await signFor(purpose, params));
  }
  const B = {
    st, act, secure, errText, alive: () => alive,
    refreshStatus: async () => { st.info = { ...st.info, ...(await bankApi.status().catch(() => ({}))) }; },
    setUnread: (n) => { st.unread = n; const b = body.querySelector('[data-unread]'); if (b) { b.textContent = n > 9 ? '9+' : String(n); b.hidden = !n; } },
    go: (tab) => { st.tab = tab; body.querySelectorAll('[data-tab]').forEach((x) => x.classList.toggle('is-on', x.dataset.tab === tab)); paint(); },
  };

  async function boot() {
    try { st.info = await bankApi.status(); } catch (e) { body.innerHTML = `<div class="alert alert-error">${icons.alert}<div>${esc(e.code === 'server_missing' || e.code === 'server_unreachable' ? T('noServer') : errText(e))}</div></div>`; return; }
    if (!alive) return;
    st.owner = Boolean(st.info.owner);
    await reloadWallet(true); if (!alive) return;
    st.stopStream = startBankStream((kind) => { if (!alive) return; if (kind === 'notify') refreshUnread(); else reloadWallet(false); });
    draw(); refreshUnread();
    bankApi.prefs().then((p) => { if (p.lang !== getLang()) bankApi.setPrefs({ lang: getLang() }).catch(() => {}); }).catch(() => {});
  }
  async function refreshUnread() { const r = await bankApi.notifications().catch(() => null); if (r && alive) B.setUnread(r.unread); }
  async function reloadWallet(first) {
    try {
      const w = await bankApi.wallet(); st.wallet = w;
      if (!first && alive && st.tab === 'wallet') { const p = pane(); if (p) { updateBalances(p); B.histReload?.(); } }
      if (!first && alive && ['withdraw', 'deposit'].includes(st.tab) && !st.busy) paint();
    } catch (e) { if (first) { body.innerHTML = `<div class="alert alert-error">${icons.alert}<div>${esc(e.code === 'bank_disabled' ? T('notEnabled') : errText(e))}</div></div>`; throw e; } }
  }
  /** Live balance update without redrawing forms the user may be typing in. */
  function updateBalances(p) {
    for (const w of st.wallet.wallets) { const b = p.querySelector(`[data-bal="${w.currency}"]`); if (b) b.textContent = fmtMinor(w.available, w.currency); }
  }

  function draw() {
    const tabs = [...TABS, ...(st.owner ? ['admin'] : [])];
    body.innerHTML = `<div class="bank-banner ${st.info.mode === 'sandbox' ? 'is-sandbox' : 'is-live'}">${icons.info}<span>${esc(T(st.info.mode === 'sandbox' ? 'bannerSandbox' : 'bannerLive'))}</span>
        <span class="bank-tools"><button class="btn btn-sm btn-ghost bank-bell" data-bell title="${esc(T('nt.centre'))}" aria-label="${esc(T('nt.centre'))}">${icons.bell}<b data-unread hidden></b></button>
        ${voiceSupported() ? `<button class="btn btn-sm btn-ghost" data-mic title="${esc(T('vo.title'))}" aria-label="${esc(T('vo.title'))}">${icons.mic}</button>` : ''}</span></div>
      ${st.info.frozen ? `<div class="alert alert-error">${icons.lock}<div>${esc(T('sec.frozenBanner'))}</div></div>` : ''}
      <p class="bank-voice muted" data-voice hidden aria-live="polite"></p>
      <nav class="radar-tabs hub-tabs bank-tabs card" data-n="${tabs.length}">${tabs.map((x) => `<a href="#" data-tab="${x}" class="${x === st.tab ? 'is-on' : ''}"><span>${esc(T(`tab.${x}`))}</span></a>`).join('')}</nav>
      <div class="bank-pane" data-pane></div>`;
    body.querySelector('nav').addEventListener('click', (e) => { const a = e.target.closest('[data-tab]'); if (!a) return; e.preventDefault(); B.go(a.dataset.tab); });
    body.querySelector('[data-bell]').addEventListener('click', () => { st.tab = 'notifications'; body.querySelectorAll('[data-tab]').forEach((x) => x.classList.remove('is-on')); paint(); });
    body.querySelector('[data-mic]')?.addEventListener('click', voice);
    B.setUnread(st.unread);
    paint();
  }
  const pane = () => body.querySelector('[data-pane]');
  function paint() {
    const p = pane(); if (!p) return;
    const map = { wallet: walletTab, deposit, withdraw, cards: cardsTab, invest, money: moneyTab, insights: insightsTab, rewards: rewardsTab, security: securityTab, support: supportTab, identity, admin, notifications: notificationsPane };
    B.histReload = null;
    (map[st.tab] || walletTab)(p, B);
  }

  /* ───────── voice ───────── */
  let voiceWarned = false;
  function voice() {
    const out = body.querySelector('[data-voice]'); out.hidden = false;
    if (!voiceWarned) { voiceWarned = true; toast(T('vo.privacy'), 'info'); }
    out.textContent = T('vo.listening');
    listenOnce(getLang(), async (text) => {
      const c = parseCommand(text); out.textContent = `“${text}”`;
      if (c.intent === 'balance') { out.textContent = `“${text}” → ${st.wallet.wallets.filter((w) => w.available).map((w) => `${fmtMinor(w.available, w.currency)} ${w.currency}`).join(' · ') || '0'}`; return; }
      if (c.intent === 'spending') {
        const b = await bankApi.budgets().catch(() => null); const v = b ? (c.category ? b.spent[c.category] || 0 : Object.values(b.spent).reduce((s, x) => s + x, 0)) : 0;
        out.textContent = `“${text}” → ${T('vo.spent', { c: c.category ? Tx(`cat.${c.category}`, c.category) : T('vo.all'), a: `${fmtMinor(v, 'USD')} USD` })}`; return;
      }
      if (c.intent === 'open') { B.go(c.tab); return; }
      if (c.intent === 'freeze') { if (window.confirm(T('sec.confirmFreeze')) && await act(null, () => bankApi.freeze({ on: true }), T('sec.frozen'))) { await B.refreshStatus(); draw(); } return; }
      if (c.intent === 'pocket_in') {
        const ps = await bankApi.pockets().catch(() => ({ items: [] }));
        const pk = ps.items.find((x) => normName(x.name) === normName(c.pocket)) || ps.items.find((x) => normName(x.name).includes(normName(c.pocket)));
        if (!pk) { out.textContent = `“${text}” → ${T('vo.noPocket', { n: c.pocket })}`; return; }
        if (window.confirm(T('vo.confirmMove', { a: c.amount, c: pk.currency, n: pk.name }))) await act(null, () => bankApi.movePocket({ pocketId: pk.id, direction: 'in', amount: c.amount }), T('pk.moved'));
        return;
      }
      out.textContent = `“${text}” → ${T('vo.unknown')}`;
    }, (code) => { out.textContent = Tx(`err.${code}`, T('err.unknown')); });
  }

  /* ───────── deposit ───────── */
  async function deposit(p) {
    p.innerHTML = `<form class="card bank-form" data-dep>${field(T('currency'), `<select class="select" name="currency">${opts(CURS)}</select>`)}
      <span data-net></span>${field(T('amount'), input('amount', { mono: true, ph: '500', req: true, mode: 'decimal' }))}
      <button class="btn btn-sm btn-primary" type="submit">${icons.download}<span>${esc(T('requestDeposit'))}</span></button></form>
      <p class="muted tool-note">${esc(T(st.info.mode === 'sandbox' ? 'depSandboxNote' : 'depLiveNote'))}</p><div data-deplist></div>`;
    const form = p.querySelector('[data-dep]');
    const net = () => { const c = CURRENCIES[form.currency.value]; p.querySelector('[data-net]').innerHTML = c.kind === 'crypto' ? field(T('network'), `<select class="select" name="network">${opts(c.networks)}</select>`) : ''; };
    form.currency.addEventListener('change', net); net();
    const list = async () => {
      const r = await bankApi.deposits().catch(() => ({ items: [] }));
      p.querySelector('[data-deplist]').innerHTML = r.items.length ? `<div class="table-scroll"><table class="kv-table"><thead><tr><th>${esc(T('when'))}</th><th>${esc(T('amount'))}</th><th>${esc(T('reference'))}</th><th>${esc(T('status'))}</th></tr></thead><tbody>${r.items.map((d) => `<tr><td class="mono">${esc(dateStr(d.createdAt))}</td><td class="mono">${fmtMinor(d.amount, d.currency)} ${d.currency}</td><td class="mono">${esc(d.reference)}${d.instructions === 'not_configured' ? `<br><small class="muted">${esc(T('noDetails'))}</small>` : d.instructions && d.instructions !== 'sandbox' ? `<br><small class="muted">${esc(d.instructions)}</small>` : ''}</td><td>${badge(d.status)}</td></tr>`).join('')}</tbody></table></div>` : '';
    };
    list();
    form.addEventListener('submit', async (e) => { e.preventDefault(); const f = fd(form); if (await act(form.querySelector('button'), () => bankApi.requestDeposit({ currency: f.currency, amount: f.amount, network: f.network }), T('depRequested'))) { form.amount.value = ''; list(); } });
  }

  /* ───────── withdraw (+ cross-border) ───────── */
  async function withdraw(p) {
    if (st.wallet.kyc.tier < 1) { p.innerHTML = `<div class="card sig-empty">${icons.shield}<span>${esc(T('needKyc'))}</span></div>`; return; }
    const [bens, wds] = await Promise.all([bankApi.beneficiaries().catch(() => ({ items: [] })), bankApi.withdrawals().catch(() => ({ items: [] }))]);
    if (!alive || st.tab !== 'withdraw') return;
    const fiat = bens.items.filter((b) => CURRENCIES[b.currency].kind === 'fiat');
    p.innerHTML = `<article class="card tool-card"><h2 class="card-title">${icons.plus}<span>${esc(T('addBeneficiary'))}</span></h2>
      <form class="bank-form" data-ben>${field(T('currency'), `<select class="select" name="currency">${opts(CURS)}</select>`)}${field(T('label'), input('label', { max: 40, req: true }))}
        <span data-benfields class="bank-sub"></span><button class="btn btn-sm btn-primary" type="submit">${icons.check}<span>${esc(T('save'))}</span></button></form>
      <p class="muted tool-note">${esc(T('coolingNote'))}</p>
      ${bens.items.length ? `<ul class="bank-list">${bens.items.map((b) => `<li><b>${esc(b.label)}</b> <span class="muted mono">${esc(b.currency)} · …${esc(b.last4)}</span> ${b.usableAfter > Date.now() ? `<small class="muted">${esc(T('usableAfter', { t: dateStr(b.usableAfter) }))}</small>` : ''}<button class="btn btn-sm btn-ghost" data-delben="${esc(b.id)}">${icons.trash}</button></li>`).join('')}</ul>` : ''}</article>
      <article class="card tool-card"><h2 class="card-title">${icons.bolt}<span>${esc(T('withdrawTitle'))}</span></h2>
      <form class="bank-form" data-wd>${field(T('beneficiary'), `<select class="select" name="beneficiaryId">${bens.items.map((b) => `<option value="${esc(b.id)}" data-cur="${b.currency}">${esc(b.label)} (${b.currency} …${esc(b.last4)})</option>`).join('')}</select>`)}
        ${field(T('amount'), input('amount', { mono: true, ph: '100', req: true, mode: 'decimal' }))}<button class="btn btn-sm btn-primary" type="submit" ${bens.items.length ? '' : 'disabled'}>${icons.send}<span>${esc(T('requestWithdraw'))}</span></button></form>
      <p class="muted tool-note">${esc(T('wdNote'))}</p>
      ${wds.items.length ? `<div class="table-scroll"><table class="kv-table"><thead><tr><th>${esc(T('when'))}</th><th>${esc(T('amount'))}</th><th>${esc(T('fee'))}</th><th>${esc(T('status'))}</th><th></th></tr></thead><tbody>${wds.items.map((w) => `<tr><td class="mono">${esc(dateStr(w.createdAt))}</td><td class="mono">${fmtMinor(w.amount, w.currency)} ${w.currency}${w.intl ? `<br><small class="muted">→ ${fmtMinor(w.intl.receive, w.intl.to)} ${esc(w.intl.to)}</small>` : ''}</td><td class="mono">${fmtMinor(w.fee, w.currency)}</td><td>${badge(w.status)}${w.note ? `<br><small class="muted">${esc(Tx(`note.${w.note}`, w.note))}</small>` : ''}</td><td>${['requested', 'awaiting_approvals'].includes(w.status) ? `<button class="btn btn-sm btn-ghost" data-cancelwd="${esc(w.id)}">${esc(T('cancel'))}</button>` : ''}</td></tr>`).join('')}</tbody></table></div>` : ''}</article>
      ${card(T('ix.title'), icons.globe2, fiat.length ? `<form class="bank-form" data-ix>${field(T('ix.from'), `<select class="select" name="from">${opts(['USD', 'EUR', 'USDT'], 'USD')}</select>`)}${field(T('amount'), input('amount', { mono: true, req: true, mode: 'decimal', ph: '200' }))}
          ${field(T('ix.to'), `<select class="select" name="beneficiaryId">${fiat.map((b) => `<option value="${esc(b.id)}">${esc(b.label)} (${b.currency})</option>`).join('')}</select>`)}
          <button class="btn btn-sm" type="submit">${icons.refresh}<span>${esc(T('ix.quote'))}</span></button></form><div data-quote aria-live="polite"></div><p class="muted tool-note">${esc(T(st.info.mode === 'sandbox' ? 'ix.noteSandbox' : 'ix.noteLive'))}</p>` : empty(T('ix.needBen')))}`;
    const bf = p.querySelector('[data-ben]');
    const fields = () => { const c = CURRENCIES[bf.currency.value]; p.querySelector('[data-benfields]').innerHTML = c.kind === 'fiat'
      ? `${field('IBAN', input('iban', { mono: true, dir: 'ltr', max: 40, req: true }), true)}${field(T('holder'), input('holder', { max: 70, req: true }))}`
      : `${field(T('network'), `<select class="select" name="network">${opts(c.networks)}</select>`)}${field(T('address'), input('address', { mono: true, dir: 'ltr', max: 100, req: true }), true)}${field(T('memo'), input('memo', { max: 40 }))}`; };
    bf.currency.addEventListener('change', fields); fields();
    bf.addEventListener('submit', async (e) => { e.preventDefault(); const f = fd(bf); if (await act(bf.querySelector('button'), () => secure('beneficiary_add', f, (passkey) => bankApi.addBeneficiary({ ...f, passkey })), T('benSaved'))) { bf.reset(); withdraw(p); } });
    p.querySelectorAll('[data-delben]').forEach((b) => b.addEventListener('click', async () => { if (!window.confirm(T('confirmDel'))) return; const id = b.dataset.delben; if (await act(b, () => secure('beneficiary_remove', { id }, (passkey) => bankApi.removeBeneficiary(id, { passkey })))) withdraw(p); }));
    p.querySelectorAll('[data-cancelwd]').forEach((b) => b.addEventListener('click', async () => { if (await act(b, () => bankApi.cancelWithdrawal(b.dataset.cancelwd), T('cancelled'))) withdraw(p); }));
    const wf = p.querySelector('[data-wd]');
    wf.addEventListener('submit', async (e) => {
      e.preventDefault(); const f = fd(wf); const cur = wf.beneficiaryId.selectedOptions[0]?.dataset.cur; if (!cur) return;
      if (!window.confirm(T('confirmWd', { a: f.amount, c: cur }))) return;
      const b = { beneficiaryId: f.beneficiaryId, currency: cur, amount: f.amount };
      if (await act(wf.querySelector('button'), () => secure('withdraw', b, (passkey) => bankApi.withdraw({ ...b, passkey })), T('wdRequested'))) withdraw(p);
    });
    const ix = p.querySelector('[data-ix]');
    ix?.addEventListener('submit', async (e) => {
      e.preventDefault(); const v = fd(ix); const out = p.querySelector('[data-quote]');
      const q = await act(ix.querySelector('button'), () => bankApi.intlQuote(v)); if (!q || !q.id) return;
      let left = Math.max(0, Math.round((q.expiresAt - Date.now()) / 1000));
      out.innerHTML = `<div class="bank-quote"><p>${esc(T('ix.send'))}: ${amt(q.amount, q.from)} + ${esc(T('fee'))} ${amt(q.fee, q.from)}</p><p>${esc(T('ix.receive'))}: <b>${amt(q.receive, q.to)}</b> <small class="muted">${esc(T('ix.rate'))} ${q.rate.toFixed(4)}</small></p>
        <button class="btn btn-sm btn-primary" data-ixok>${icons.send}<span>${esc(T('ix.confirm'))}</span></button> <small class="muted" data-left>${esc(T('ix.valid', { s: left }))}</small></div>`;
      const tick = setInterval(() => { left -= 1; const l = out.querySelector('[data-left]'); if (!l || left <= 0) { clearInterval(tick); if (l) { l.textContent = T('ix.expired'); out.querySelector('[data-ixok]')?.setAttribute('disabled', ''); } return; } l.textContent = T('ix.valid', { s: left }); }, 1000);
      out.querySelector('[data-ixok]').addEventListener('click', async (ev) => {
        clearInterval(tick);
        if (await act(ev.currentTarget, () => secure('intl_transfer', { quoteId: q.id }, (passkey) => bankApi.intlConfirm({ quoteId: q.id, passkey })), T('ix.done'))) withdraw(p);
      });
    });
  }

  /* ───────── identity (KYC) ───────── */
  async function identity(p) {
    const k = await bankApi.kyc().catch(() => st.wallet.kyc); if (!alive || st.tab !== 'identity') return;
    const addr = (pre = '') => `${field(T('country'), input(`${pre}country`, { max: 2, ph: 'DE', req: true }))}${field(T('region'), input(`${pre}region`, { max: 60 }))}${field(T('city'), input(`${pre}city`, { max: 60, req: true }))}${field(T('postal'), input(`${pre}postal`, { max: 12, req: true }))}${field(T('line1'), input(`${pre}line1`, { max: 80, req: true }), true)}${field(T('line2'), input(`${pre}line2`, { max: 80 }), true)}`;
    p.innerHTML = `<article class="card tool-card"><div class="tool-head"><h2 class="card-title">${icons.shield}<span>${esc(T('kycTitle'))}</span></h2>${badge(k.status === 'approved' ? 'approved' : k.status === 'none' ? 'requested' : k.status)}</div>
      <p class="muted">${esc(T('kycTier', { n: k.tier }))}${k.status === 'rejected' && k.reason ? ` · ${esc(T('rejectedWhy', { r: k.reason }))}` : ''}</p>
      ${k.status === 'pending' ? `<p>${esc(T('kycPending'))}</p>` : `<form class="bank-form" data-kyc>
        ${field(T('targetTier'), `<select class="select" name="tier"><option value="1">${esc(T('tier1'))}</option><option value="2" ${k.tier >= 1 ? 'selected' : ''}>${esc(T('tier2'))}</option></select>`)}
        ${field(T('fullName'), input('fullName', { max: 80, req: true }))}${field(T('dob'), input('dob', { type: 'date', req: true }))}${field(T('nationality'), input('nationality', { max: 2, ph: 'DE', req: true }))}
        ${field(T('idType'), `<select class="select" name="idType">${opts(['passport', 'national_id', 'driver_license'], 'passport', (x) => T(`idt.${x}`))}</select>`)}${field(T('idNumber'), input('idNumber', { max: 30, req: true }))}${field(T('idExpiry'), input('idExpiry', { type: 'date', req: true }))}
        <h3 class="bank-h">${esc(T('residence'))}</h3>${addr('a_')}
        <span data-t2 hidden class="bank-sub"><h3 class="bank-h">${esc(T('tier2Extra'))}</h3>${field(T('sourceOfFunds'), `<select class="select" name="sourceOfFunds">${opts(['salary', 'business', 'savings', 'investments', 'other'], 'salary', (x) => T(`sof.${x}`))}</select>`)}${field(T('proofRef'), input('proofOfAddressRef', { max: 80 }))}</span>
        <button class="btn btn-sm btn-primary" type="submit">${icons.check}<span>${esc(T('submitKyc'))}</span></button></form>
        <p class="muted tool-note">${esc(T('kycNote'))}</p>`}</article>`;
    const f = p.querySelector('[data-kyc]'); if (!f) return;
    const sync = () => { p.querySelector('[data-t2]').hidden = f.tier.value !== '2'; }; f.tier.addEventListener('change', sync); sync();
    f.addEventListener('submit', async (e) => {
      e.preventDefault(); const v = fd(f);
      const a = { country: v.a_country, region: v.a_region || '-', city: v.a_city, postal: v.a_postal, line1: v.a_line1, line2: v.a_line2 };
      const payload = { tier: Number(v.tier), fullName: v.fullName, dob: v.dob, nationality: v.nationality, address: a, idType: v.idType, idNumber: v.idNumber, idExpiry: v.idExpiry, ...(v.tier === '2' ? { sourceOfFunds: v.sourceOfFunds, proofOfAddressRef: v.proofOfAddressRef } : {}) };
      const ok = await act(f.querySelector('button'), () => bankApi.submitKyc(payload), T('kycSent')); f.reset(); if (ok) identity(p);
    });
  }

  /* ───────── invest: plans, holdings (sell), orders, tax report ───────── */
  async function invest(p) {
    const [plans, orders, hold] = await Promise.all([bankApi.plans().catch(() => ({ items: [] })), bankApi.orders().catch(() => ({ items: [] })), bankApi.holdings().catch(() => ({ items: [] }))]);
    if (!alive || st.tab !== 'invest') return;
    const year = new Date().getFullYear();
    p.innerHTML = `<div class="bank-banner is-sandbox">${icons.info}<span>${esc(T(st.info.mode === 'sandbox' ? 'investSandbox' : 'investLive'))}</span></div>
      <article class="card tool-card"><h2 class="card-title">${icons.bulb}<span>${esc(T('planNew'))}</span></h2>
      <form class="bank-form" data-plan>${field(T('asset'), `<select class="select" name="asset">${opts(['BTC', 'ETH', 'SOL', 'BNB'])}</select>`)}${field(`${T('amount')} (USDT)`, input('amount', { mono: true, ph: '20', req: true, mode: 'decimal' }))}
        ${field(T('every'), `<select class="select" name="every">${opts(['daily', 'weekly', 'monthly'], 'weekly', (x) => T(`ev.${x}`))}</select>`)}${field(`${T('dailyCap')} (USDT)`, input('dailyCap', { mono: true, ph: '500', mode: 'decimal' }))}
        <button class="btn btn-sm btn-primary" type="submit">${icons.check}<span>${esc(T('createPlan'))}</span></button></form>
      <p class="muted tool-note">${esc(T('investNote'))}</p></article>
      ${plans.items.length ? `<article class="card tool-card"><h2 class="card-title">${icons.refresh}<span>${esc(T('plans'))}</span></h2><div class="table-scroll"><table class="kv-table"><tbody>${plans.items.map((x) => `<tr><td><b>${esc(x.asset)}</b></td><td class="mono">${fmtMinor(x.amount, 'USDT')} USDT · ${esc(T(`ev.${x.every}`))}</td><td>${badge(x.status === 'paused' ? 'cancelled' : 'active')}</td><td class="muted mono">${esc(dateStr(x.nextRun))}</td><td>${x.status === 'active' ? `<button class="btn btn-sm" data-pa="pause" data-id="${esc(x.id)}">${esc(T('pause'))}</button>` : `<button class="btn btn-sm" data-pa="resume" data-id="${esc(x.id)}">${esc(T('resume'))}</button>`} <button class="btn btn-sm btn-ghost" data-pa="delete" data-id="${esc(x.id)}">${icons.trash}</button></td></tr>`).join('')}</tbody></table></div></article>` : ''}
      ${hold.items.length ? `<article class="card tool-card"><h2 class="card-title">${icons.layers}<span>${esc(T('holdings'))} (${esc(T(hold.mode === 'sandbox' ? 'paperTag' : 'brokerTag'))})</span></h2><ul class="bank-list">${hold.items.map((h) => `<li><b>${esc(h.asset)}</b> <span class="mono">${(h.qty / 1e8).toFixed(8)}</span> <span class="muted">${esc(T('cost'))}: ${fmtMinor(h.cost, 'USDT')} USDT</span>
          <form class="bank-inline-form" data-sell="${esc(h.asset)}"><input class="input mono" name="qty" placeholder="${esc(T('iv.qty'))}" inputmode="decimal" size="10"/><button class="btn btn-sm" type="submit">${esc(T('iv.sell'))}</button><button class="btn btn-sm btn-ghost" type="button" data-sellall>${esc(T('iv.sellAll'))}</button></form></li>`).join('')}</ul></article>` : ''}
      ${orders.items.length ? `<article class="card tool-card"><h2 class="card-title">${icons.journal}<span>${esc(T('orders'))}</span></h2><div class="table-scroll"><table class="kv-table"><tbody>${orders.items.map((o) => `<tr><td class="mono">${esc(dateStr(o.created_at))}</td><td>${esc(o.asset)}</td><td class="mono">${fmtMinor(o.amount, 'USDT')}</td><td>${badge(o.status)}</td><td class="muted">${esc(o.reason ? Tx(`oreason.${o.reason}`, o.reason) : '')}</td></tr>`).join('')}</tbody></table></div></article>` : ''}
      ${card(T('tx2.title'), icons.calendar, `<form class="bank-form" data-tax>${field(T('tx2.year'), `<select class="select" name="year">${opts([String(year), String(year - 1), String(year - 2)], String(year))}</select>`)}<button class="btn btn-sm" type="submit">${icons.refresh}<span>${esc(T('tx2.show'))}</span></button><button class="btn btn-sm" type="button" data-csv>${icons.download}<span>CSV</span></button></form><div data-taxout></div><p class="muted tool-note">${esc(T('tx2.note'))}</p>`)}`;
    const f = p.querySelector('[data-plan]');
    f.addEventListener('submit', async (e) => { e.preventDefault(); const v = fd(f); if (await act(f.querySelector('button'), () => bankApi.createPlan({ asset: v.asset, amount: v.amount, every: v.every, ...(v.dailyCap ? { dailyCap: v.dailyCap } : {}) }), T('planCreated'))) invest(p); });
    p.querySelectorAll('[data-pa]').forEach((b) => b.addEventListener('click', async () => { if (b.dataset.pa === 'delete' && !window.confirm(T('confirmDel'))) return; if (await act(b, () => bankApi.planAction(b.dataset.id, b.dataset.pa))) invest(p); }));
    p.querySelectorAll('[data-sell]').forEach((sf) => {
      const asset = sf.dataset.sell;
      const go = async (btn, all) => { const qty = sf.qty.value; if (!all && !qty) return; if (!window.confirm(T('iv.confirm', { a: asset }))) return; if (await act(btn, () => bankApi.sell(all ? { asset, all: true } : { asset, qty }), T('iv.sold'))) invest(p); };
      sf.addEventListener('submit', (e) => { e.preventDefault(); go(sf.querySelector('[type=submit]'), false); });
      sf.querySelector('[data-sellall]').addEventListener('click', (e) => go(e.currentTarget, true));
    });
    const tf = p.querySelector('[data-tax]'); const tout = p.querySelector('[data-taxout]');
    tf.addEventListener('submit', async (e) => {
      e.preventDefault(); const r = await act(tf.querySelector('[type=submit]'), () => bankApi.tax(fd(tf).year)); if (!r?.sales) return;
      tout.innerHTML = `<p>${esc(T('tx2.gain'))}: <b class="mono ${r.realizedGainUsdt >= 0 ? 'up' : 'down'}">${fmtMinor(r.realizedGainUsdt, 'USDT')} USDT</b> · ${esc(T('tx2.method'))}: FIFO · ${esc(T('tx2.sales'))}: ${r.sales.length}${r.cashbackUsd ? ` · ${esc(T('tx2.cashback'))}: ${fmtMinor(r.cashbackUsd, 'USD')} USD` : ''}</p>
        ${r.sales.length ? `<div class="table-scroll"><table class="kv-table bank-small"><thead><tr><th>${esc(T('asset'))}</th><th>${esc(T('iv.qty'))}</th><th>${esc(T('tx2.proceeds'))}</th><th>${esc(T('tx2.basis'))}</th><th>${esc(T('tx2.gainCol'))}</th></tr></thead><tbody>${r.sales.map((s) => `<tr><td>${esc(s.asset)}</td><td class="mono">${(s.qty / 1e8).toFixed(8)}</td><td class="mono">${fmtMinor(s.proceeds, 'USDT')}</td><td class="mono">${fmtMinor(s.costBasis, 'USDT')}</td><td class="mono ${s.gain >= 0 ? 'up' : 'down'}">${fmtMinor(s.gain, 'USDT')}</td></tr>`).join('')}</tbody></table></div>` : ''}
        ${r.fees.length ? `<p class="muted">${esc(T('tx2.fees'))}: ${r.fees.map((x) => `${fmtMinor(x.amount, x.currency)} ${x.currency}`).join(' · ')}</p>` : ''}`;
    });
    p.querySelector('[data-csv]').addEventListener('click', (e) => act(e.currentTarget, () => downloadTaxCsv(fd(tf).year)));
  }

  /* ───────── owner's desk ───────── */
  async function admin(p) {
    let q; let d; let tk; let rk = { items: [] }; let cr = { items: [] };
    try { [q, d, tk, rk, cr] = await Promise.all([bankApi.admin.queue(), bankApi.admin.dashboard().catch(() => null), bankApi.admin.tickets().catch(() => ({ items: [] })), bankApi.admin.risk().catch(() => ({ items: [] })), bankApi.admin.compliance().catch(() => ({ items: [] }))]); } catch (e) { p.innerHTML = `<div class="alert alert-error">${icons.alert}<div>${esc(errText(e))}</div></div>`; return; }
    if (!alive || st.tab !== 'admin') return;
    const short = (u) => esc(String(u).slice(0, 10));
    p.innerHTML = `<article class="card tool-card"><div class="tool-head"><h2 class="card-title">${icons.shield}<span>${esc(T('integrity'))}</span></h2><span class="badge ${q.ledger.ok && q.audit.ok ? 'badge-live' : 'badge-error'}">${esc(q.ledger.ok && q.audit.ok ? T('intact') : T('broken'))}</span></div>
        <p class="muted mono">${esc(T('auditRows', { n: q.audit.rows ?? '?' }))}</p>
        ${d ? `<div class="bank-kpis"><div><span class="muted">${esc(T('ad.users'))}</span><b class="mono">${d.users}</b></div><div><span class="muted">${esc(T('ad.pending'))}</span><b class="mono">${d.pending.deposits + d.pending.withdrawals + d.pending.kyc}</b></div>
          <div><span class="muted">${esc(T('ad.cosign'))}</span><b class="mono">${d.pending.awaitingCosigners}</b></div><div><span class="muted">${esc(T('ad.tickets'))}</span><b class="mono">${d.pending.tickets}</b></div>
          <div><span class="muted">${esc(T('ad.cards30'))}</span><b class="mono">${d.last30.cards.reduce((s, x) => s + x.n, 0)}</b></div><div><span class="muted">${esc(T('ad.declines'))}</span><b class="mono">${d.declines.reduce((s, x) => s + x.c, 0)}</b></div></div>
          <p class="muted">${esc(T('ad.fees'))}: ${d.feesCollected.filter((x) => x.amount).map((x) => `${fmtMinor(x.amount, x.currency)} ${x.currency}`).join(' · ') || '—'}${d.flags.length ? ` · ${esc(T('ad.flags'))}: ${d.flags.map((x) => `${esc(Tx(`flag.${x.flag}`, x.flag))} ${x.c}`).join(', ')}` : ''}</p>` : ''}</article>
      <article class="card tool-card"><h2 class="card-title">${icons.download}<span>${esc(T('adm.deposits'))} (${q.deposits.length})</span></h2>${q.deposits.map((dp) => `<form class="bank-row" data-adep="${esc(dp.id)}"><span class="mono">${short(dp.uid)}… ${fmtMinor(dp.amount, dp.currency)} ${dp.currency} · ${esc(dp.reference)}</span>${input('extRef', { mono: true, ph: T('adm.extRef'), max: 100, req: true })}<button class="btn btn-sm btn-primary" data-do="confirm">${esc(T('adm.confirm'))}</button><button class="btn btn-sm btn-ghost" type="button" data-do="reject">${esc(T('adm.reject'))}</button></form>`).join('') || `<p class="muted">—</p>`}</article>
      <article class="card tool-card"><h2 class="card-title">${icons.send}<span>${esc(T('adm.withdrawals'))} (${q.withdrawals.length})</span></h2>${q.withdrawals.map((w) => `<form class="bank-row" data-awd="${esc(w.id)}"><span class="mono">${short(w.uid)}… ${fmtMinor(w.amount, w.currency)} ${w.currency} ${badge(w.status)} ${w.flags.map((f) => `<span class="badge badge-demo">${esc(Tx(`flag.${f}`, f))}</span>`).join(' ')}</span>
        ${w.status === 'requested' ? `<button class="btn btn-sm btn-primary" type="button" data-do="approve">${esc(T('adm.approve'))}</button><button class="btn btn-sm btn-ghost" type="button" data-do="reject">${esc(T('adm.reject'))}</button>` : `<button class="btn btn-sm" type="button" data-do="dest">${esc(T('adm.destination'))}</button>${input('extRef', { mono: true, ph: T('adm.payoutRef'), max: 100 })}<button class="btn btn-sm btn-primary" type="button" data-do="complete">${esc(T('adm.complete'))}</button>`}<pre class="mono bank-dest" data-out hidden></pre></form>`).join('') || `<p class="muted">—</p>`}</article>
      <article class="card tool-card"><h2 class="card-title">${icons.user}<span>${esc(T('adm.kyc'))} (${q.kyc.length})</span></h2>${q.kyc.map((k) => `<form class="bank-row" data-akyc="${esc(k.uid)}"><span class="mono">${short(k.uid)}… → ${esc(T('kycTier', { n: k.requested_tier }))}</span><button class="btn btn-sm" type="button" data-do="view">${esc(T('adm.view'))}</button><button class="btn btn-sm btn-primary" type="button" data-do="approve">${esc(T('adm.approve'))}</button><button class="btn btn-sm btn-ghost" type="button" data-do="reject">${esc(T('adm.reject'))}</button><pre class="mono bank-dest" data-out hidden></pre></form>`).join('') || `<p class="muted">—</p>`}</article>
      <article class="card tool-card"><h2 class="card-title">${icons.wallet}<span>${esc(T('adm.cards'))} (${q.cards.length})</span></h2>${q.cards.map((c) => `<form class="bank-row" data-acard="${esc(c.id)}"><span class="mono">${short(c.uid)}… ${esc(c.product)} ${esc(c.city || '')} ${badge(c.status)}</span><button class="btn btn-sm" type="button" data-do="view">${esc(T('adm.view'))}</button>
        <select class="select" name="status">${opts(({ requested: ['review', 'rejected'], review: ['sent_to_issuer', 'rejected'], sent_to_issuer: ['produced'], produced: ['shipped'], shipped: ['delivered'], delivered: ['active'] })[c.status] || [], '', (x) => T(`st.${x}`))}</select>${input('tracking', { mono: true, ph: T('tracking'), max: 40 })}<button class="btn btn-sm btn-primary" type="button" data-do="update">${esc(T('adm.update'))}</button><pre class="mono bank-dest" data-out hidden></pre></form>`).join('') || `<p class="muted">—</p>`}</article>
      <article class="card tool-card"><h2 class="card-title">${icons.chat}<span>${esc(T('ad.ticketsTitle'))} (${tk.items.length})</span></h2>${tk.items.map((x) => `<div class="bank-row" data-atk="${esc(x.id)}"><span class="mono">${esc(x.user)}… ${esc(T(`su.t.${x.topic}`))}</span> ${badge(x.status)} <small class="muted">${esc(dateStr(x.updatedAt))}</small><button class="btn btn-sm" type="button" data-do="open">${esc(T('adm.view'))}</button><div class="bank-thread" data-tout hidden></div></div>`).join('') || `<p class="muted">—</p>`}</article>`;
    p.insertAdjacentHTML('beforeend', `<article class="card tool-card" data-risk-card><h2 class="card-title">${icons.shield}<span>${esc(T('rc.risk'))} (${rk.items.length})</span></h2>
      ${rk.items.length ? rk.items.map((x) => `<div class="bank-row"><span class="mono">${short(x.uid)}…</span> ${badge(x.level === 'block' ? 'rejected' : 'pending')} <b class="mono">${x.score}</b> <small class="muted">${esc(x.kind)} · ${x.reasons.map((r) => esc(Tx(`rc.why.${r.why}`, r.why))).join(', ')}</small> <button class="btn btn-sm" data-risk-ok="${esc(x.id)}">${esc(T('rc.reviewed'))}</button></div>`).join('') : empty(T('rc.none'))}</article>
      <article class="card tool-card"><h2 class="card-title">${icons.download}<span>${esc(T('rc.reports'))}</span></h2><p class="muted tool-note">${esc(T('rc.note'))}</p>
      ${cr.items.length ? cr.items.slice(0, 12).map((x) => `<div class="bank-row"><b class="mono">${esc(x.period)}</b> <button class="btn btn-sm" data-cr-csv="${esc(x.id)}" data-cr-name="${esc(x.period)}">CSV</button></div>`).join('') : empty(T('rc.noReports'))}</article>`);
    p.querySelectorAll('[data-risk-ok]').forEach((b) => b.addEventListener('click', () => act(b, () => bankApi.admin.riskReview(b.dataset.riskOk, 'ok'), T('adm.done')).then((r) => { if (r) admin(p); })));
    p.querySelectorAll('[data-cr-csv]').forEach((b) => b.addEventListener('click', () => act(b, () => downloadComplianceCsv(b.dataset.crCsv, b.dataset.crName))));
    const run = (btn, fn, ok) => act(btn, async () => { await fn(); }, ok).then((r) => { if (r) admin(p); });
    const show = (form, data) => { const o = form.querySelector('[data-out]'); o.hidden = false; o.textContent = JSON.stringify(data, null, 2); };
    p.querySelectorAll('[data-adep]').forEach((f) => f.addEventListener('click', (e) => { const b = e.target.closest('[data-do]'); if (!b) return; e.preventDefault(); const id = f.dataset.adep;
      if (b.dataset.do === 'confirm') { if (!f.extRef.value.trim()) return; run(b, () => bankApi.admin.deposit(id, 'confirm', { extRef: f.extRef.value.trim() }), T('adm.done')); } else run(b, () => bankApi.admin.deposit(id, 'reject', { reason: 'rejected' }), T('adm.done')); }));
    p.querySelectorAll('[data-awd]').forEach((f) => f.addEventListener('click', async (e) => { const b = e.target.closest('[data-do]'); if (!b) return; e.preventDefault(); const id = f.dataset.awd; const dd = b.dataset.do;
      if (dd === 'dest') { act(b, async () => show(f, await bankApi.admin.destination(id))); return; }
      if (dd === 'complete') { if (!f.extRef.value.trim()) return; run(b, () => bankApi.admin.withdrawal(id, 'complete', { extRef: f.extRef.value.trim() }), T('adm.done')); return; }
      run(b, () => bankApi.admin.withdrawal(id, dd, { note: dd === 'reject' ? 'rejected' : '' }), T('adm.done')); }));
    p.querySelectorAll('[data-akyc]').forEach((f) => f.addEventListener('click', (e) => { const b = e.target.closest('[data-do]'); if (!b) return; e.preventDefault(); const uid = f.dataset.akyc;
      if (b.dataset.do === 'view') act(b, async () => show(f, await bankApi.admin.kycDetail(uid))); else run(b, () => bankApi.admin.kycReview(uid, b.dataset.do, { reason: b.dataset.do === 'reject' ? 'rejected' : '' }), T('adm.done')); }));
    p.querySelectorAll('[data-acard]').forEach((f) => f.addEventListener('click', (e) => { const b = e.target.closest('[data-do]'); if (!b) return; e.preventDefault(); const id = f.dataset.acard;
      if (b.dataset.do === 'view') act(b, async () => show(f, await bankApi.admin.card(id))); else if (f.status.value) run(b, () => bankApi.admin.cardUpdate(id, { status: f.status.value, tracking: f.tracking.value.trim() || undefined }), T('adm.done')); }));
    p.querySelectorAll('[data-atk]').forEach((row) => row.querySelector('[data-do=open]').addEventListener('click', async (e) => {
      const id = row.dataset.atk; const t = await act(e.currentTarget, () => bankApi.admin.ticket(id)); if (!t?.messages) return;
      const out = row.querySelector('[data-tout]'); out.hidden = false;
      out.innerHTML = `<h3 class="bank-h">${esc(t.subject || '')}</h3>${t.messages.map((m) => `<div class="bank-msg is-${esc(m.author)}"><small class="muted">${esc(T(`su.a.${m.author}`))} · ${esc(dateStr(m.at))}</small><p>${esc(m.body || '')}</p></div>`).join('')}
        <form class="bank-form" data-arep><label class="tf-field tf-wide"><span>${esc(T('su.reply'))}</span><textarea class="input" name="body" rows="3" maxlength="2000" required></textarea></label><label class="bank-check"><input type="checkbox" name="close"/> ${esc(T('ad.closeAfter'))}</label><button class="btn btn-sm btn-primary" type="submit">${icons.send}<span>${esc(T('su.send'))}</span></button></form>`;
      out.querySelector('[data-arep]').addEventListener('submit', (ev) => { ev.preventDefault(); const v = fd(ev.target); run(ev.target.querySelector('button'), () => bankApi.admin.replyTicket(id, { body: v.body, close: Boolean(v.close) }), T('adm.done')); });
    }));
  }

  boot().catch(() => {});
  return el;
}
