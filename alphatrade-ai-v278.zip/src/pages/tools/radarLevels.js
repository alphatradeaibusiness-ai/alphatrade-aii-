// Alpha Radar — automatic support & resistance: levels found from clustered swing points, scored
// by touches, bounces, recency, volume and role reversal; drawn live on the chart; cross-checked on
// other timeframes (confluence); one tap sets a price alert on a level.
import { esc, fmtNum, fmtPct } from '../../utils/dom.js';
import { alertSlotOk } from '../../components/gate.js';
import { icons } from '../../components/icons.js';
import { t } from '../../i18n/index.js';
import { storage } from '../../utils/storage.js';
import { store } from '../../state/store.js';
import { INSTRUMENTS, getInstrument } from '../../config/instruments.js';
import { getCandles, isUnavailable } from '../../services/market/index.js';
import { openLiveCandles } from '../../services/market/liveFeed.js';
import { ema } from '../../indicators/index.js';
import { supportResistance, confluence } from '../../indicators/levels.js';
import { addAlert } from '../../services/alerts.js';
import { createMiniChart } from '../../components/chart/miniChart.js';
import { onUnmount, dateStr, loading } from './common.js';

const yieldTask = () => new Promise((r) => setTimeout(r, 0));
import { toast } from '../../components/ui.js';

const TFS = ['15m', '1h', '4h', '1D'];
const stars = (n) => `<span class="stars" aria-label="${n}/5">${'★'.repeat(n)}<i>${'★'.repeat(5 - n)}</i></span>`;

export function mountLevels(page, body) {
  const list = INSTRUMENTS.filter((i) => !isUnavailable(i.symbol));
  const st = { symbol: store.get('symbol') || 'BTCUSDT', tf: '1h', ...storage.get('radar-levels', {}) };
  if (!list.some((i) => i.symbol === st.symbol)) st.symbol = list[0].symbol;
  body.innerHTML = `
    <div class="card perf-controls fade-in">
      <label class="perf-field"><span>${esc(t('tools.common.symbol'))}</span><select class="select" data-sym>${list.map((i) => `<option ${i.symbol === st.symbol ? 'selected' : ''}>${i.symbol}</option>`).join('')}</select></label>
      <div class="perf-field"><span>${esc(t('perf.timeframe'))}</span><div class="seg" data-tfs>${TFS.map((tf) => `<button type="button" data-v="${tf}" class="${tf === st.tf ? 'is-on' : ''}">${esc(t(`perf.tfShort.${tf}`))}</button>`).join('')}</div></div>
      <span class="ms-live lv-live"><i></i><span class="muted" data-upd></span></span>
    </div>
    <div class="lv-top"><article class="card lv-chart-card fade-in"><div class="lv-chart"></div></article>
      <article class="card tool-card fade-in lv-sum" data-sum>${loading()}</article></div>
    <article class="card tool-card fade-in"><h2 class="card-title">${icons.levels}<span>${esc(t('tools.levels.table'))}</span></h2><div data-table>${loading()}</div></article>
    <article class="card tool-card fade-in"><h2 class="card-title">${icons.info}<span>${esc(t('tools.levels.howTitle'))}</span></h2><ul class="tool-list">${t('tools.levels.how').map((x) => `<li>${esc(x)}</li>`).join('')}</ul></article>`;
  const $ = (s) => body.querySelector(s);
  const chart = createMiniChart($('.lv-chart'), { precision: getInstrument(st.symbol).precision });
  let candles = []; let ds = null; let feed = null; let token = 0; let sr = null; let others = {}; let lastCalc = 0;

  function render() {
    if (!sr) return;
    const inst = getInstrument(st.symbol);
    const p = (v) => fmtNum(v, inst.precision);
    const price = candles.at(-1).close;
    const lines = [];
    sr.supports.forEach((l, i) => lines.push({ price: l.price, color: `rgba(34,197,94,${0.4 + l.strength * 0.12})`, width: l.strength >= 4 ? 3 : l.strength >= 3 ? 2 : 1, style: l.strength >= 4 ? 0 : 2, title: `S${i + 1} ${'★'.repeat(l.strength)}` }));
    sr.resistances.forEach((l, i) => lines.push({ price: l.price, color: `rgba(240,68,79,${0.4 + l.strength * 0.12})`, width: l.strength >= 4 ? 3 : l.strength >= 3 ? 2 : 1, style: l.strength >= 4 ? 0 : 2, title: `R${i + 1} ${'★'.repeat(l.strength)}` }));
    chart.setLines(lines);
    const s1 = sr.supports[0]; const r1 = sr.resistances[0];
    const pos = s1 && r1 ? Math.max(0, Math.min(100, ((price - s1.price) / (r1.price - s1.price)) * 100)) : null;
    const near = [s1, r1].filter(Boolean).sort((a, b) => Math.abs(a.distPct) - Math.abs(b.distPct))[0];
    const nearAtr = near ? Math.abs(near.price - price) / sr.atr : null;
    $('[data-sum]').innerHTML = `<h2 class="card-title">${icons.crosshair}<span>${esc(t('tools.levels.now'))}</span></h2>
      <div class="lv-price"><b class="mono">${p(price)}</b><span class="muted">${esc(st.symbol)} · ${esc(t(`perf.tfShort.${st.tf}`))}</span></div>
      <div class="lv-range">
        <div class="lv-r down"><span>${esc(t('tools.levels.nearR'))}</span><b class="mono">${r1 ? p(r1.price) : '—'}</b><small>${r1 ? `<bdi>${fmtPct(r1.distPct)}</bdi> · ${stars(r1.strength)}` : ''}</small></div>
        <div class="lv-bar"><i style="bottom:${pos ?? 50}%"></i></div>
        <div class="lv-r up"><span>${esc(t('tools.levels.nearS'))}</span><b class="mono">${s1 ? p(s1.price) : '—'}</b><small>${s1 ? `<bdi>${fmtPct(s1.distPct)}</bdi> · ${stars(s1.strength)}` : ''}</small></div>
      </div>
      <p class="lv-note ${near && nearAtr < 0.6 ? (near.role === 'support' ? 'up' : 'down') : 'muted'}">${esc(near ? (nearAtr < 0.6 ? t(near.role === 'support' ? 'tools.levels.atSupport' : 'tools.levels.atResistance', { s: near.strength }) : t('tools.levels.between', { p: fmtNum(pos ?? 50, 0) })) : t('tools.levels.none'))}</p>`;
    const row = (l, i) => {
      const tfs = l.tfs || [st.tf];
      return `<tr class="lv-${l.role}"><td><span class="badge ${l.role === 'support' ? 'badge-live' : 'badge-error'}">${l.role === 'support' ? `S${i + 1}` : `R${i + 1}`}</span></td>
        <td class="mono"><b>${p(l.price)}</b></td><td>${stars(l.strength)}</td><td class="mono">${l.touches} <small class="muted">/ ${l.reactions}</small></td>
        <td class="mono"><bdi class="${l.distPct >= 0 ? 'down' : 'up'}">${fmtPct(l.distPct)}</bdi></td>
        <td class="muted">${esc(dateStr(l.lastTime * 1000, { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }))}</td>
        <td>${l.flip ? `<span class="badge badge-muted">${esc(t('tools.levels.flip'))}</span>` : ''}${tfs.length > 1 ? ` <span class="badge badge-live" title="${tfs.join(', ')}">${esc(t('tools.levels.mtf', { n: tfs.length }))}</span>` : ''}</td>
        <td><button type="button" class="btn btn-sm btn-ghost" data-alert="${l.price}" data-role="${l.role}">${icons.alarm}<span>${esc(t('tools.levels.alert'))}</span></button></td></tr>`;
    };
    $('[data-table]').innerHTML = `<div class="table-scroll"><table class="kv-table perf-table lv-table"><thead><tr><th></th><th>${esc(t('tools.risk.price'))}</th><th>${esc(t('tools.levels.strength'))}</th><th>${esc(t('tools.levels.touches'))}</th><th>${esc(t('tools.alerts.dist'))}</th><th>${esc(t('tools.levels.last'))}</th><th></th><th></th></tr></thead><tbody>
      ${sr.resistances.slice().reverse().map((l) => row(l, sr.resistances.indexOf(l))).join('')}
      <tr class="lv-now"><td colspan="8"><span>${esc(t('tools.levels.priceNow'))}</span> <b class="mono">${p(price)}</b></td></tr>
      ${sr.supports.map(row).join('')}</tbody></table></div>`;
  }

  function compute(force) {
    if (!force && Date.now() - lastCalc < 5000) return;
    lastCalc = Date.now();
    sr = supportResistance(candles);
    if (sr && Object.keys(others).length) confluence({ [st.tf]: sr, ...others });
    render();
    $('[data-upd]').textContent = t('tools.levels.updated', { time: dateStr(Date.now(), { hour: '2-digit', minute: '2-digit', second: '2-digit' }) });
  }

  async function loadOthers(my) {
    // Other timeframes for confluence (Twelve Data instruments: only one more, to save API credits).
    const inst = getInstrument(st.symbol);
    const tfs = TFS.filter((x) => x !== st.tf).slice(0, inst.provider === 'binance' ? 3 : 1);
    others = {};
    for (const tf of tfs) {
      try {
        const d = await getCandles(st.symbol, tf);
        await yieldTask();   // one timeframe per task: the page stays responsive while the levels are computed
        if (my !== token) return;
        if (d.mode === 'live') others[tf] = supportResistance(d.candles);
      } catch { /* skip */ }
    }
    if (my === token) compute(true);
  }

  async function load() {
    const my = ++token;
    feed?.close(); feed = null; sr = null;
    $('[data-table]').innerHTML = loading();
    chart.setPrecision(getInstrument(st.symbol).precision);
    try {
      const d = await getCandles(st.symbol, st.tf);
      if (my !== token) return;
      ds = d; candles = d.candles.slice();
      chart.setData(candles, ema(candles.map((c) => c.close), 50));
      chart.showLast(180);
      await yieldTask();
      if (my !== token) return;
      compute(true);
      loadOthers(my);
      feed = openLiveCandles(st.symbol, st.tf, {
        onStatus: (s) => $('.lv-live').classList.toggle('is-live', s === 'open'),
        onCandle: (c) => {
          if (my !== token) return;
          const last = candles.at(-1);
          let closed = false;
          if (c.time > last.time) { candles.push(c); candles.shift(); closed = true; } else if (c.time === last.time) candles[candles.length - 1] = { ...last, ...c }; else return;
          chart.update(c);
          compute(closed);
        },
      });
    } catch {
      $('[data-table]').innerHTML = `<p class="down">${esc(t('tools.multi.noData'))}</p>`;
    }
  }

  $('[data-sym]').addEventListener('change', (e) => { st.symbol = e.target.value; storage.set('radar-levels', st); load(); });
  $('[data-tfs]').addEventListener('click', (e) => {
    const b = e.target.closest('[data-v]'); if (!b) return;
    st.tf = b.dataset.v; storage.set('radar-levels', st);
    $('[data-tfs]').querySelectorAll('button').forEach((x) => x.classList.toggle('is-on', x === b));
    load();
  });
  $('[data-table]').addEventListener('click', (e) => {
    const b = e.target.closest('[data-alert]'); if (!b) return;
    const price = Number(b.dataset.alert);
    const now = candles.at(-1)?.close;
    const kind = price >= now ? 'above' : 'below';
    if (!alertSlotOk()) return;
    addAlert({ symbol: st.symbol, kind, value: Number(price.toFixed(getInstrument(st.symbol).precision)), note: t(b.dataset.role === 'support' ? 'tools.levels.noteS' : 'tools.levels.noteR', { tf: t(`perf.tfShort.${st.tf}`) }) });
    toast(t('tools.levels.alertSet'), 'success');
  });
  load();
  const offTheme = store.on('theme', () => chart.theme());
  onUnmount(page, () => { token++; feed?.close(); chart.destroy(); offTheme(); });
}
