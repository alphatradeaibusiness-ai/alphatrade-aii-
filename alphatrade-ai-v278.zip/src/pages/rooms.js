// v251 Private Trading Rooms — a room dashboard, discovery, create / join (code, link, password, approval), and the room
// itself: members on one side, a shared workspace in the middle (chart + annotations, or the presenter's screen), the room
// chat on the other side, and meeting controls at the bottom. Everything is checked on the server (server/rooms.js):
// roles, permissions, anti-spam, prediction prices and results (taken by the server from market data, never from a page).
// Meetings are WebRTC peer-to-peer (mesh, up to the server's limit); the server only relays the signalling.
import { h, esc, fmtNum } from '../utils/dom.js';
import { icons } from '../components/icons.js';
import { getLocale } from '../i18n/index.js';
import { tx } from '../i18n/tx.js';
import { apiRequest, apiBlobUrl } from '../services/ai/gateway.js';
import { toast } from '../components/ui.js';
import { isAdmin } from '../config/admin.js';
import { getHistory } from '../services/market/index.js';
import { whileMounted, onUnmount } from './tools/common.js';
import { pageHead, errText } from './community.js';
import '../styles/rooms.css';

const L = (ar, en) => tx({ ar, en });
const ROOM_ERR = {
  bad_password: ['كلمة السر غلط.', 'Wrong password.'], room_full: ['الغرفة مليانة.', 'The room is full.'], invite_only: ['هالغرفة بالدعوة بس.', 'This room is invite-only.'],
  bad_invite: ['الدعوة منتهية أو مش إلك.', 'The invitation expired or is not for you.'], banned: ['إنت محظور من هالغرفة.', 'You are blocked from this room.'],
  muted: ['إنت مكتوم بهالغرفة.', 'You are muted in this room.'], slow_down: ['شوي شوي — استنى لحظة.', 'Slow down a little.'], duplicate: ['نفس الرسالة تكررت.', 'Same message repeated.'],
  name_short: ['اسم الغرفة قصير (3 أحرف على الأقل).', 'Room name too short (3+ characters).'], room_limit: ['وصلت الحد الأقصى لعدد غرفك.', 'You reached your room limit.'],
  meeting_full: ['الاجتماع مليان.', 'The meeting is full.'], ai_disabled: ['المساعد مش مفعّل بهالغرفة.', 'The assistant is off in this room.'], ai_off: ['الذكاء الاصطناعي موقوف من الإدارة.', 'AI is turned off by the platform.'],
  no_price: ['ما قدرنا نجيب سعر حقيقي لهالرمز هلّق.', 'Could not get a real price for this symbol now.'], bad_target: ['الهدف لازم يكون بنفس اتجاه التوقع (وأقل من 50%).', 'The target must be on the predicted side (within 50%).'],
  bad_band: ['النطاق بين 0.1% و 10%.', 'Band must be 0.1%–10%.'], closed: ['التصويت مسكّر.', 'Voting is closed.'], forbidden: ['ما عندك صلاحية.', 'You do not have permission.'],
  not_found: ['مش موجود.', 'Not found.'], suspended: ['الغرفة موقوفة.', 'The room is suspended.'], file_too_large: ['الملف كبير (صورة 1.5MB، صوت 1MB).', 'File too large (image 1.5MB, audio 1MB).'],
  bad_file: ['نوع الملف مش مدعوم.', 'File type not supported.'], not_configured: ['مفتاح الـAI مش مضبوط عند الإدارة.', 'The AI key is not set by the owner.'], platform_plan_required: ['هالميزة بالخطة المدفوعة.', 'This needs a paid plan.'],
  owner_cannot_leave: ['المالك ما بيقدر يطلع — أرشف الغرفة بدل.', 'The owner cannot leave — archive the room instead.'], bad_max: ['الحد الأقصى للأعضاء مش مسموح.', 'Member limit not allowed.'],
  bad_price: ['السعر بين 0 و 10000$.', 'Price must be 0–10000 $.'], already: ['طلبك موجود.', 'Already done.'], bio_short: ['اكتب نبذة أطول (20 حرف).', 'Write a longer bio (20+).'], no_meeting: ['ما في اجتماع.', 'No meeting.'],
  bad_symbol: ['الرمز مش صحيح.', 'Bad symbol.'], bad_annotation: ['السعر مش صحيح.', 'Bad price.'], too_many: ['وصلت الحد.', 'Limit reached.'],
};
export const roomErr = (e) => { const c = e?.code || e; const x = ROOM_ERR[c]; return x ? L(x[0], x[1]) : errText(c); };
const api = (m, p, b, ms) => apiRequest(m, `/api${p}`, b, ms);
const when = (ms) => (ms ? new Date(ms).toLocaleString(getLocale(), { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : '');
const clock = (ms) => new Date(ms).toLocaleTimeString(getLocale(), { hour: '2-digit', minute: '2-digit' });
const SPECS = { crypto: ['كريبتو', 'Crypto'], forex: ['فوركس', 'Forex'], gold: ['ذهب', 'Gold'], indices: ['مؤشرات', 'Indices'], stocks: ['أسهم', 'Stocks'], mixed: ['متنوّع', 'Mixed'] };
const ROLE = { owner: ['المالك', 'Owner'], admin: ['مشرف عام', 'Admin'], mod: ['مشرف', 'Moderator'], expert: ['خبير', 'Expert'], member: ['عضو', 'Member'], ai: ['AI', 'AI'], system: ['', ''] };
const specName = (s) => L(...(SPECS[s] || SPECS.mixed));
const roleName = (r) => L(...(ROLE[r] || ROLE.member));
const REACTIONS = ['👍', '🔥', '🎯', '😂', '😮', '👀', '📈', '📉'];
const SYMBOLS = ['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'XAUUSD', 'XAGUSD', 'EURUSD', 'GBPUSD', 'USDJPY', 'US100', 'US30', 'SPX500', 'GER40', 'USOIL'];
const TFS = ['5m', '15m', '1h', '4h', '1D'];
const page = (cls, inner) => h(`<section class="subpage tool cm rm ${cls} page-enter">${inner}</section>`);
const initials = (n) => String(n || '?').trim().split(/\s+/).map((x) => x[0]).join('').slice(0, 2).toUpperCase();
const hue = (s) => { let x = 0; for (const ch of String(s)) x = (x * 31 + ch.charCodeAt(0)) % 360; return x; };
const avatar = (name, uid, cls = '') => `<span class="rm-av ${cls}" style="--h:${hue(uid || name)}">${esc(initials(name))}</span>`;
const readFile = (file) => new Promise((ok, no) => { const r = new FileReader(); r.onload = () => ok(r.result); r.onerror = no; r.readAsDataURL(file); });

/* ───────────────────────── dashboard ───────────────────────── */
function roomCard(c, { join = false } = {}) {
  const badges = [c.access === 'private' ? `<span class="rm-badge">${icons.lock}${L('خاصة', 'Private')}</span>` : `<span class="rm-badge">${icons.globe}${L('عامة', 'Public')}</span>`,
    c.hasPassword ? `<span class="rm-badge">🔑</span>` : '', c.price ? `<span class="rm-badge is-paid">$${fmtNum(c.price.amount, 2)}/${esc(c.price.period)}</span>` : '',
    c.meeting ? `<span class="rm-badge is-live">● ${L('اجتماع مباشر', 'Live')}</span>` : '', c.unread ? `<span class="rm-badge is-unread">${c.unread}</span>` : '', c.pending ? `<span class="rm-badge">${L('بانتظار الموافقة', 'Pending')}</span>` : ''].join('');
  return `<article class="rm-card card" data-room="${esc(c.id)}">
    <div class="rm-card-top">${avatar(c.name, c.id, 'is-room')}<div class="rm-card-t"><h3>${esc(c.name)}</h3><p class="muted">${esc(specName(c.spec))} · ${c.members}/${c.maxMembers} ${L('عضو', 'members')} · <span class="up">${c.online} ${L('متصل', 'online')}</span></p></div>
    ${c.fav ? '<span class="rm-fav">★</span>' : ''}</div>
    ${c.desc ? `<p class="rm-card-d">${esc(c.desc.slice(0, 140))}</p>` : ''}
    <div class="rm-badges">${badges}${c.role ? `<span class="rm-badge is-role">${esc(roleName(c.role))}</span>` : ''}${c.performance?.predictions ? `<span class="rm-badge">🎯 ${c.performance.hits}/${c.performance.predictions}</span>` : ''}</div>
    <div class="rm-card-a">${c.role ? `<a class="btn btn-sm btn-primary" href="#/app/rooms/${esc(c.id)}">${icons.chat}<span>${L('ادخل', 'Open')}</span></a>`
      : join ? `<button type="button" class="btn btn-sm btn-primary" data-join="${esc(c.id)}" data-pw="${c.hasPassword ? 1 : 0}">${icons.plus}<span>${c.approval || c.price ? L('اطلب الانضمام', 'Request to join') : L('انضم', 'Join')}</span></button>` : ''}</div>
  </article>`;
}
const grid = (list, opts, empty) => (list?.length ? `<div class="rm-grid">${list.map((c) => roomCard(c, opts)).join('')}</div>` : `<p class="muted rm-empty">${esc(empty)}</p>`);

const TABS = [['mine', 'غرفي', 'My rooms', 'chat'], ['discover', 'اكتشف', 'Discover', 'search'], ['create', 'أنشئ غرفة', 'Create', 'plus'], ['join', 'انضم بكود', 'Join by code', 'lock'], ['top', 'الترتيب', 'Leaderboard', 'trophy'], ['experts', 'الخبراء', 'Experts', 'crown']];

export function renderRooms() {
  const rid = (location.hash.match(/^#\/app\/rooms\/([A-Z2-9]{6})/) || [])[1];
  if (rid) return roomView(rid);
  const joinCode = (location.hash.match(/[?&]join=([A-Z2-9]{6,10})/i) || [])[1];
  const root = page('rm-dash', `${pageHead('chat', L('غرف التداول الخاصة', 'Private trading rooms'), L('غرف لفريقك أو طلابك: شات، شارت مشترك، اجتماعات صوت وفيديو ومشاركة شاشة، توقعات بنتائج حقيقية، ومساعد AI.', 'Rooms for your team or students: chat, a shared chart, voice/video meetings and screen sharing, predictions with real results, and an AI assistant.'))}
    <nav class="rm-tabs" role="tablist">${TABS.map(([id, ar, en, ic], i) => `<button type="button" role="tab" class="rm-tab${i ? '' : ' is-on'}" data-tab="${id}">${icons[ic]}<span>${esc(L(ar, en))}</span></button>`).join('')}
    ${isAdmin() ? `<a class="rm-tab" href="#/app/rooms-admin">${icons.shield}<span>${L('إدارة المنصة', 'Platform admin')}</span></a>` : ''}</nav>
    <div class="tool-body rm-body" data-body></div>`);
  const body = root.querySelector('[data-body]');
  const tabs = {
    async mine() {
      const d = await api('GET', '/rooms');
      const meet = d.meetings.length ? `<div class="card rm-sec rm-live"><h2>● ${L('اجتماعات شغّالة هلّق', 'Meetings live now')}</h2>${grid(d.meetings, {}, '')}</div>` : '';
      const inv = d.pending.length ? `<div class="card rm-sec"><h2>${icons.mail} ${L('دعوات إلك', 'Invitations for you')}</h2>${d.pending.map((p) => `<div class="rm-row"><b>${esc(p.room.name)}</b> <span class="muted">${esc(roleName(p.role))} · ${L('تنتهي', 'expires')} ${when(p.expires)}</span><button type="button" class="btn btn-sm btn-primary" data-code="${esc(p.code)}">${L('اقبل', 'Accept')}</button></div>`).join('')}</div>` : '';
      const act = d.activity.length ? `<div class="card rm-sec"><h2>${icons.pulse} ${L('آخر النشاط', 'Recent activity')}</h2>${d.activity.map((a) => `<a class="rm-row rm-act" href="#/app/rooms/${esc(a.room)}"><b>${esc(a.roomName)}</b><span class="muted">${esc(a.name)}: ${esc(a.text)}</span><time>${when(a.at)}</time></a>`).join('')}</div>` : '';
      body.innerHTML = `${meet}${inv}
        <div class="rm-stats">${[[d.mine.length, L('غرف بملكك', 'Rooms you own'), `${d.limits.owned}/${d.limits.maxRooms}`], [d.managed.length, L('غرف بتشرف عليها', 'Rooms you manage')], [d.joined.length, L('غرف منضم إلها', 'Rooms you joined')], [d.favorites.length, L('المفضلة', 'Favourites')]].map(([n, t, s]) => `<div class="card rm-stat"><b>${n}</b><span>${esc(t)}</span>${s ? `<small class="muted">${s}</small>` : ''}</div>`).join('')}</div>
        ${d.favorites.length ? `<div class="card rm-sec"><h2>★ ${L('المفضلة', 'Favourites')}</h2>${grid(d.favorites, {}, '')}</div>` : ''}
        <div class="card rm-sec"><h2>${icons.crown} ${L('غرفي', 'My rooms')}</h2>${grid(d.mine, {}, L('لسا ما عملت غرفة. روح على "أنشئ غرفة".', 'No rooms yet — use “Create”.'))}</div>
        ${d.managed.length ? `<div class="card rm-sec"><h2>${icons.shield} ${L('غرف بشرف عليها', 'Managed')}</h2>${grid(d.managed, {}, '')}</div>` : ''}
        <div class="card rm-sec"><h2>${icons.chat} ${L('غرف منضم إلها', 'Joined')}</h2>${grid(d.joined, {}, L('ما انضميت لأي غرفة لسا.', 'You have not joined a room yet.'))}</div>
        ${act}
        ${d.recommended.length ? `<div class="card rm-sec"><h2>${icons.sparkle} ${L('غرف عامة مقترحة', 'Suggested public rooms')}</h2>${grid(d.recommended, { join: true }, '')}</div>` : ''}`;
    },
    async discover() {
      body.innerHTML = `<div class="card rm-sec"><form class="rm-search" data-q><input class="input" name="q" placeholder="${esc(L('دوّر باسم الغرفة أو كودها', 'Search by room name or code'))}"><button class="btn">${icons.search}</button></form><div data-list></div></div>`;
      const run = async (q = '') => { const d = await api('GET', `/rooms/directory?q=${encodeURIComponent(q)}`); body.querySelector('[data-list]').innerHTML = grid(d.items, { join: true }, L('ما في غرف عامة بهالاسم.', 'No public rooms found.')); };
      body.querySelector('[data-q]').addEventListener('submit', (e) => { e.preventDefault(); run(e.target.q.value.trim()).catch((x) => toast(roomErr(x), 'error')); });
      await run();
    },
    async create() { body.replaceChildren(createForm()); },
    async join() {
      body.innerHTML = `<div class="card rm-sec rm-joinbox"><h2>${icons.lock} ${L('انضم بكود دعوة أو رقم غرفة', 'Join with an invite code or room ID')}</h2>
        <form data-jf class="rm-form"><label>${L('الكود', 'Code')}<input class="input mono" name="code" maxlength="10" required placeholder="ABC123 / XXXXXXXXXX" value="${esc(joinCode || '')}"></label>
        <label>${L('كلمة السر (إذا في)', 'Password (if any)')}<input class="input" type="password" name="pw" maxlength="64" autocomplete="off"></label>
        <button class="btn btn-primary">${L('افحص وانضم', 'Check & join')}</button></form><div data-prev></div></div>`;
      const f = body.querySelector('[data-jf]');
      f.addEventListener('submit', async (e) => {
        e.preventDefault(); const c = f.code.value.trim().toUpperCase(); const isInvite = c.length === 10;
        try {
          const p = await api('POST', '/rooms/preview', isInvite ? { code: c } : { id: c });
          body.querySelector('[data-prev]').innerHTML = `<div class="rm-preview">${roomCard(p.room)}${p.room.rules ? `<p class="rm-rules"><b>${L('قوانين الغرفة', 'Room rules')}:</b> ${esc(p.room.rules)}</p>` : ''}</div>`;
          const r = await api('POST', '/rooms/join', isInvite ? { code: c } : { id: c, password: f.pw.value });
          if (r.pending) toast(L('انبعت طلبك — بتوصلك إشعار لما يوافقوا.', 'Request sent — you will be notified when approved.'), 'success');
          else location.hash = `#/app/rooms/${r.room.id}`;
        } catch (x) { toast(roomErr(x), 'error'); }
      });
      if (joinCode) setTimeout(() => { if (f.isConnected) f.requestSubmit(); }, 60);   // the page is attached after this returns
    },
    async top() {
      body.innerHTML = `<div class="card rm-sec"><div class="rm-seg" data-per><button type="button" class="is-on" data-p="week">${L('أسبوعي', 'Weekly')}</button><button type="button" data-p="month">${L('شهري', 'Monthly')}</button></div><div data-lb></div></div>`;
      const load = async (p) => {
        const d = await api('GET', `/rooms/leaderboard?period=${p}`);
        body.querySelector('[data-lb]').innerHTML = `<div class="rm-table-wrap"><table class="rm-table"><thead><tr><th>#</th><th>${L('الغرفة', 'Room')}</th><th>${L('التقييم', 'Score')}</th><th>${L('دقة التوقعات', 'Accuracy')}</th><th>${L('توقعات', 'Predictions')}</th><th>${L('أعضاء نشطين', 'Active')}</th><th>${L('رسائل', 'Messages')}</th></tr></thead><tbody>
          ${d.items.map((x, i) => `<tr><td>${i + 1}</td><td>${x.id ? `<a href="#/app/rooms?join=${esc(x.id)}" data-dir="${esc(x.id)}">${esc(x.name)}</a>` : `${esc(x.name)} ${icons.lock}`}<small class="muted"> ${esc(specName(x.spec))}</small></td><td><b>${x.score ?? '—'}</b></td><td>${x.accuracy != null ? `${x.accuracy}% (${x.hits}/${x.predictions})` : '—'}</td><td>${x.predictions}</td><td>${x.active}</td><td>${x.messages}</td></tr>`).join('') || `<tr><td colspan="7" class="muted">${L('لسا ما في غرف كفاية بالترتيب.', 'Not enough rooms ranked yet.')}</td></tr>`}</tbody></table></div>
          <p class="rm-rules muted">${icons.info} ${L('طريقة الحساب (شفافة):', 'How it is computed (transparent):')} <span class="mono" dir="ltr">${esc(d.rules)}</span></p>`;
      };
      body.querySelector('[data-per]').addEventListener('click', (e) => { const b = e.target.closest('[data-p]'); if (!b) return; body.querySelectorAll('[data-p]').forEach((x) => x.classList.toggle('is-on', x === b)); load(b.dataset.p).catch((x) => toast(roomErr(x), 'error')); });
      await load('week');
    },
    async experts() {
      const [d, me] = await Promise.all([api('GET', '/experts'), api('GET', '/rooms').catch(() => ({}))]);
      body.innerHTML = `<div class="card rm-sec"><h2>${icons.crown} ${L('خبراء موثّقين', 'Verified experts')}</h2>
        <p class="muted">${L('السجل محسوب من توقعات الخبير اللي انحسمت بأسعار السوق الحقيقية على السيرفر.', 'The record is computed from the expert’s predictions resolved by the server on real market prices.')}</p>
        ${d.items.length ? `<div class="rm-grid">${d.items.map((x) => `<article class="card rm-card">${avatar(x.name, x.uid)}<h3>${esc(x.name)} <span class="rm-verified" title="verified">✔</span></h3><p class="muted">${esc(x.markets || '')}</p><p class="rm-card-d">${esc(x.bio)}</p><p>🎯 ${x.record.n ? `${x.record.hits}/${x.record.n} (${Math.round((x.record.hits / x.record.n) * 100)}%)` : L('لسا ما في توقعات محسومة', 'No resolved predictions yet')}</p></article>`).join('')}</div>` : `<p class="muted">${L('ما في خبراء موثّقين لسا.', 'No verified experts yet.')}</p>`}</div>
        ${me.expert ? `<p class="card rm-sec">✔ ${L('إنت خبير موثّق.', 'You are a verified expert.')}</p>` : `<div class="card rm-sec"><h2>${L('قدّم طلب توثيق كخبير', 'Apply to be a verified expert')}</h2><form class="rm-form" data-ap>
          <label>${L('نبذة عن خبرتك', 'About your experience')}<textarea class="input" name="bio" rows="3" maxlength="600" required></textarea></label><label>${L('الأسواق', 'Markets')}<input class="input" name="markets" maxlength="120" placeholder="Gold, BTC…"></label>
          <button class="btn btn-primary">${L('ابعث الطلب', 'Send')}</button><p class="muted">${L('إدارة المنصة بتراجع الطلب. التوثيق مش ضمان أرباح.', 'The platform reviews requests. Verification is not a profit guarantee.')}</p></form></div>`}`;
      body.querySelector('[data-ap]')?.addEventListener('submit', async (e) => { e.preventDefault(); try { await api('POST', '/experts/apply', { bio: e.target.bio.value, markets: e.target.markets.value }); toast(L('انبعت الطلب.', 'Request sent.'), 'success'); e.target.reset(); } catch (x) { toast(roomErr(x), 'error'); } });
    },
  };
  const show = (id) => { root.querySelectorAll('[data-tab]').forEach((b) => b.classList.toggle('is-on', b.dataset.tab === id)); body.innerHTML = '<div class="perf-loading"><span class="spinner"></span></div>'; tabs[id]().catch((x) => { body.innerHTML = `<div class="alert alert-error">${icons.alert}<div>${esc(roomErr(x))}</div></div>`; }); };
  root.querySelector('.rm-tabs').addEventListener('click', (e) => { const b = e.target.closest('[data-tab]'); if (b) show(b.dataset.tab); });
  body.addEventListener('click', async (e) => {
    const j = e.target.closest('[data-join]'); const c = e.target.closest('[data-code]'); const dir = e.target.closest('[data-dir]');
    if (dir) { e.preventDefault(); show('join'); setTimeout(() => { const f = body.querySelector('[data-jf]'); if (f) { f.code.value = dir.dataset.dir; } }, 50); return; }
    if (!j && !c) return;
    try {
      let b; if (c) b = { code: c.dataset.code };
      else { b = { id: j.dataset.join }; if (j.dataset.pw === '1') { const pw = window.prompt(L('كلمة سر الغرفة', 'Room password')); if (pw == null) return; b.password = pw; } }
      const r = await api('POST', '/rooms/join', b);
      if (r.pending) toast(L('انبعت طلب الانضمام.', 'Join request sent.'), 'success'); else location.hash = `#/app/rooms/${r.room.id}`;
    } catch (x) { toast(roomErr(x), 'error'); }
  });
  show(joinCode ? 'join' : 'mine');
  return root;
}

function createForm(existing = null, onSaved = null) {
  const e = existing || {}; const perms = e.perms || { share: 'all', upload: 'all', predict: 'all', meet: 'mods' };
  const permSel = (k, ar, en) => `<label>${esc(L(ar, en))}<select class="input" name="p_${k}"><option value="all"${perms[k] === 'all' ? ' selected' : ''}>${L('كل الأعضاء', 'All members')}</option><option value="mods"${perms[k] === 'mods' ? ' selected' : ''}>${L('المشرفين والخبراء', 'Moderators & experts')}</option></select></label>`;
  const f = h(`<form class="card rm-sec rm-form rm-create">
    <h2>${icons.plus} ${existing ? L('إعدادات الغرفة', 'Room settings') : L('غرفة جديدة', 'New room')}</h2>
    <div class="rm-form-g">
      <label>${L('اسم الغرفة', 'Room name')}<input class="input" name="name" maxlength="60" required value="${esc(e.name || '')}"></label>
      <label>${L('التخصص', 'Specialty')}<select class="input" name="spec">${Object.keys(SPECS).map((s) => `<option value="${s}"${(e.spec || 'mixed') === s ? ' selected' : ''}>${esc(specName(s))}</option>`).join('')}</select></label>
      <label>${L('اللغة', 'Language')}<select class="input" name="lang">${['ar', 'en', 'he', 'es', 'zh'].map((x) => `<option${(e.lang || 'ar') === x ? ' selected' : ''}>${x}</option>`).join('')}</select></label>
      <label>${L('الخصوصية', 'Privacy')}<select class="input" name="access"><option value="private"${e.access !== 'public' ? ' selected' : ''}>${L('خاصة', 'Private')}</option><option value="public"${e.access === 'public' ? ' selected' : ''}>${L('عامة (بتطلع بالبحث)', 'Public (listed)')}</option></select></label>
      <label>${L('الحد الأقصى للأعضاء', 'Max members')}<input class="input" type="number" name="maxMembers" min="2" max="1000" value="${e.maxMembers || 50}"></label>
      <label>${L('كلمة سر (اختياري)', 'Password (optional)')}<input class="input" type="password" name="password" maxlength="64" autocomplete="new-password" placeholder="${existing ? esc(L('اتركها فاضية = بدون تغيير', 'empty = unchanged')) : ''}"></label>
      <label>${L('اشتراك شهري/سنوي $ (0 = مجاني)', 'Subscription $ (0 = free)')}<input class="input" type="number" step="0.01" min="0" max="10000" name="price" value="${e.price?.amount || 0}"></label>
      <label>${L('الفترة', 'Period')}<select class="input" name="period">${[['month', 'شهري', 'Monthly'], ['year', 'سنوي', 'Yearly'], ['once', 'مرة وحدة', 'One-time']].map(([v, a, b]) => `<option value="${v}"${e.price?.period === v ? ' selected' : ''}>${esc(L(a, b))}</option>`).join('')}</select></label>
      ${permSel('share', 'مشاركة الشارت/الشاشة', 'Share chart / screen')}${permSel('upload', 'رفع صور وصوت', 'Upload images / audio')}${permSel('predict', 'نشر توقعات', 'Post predictions')}${permSel('meet', 'بدء اجتماع', 'Start meetings')}
    </div>
    <label>${L('وصف', 'Description')}<textarea class="input" name="desc" rows="2" maxlength="600">${esc(e.desc || '')}</textarea></label>
    <label>${L('قوانين الغرفة', 'Room rules')}<textarea class="input" name="rules" rows="2" maxlength="1500">${esc(e.rules || '')}</textarea></label>
    <div class="rm-checks"><label><input type="checkbox" name="inviteOnly"${e.inviteOnly ? ' checked' : ''}> ${L('بالدعوة بس', 'Invite only')}</label><label><input type="checkbox" name="approval"${e.approval ? ' checked' : ''}> ${L('موافقة قبل الانضمام', 'Approve before joining')}</label>
      <label>${L('صورة', 'Image')} <input type="file" name="image" accept="image/png,image/jpeg,image/webp"></label></div>
    <p class="muted">${icons.info} ${L('الغرف المدفوعة: الانضمام دايمًا بموافقتك. المنصة ما بتحصّل الدفع عنك — رتّبه مع الأعضاء وبعدين وافق.', 'Paid rooms: joining always needs your approval. The platform does not collect payment for you — arrange it with members, then approve.')}</p>
    <div class="rm-form-a"><button class="btn btn-primary">${existing ? L('احفظ', 'Save') : L('أنشئ الغرفة', 'Create room')}</button>${existing && e.role === 'owner' ? `<button type="button" class="btn btn-ghost" data-archive>${e.archived ? L('رجّع الغرفة', 'Unarchive') : L('أرشف الغرفة', 'Archive')}</button>` : ''}</div>
  </form>`);
  f.querySelector('[data-archive]')?.addEventListener('click', async () => { try { await api('PATCH', `/rooms/${e.id}`, { archived: !e.archived }); toast('✔', 'success'); onSaved?.(); } catch (x) { toast(roomErr(x), 'error'); } });
  f.addEventListener('submit', async (ev) => {
    ev.preventDefault(); const v = (n) => f.elements[n].value;
    const b = { name: v('name'), spec: v('spec'), lang: v('lang'), access: v('access'), maxMembers: Number(v('maxMembers')), desc: v('desc'), rules: v('rules'), inviteOnly: f.inviteOnly.checked, approval: f.approval.checked,
      price: Number(v('price')) > 0 ? { amount: Number(v('price')), period: v('period') } : null, perms: { share: v('p_share'), upload: v('p_upload'), predict: v('p_predict'), meet: v('p_meet') } };
    if (v('password')) b.password = v('password');
    const file = f.image.files[0]; if (file) { if (file.size > 1_500_000) return toast(roomErr('file_too_large'), 'error'); b.image = await readFile(file); }
    try {
      const r = existing ? await api('PATCH', `/rooms/${e.id}`, b) : await api('POST', '/rooms', b);
      toast(existing ? L('انحفظت الإعدادات.', 'Saved.') : L('انعملت الغرفة.', 'Room created.'), 'success');
      if (existing) onSaved?.(); else location.hash = `#/app/rooms/${r.room.id}`;
    } catch (x) { toast(roomErr(x), 'error'); }
  });
  return f;
}

/* ───────────────────────── workspace chart ───────────────────────── */
const ANN = { level: ['مستوى', 'Level', '#60a5fa'], zone: ['منطقة', 'Zone', '#a78bfa'], trend: ['ترند', 'Trend', '#f59e0b'], entry: ['دخول', 'Entry', '#38bdf8'], target: ['هدف', 'Target', '#22c55e'], stop: ['وقف', 'Stop', '#ef4444'] };
function drawChart(cv, candles, ann, { live = null } = {}) {
  const dpr = window.devicePixelRatio || 1; const W = cv.clientWidth || 600, H = cv.clientHeight || 320;
  cv.width = W * dpr; cv.height = H * dpr; const g = cv.getContext('2d'); g.setTransform(dpr, 0, 0, dpr, 0, 0); g.clearRect(0, 0, W, H);
  const css = getComputedStyle(cv); const txt = css.getPropertyValue('--text-3') || '#8b93a7'; const grd = css.getPropertyValue('--border') || 'rgba(255,255,255,.08)';
  if (!candles?.length) { g.fillStyle = txt; g.font = '13px system-ui'; g.fillText('…', W / 2, H / 2); return null; }
  const c = candles.slice(-Math.max(30, Math.floor((W - 60) / 6))); const padR = 62, padT = 10, padB = 18;
  let lo = Math.min(...c.map((x) => x.low)), hi = Math.max(...c.map((x) => x.high));
  for (const a of ann) for (const p of [a.p1, a.p2]) if (p > 0 && p > lo * 0.97 && p < hi * 1.03) { lo = Math.min(lo, p); hi = Math.max(hi, p); }
  const pad = (hi - lo) * 0.06 || hi * 0.01; lo -= pad; hi += pad;
  const y = (p) => padT + (1 - (p - lo) / (hi - lo)) * (H - padT - padB); const bw = (W - padR) / c.length; const x = (i) => i * bw + bw / 2;
  g.strokeStyle = grd; g.lineWidth = 1; g.fillStyle = txt; g.font = '10.5px ui-monospace, monospace'; g.textAlign = 'left';
  const dig = hi > 1000 ? 1 : hi > 10 ? 2 : 4;
  for (let k = 0; k <= 5; k++) { const p = lo + ((hi - lo) * k) / 5; const yy = y(p); g.beginPath(); g.moveTo(0, yy); g.lineTo(W - padR, yy); g.stroke(); g.fillText(p.toFixed(dig), W - padR + 4, yy + 3); }
  c.forEach((k, i) => { const up = k.close >= k.open; g.strokeStyle = g.fillStyle = up ? '#22c55e' : '#ef4444'; g.beginPath(); g.moveTo(x(i), y(k.high)); g.lineTo(x(i), y(k.low)); g.stroke(); const t = y(Math.max(k.open, k.close)), b = y(Math.min(k.open, k.close)); g.fillRect(x(i) - bw * 0.35, t, Math.max(1, bw * 0.7), Math.max(1, b - t)); });
  const t0 = c[0].time, t1 = c.at(-1).time; const tx2 = (t) => (t ? Math.max(0, Math.min(W - padR, ((t - t0) / Math.max(1, t1 - t0)) * (W - padR))) : null);
  for (const a of ann) {
    const col = a.color || ANN[a.kind]?.[2] || '#60a5fa'; g.strokeStyle = col; g.fillStyle = col; g.lineWidth = 1.5; g.setLineDash(a.kind === 'stop' || a.kind === 'target' ? [5, 4] : []);
    if (a.kind === 'zone' && a.p2) { g.globalAlpha = 0.16; g.fillRect(0, y(Math.max(a.p1, a.p2)), W - padR, Math.abs(y(a.p1) - y(a.p2))); g.globalAlpha = 1; }
    else if (a.kind === 'trend' && a.p2) { const xa = tx2(a.t1) ?? 0, xb = tx2(a.t2) ?? W - padR; g.beginPath(); g.moveTo(xa, y(a.p1)); g.lineTo(xb, y(a.p2)); g.stroke(); }
    else { g.beginPath(); g.moveTo(0, y(a.p1)); g.lineTo(W - padR, y(a.p1)); g.stroke(); }
    g.setLineDash([]); g.font = '11px system-ui'; g.fillText(`${a.label || tx({ ar: ANN[a.kind]?.[0], en: ANN[a.kind]?.[1] })} ${(+a.p1).toFixed(dig)}`, 6, y(a.p1) - 4);
  }
  const last = live ?? c.at(-1).close; g.fillStyle = '#7c5cff'; g.fillRect(W - padR, y(last) - 8, padR, 16); g.fillStyle = '#fff'; g.fillText(last.toFixed(dig), W - padR + 4, y(last) + 4);
  return { yToPrice: (py) => lo + (1 - (py - padT) / (H - padT - padB)) * (hi - lo), xToTime: (px) => t0 + (px / (W - padR)) * (t1 - t0), dig };
}

/* ───────────────────────── meeting (WebRTC mesh) ───────────────────────── */
function createMeeting(rid, myUid, { onChange, onError }) {
  const pcs = new Map(); const remote = new Map(); const screenIds = new Map(); let local = null; let screen = null; let ice = null; let timer = null; let active = false; let st = { mic: true, cam: false, screen: false, hand: false, speaking: false };
  let meeting = null; let ac = null; let vadT = null;
  const call = (b) => api('POST', `/rooms/${rid}/meeting`, b, 20000);
  const signal = (to, type, data) => call({ action: 'signal', to, type, data }).catch(() => {});
  const polite = (peer) => String(myUid()) < String(peer);
  function peer(uid) {
    if (pcs.has(uid)) return pcs.get(uid);
    const pc = new RTCPeerConnection({ iceServers: ice || [{ urls: 'stun:stun.l.google.com:19302' }] }); const s = { pc, making: false, ignore: false };
    pcs.set(uid, s);
    for (const t of local?.getTracks() || []) pc.addTrack(t, local);
    if (screen) for (const t of screen.getTracks()) pc.addTrack(t, screen);
    pc.onicecandidate = (e) => { if (e.candidate) signal(uid, 'ice', e.candidate.toJSON()); };
    pc.onnegotiationneeded = async () => { try { s.making = true; await pc.setLocalDescription(); signal(uid, 'offer', { sdp: pc.localDescription.toJSON(), screen: screen?.id || null }); } catch { /* */ } finally { s.making = false; } };
    pc.ontrack = (e) => { const st2 = e.streams[0]; if (!st2) return; const m = remote.get(uid) || new Map(); m.set(st2.id, st2); remote.set(uid, m); st2.onremovetrack = () => { if (!st2.getTracks().length) { m.delete(st2.id); onChange(); } }; onChange(); };
    pc.onconnectionstatechange = () => { if (['failed', 'closed'].includes(pc.connectionState)) { drop(uid); } onChange(); };
    return s;
  }
  function drop(uid) { const s = pcs.get(uid); try { s?.pc.close(); } catch { /* */ } pcs.delete(uid); remote.delete(uid); screenIds.delete(uid); onChange(); }
  async function onSignal(x) {
    if (x.type === 'join') { peer(x.from); return; }
    if (x.type === 'mute') { setMic(false); toast(L('المشرف كتم المايك تبعك.', 'A moderator muted your mic.')); return; }
    const s = peer(x.from); const pc = s.pc;
    try {
      if (x.type === 'offer') {
        if (x.data?.screen !== undefined) screenIds.set(x.from, x.data.screen);
        const collision = s.making || pc.signalingState !== 'stable'; s.ignore = !polite(x.from) && collision; if (s.ignore) return;
        await pc.setRemoteDescription(x.data.sdp); await pc.setLocalDescription(); signal(x.from, 'answer', { sdp: pc.localDescription.toJSON() });
      } else if (x.type === 'answer') { await pc.setRemoteDescription(x.data.sdp); }
      else if (x.type === 'ice') { try { await pc.addIceCandidate(x.data); } catch (e) { if (!s.ignore) throw e; } }
    } catch { /* one bad signal must not break the meeting */ }
  }
  async function tick() {
    if (!active) return;
    try {
      const r = await call({ action: 'poll' }); meeting = r.meeting;
      for (const x of r.signals || []) await onSignal(x);
      const ids = new Set((meeting?.participants || []).map((p) => p.uid)); for (const uid of [...pcs.keys()]) if (!ids.has(uid)) drop(uid);
      onChange();
    } catch (e) { if (['no_meeting', 'not_in_meeting', 'forbidden'].includes(e.code)) { stop(true); toast(L('انتهى الاجتماع.', 'The meeting ended.')); } }
  }
  function vad() {
    try {
      ac = new (window.AudioContext || window.webkitAudioContext)(); const an = ac.createAnalyser(); an.fftSize = 512; ac.createMediaStreamSource(local).connect(an); const buf = new Uint8Array(an.fftSize); let on = false, since = 0;
      vadT = setInterval(() => { an.getByteTimeDomainData(buf); let s = 0; for (const v of buf) s += (v - 128) ** 2; const lvl = Math.sqrt(s / buf.length); const sp = st.mic && lvl > 6;
        if (sp !== on) { if (!since) since = Date.now(); if (Date.now() - since > 250) { on = sp; since = 0; st.speaking = on; call({ action: 'state', speaking: on }).catch(() => {}); } } else since = 0; }, 120);
    } catch { /* no audio analysis on this browser */ }
  }
  async function start({ kind = 'voice', create = false } = {}) {
    if (!navigator.mediaDevices?.getUserMedia || !window.RTCPeerConnection) throw Object.assign(new Error('x'), { code: 'no_webrtc' });
    ice = (await api('GET', '/support/ice').catch(() => ({}))).iceServers || null;
    try { local = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true }, video: kind === 'video' ? { width: 640, height: 360 } : false }); }
    catch { local = await navigator.mediaDevices.getUserMedia({ audio: true }).catch(() => new MediaStream()); }
    st.cam = local.getVideoTracks().length > 0; st.mic = local.getAudioTracks().length > 0;
    const r = await call({ action: create ? 'start' : 'join', kind }); meeting = r.meeting; active = true;
    for (const uid of r.peers || []) peer(uid);
    await call({ action: 'state', mic: st.mic, cam: st.cam }).catch(() => {});
    vad(); timer = setInterval(tick, 1000); onChange();
  }
  function setMic(on) { st.mic = on; local?.getAudioTracks().forEach((t) => { t.enabled = on; }); call({ action: 'state', mic: on }).catch(() => {}); onChange(); }
  function setCam(on) { st.cam = on && (local?.getVideoTracks().length > 0); local?.getVideoTracks().forEach((t) => { t.enabled = on; }); call({ action: 'state', cam: st.cam }).catch(() => {}); onChange(); }
  async function setScreen(on) {
    if (on) {
      try { screen = await navigator.mediaDevices.getDisplayMedia({ video: true, audio: false }); } catch { return; }
      const r = await call({ action: 'state', screen: true }).catch((e) => { onError(e); return null; }); if (!r) { screen.getTracks().forEach((t) => t.stop()); screen = null; return; }
      screen.getVideoTracks()[0].onended = () => setScreen(false);
      for (const { pc } of pcs.values()) for (const t of screen.getTracks()) pc.addTrack(t, screen);
      st.screen = true;
    } else if (screen) {
      for (const { pc } of pcs.values()) for (const snd of pc.getSenders()) if (snd.track && screen.getTracks().includes(snd.track)) { try { pc.removeTrack(snd); } catch { /* */ } }
      screen.getTracks().forEach((t) => t.stop()); screen = null; st.screen = false; call({ action: 'state', screen: false }).catch(() => {});
    }
    onChange();
  }
  function setHand(on) { st.hand = on; call({ action: 'state', hand: on }).catch(() => {}); onChange(); }
  function stop(silent = false) {
    if (!active && !local) return; active = false; clearInterval(timer); clearInterval(vadT); try { ac?.close(); } catch { /* */ }
    for (const uid of [...pcs.keys()]) drop(uid); local?.getTracks().forEach((t) => t.stop()); screen?.getTracks().forEach((t) => t.stop()); local = null; screen = null; st = { mic: true, cam: false, screen: false, hand: false, speaking: false };
    if (!silent) call({ action: 'leave' }).catch(() => {}); onChange();
  }
  return { start, stop, setMic, setCam, setScreen, setHand, end: () => call({ action: 'end' }).then(() => stop(true)), mute: (uid) => call({ action: 'mute', uid }),
    get active() { return active; }, get state() { return st; }, get meeting() { return meeting; }, get local() { return local; }, get screen() { return screen; }, remote, screenIds, pcs };
}

/* ───────────────────────── the room ───────────────────────── */
function roomView(rid) {
  const root = page('rm-room', `
    <header class="rm-top card">
      <a class="btn btn-sm btn-ghost" href="#/app/rooms" title="${esc(L('رجوع', 'Back'))}">${icons.chevronDown}</a>
      <div class="rm-top-t" data-title><b>…</b></div>
      <div class="rm-top-tools">
        <select class="input input-sm" data-sym title="${esc(L('الرمز', 'Symbol'))}">${SYMBOLS.map((s) => `<option>${s}</option>`).join('')}</select>
        <select class="input input-sm" data-tf>${TFS.map((s) => `<option>${s}</option>`).join('')}</select>
        <button type="button" class="btn btn-sm" data-act="invite" title="${esc(L('دعوة', 'Invite'))}">${icons.plus}<span>${L('دعوة', 'Invite')}</span></button>
        <button type="button" class="btn btn-sm" data-act="fav" title="★">★</button>
        <button type="button" class="btn btn-sm" data-act="settings" hidden>${icons.settings}</button>
        <button type="button" class="btn btn-sm btn-ghost" data-act="leave" title="${esc(L('اطلع من الغرفة', 'Leave room'))}">${icons.logout}</button>
      </div>
    </header>
    <nav class="rm-mtabs"><button type="button" class="is-on" data-pane="work">${icons.candles}${L('المساحة', 'Workspace')}</button><button type="button" data-pane="chat">${icons.chat}${L('الشات', 'Chat')}<i data-unread hidden></i></button><button type="button" data-pane="people">${icons.user}${L('الأعضاء', 'Members')}</button><button type="button" data-pane="pred">🎯 ${L('التوقعات', 'Predictions')}</button></nav>
    <div class="rm-layout" data-layout data-show="work">
      <aside class="rm-people card" data-p="people">
        <h3>${L('الأعضاء', 'Members')} <small class="muted" data-count></small></h3>
        <div data-pending></div>
        <ul class="rm-mlist" data-members></ul>
      </aside>
      <main class="rm-work" data-p="work">
        <div class="rm-stage card" data-stage data-p="stage">
          <div class="rm-stage-head"><span data-stage-t></span><span class="muted" data-src></span></div>
          <div class="rm-stage-main" data-main><canvas class="rm-chart" data-chart></canvas><video class="rm-present" data-present autoplay playsinline muted hidden></video></div>
          <div class="rm-tiles" data-tiles></div>
          <form class="rm-annbar" data-annf>
            <select class="input input-sm" name="kind">${Object.entries(ANN).map(([k, v]) => `<option value="${k}">${esc(L(v[0], v[1]))}</option>`).join('')}</select>
            <input class="input input-sm mono" name="p1" inputmode="decimal" placeholder="${esc(L('سعر (أو اضغط على الشارت)', 'price (or click chart)'))}">
            <input class="input input-sm mono" name="p2" inputmode="decimal" placeholder="${esc(L('سعر 2 (منطقة/ترند)', 'price 2 (zone/trend)'))}">
            <input class="input input-sm" name="label" maxlength="40" placeholder="${esc(L('ملاحظة', 'label'))}">
            <button class="btn btn-sm btn-primary">${icons.plus}</button><button type="button" class="btn btn-sm btn-ghost" data-clear title="${esc(L('امسح الكل', 'Clear all'))}">${icons.trash}</button>
          </form>
          <ul class="rm-annlist" data-annlist></ul>
        </div>
        <section class="card rm-preds" data-p="pred">
          <h3>🎯 ${L('التوقعات', 'Predictions')} <small class="muted">${L('السعر المرجعي والنتيجة من السيرفر — ما بينعدلوا وما بينحذفوا', 'Reference price and result come from the server — cannot be edited or deleted')}</small></h3>
          <form class="rm-predf" data-predf>
            <select class="input input-sm" name="symbol">${SYMBOLS.map((s) => `<option>${s}</option>`).join('')}</select>
            <select class="input input-sm" name="direction"><option value="up">${L('صعود ⬆', 'Up ⬆')}</option><option value="down">${L('هبوط ⬇', 'Down ⬇')}</option><option value="flat">${L('عرضي ↔', 'Range ↔')}</option></select>
            <input class="input input-sm mono" name="target" inputmode="decimal" placeholder="${esc(L('الهدف', 'Target'))}">
            <input class="input input-sm mono" name="band" inputmode="decimal" placeholder="${esc(L('النطاق % (للعرضي)', 'Band % (range)'))}" hidden>
            <select class="input input-sm" name="horizonH">${[[1, '1h'], [4, '4h'], [12, '12h'], [24, '1d'], [72, '3d'], [168, '1w']].map(([v, t]) => `<option value="${v}"${v === 24 ? ' selected' : ''}>${t}</option>`).join('')}</select>
            <input class="input input-sm" name="analysis" maxlength="600" placeholder="${esc(L('التحليل باختصار', 'Short analysis'))}">
            <input class="input input-sm" name="risk" maxlength="200" placeholder="${esc(L('المخاطر', 'Risks'))}">
            <button class="btn btn-sm btn-primary">${L('انشر', 'Post')}</button>
          </form>
          <div class="rm-plist" data-preds></div>
        </section>
      </main>
      <aside class="rm-chat card" data-p="chat">
        <div class="rm-chat-h"><b>${icons.chat} ${L('الشات', 'Chat')}</b>
          <form data-sf class="rm-chat-s"><input class="input input-sm" name="q" placeholder="${esc(L('بحث', 'Search'))}"></form>
          <div class="rm-ai" data-ai hidden><button type="button" class="btn btn-sm" data-ai-m="summary">${icons.sparkle}${L('لخّص', 'Summary')}</button><button type="button" class="btn btn-sm" data-ai-m="disagreements">${L('الخلافات', 'Disagreements')}</button><button type="button" class="btn btn-sm" data-ai-m="mentor" hidden data-mentor-btn>🎓</button></div>
        </div>
        <div class="rm-pins" data-pins hidden></div>
        <ol class="rm-msgs" data-msgs aria-live="polite"></ol>
        <div class="rm-reply" data-reply hidden></div>
        <form class="rm-compose" data-cf>
          <select class="input input-sm rm-to" name="to" title="${esc(L('رسالة خاصة', 'Private message'))}"><option value="">${L('للكل', 'Everyone')}</option></select>
          <textarea class="input" name="text" rows="1" maxlength="2000" placeholder="${esc(L('اكتب رسالة… (@اسم للإشارة، /ai لسؤال المساعد)', 'Message… (@name to mention, /ai to ask the assistant)'))}"></textarea>
          <label class="btn btn-sm btn-ghost rm-file" title="${esc(L('صورة', 'Image'))}">${icons.camera}<input type="file" accept="image/png,image/jpeg,image/webp" hidden data-img></label>
          <button type="button" class="btn btn-sm btn-ghost" data-rec title="${esc(L('رسالة صوتية', 'Voice note'))}">${icons.mic}</button>
          <button class="btn btn-sm btn-primary">${icons.send}</button>
        </form>
      </aside>
    </div>
    <footer class="rm-controls card" data-controls>
      <div class="rm-ctl-l" data-meet-info></div>
      <div class="rm-ctl-c">
        <button type="button" class="rm-ctl" data-m="join">${icons.mic}<span>${L('انضم للاجتماع', 'Join meeting')}</span></button>
        <button type="button" class="rm-ctl" data-m="startv" hidden>${icons.camera}<span>${L('اجتماع فيديو', 'Video meeting')}</span></button>
        <button type="button" class="rm-ctl" data-m="mic" hidden>${icons.mic}<span>${L('المايك', 'Mic')}</span></button>
        <button type="button" class="rm-ctl" data-m="cam" hidden>${icons.camera}<span>${L('الكاميرا', 'Camera')}</span></button>
        <button type="button" class="rm-ctl" data-m="screen" hidden>${icons.grid}<span>${L('شارك الشاشة', 'Share screen')}</span></button>
        <button type="button" class="rm-ctl" data-m="hand" hidden>✋<span>${L('ارفع إيدك', 'Raise hand')}</span></button>
        <button type="button" class="rm-ctl is-end" data-m="leave" hidden>${icons.close}<span>${L('اطلع', 'Leave')}</span></button>
        <button type="button" class="rm-ctl is-end" data-m="end" hidden>${icons.close}<span>${L('أنهِ للكل', 'End for all')}</span></button>
      </div>
      <div class="rm-ctl-r"><span class="muted" data-netq></span></div>
    </footer>
    <div data-modal></div>`);
  const $ = (s) => root.querySelector(s);
  const S = { rev: 0, room: null, me: null, members: [], msgs: new Map(), ws: null, preds: [], meeting: null, candles: null, chartMap: null, replyTo: null, wsKey: '', blobs: new Map(), live: null, searching: false };
  const isStaff = () => ['owner', 'admin', 'mod'].includes(S.me?.role); const isMgr = () => ['owner', 'admin'].includes(S.me?.role);
  const canDo = (perm) => { if (isMgr()) return true; const p = S.room?.perms?.[perm] || 'all'; return p === 'all' ? Boolean(S.me?.role) : isStaff() || S.me?.role === 'expert'; };
  const meet = createMeeting(rid, () => S.me?.uid, { onChange: () => renderMeeting(), onError: (e) => toast(roomErr(e), 'error') });

  // mobile panes
  $('.rm-mtabs').addEventListener('click', (e) => { const b = e.target.closest('[data-pane]'); if (!b) return; root.querySelectorAll('.rm-mtabs button').forEach((x) => x.classList.toggle('is-on', x === b)); $('[data-layout]').dataset.show = b.dataset.pane; if (b.dataset.pane === 'chat') { $('[data-unread]').hidden = true; scrollChat(); } if (b.dataset.pane === 'work') paintChart(); });

  /* ── chat ── */
  const fileUrl = async (fid) => { if (S.blobs.has(fid)) return S.blobs.get(fid); const u = await apiBlobUrl(`/api/rooms/${rid}/file/${fid}`); S.blobs.set(fid, u); return u; };
  const fmtText = (t) => esc(t).replace(/(^|\s)@([^\s@]{2,40})/g, '$1<b class="rm-mention">@$2</b>').replace(/\n/g, '<br>');
  function msgHtml(m) {
    if (m.kind === 'system') return `<li class="rm-msg is-sys" data-id="${m.id}"><span>${esc(m.text)}</span><time>${clock(m.at)}</time></li>`;
    const mine = m.uid && m.uid === S.me?.uid; const rep = m.replyTo ? S.msgs.get(m.replyTo) : null;
    const reacts = Object.entries(m.reactions || {}).map(([e, l]) => `<button type="button" class="rm-react${l.includes(S.me?.uid) ? ' is-on' : ''}" data-react="${e}">${e} ${l.length}</button>`).join('');
    return `<li class="rm-msg${mine ? ' is-mine' : ''}${m.kind === 'ai' ? ' is-ai' : ''}${m.to ? ' is-dm' : ''}${m.pinned ? ' is-pinned' : ''}${m.mentions?.includes(S.me?.uid) ? ' is-mention' : ''}" data-id="${m.id}">
      ${m.kind === 'ai' ? `<span class="rm-av is-ai">AI</span>` : avatar(m.name, m.uid)}
      <div class="rm-bubble">
        <div class="rm-mh"><b>${esc(m.name)}</b>${m.role && m.role !== 'member' ? `<span class="rm-role is-${m.role}">${esc(roleName(m.role))}</span>` : ''}${m.expert ? '<span class="rm-verified" title="verified expert">✔</span>' : ''}${m.to ? `<span class="rm-role">🔒 ${L('خاص', 'private')}</span>` : ''}${m.pinned ? '📌' : ''}<time>${clock(m.at)}</time></div>
        ${rep ? `<div class="rm-quote"><b>${esc(rep.name)}</b> ${esc((rep.text || '📎').slice(0, 90))}</div>` : ''}
        ${m.deleted ? `<p class="muted"><i>${L('انحذفت الرسالة', 'Message deleted')}</i></p>` : `<div class="rm-text">${fmtText(m.text)}${m.edited ? ` <small class="muted">(${L('معدّلة', 'edited')})</small>` : ''}</div>`}
        ${m.file ? `<div class="rm-filebox" data-file="${m.file}" data-kind="${m.fileKind}"><span class="spinner"></span></div>` : ''}
        ${m.ai ? `<small class="muted">${L('سؤال من', 'asked by')} ${esc(m.ai.askedBy || '')} · ${L('ذكاء اصطناعي — للتعليم، مش نصيحة مالية', 'AI — educational, not financial advice')}</small>` : ''}
        <div class="rm-reacts">${reacts}</div>
      </div>
      ${m.deleted ? '' : `<div class="rm-mact"><button type="button" data-ma="reply" title="reply">↩</button><button type="button" data-ma="react" title="react">☺</button>${mine ? '<button type="button" data-ma="edit" title="edit">✎</button>' : ''}${mine || (isStaff() && !m.to) ? '<button type="button" data-ma="delete" title="delete">🗑</button>' : ''}${isStaff() && !m.to ? `<button type="button" data-ma="${m.pinned ? 'unpin' : 'pin'}" title="pin">📌</button>` : ''}${!mine && m.uid ? '<button type="button" data-ma="report" title="report">⚑</button>' : ''}</div>`}
    </li>`;
  }
  const chatEl = $('[data-msgs]');
  const nearBottom = () => chatEl.scrollHeight - chatEl.scrollTop - chatEl.clientHeight < 120;
  const scrollChat = () => { chatEl.scrollTop = chatEl.scrollHeight; };
  function hydrateFiles(scope) {
    scope.querySelectorAll('[data-file]:not([data-done])').forEach((el) => { el.dataset.done = '1'; fileUrl(el.dataset.file).then((u) => { el.innerHTML = el.dataset.kind === 'audio' ? `<audio controls src="${u}"></audio>` : `<img src="${u}" alt="" loading="lazy">`; }).catch(() => { el.textContent = '📎'; }); });
  }
  function renderMsgs(changed, full = false) {
    const stick = nearBottom() || full;
    if (full) chatEl.innerHTML = [...S.msgs.values()].map(msgHtml).join('');
    else for (const m of changed) { const old = chatEl.querySelector(`[data-id="${m.id}"]`); const el = h(msgHtml(m)); if (old) old.replaceWith(el); else chatEl.append(el); }
    hydrateFiles(chatEl);
    const pins = [...S.msgs.values()].filter((m) => m.pinned && !m.deleted); const pe = $('[data-pins]'); pe.hidden = !pins.length; pe.innerHTML = pins.slice(-3).map((m) => `<div>📌 <b>${esc(m.name)}</b> ${esc(m.text.slice(0, 120))}</div>`).join('');
    if (stick) scrollChat();
  }
  chatEl.addEventListener('click', async (e) => {
    const li = e.target.closest('.rm-msg'); if (!li) return; const m = S.msgs.get(li.dataset.id); if (!m) return;
    const rb = e.target.closest('[data-react]'); const a = e.target.closest('[data-ma]')?.dataset.ma;
    const edit = (b) => api('POST', `/rooms/${rid}/messages/${m.id}`, b).then((r) => { S.msgs.set(r.message.id, r.message); renderMsgs([r.message]); }).catch((x) => toast(roomErr(x), 'error'));
    if (rb) return edit({ action: 'react', emoji: rb.dataset.react });
    if (a === 'react') { const pick = h(`<div class="rm-picker">${REACTIONS.map((x) => `<button type="button">${x}</button>`).join('')}</div>`); li.querySelector('.rm-bubble').append(pick); pick.addEventListener('click', (ev) => { const b = ev.target.closest('button'); if (b) { pick.remove(); edit({ action: 'react', emoji: b.textContent }); } }); return; }
    if (a === 'reply') { S.replyTo = m.id; const r = $('[data-reply]'); r.hidden = false; r.innerHTML = `↩ <b>${esc(m.name)}</b> ${esc((m.text || '📎').slice(0, 80))} <button type="button" data-x>×</button>`; $('[data-cf] textarea').focus(); return; }
    if (a === 'edit') { const t = window.prompt(L('عدّل الرسالة', 'Edit message'), m.text); if (t && t !== m.text) edit({ action: 'edit', text: t }); return; }
    if (a === 'delete') { if (window.confirm(L('تحذف الرسالة؟', 'Delete this message?'))) edit({ action: 'delete' }); return; }
    if (a === 'pin' || a === 'unpin') return edit({ action: a });
    if (a === 'report') { const reason = window.prompt(L('ليش بتبلّغ عن الرسالة؟', 'Why are you reporting this message?')); if (reason == null) return; api('POST', `/rooms/${rid}/report`, { mid: m.id, reason }).then(() => toast(L('وصل البلاغ للإدارة.', 'Report sent.'), 'success')).catch((x) => toast(roomErr(x), 'error')); }
  });
  $('[data-reply]').addEventListener('click', (e) => { if (e.target.closest('[data-x]')) { S.replyTo = null; $('[data-reply]').hidden = true; } });
  const cf = $('[data-cf]'); const ta = cf.text;
  ta.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); cf.requestSubmit(); } });
  async function send(extra = {}) {
    const text = ta.value.trim();
    if (/^\/ai\b/i.test(text) && !extra.file) { ta.value = ''; return askAi('ask', text.replace(/^\/ai\s*/i, '')); }
    if (!text && !extra.file) return;
    try {
      const r = await api('POST', `/rooms/${rid}/messages`, { text, to: cf.to.value || undefined, replyTo: S.replyTo || undefined, ...extra }, 60000);
      ta.value = ''; S.replyTo = null; $('[data-reply]').hidden = true; S.msgs.set(r.message.id, r.message); renderMsgs([r.message]); scrollChat();
    } catch (x) { toast(roomErr(x), 'error'); }
  }
  cf.addEventListener('submit', (e) => { e.preventDefault(); send(); });
  $('[data-img]').addEventListener('change', async (e) => { const f = e.target.files[0]; e.target.value = ''; if (!f) return; if (f.size > 1_500_000) return toast(roomErr('file_too_large'), 'error'); send({ file: await readFile(f) }); });
  let rec = null;
  $('[data-rec]').addEventListener('click', async (e) => {
    const b = e.currentTarget;
    if (rec) { rec.stop(); return; }
    try {
      const s = await navigator.mediaDevices.getUserMedia({ audio: true }); const type = ['audio/webm;codecs=opus', 'audio/webm', 'audio/ogg', 'audio/mp4'].find((t) => window.MediaRecorder?.isTypeSupported?.(t)) || '';
      const chunks = []; rec = new MediaRecorder(s, type ? { mimeType: type, audioBitsPerSecond: 32000 } : undefined); b.classList.add('is-rec');
      const cut = setTimeout(() => rec?.state === 'recording' && rec.stop(), 120_000);
      rec.ondataavailable = (ev) => chunks.push(ev.data);
      rec.onstop = async () => { clearTimeout(cut); s.getTracks().forEach((t) => t.stop()); b.classList.remove('is-rec'); const blob = new Blob(chunks, { type: (rec.mimeType || 'audio/webm').split(';')[0] }); rec = null; if (blob.size > 1_000_000) return toast(roomErr('file_too_large'), 'error'); if (blob.size) send({ file: await readFile(blob) }); };
      rec.start(); toast(L('عم نسجّل… اضغط مرة تانية للإرسال.', 'Recording… tap again to send.'));
    } catch { toast(L('لازم تسمح بالمايكروفون.', 'Microphone access is needed.'), 'error'); }
  });
  $('[data-sf]').addEventListener('submit', async (e) => {
    e.preventDefault(); const q = e.target.q.value.trim();
    if (!q) { S.searching = false; renderMsgs([], true); return; }
    try { const r = await api('GET', `/rooms/${rid}/search?q=${encodeURIComponent(q)}`); S.searching = true; chatEl.innerHTML = `<li class="rm-msg is-sys"><span>${r.items.length} ${L('نتيجة', 'results')} — <button type="button" class="btn btn-sm btn-ghost" data-endsearch>${L('رجوع', 'Back')}</button></span></li>${r.items.map(msgHtml).join('')}`; hydrateFiles(chatEl); }
    catch (x) { toast(roomErr(x), 'error'); }
  });
  chatEl.addEventListener('click', (e) => { if (e.target.closest('[data-endsearch]')) { S.searching = false; $('[data-sf]').q.value = ''; renderMsgs([], true); } });
  async function askAi(mode, text = '') {
    toast(L('المساعد عم يفكّر…', 'The assistant is thinking…'));
    try { const r = await api('POST', `/rooms/${rid}/ai`, { mode, text }, 90000); S.msgs.set(r.message.id, r.message); renderMsgs([r.message]); scrollChat(); } catch (x) { toast(roomErr(x), 'error'); }
  }
  $('[data-ai]').addEventListener('click', (e) => { const b = e.target.closest('[data-ai-m]'); if (!b) return; if (b.dataset.aiM === 'mentor') { const q = window.prompt(L('سؤالك للمرشد', 'Your question for the mentor')); if (q) askAi('mentor', q); } else askAi(b.dataset.aiM); });

  /* ── members ── */
  function renderMembers() {
    $('[data-count]').textContent = `${S.members.filter((m) => m.online).length}/${S.members.length}`;
    const inMeet = new Map((S.meeting?.participants || []).map((p) => [p.uid, p]));
    $('[data-members]').innerHTML = S.members.map((m) => { const p = inMeet.get(m.uid);
      return `<li class="rm-mem${m.online ? ' is-on' : ''}${p?.speaking ? ' is-speaking' : ''}" data-uid="${esc(m.uid)}">${avatar(m.name, m.uid)}<div><b>${esc(m.name)}${m.expert ? ' <span class="rm-verified">✔</span>' : ''}</b><small class="muted">${esc(roleName(m.role))}${m.muted ? ' · 🔇' : ''}${p ? ` · ${p.mic ? '🎙️' : '🔇'}${p.cam ? '📷' : ''}${p.screen ? '🖥️' : ''}${p.hand ? '✋' : ''}` : ''}</small></div>
        ${isStaff() && m.uid !== S.me?.uid && m.role !== 'owner' ? `<details class="rm-mmenu"><summary>⋯</summary><div>
          <button type="button" data-mg="${m.muted ? 'unmute' : 'mute'}">${m.muted ? L('فك الكتم', 'Unmute') : L('اكتم', 'Mute')}</button>
          ${p && p.mic ? `<button type="button" data-mg="meetmute">${L('اكتم مايكه بالاجتماع', 'Mute in meeting')}</button>` : ''}
          ${isMgr() ? `<button type="button" data-mg="role" data-role="mod">${L('خليه مشرف', 'Make moderator')}</button><button type="button" data-mg="role" data-role="member">${L('عضو عادي', 'Member')}</button>${S.me.role === 'owner' ? `<button type="button" data-mg="role" data-role="admin">${L('مشرف عام', 'Admin')}</button>` : ''}${m.expert ? `<button type="button" data-mg="role" data-role="expert">${L('خبير', 'Expert')}</button>` : ''}` : ''}
          <button type="button" data-mg="remove">${L('اطرد', 'Remove')}</button><button type="button" data-mg="block" class="down">${L('احظر', 'Block')}</button></div></details>` : ''}
        ${m.uid !== S.me?.uid ? `<button type="button" class="rm-dm" data-dm="${esc(m.uid)}" title="${esc(L('رسالة خاصة', 'Private message'))}">✉</button>` : ''}</li>`; }).join('');
    const to = cf.to; const cur = to.value; to.innerHTML = `<option value="">${L('للكل', 'Everyone')}</option>${S.members.filter((m) => m.uid !== S.me?.uid).map((m) => `<option value="${esc(m.uid)}">🔒 ${esc(m.name)}</option>`).join('')}`; to.value = cur;
    const pend = $('[data-pending]'); pend.innerHTML = (S.pending || []).length ? `<div class="rm-pend"><b>${L('طلبات انضمام', 'Join requests')}</b>${S.pending.map((p) => `<div class="rm-row"><span>${esc(p.name)}</span><button type="button" class="btn btn-sm btn-primary" data-dec="approve" data-u="${esc(p.uid)}">✔</button><button type="button" class="btn btn-sm btn-ghost" data-dec="reject" data-u="${esc(p.uid)}">✕</button></div>`).join('')}</div>` : '';
  }
  $('[data-p="people"]').addEventListener('click', async (e) => {
    const dm = e.target.closest('[data-dm]'); const mg = e.target.closest('[data-mg]'); const dec = e.target.closest('[data-dec]');
    try {
      if (dm) { cf.to.value = dm.dataset.dm; root.querySelector('[data-pane="chat"]').click(); ta.focus(); return; }
      if (dec) { await api('POST', `/rooms/${rid}/decide`, { uid: dec.dataset.u, accept: dec.dataset.dec === 'approve' }); toast('✔', 'success'); return poll(); }
      if (!mg) return; const uid = mg.closest('[data-uid]').dataset.uid;
      if (mg.dataset.mg === 'meetmute') { await meet.mute(uid); return; }
      if (['remove', 'block'].includes(mg.dataset.mg) && !window.confirm(L('متأكد؟', 'Are you sure?'))) return;
      await api('POST', `/rooms/${rid}/manage`, { uid, action: mg.dataset.mg, role: mg.dataset.role }); toast('✔', 'success'); poll();
    } catch (x) { toast(roomErr(x), 'error'); }
  });

  /* ── workspace ── */
  const cv = $('[data-chart]');
  const paintChart = () => { if (!S.ws) return; S.chartMap = drawChart(cv, S.candles, S.ws.ann || [], { live: S.live }); };
  async function loadCandles() {
    const k = `${S.ws.symbol}:${S.ws.tf}`;
    try { const r = await getHistory(S.ws.symbol, S.ws.tf, 220); if (`${S.ws.symbol}:${S.ws.tf}` !== k) return; S.candles = r.candles; $('[data-src]').textContent = `${r.mode === 'demo' ? L('بيانات تجريبية', 'demo data') : r.source?.name || r.source || ''}`; paintChart(); } catch { /* keep the old chart */ }
  }
  function renderWorkspace(force = false) {
    const ws = S.ws; if (!ws) return; const key = `${ws.symbol}:${ws.tf}`;
    $('[data-sym]').value = SYMBOLS.includes(ws.symbol) ? ws.symbol : SYMBOLS[0]; $('[data-tf]').value = ws.tf;
    $('[data-stage-t]').innerHTML = `<b>${esc(ws.symbol)}</b> · ${esc(ws.tf)}${ws.by ? ` <small class="muted">· ${L('آخر تعديل', 'last change')}: ${esc(ws.by)}</small>` : ''}`;
    $('[data-annlist]').innerHTML = (ws.ann || []).map((a) => `<li style="--c:${a.color || ANN[a.kind]?.[2]}"><b>${esc(L(ANN[a.kind][0], ANN[a.kind][1]))}</b> <span class="mono">${a.p1}${a.p2 ? ` → ${a.p2}` : ''}</span> ${esc(a.label || '')} <small class="muted">${esc(a.name)}</small>${a.by === S.me?.uid || isStaff() ? `<button type="button" data-rm="${a.id}">×</button>` : ''}</li>`).join('');
    const share = canDo('share'); $('[data-annf]').hidden = !share; $('[data-sym]').disabled = !share; $('[data-tf]').disabled = !share; $('[data-clear]').hidden = !isStaff();
    if (force || key !== S.wsKey) { S.wsKey = key; S.candles = null; paintChart(); loadCandles(); } else paintChart();
  }
  const wsPost = (b) => api('POST', `/rooms/${rid}/workspace`, b).then((r) => { S.ws = r.workspace; renderWorkspace(); }).catch((x) => toast(roomErr(x), 'error'));
  $('[data-sym]').addEventListener('change', (e) => wsPost({ symbol: e.target.value }));
  $('[data-tf]').addEventListener('change', (e) => wsPost({ tf: e.target.value }));
  let clickPts = [];
  cv.addEventListener('click', (e) => { if (!S.chartMap || !canDo('share')) return; const r = cv.getBoundingClientRect(); const p = +S.chartMap.yToPrice(e.clientY - r.top).toFixed(S.chartMap.dig + 1); const t = Math.round(S.chartMap.xToTime(e.clientX - r.left));
    const f = $('[data-annf]'); clickPts.push({ p, t }); if (clickPts.length > 2) clickPts = [clickPts[2]];
    f.p1.value = clickPts[0].p; f.p2.value = clickPts[1]?.p ?? ''; f.dataset.t1 = clickPts[0].t; f.dataset.t2 = clickPts[1]?.t ?? ''; });
  $('[data-annf]').addEventListener('submit', (e) => { e.preventDefault(); const f = e.target; const p2 = f.p2.value.trim();
    wsPost({ add: { kind: f.kind.value, p1: Number(f.p1.value), p2: p2 ? Number(p2) : null, t1: Number(f.dataset.t1) || null, t2: Number(f.dataset.t2) || null, label: f.label.value } }).then(() => { f.p1.value = ''; f.p2.value = ''; f.label.value = ''; clickPts = []; }); });
  $('[data-clear]').addEventListener('click', () => { if (window.confirm(L('تمسح كل الرسومات؟', 'Clear all drawings?'))) wsPost({ clear: true }); });
  $('[data-annlist]').addEventListener('click', (e) => { const b = e.target.closest('[data-rm]'); if (b) wsPost({ remove: b.dataset.rm }); });
  const ro = new ResizeObserver(() => paintChart()); ro.observe(cv);

  /* ── predictions ── */
  const pf = $('[data-predf]');
  pf.direction.addEventListener('change', () => { const flat = pf.direction.value === 'flat'; pf.target.hidden = flat; pf.band.hidden = !flat; });
  pf.addEventListener('submit', async (e) => {
    e.preventDefault(); const b = { symbol: pf.symbol.value, direction: pf.direction.value, horizonH: Number(pf.horizonH.value), analysis: pf.analysis.value, risk: pf.risk.value };
    if (b.direction === 'flat') b.band = Number(pf.band.value); else b.target = Number(pf.target.value);
    try { await api('POST', `/rooms/${rid}/predict`, b); toast(L('انسجّل التوقع بالسعر الحالي من السيرفر.', 'Prediction recorded at the server’s current price.'), 'success'); pf.reset(); pf.target.hidden = false; pf.band.hidden = true; poll(); } catch (x) { toast(roomErr(x), 'error'); }
  });
  function renderPreds() {
    pf.hidden = !canDo('predict');
    $('[data-preds]').innerHTML = S.preds.length ? [...S.preds].reverse().map((p) => { const open = !p.result && Date.now() < p.endsAt; const dir = { up: '⬆', down: '⬇', flat: '↔' }[p.direction];
      return `<article class="rm-pred${p.result ? (p.result.hit ? ' is-hit' : ' is-miss') : ''}">
        <div class="rm-pred-h"><b>${esc(p.symbol)} ${dir}</b> <span class="muted">${esc(p.name)} · ${when(p.at)}</span>${p.result ? `<span class="rm-badge ${p.result.hit ? 'is-hit' : 'is-miss'}">${p.result.hit ? L('تحقق ✅', 'Hit ✅') : L('ما تحقق ❌', 'Missed ❌')}</span>` : `<span class="rm-badge">${L('ينتهي', 'ends')} ${when(p.endsAt)}</span>`}</div>
        <div class="rm-pred-n mono">${L('مرجع', 'ref')} ${p.ref}${p.target ? ` → ${L('هدف', 'target')} ${p.target}` : ` ± ${p.band}%`}${p.result ? ` · ${L('النهاية', 'final')} ${p.result.price} (${p.result.movePct >= 0 ? '+' : ''}${p.result.movePct}%)` : ''}</div>
        ${p.analysis ? `<p>${esc(p.analysis)}</p>` : ''}${p.risk ? `<p class="muted">⚠ ${esc(p.risk)}</p>` : ''}
        <div class="rm-votes">${['bull', 'bear', 'neutral'].map((v) => `<button type="button" class="rm-vote${p.myVote === v ? ' is-on' : ''}" data-vote="${v}" data-pid="${p.id}"${open ? '' : ' disabled'}>${{ bull: '🐂', bear: '🐻', neutral: '😐' }[v]} ${p.votes.pct[v]}%</button>`).join('')}<small class="muted">${p.votes.total} ${L('صوت', 'votes')}</small></div>
        <small class="muted rm-hash" title="${esc(L('مصدر السعر وبصمة السجل', 'price source and record hash'))}">${esc(p.source || '')}${p.hash ? ` · #${p.hash.slice(0, 12)}` : ''}${p.result?.hash ? ` · ✔${p.result.hash.slice(0, 12)}` : ''}</small>
      </article>`; }).join('') : `<p class="muted">${L('لسا ما في توقعات بهالغرفة.', 'No predictions in this room yet.')}</p>`;
  }
  $('[data-preds]').addEventListener('click', (e) => { const b = e.target.closest('[data-vote]'); if (!b) return; api('POST', `/rooms/${rid}/vote/${b.dataset.pid}`, { vote: b.dataset.vote }).then(() => poll()).catch((x) => toast(roomErr(x), 'error')); });

  /* ── meeting UI ── */
  function renderMeeting() {
    const m = meet.active ? meet.meeting || S.meeting : S.meeting; const inM = meet.active; const st = meet.state;
    const show = (k, on) => { const b = root.querySelector(`[data-m="${k}"]`); if (b) b.hidden = !on; };
    show('join', !inM && (Boolean(m) || canDo('meet'))); root.querySelector('[data-m="join"] span').textContent = m ? L('انضم للاجتماع', 'Join meeting') : L('ابدأ اجتماع صوتي', 'Start voice meeting');
    show('startv', !inM && !m && canDo('meet')); ['mic', 'cam', 'screen', 'hand', 'leave'].forEach((k) => show(k, inM)); show('end', inM && (isStaff() || m?.by === S.me?.uid)); show('screen', inM && canDo('share'));
    const set = (k, on) => root.querySelector(`[data-m="${k}"]`)?.classList.toggle('is-off', !on); set('mic', st.mic); set('cam', st.cam); root.querySelector('[data-m="screen"]').classList.toggle('is-on', st.screen); root.querySelector('[data-m="hand"]').classList.toggle('is-on', st.hand);
    $('[data-meet-info]').innerHTML = m ? `<span class="rm-live-dot"></span> ${m.kind === 'video' ? L('اجتماع فيديو', 'Video meeting') : L('اجتماع صوتي', 'Voice meeting')} · ${m.participants.length} ${L('مشارك', 'in call')}` : `<span class="muted">${L('ما في اجتماع هلّق', 'No meeting now')}</span>`;
    // tiles + presenter
    const tiles = $('[data-tiles]'); const parts = m?.participants || [];
    if (!inM) { tiles.innerHTML = parts.length ? parts.map((p) => `<div class="rm-tile${p.speaking ? ' is-speaking' : ''}">${avatar(p.name, p.uid)}<span>${esc(p.name)} ${p.mic ? '' : '🔇'}${p.hand ? '✋' : ''}</span></div>`).join('') : ''; $('[data-present]').hidden = true; cv.hidden = false; renderMembers(); return; }
    const want = new Set(); const elFor = (key, make) => { want.add(key); let el = tiles.querySelector(`[data-k="${key}"]`); if (!el) { el = h(make()); tiles.append(el); } return el; };
    const meTile = elFor('me', () => `<div class="rm-tile is-me" data-k="me">${avatar(S.me?.name || S.members.find((x) => x.uid === S.me?.uid)?.name || '?', S.me?.uid)}<video autoplay playsinline muted></video><span>${L('إنت', 'You')}</span></div>`);
    const mv = meTile.querySelector('video'); if (meet.local && mv.srcObject !== meet.local) mv.srcObject = meet.local; meTile.classList.toggle('has-video', st.cam); meTile.classList.toggle('is-speaking', st.speaking);
    let present = null;
    for (const p of parts) {
      if (p.uid === S.me?.uid) continue; const streams = meet.remote.get(p.uid) || new Map(); const scrId = meet.screenIds.get(p.uid);
      let cam = null; for (const s of streams.values()) { if (scrId && s.id === scrId) { if (p.screen) present = s; } else cam = s; }
      const t = elFor(`u${p.uid}`, () => `<div class="rm-tile" data-k="u${esc(p.uid)}"><video autoplay playsinline></video><span></span></div>`);
      const v = t.querySelector('video'); if (cam && v.srcObject !== cam) v.srcObject = cam; t.classList.toggle('has-video', Boolean(cam?.getVideoTracks().some((x) => x.readyState === 'live')) && p.cam); t.classList.toggle('is-speaking', p.speaking);
      t.querySelector('span').textContent = `${p.name} ${p.mic ? '' : '🔇'}${p.hand ? '✋' : ''}${p.screen ? '🖥️' : ''}`;
      if (!t.querySelector('.rm-av')) t.insertAdjacentHTML('afterbegin', avatar(p.name, p.uid));
    }
    tiles.querySelectorAll('[data-k]').forEach((el) => { if (!want.has(el.dataset.k)) el.remove(); });
    const pv = $('[data-present]'); const mine = st.screen ? meet.screen : null; const src = present || mine;
    pv.hidden = !src; cv.hidden = Boolean(src); if (src && pv.srcObject !== src) pv.srcObject = src;
    renderMembers();
  }
  $('[data-controls]').addEventListener('click', async (e) => {
    const b = e.target.closest('[data-m]'); if (!b) return; const k = b.dataset.m;
    try {
      if (k === 'join' || k === 'startv') { b.disabled = true; await meet.start({ kind: k === 'startv' ? 'video' : (S.meeting?.kind || 'voice'), create: !S.meeting }); b.disabled = false; }
      else if (k === 'mic') meet.setMic(!meet.state.mic);
      else if (k === 'cam') meet.setCam(!meet.state.cam);
      else if (k === 'screen') await meet.setScreen(!meet.state.screen);
      else if (k === 'hand') meet.setHand(!meet.state.hand);
      else if (k === 'leave') meet.stop();
      else if (k === 'end') { if (window.confirm(L('تنهي الاجتماع للكل؟', 'End the meeting for everyone?'))) await meet.end(); }
      poll();
    } catch (x) { b.disabled = false; toast(x.code === 'no_webrtc' ? L('المتصفح ما بيدعم الاجتماعات.', 'This browser does not support meetings.') : roomErr(x), 'error'); }
  });

  /* ── top bar ── */
  root.querySelector('.rm-top-tools').addEventListener('click', async (e) => {
    const b = e.target.closest('[data-act]'); if (!b) return;
    try {
      if (b.dataset.act === 'fav') { await api('POST', `/rooms/${rid}/fav`, { on: !S.room.fav }); S.room.fav = !S.room.fav; b.classList.toggle('is-on', S.room.fav); }
      if (b.dataset.act === 'leave') { if (!window.confirm(L('تطلع من الغرفة؟', 'Leave this room?'))) return; meet.stop(); await api('POST', `/rooms/${rid}/leave`); location.hash = '#/app/rooms'; }
      if (b.dataset.act === 'invite') {
        const r = await api('POST', `/rooms/${rid}/invite`, { days: 7, max: 20 }); const link = `${location.origin}${r.link}`;
        modal(`<h3>${icons.plus} ${L('دعوة للغرفة', 'Room invitation')}</h3><p>${L('الكود', 'Code')}: <b class="mono rm-code">${esc(r.code)}</b></p><p>${L('رقم الغرفة', 'Room ID')}: <b class="mono">${esc(rid)}</b></p>
          <input class="input mono" readonly value="${esc(link)}"><p class="muted">${L('صالحة لـ 7 أيام و 20 استخدام.', 'Valid 7 days, 20 uses.')}</p><div class="rm-form-a"><button type="button" class="btn btn-primary" data-copy="${esc(link)}">${L('انسخ الرابط', 'Copy link')}</button></div>`);
      }
      if (b.dataset.act === 'settings') settings();
    } catch (x) { toast(roomErr(x), 'error'); }
  });
  function modal(inner) {
    const m = h(`<div class="rm-modal" role="dialog"><div class="card rm-modal-b"><button type="button" class="rm-modal-x" data-close>×</button>${typeof inner === 'string' ? inner : ''}</div></div>`);
    if (typeof inner !== 'string') m.querySelector('.rm-modal-b').append(inner);
    m.addEventListener('click', (e) => { if (e.target === m || e.target.closest('[data-close]')) m.remove(); const c = e.target.closest('[data-copy]'); if (c) navigator.clipboard?.writeText(c.dataset.copy).then(() => toast(L('انتسخ ✔', 'Copied ✔'), 'success')); });
    $('[data-modal]').replaceChildren(m); return m;
  }
  async function settings() {
    const wrap = h('<div class="rm-settings"></div>');
    wrap.append(createForm({ ...S.room, perms: S.room.perms }, () => { $('[data-modal]').replaceChildren(); poll(); }));
    const mentors = await api('GET', '/mentors').catch(() => ({ items: [] }));
    const ai = h(`<form class="card rm-sec rm-form"><h2>${icons.sparkle} ${L('الذكاء الاصطناعي بالغرفة', 'AI in this room')}</h2>
      <label class="rm-checks"><input type="checkbox" name="assistant"${S.room.ai?.assistant ? ' checked' : ''}> ${L('مساعد الغرفة (يلخص، يجاوب، يبيّن الخلافات)', 'Room assistant (summaries, answers, disagreements)')}</label>
      <label>${L('مرشد AI للغرفة', 'AI mentor for the room')}<select class="input" name="mentor"><option value="">—</option>${mentors.items.map((x) => `<option value="${x.id}"${S.room.ai?.mentor === x.id ? ' selected' : ''}>${esc(tx(x.name))}</option>`).join('')}</select></label>
      <p class="muted">${L('بيستعمل مفتاح الـAI تبع المنصة وحدود خطتك.', 'Uses the platform’s AI key and your plan limits.')}</p><button class="btn btn-primary">${L('احفظ', 'Save')}</button></form>`);
    ai.addEventListener('submit', async (e) => { e.preventDefault(); try { await api('POST', `/rooms/${rid}/aiconfig`, { assistant: ai.assistant.checked, mentor: ai.mentor.value || null }); toast('✔', 'success'); poll(); } catch (x) { toast(roomErr(x), 'error'); } });
    wrap.append(ai); modal(wrap);
  }

  /* ── polling ── */
  let busy = false; let first = true;
  async function poll() {
    if (busy) return; busy = true;
    try {
      const r = await api('GET', `/rooms/${rid}?since=${S.rev}`, undefined, 20000);
      const prevRole = S.me?.role; S.room = r.room; S.me = r.me; S.members = r.members; S.pending = r.pending; S.meeting = r.meeting;
      const changed = []; for (const m of r.messages) { S.msgs.set(m.id, m); changed.push(m); }
      if (S.msgs.size > 600) { const keep = [...S.msgs.entries()].slice(-500); S.msgs = new Map(keep); }
      S.rev = r.rev;
      $('[data-title]').innerHTML = `${avatar(r.room.name, r.room.id, 'is-room')}<div><b>${esc(r.room.name)}</b><small class="muted">${esc(specName(r.room.spec))} · ${r.room.online}/${r.room.members} ${L('متصل', 'online')} · <span class="mono">${esc(r.room.id)}</span>${r.room.suspended ? ` · <b class="down">${L('موقوفة', 'suspended')}</b>` : ''}</small></div>`;
      root.querySelector('[data-act="fav"]').classList.toggle('is-on', r.room.fav); root.querySelector('[data-act="settings"]').hidden = !isMgr();
      $('[data-ai]').hidden = !(r.room.ai?.assistant || r.room.ai?.mentor); root.querySelector('[data-mentor-btn]').hidden = !r.room.ai?.mentor;
      root.querySelectorAll('[data-ai-m="summary"],[data-ai-m="disagreements"]').forEach((x) => { x.hidden = !r.room.ai?.assistant; });
      if (!S.searching) renderMsgs(changed, first || prevRole !== S.me.role);
      if (!first && changed.some((m) => m.uid !== S.me.uid) && $('[data-layout]').dataset.show !== 'chat') $('[data-unread]').hidden = false;
      if (!S.ws || r.workspace.rev !== S.ws.rev || first) { S.ws = r.workspace; renderWorkspace(first); }
      S.preds = r.predictions; renderPreds(); renderMeeting();
      first = false;
    } catch (x) {
      if (first) { root.querySelector('[data-layout]').innerHTML = `<div class="alert alert-error">${icons.alert}<div>${esc(roomErr(x))} <a href="#/app/rooms">${L('رجوع للغرف', 'Back to rooms')}</a></div></div>`; stopAll(); }
    } finally { busy = false; }
  }
  const liveTick = async () => { if (!S.candles || !S.ws) return; try { const r = await getHistory(S.ws.symbol, S.ws.tf, 220); S.candles = r.candles; S.live = r.candles.at(-1)?.close ?? null; paintChart(); } catch { /* */ } };
  let stopped = false; const stopAll = () => { stopped = true; };
  whileMounted(root, () => { if (!stopped) poll(); }, 2000);
  whileMounted(root, () => { if (!stopped) liveTick(); }, 30000);
  poll();
  onUnmount(root, () => { stopped = true; meet.stop(); ro.disconnect(); for (const u of S.blobs.values()) URL.revokeObjectURL(u); });
  return root;
}

/* ───────────────────────── platform owners ───────────────────────── */
export function renderRoomsAdmin() {
  const root = page('rm-admin', `${pageHead('shield', L('إدارة غرف التداول', 'Trading rooms admin'), L('لأصحاب المنصة بس: الغرف، البلاغات، توثيق الخبراء والحدود.', 'Owners only: rooms, reports, expert verification and limits.'))}<div class="tool-body" data-body><div class="perf-loading"><span class="spinner"></span></div></div>`);
  const body = root.querySelector('[data-body]');
  const act = (b) => api('POST', '/rooms/admin', b).then(() => { toast('✔', 'success'); load(); }).catch((x) => toast(roomErr(x), 'error'));
  async function load() {
    try {
      const d = await api('GET', '/rooms/admin');
      body.innerHTML = `
        <div class="card rm-sec"><h2>${icons.settings} ${L('الحدود', 'Limits')}</h2><form class="rm-form rm-form-g" data-lim>
          <label>${L('غرف لكل مستخدم', 'Rooms per user')}<input class="input" type="number" name="maxRoomsPerUser" value="${d.limits.maxRoomsPerUser}"></label>
          <label>${L('أقصى أعضاء للغرفة', 'Members cap')}<input class="input" type="number" name="maxMembersCap" value="${d.limits.maxMembersCap}"></label>
          <label>${L('أقصى مشاركين بالاجتماع', 'Meeting max')}<input class="input" type="number" name="meetingMax" min="2" max="12" value="${d.limits.meetingMax}"></label>
          <label class="rm-checks"><input type="checkbox" name="aiEnabled"${d.limits.aiEnabled ? ' checked' : ''}> ${L('AI مفعّل بالغرف', 'AI enabled in rooms')}</label><button class="btn btn-primary">${L('احفظ', 'Save')}</button></form></div>
        <div class="card rm-sec"><h2>⚑ ${L('البلاغات', 'Reports')} (${d.reports.filter((x) => x.status === 'open').length})</h2>${d.reports.filter((x) => x.status === 'open').map((x) => `<div class="rm-row"><b class="mono">${esc(x.roomId)}</b><span>${esc(x.reason || '')} — <i>${esc(String(x.text || '').slice(0, 140))}</i></span><time>${when(x.at)}</time>
          <button type="button" class="btn btn-sm" data-rep="${esc(x.id)}" data-del="1">${L('احذف الرسالة', 'Delete message')}</button><button type="button" class="btn btn-sm btn-ghost" data-rep="${esc(x.id)}">${L('تجاهل', 'Dismiss')}</button></div>`).join('') || `<p class="muted">${L('ما في بلاغات مفتوحة.', 'No open reports.')}</p>`}</div>
        <div class="card rm-sec"><h2>${icons.crown} ${L('طلبات توثيق الخبراء', 'Expert requests')}</h2>${d.expertRequests.map((x) => `<div class="rm-row"><b>${esc(x.name)}</b><span>${esc(x.bio)} <small class="muted">${esc(x.markets || '')}</small></span><button type="button" class="btn btn-sm btn-primary" data-ver="${esc(x.uid)}">${L('وثّق', 'Verify')}</button></div>`).join('') || `<p class="muted">—</p>`}
          <h3>${L('الخبراء', 'Experts')}</h3>${d.experts.map((x) => `<div class="rm-row"><b>${esc(x.name)} ✔</b><span class="muted">🎯 ${x.record.hits}/${x.record.n}</span><button type="button" class="btn btn-sm btn-ghost" data-rev="${esc(x.uid)}">${L('الغِ التوثيق', 'Revoke')}</button></div>`).join('') || '<p class="muted">—</p>'}</div>
        <div class="card rm-sec"><h2>${icons.chat} ${L('كل الغرف', 'All rooms')} (${d.rooms.length})</h2><div class="rm-table-wrap"><table class="rm-table"><thead><tr><th>ID</th><th>${L('الاسم', 'Name')}</th><th>${L('المالك', 'Owner')}</th><th>${L('أعضاء', 'Members')}</th><th>${L('رسائل', 'Msgs')}</th><th>${L('توقعات', 'Preds')}</th><th>⚑</th><th></th></tr></thead><tbody>
          ${d.rooms.map((r) => `<tr><td class="mono">${esc(r.id)}</td><td>${esc(r.name)} <small class="muted">${esc(r.access)}${r.price ? ' $' : ''}</small></td><td>${esc(r.owner)}</td><td>${r.members}</td><td>${r.messages}</td><td>${r.predictions}</td><td>${r.reports || ''}</td>
            <td><button type="button" class="btn btn-sm ${r.suspended ? '' : 'btn-ghost'}" data-sus="${esc(r.id)}" data-on="${r.suspended ? 0 : 1}">${r.suspended ? L('فك الإيقاف', 'Unsuspend') : L('أوقف', 'Suspend')}</button> <a class="btn btn-sm btn-ghost" href="#/app/rooms/${esc(r.id)}">${icons.eye}</a></td></tr>`).join('')}</tbody></table></div></div>`;
      body.querySelector('[data-lim]').addEventListener('submit', (e) => { e.preventDefault(); const f = e.target; act({ action: 'limits', limits: { maxRoomsPerUser: +f.maxRoomsPerUser.value, maxMembersCap: +f.maxMembersCap.value, meetingMax: +f.meetingMax.value, aiEnabled: f.aiEnabled.checked } }); });
    } catch (x) { body.innerHTML = `<div class="alert alert-error">${icons.alert}<div>${esc(roomErr(x))}</div></div>`; }
  }
  body.addEventListener('click', (e) => {
    const s = e.target.closest('[data-sus]'); const r = e.target.closest('[data-rep]'); const v = e.target.closest('[data-ver]'); const rv = e.target.closest('[data-rev]');
    if (s) act({ action: s.dataset.on === '1' ? 'suspend' : 'unsuspend', room: s.dataset.sus });
    if (r) act({ action: 'report', id: r.dataset.rep, status: r.dataset.del ? 'resolve' : 'dismiss', deleteMessage: Boolean(r.dataset.del) });
    if (v) act({ action: 'expert', uid: v.dataset.ver });
    if (rv) act({ action: 'expert', uid: rv.dataset.rev, revoke: true });
  });
  load();
  return root;
}
