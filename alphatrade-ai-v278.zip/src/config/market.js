import { readEnv } from './env.js';

export const marketConfig = {
  // auto | demo | live
  mode: readEnv('VITE_MARKET_MODE', 'auto').toLowerCase(),
  binanceBaseUrl: readEnv('VITE_BINANCE_BASE_URL', 'https://data-api.binance.vision').replace(/\/$/, ''),
  // USDT-M futures (public): funding rates and open interest.
  binanceFuturesUrl: readEnv('VITE_BINANCE_FUTURES_URL', 'https://fapi.binance.com').replace(/\/$/, ''),
  // Real-time stream (prices every second). Alternative: wss://stream.binance.com:9443
  binanceWsUrl: readEnv('VITE_BINANCE_WS_URL', 'wss://data-stream.binance.vision').replace(/\/$/, ''),
  // Set to false to use polling only.
  streaming: readEnv('VITE_MARKET_STREAMING', 'true') !== 'false',
  // Only outside a browser (the server worker). The browser always goes through the server proxy (/api/market/twelve),
  // so a market key is never part of the public bundle.
  twelveDataKey: typeof window === 'undefined' ? readEnv('TWELVEDATA_API_KEY') : '',
  refreshSeconds: Math.max(1, Number(readEnv('VITE_MARKET_REFRESH_SECONDS', '1')) || 1),
  candleLimit: 500,
  requestTimeoutMs: 9000,
};

export const TIMEFRAMES = [
  { id: '1m', seconds: 60, binance: '1m', twelve: '1min' },
  { id: '5m', seconds: 300, binance: '5m', twelve: '5min' },
  { id: '15m', seconds: 900, binance: '15m', twelve: '15min' },
  { id: '1h', seconds: 3600, binance: '1h', twelve: '1h' },
  { id: '4h', seconds: 14400, binance: '4h', twelve: '4h' },
  { id: '1D', seconds: 86400, binance: '1d', twelve: '1day' },
];

export const DEFAULT_TIMEFRAME = '4h';
