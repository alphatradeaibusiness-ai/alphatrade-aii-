// Display names of every market for the recommendations channel's top menu (Arabic / English).
export const MARKET_NAMES = {
  BTCUSDT: ['بيتكوين', 'Bitcoin'], ETHUSDT: ['إيثريوم', 'Ethereum'], SOLUSDT: ['سولانا', 'Solana'], BNBUSDT: ['بينانس كوين', 'BNB'],
  XRPUSDT: ['ريبل', 'XRP'], DOGEUSDT: ['دوجكوين', 'Dogecoin'], ADAUSDT: ['كاردانو', 'Cardano'], AVAXUSDT: ['أفالانش', 'Avalanche'],
  LINKUSDT: ['تشينلينك', 'Chainlink'], LTCUSDT: ['لايتكوين', 'Litecoin'], TRXUSDT: ['ترون', 'TRON'], DOTUSDT: ['بولكادوت', 'Polkadot'],
  ATOMUSDT: ['كوزموس', 'Cosmos'], NEARUSDT: ['نير', 'NEAR'], SUIUSDT: ['سوي', 'Sui'], PEPEUSDT: ['بيبي', 'Pepe'],
  XAUUSD: ['الذهب', 'Gold'], XAGUSD: ['الفضة', 'Silver'], XPTUSD: ['البلاتين', 'Platinum'], COPPER: ['النحاس', 'Copper'],
  US30: ['داو جونز 30', 'Dow Jones 30'], US100: ['ناسداك 100', 'Nasdaq 100'], SPX500: ['إس آند بي 500', 'S&P 500'], UK100: ['فوتسي 100', 'FTSE 100'],
  GER40: ['داكس 40', 'DAX 40'], FRA40: ['كاك 40', 'CAC 40'], EU50: ['يورو ستوكس 50', 'Euro Stoxx 50'], JP225: ['نيكاي 225', 'Nikkei 225'],
  HK50: ['هانغ سنغ', 'Hang Seng'], AUS200: ['أستراليا 200', 'ASX 200'], SPAIN35: ['إيبكس 35', 'IBEX 35'], SWISS20: ['سويسرا 20', 'SMI 20'],
  NED25: ['هولندا 25', 'AEX 25'], KOSPI: ['كوسبي', 'KOSPI'], INDIA50: ['نيفتي 50', 'Nifty 50'],
  USOIL: ['نفط WTI', 'WTI Crude'], UKOIL: ['نفط برنت', 'Brent Crude'], NATGAS: ['الغاز الطبيعي', 'Natural Gas'],
  EURUSD: ['يورو / دولار', 'EUR/USD'], GBPUSD: ['إسترليني / دولار', 'GBP/USD'], USDJPY: ['دولار / ين', 'USD/JPY'], USDCHF: ['دولار / فرنك', 'USD/CHF'],
  AUDUSD: ['أسترالي / دولار', 'AUD/USD'], NZDUSD: ['نيوزلندي / دولار', 'NZD/USD'], USDCAD: ['دولار / كندي', 'USD/CAD'],
  EURGBP: ['يورو / إسترليني', 'EUR/GBP'], EURJPY: ['يورو / ين', 'EUR/JPY'], GBPJPY: ['إسترليني / ين', 'GBP/JPY'],
};
/** The channel's market groups, in menu order. */
export const MARKET_GROUPS = [
  { id: 'crypto', name: ['توصيات كريبتو', 'Crypto signals'] },
  { id: 'metal', name: ['توصيات الذهب والمعادن', 'Gold & metals signals'] },
  { id: 'index', name: ['توصيات المؤشرات', 'Index signals'] },
  { id: 'energy', name: ['توصيات النفط والطاقة', 'Oil & energy signals'] },
  { id: 'forex', name: ['توصيات الفوركس', 'Forex signals'] },
];
export const marketName = (symbol, en = false) => (MARKET_NAMES[symbol] || [symbol, symbol])[en ? 1 : 0];
