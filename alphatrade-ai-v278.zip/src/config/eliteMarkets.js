// v247 Alpha Elite Signals — the markets of the section and how the names traders use map to the platform's real symbols.
// Only strong, liquid indices, the precious metals, three major commodities and Bitcoin. Nothing is substituted: a name with
// no real, live instrument on the platform's providers is listed as unavailable, with the reason.
import { findInstrument } from './instruments.js';

export const ELITE_CATEGORIES = ['index', 'metal', 'commodity', 'bitcoin'];   // UI filter groups
// sub-groups of "index" kept for display: US majors / international
const M = (id, names, cat, symbol, extra = {}) => ({ id, names, cat, symbol, ...extra });
export const ELITE_MARKETS = [
  // A. Major US indices
  M('US100', ['US100', 'NAS100', 'NASDAQ100', 'Nasdaq 100'], 'index', 'US100', { region: 'us' }),
  M('US30', ['US30', 'DJ30', 'Dow Jones'], 'index', 'US30', { region: 'us' }),
  M('SPX500', ['SPX500', 'US500', 'S&P 500', 'SP500'], 'index', 'SPX500', { region: 'us' }),
  M('US2000', ['US2000', 'RUSSELL2000', 'Russell 2000'], 'index', 'US2000', { region: 'us' }),
  // The VIX index is a calculated volatility index, not a tradable price: no provider here offers a tradable VIX contract.
  M('VIX', ['VIX', 'Volatility index'], 'index', null, { region: 'us', unavailable: 'not_tradable' }),
  // B. Major international indices
  M('UK100', ['UK100', 'FTSE 100', 'FTSE100'], 'index', 'UK100', { region: 'world' }),
  M('GER40', ['GER40', 'DAX 40', 'DAX40', 'DE40'], 'index', 'GER40', { region: 'world' }),
  M('FRA40', ['FRA40', 'CAC 40', 'CAC40'], 'index', 'FRA40', { region: 'world' }),
  M('EU50', ['EU50', 'Euro Stoxx 50', 'STOXX50'], 'index', 'EU50', { region: 'world' }),
  M('JP225', ['JP225', 'Nikkei 225', 'NIKKEI225'], 'index', 'JP225', { region: 'world' }),
  M('HK50', ['HK50', 'Hang Seng', 'HSI'], 'index', 'HK50', { region: 'world' }),
  M('AUS200', ['AUS200', 'ASX 200', 'ASX200'], 'index', 'AUS200', { region: 'world' }),
  M('CH20', ['CH20', 'SWISS20', 'SMI', 'Swiss Market Index'], 'index', 'SWISS20', { region: 'world' }),
  M('SPA35', ['SPA35', 'SPAIN35', 'IBEX 35', 'IBEX35'], 'index', 'SPAIN35', { region: 'world' }),
  M('NETH25', ['NETH25', 'NED25', 'AEX'], 'index', 'NED25', { region: 'world' }),
  // C. Precious metals
  M('XAUUSD', ['XAUUSD', 'GOLD', 'Gold'], 'metal', 'XAUUSD'),
  M('XAGUSD', ['XAGUSD', 'SILVER', 'Silver'], 'metal', 'XAGUSD'),
  M('XPTUSD', ['XPTUSD', 'PLATINUM', 'Platinum'], 'metal', 'XPTUSD'),
  M('XPDUSD', ['XPDUSD', 'PALLADIUM', 'Palladium'], 'metal', 'XPDUSD'),
  // D. Commodities (kept apart from indices and precious metals)
  M('COPPER', ['COPPER', 'XCUUSD', 'HG', 'Copper'], 'commodity', 'COPPER'),
  M('WTI', ['WTI', 'USOIL', 'WTI Crude Oil', 'CL'], 'commodity', 'USOIL'),
  M('BRENT', ['BRENT', 'UKOIL', 'Brent Crude Oil', 'BZ'], 'commodity', 'UKOIL'),
  // E. Bitcoin only (BTCUSD is the same market; the platform's live Bitcoin feed is Binance BTC/USDT)
  M('BTCUSDT', ['BTCUSDT', 'BTCUSD', 'BTC', 'Bitcoin'], 'bitcoin', 'BTCUSDT'),
];

const norm = (s) => String(s || '').toUpperCase().replace(/[\s/_\-.&]/g, '');
/** A requested name ('NAS100', 'Dow Jones', 'BTCUSD'…) → the Elite market, or null. */
export function resolveEliteMarket(name) {
  const n = norm(name); if (!n) return null;
  return ELITE_MARKETS.find((m) => m.names.some((x) => norm(x) === n)) || null;
}
/** Availability of one Elite market on this platform → { ok, symbol, inst, reason } (never a substitute instrument). */
export function eliteAvailability(m) {
  if (!m) return { ok: false, symbol: null, inst: null, reason: 'unknown' };
  if (m.unavailable || !m.symbol) return { ok: false, symbol: null, inst: null, reason: m.unavailable || 'no_symbol' };
  const inst = findInstrument(m.symbol);
  if (!inst) return { ok: false, symbol: m.symbol, inst: null, reason: 'no_instrument' };
  return { ok: true, symbol: m.symbol, inst, reason: null };
}
export const eliteMarketOf = (symbol) => ELITE_MARKETS.find((m) => m.symbol === symbol) || null;
/** The asset class the AI engine and the cost model use for a market. */
export const assetOf = (inst) => ({ crypto: 'crypto', metal: 'metal', energy: 'energy', index: 'index', forex: 'forex' }[inst?.type] || 'index');
