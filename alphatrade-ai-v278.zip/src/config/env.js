// Reads Vite environment variables safely (also works in tests).
const env = (typeof import.meta !== 'undefined' && import.meta.env) || (typeof process !== 'undefined' && process.env) || {}; // browser build → Vite env; headless worker → process.env

export function readEnv(name, fallback = '') {
  const v = env[name];
  return v === undefined || v === null || v === '' ? fallback : String(v).trim();
}

export function readBool(name, fallback = false) {
  const v = readEnv(name, '');
  if (!v) return fallback;
  return /^(1|true|yes|on)$/i.test(v);
}
