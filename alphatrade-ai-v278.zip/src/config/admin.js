// Site owner(s): only these signed-in emails see the AI key page and the key status.
// Set VITE_ADMIN_EMAILS (comma separated) at build time to change it.
// Note: on a static site this hides the page in the interface. The key itself is never sent to anyone: it lives
// only in the owner's own browser. To let OTHER users use AI without ever seeing a key, put the key on the server
// (ANTHROPIC_API_KEY for the Node server) — then nothing about the key reaches any browser.
import { readEnv } from './env.js';
import { auth } from '../services/auth/index.js';

export const ADMIN_EMAILS = String(readEnv('VITE_ADMIN_EMAILS', 'shheahmad417@gmail.com'))
  .split(',').map((s) => s.trim().toLowerCase()).filter(Boolean);

export function isAdmin(user = auth.current()) {
  const email = String(user?.email || '').trim().toLowerCase();
  return Boolean(email) && ADMIN_EMAILS.includes(email);
}
