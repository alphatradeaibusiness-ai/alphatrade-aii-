// Subscription plans and payment links.
//
// Prices are in USD. Each plan opens a hosted checkout page (a "payment link")
// from your payment provider — e.g. Stripe Payment Links, Lemon Squeezy, Paddle
// or PayPal. Paste each link into .env; a plan without a link shows a clear
// "payment not configured yet" message instead of pretending to charge.
//
// Activating access automatically after payment needs a backend (webhook) and
// is not done by this static site.
import { readEnv } from './env.js';

export const PLANS = [
  { id: 'monthly', months: 1, price: 80, link: readEnv('VITE_PAY_LINK_MONTHLY') },
  { id: 'quarterly', months: 3, price: 190, link: readEnv('VITE_PAY_LINK_3M') },
  { id: 'semiannual', months: 6, price: 350, link: readEnv('VITE_PAY_LINK_6M') },
  { id: 'annual', months: 12, price: 650, link: readEnv('VITE_PAY_LINK_12M'), best: true },
  // v276: three premium yearly plans above "annual". Each unlocks the pages listed in NAV_RANK (src/config/entitlements.js).
  { id: 'prime', months: 12, price: 750, link: readEnv('VITE_PAY_LINK_PRIME'), premium: true },
  { id: 'apex', months: 12, price: 850, link: readEnv('VITE_PAY_LINK_APEX'), premium: true },
  { id: 'max', months: 12, price: 1000, link: readEnv('VITE_PAY_LINK_MAX'), premium: true },
];

export const BASE_MONTHLY = PLANS[0].price;

/** Price per month and saving versus paying monthly, rounded to whole numbers. */
export function planMath(plan) {
  const perMonth = plan.price / plan.months;
  const full = BASE_MONTHLY * plan.months;
  const saving = Math.max(0, full - plan.price);   // premium plans cost more than 12 × monthly: no fake "saving"
  return { perMonth, saving, savingPct: Math.round((saving / full) * 100) };
}
