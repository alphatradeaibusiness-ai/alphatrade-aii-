import { readEnv, readBool } from './env.js';

// Authentication configuration. Firebase is used only when all core keys exist.
const firebase = {
  apiKey: readEnv('VITE_FIREBASE_API_KEY'),
  authDomain: readEnv('VITE_FIREBASE_AUTH_DOMAIN'),
  projectId: readEnv('VITE_FIREBASE_PROJECT_ID'),
  appId: readEnv('VITE_FIREBASE_APP_ID'),
};

const firebaseConfigured = Boolean(firebase.apiKey && firebase.authDomain && firebase.projectId && firebase.appId);

export const authConfig = {
  firebase,
  firebaseConfigured,
  // Google / Apple need Firebase plus the provider enabled in the Firebase console.
  providers: {
    google: firebaseConfigured && readBool('VITE_AUTH_GOOGLE_ENABLED'),
    apple: firebaseConfigured && readBool('VITE_AUTH_APPLE_ENABLED'),
  },
  minPasswordLength: 8,
};
