// Pure indicator calculations. Every function takes plain candle arrays:
// { time, open, high, low, close, volume, buyVolume } — volume / buyVolume may be null.

/** Exponential moving average. Returns an array aligned with `values` (null until seeded). */
export function ema(values, period) {
  const out = new Array(values.length).fill(null);
  if (period < 1 || values.length < period) return out;
  const k = 2 / (period + 1);
  let prev = values.slice(0, period).reduce((a, b) => a + b, 0) / period;
  out[period - 1] = prev;
  for (let i = period; i < values.length; i++) {
    prev = values[i] * k + prev * (1 - k);
    out[i] = prev;
  }
  return out;
}

/** Wilder's RSI. Returns array aligned with `closes` (null for the first `period` values). */
export function rsi(closes, period = 14) {
  const out = new Array(closes.length).fill(null);
  if (period < 1 || closes.length <= period) return out;
  let gain = 0;
  let loss = 0;
  for (let i = 1; i <= period; i++) {
    const ch = closes[i] - closes[i - 1];
    if (ch >= 0) gain += ch; else loss -= ch;
  }
  let avgG = gain / period;
  let avgL = loss / period;
  const calc = () => (avgL === 0 ? (avgG === 0 ? 50 : 100) : 100 - 100 / (1 + avgG / avgL));
  out[period] = calc();
  for (let i = period + 1; i < closes.length; i++) {
    const ch = closes[i] - closes[i - 1];
    avgG = (avgG * (period - 1) + Math.max(ch, 0)) / period;
    avgL = (avgL * (period - 1) + Math.max(-ch, 0)) / period;
    out[i] = calc();
  }
  return out;
}

/** Average true range (Wilder). Values before the first full period are null. */
export function atr(candles, period = 14) {
  const out = new Array(candles.length).fill(null);
  let a = null;
  for (let i = 1; i < candles.length; i++) {
    const c = candles[i];
    const pc = candles[i - 1].close;
    const tr = Math.max(c.high - c.low, Math.abs(c.high - pc), Math.abs(c.low - pc));
    a = a == null ? tr : (a * (period - 1) + tr) / period;
    if (i >= period) out[i] = a;
  }
  return out;
}

/** Bollinger Bands (SMA ± mult × population standard deviation of the closes). Values before the first full period are null. */
export function bollinger(closes, period = 20, mult = 2) {
  const n = closes.length;
  const mid = new Array(n).fill(null); const upper = new Array(n).fill(null); const lower = new Array(n).fill(null);
  const p = Math.max(2, Math.floor(period));
  for (let i = p - 1; i < n; i++) {
    let sum = 0;
    for (let j = i - p + 1; j <= i; j++) sum += closes[j];
    const m = sum / p;
    let v = 0;
    for (let j = i - p + 1; j <= i; j++) v += (closes[j] - m) ** 2;
    const sd = Math.sqrt(v / p);
    mid[i] = m; upper[i] = m + mult * sd; lower[i] = m - mult * sd;
  }
  return { mid, upper, lower };
}

export const FIB_RATIOS = [0, 0.236, 0.382, 0.5, 0.618, 0.786, 1];

/** Find the highest high and lowest low in the last `lookback` candles. */
export function autoFibAnchors(candles, lookback = 120) {
  if (!candles.length) return null;
  const start = Math.max(0, candles.length - lookback);
  let hi = start;
  let lo = start;
  for (let i = start; i < candles.length; i++) {
    if (candles[i].high > candles[hi].high) hi = i;
    if (candles[i].low < candles[lo].low) lo = i;
  }
  return { high: candles[hi].high, highTime: candles[hi].time, low: candles[lo].low, lowTime: candles[lo].time };
}

/**
 * Fibonacci retracement levels. Convention used across the UI (as in the reference):
 * level 0 = swing high, level 1 = swing low; price = high − ratio × (high − low).
 */
export function fibLevels(high, low, ratios = FIB_RATIOS) {
  if (!Number.isFinite(high) || !Number.isFinite(low) || high <= low) return [];
  const range = high - low;
  return ratios.map((r) => ({ ratio: r, price: high - r * range }));
}

/** Sell zone near the high (0 → 0.236) and buy zone near the low (0.786 → 1). */
export function fibZones(high, low) {
  if (!Number.isFinite(high) || !Number.isFinite(low) || high <= low) return null;
  const range = high - low;
  return {
    sell: { top: high, bottom: high - 0.236 * range },
    buy: { top: high - 0.786 * range, bottom: low },
  };
}

/**
 * Volume profile between candle indexes [from, to] (inclusive).
 * Each candle's volume is spread over the bins its high–low range overlaps, in
 * proportion to the overlap (a standard approximation when tick data is unavailable).
 */
export function volumeProfile(candles, { rows = 40, from = 0, to = candles.length - 1, valueAreaPct = 70 } = {}) {
  const slice = candles.slice(Math.max(0, from), Math.min(candles.length - 1, to) + 1).filter((c) => Number.isFinite(c.volume));
  if (!slice.length || rows < 2) return null;
  let min = Infinity;
  let max = -Infinity;
  for (const c of slice) { if (c.low < min) min = c.low; if (c.high > max) max = c.high; }
  if (!(max > min)) max = min + Math.max(Math.abs(min) * 1e-6, 1e-8);
  const step = (max - min) / rows;
  const bins = Array.from({ length: rows }, (_, i) => ({ low: min + i * step, high: min + (i + 1) * step, volume: 0, buy: 0, sell: 0 }));
  for (const c of slice) {
    const range = c.high - c.low;
    const buyShare = Number.isFinite(c.buyVolume) && c.volume > 0 ? c.buyVolume / c.volume : (c.close >= c.open ? 1 : 0);
    const first = Math.max(0, Math.min(rows - 1, Math.floor((c.low - min) / step)));
    const last = Math.max(0, Math.min(rows - 1, Math.floor((c.high - min) / step)));
    for (let b = first; b <= last; b++) {
      const overlap = range > 0 ? (Math.min(c.high, bins[b].high) - Math.max(c.low, bins[b].low)) / range : 1 / (last - first + 1);
      if (overlap <= 0) continue;
      const v = c.volume * overlap;
      bins[b].volume += v;
      bins[b].buy += v * buyShare;
      bins[b].sell += v * (1 - buyShare);
    }
  }
  const total = bins.reduce((a, b) => a + b.volume, 0);
  let pocIdx = 0;
  bins.forEach((b, i) => { if (b.volume > bins[pocIdx].volume) pocIdx = i; });
  // Value area: expand from the POC towards the larger neighbour until valueAreaPct of volume is covered.
  let lo = pocIdx;
  let hi = pocIdx;
  let acc = bins[pocIdx].volume;
  const target = (total * valueAreaPct) / 100;
  while (acc < target && (lo > 0 || hi < rows - 1)) {
    const down = lo > 0 ? bins[lo - 1].volume : -1;
    const up = hi < rows - 1 ? bins[hi + 1].volume : -1;
    if (up >= down) { hi++; acc += bins[hi].volume; } else { lo--; acc += bins[lo].volume; }
  }
  return {
    bins, total, min, max, step,
    maxVolume: bins[pocIdx].volume,
    poc: (bins[pocIdx].low + bins[pocIdx].high) / 2,
    vah: bins[hi].high, val: bins[lo].low, vaFrom: lo, vaTo: hi,
    fromTime: slice[0].time, toTime: slice[slice.length - 1].time, count: slice.length,
  };
}

/**
 * Buyer / seller volume per candle.
 * volumeKind: 'taker' | 'synthetic' → use buyVolume; 'estimated' → close-location estimate; 'none' → null.
 */
export function pressureSeries(candles, volumeKind) {
  if (volumeKind === 'none') return null;
  return candles.map((c) => {
    const vol = Number.isFinite(c.volume) ? c.volume : 0;
    let buy;
    if ((volumeKind === 'taker' || volumeKind === 'synthetic') && Number.isFinite(c.buyVolume)) {
      buy = c.buyVolume;
    } else {
      const range = c.high - c.low;
      buy = range > 0 ? vol * ((c.close - c.low) / range) : vol / 2;
    }
    const sell = Math.max(0, vol - buy);
    return { time: c.time, buy, sell, delta: buy - sell };
  });
}

export function pressureTotals(series, window = 50) {
  if (!series || !series.length) return null;
  const part = series.slice(-window);
  const buy = part.reduce((a, p) => a + p.buy, 0);
  const sell = part.reduce((a, p) => a + p.sell, 0);
  const total = buy + sell;
  if (!(total > 0)) return null;
  return { buy, sell, buyPct: (buy / total) * 100, sellPct: (sell / total) * 100, bars: part.length };
}

/** Share of upward price movement in the window — used when no volume is available. */
export function priceDirectionShare(candles, window = 50) {
  const part = candles.slice(-window - 1);
  let up = 0;
  let down = 0;
  for (let i = 1; i < part.length; i++) {
    const ch = part[i].close - part[i - 1].close;
    if (ch > 0) up += ch; else down -= ch;
  }
  const total = up + down;
  return total > 0 ? { buyPct: (up / total) * 100, sellPct: (down / total) * 100 } : { buyPct: 50, sellPct: 50 };
}

/**
 * Combined momentum score 0–100 from RSI, EMA trend and buyer pressure.
 * Weights: RSI 40%, trend 30%, pressure 30% (re-normalised when pressure is unavailable).
 */
export function momentumScore({ candles, rsiValues, pressure }) {
  if (!candles || candles.length < 60) return null;
  const closes = candles.map((c) => c.close);
  const e20 = ema(closes, 20);
  const e50 = ema(closes, 50);
  const last = closes.length - 1;
  const r = rsiValues?.[last];
  const c = closes[last];
  let trend = 50;
  if (e20[last] !== null && e50[last] !== null) {
    if (c > e20[last] && e20[last] > e50[last]) trend = 85;
    else if (c < e20[last] && e20[last] < e50[last]) trend = 15;
    else if (c > e20[last]) trend = 65;
    else if (c < e20[last]) trend = 35;
  }
  const parts = [];
  if (Number.isFinite(r)) parts.push([r, 0.4]);
  parts.push([trend, 0.3]);
  if (pressure && Number.isFinite(pressure.buyPct)) parts.push([pressure.buyPct, 0.3]);
  const wsum = parts.reduce((a, [, w]) => a + w, 0);
  const score = parts.reduce((a, [v, w]) => a + v * w, 0) / wsum;
  let descKey = 'sideways';
  if (score >= 70) descKey = 'strongUp';
  else if (score >= 55) descKey = 'upLikely';
  else if (score <= 30) descKey = 'strongDown';
  else if (score <= 45) descKey = 'downLikely';
  const label = score > 55 ? 'positive' : score < 45 ? 'negative' : 'neutral';
  return { score, label, descKey, rsi: r, trend, ema20: e20[last], ema50: e50[last] };
}

/**
 * Trading plan with fixed point distances:
 *   stop   = `slPoints` points from entry, on the opposite side of the trade;
 *   target = `tpPoints[i]` points from entry, in the trade's direction
 *            (default 50 / 80 / 130 — NOT multiples of the stop distance).
 * One point = `pointSize` in price units for the instrument.
 */
export function tradingPlan({ entry, direction, pointSize, slPoints = 30, tpPoints = [50, 80, 130] }) {
  if (!Number.isFinite(entry) || !(pointSize > 0)) return null;
  const dir = direction === 'short' ? 'short' : 'long';
  const sign = dir === 'long' ? 1 : -1;
  const distance = slPoints * pointSize;
  return {
    direction: dir,
    entry,
    stop: entry - sign * distance,
    distance,
    points: slPoints,
    pointSize,
    targets: tpPoints.map((pts) => entry + sign * pts * pointSize),
    targetPoints: tpPoints,
    targetDistances: tpPoints.map((pts) => pts * pointSize),
  };
}
