// Automatic support and resistance.
//  1. Confirmed swing highs/lows (pivots with `len` candles on each side).
//  2. Pivots closer than a tolerance (a fraction of ATR) are clustered into one level.
//  3. Each level is scored: number of touches, how recent the last touch is, whether price
//     reacted (bounced) from it, the volume at the pivots, and role reversal (old resistance
//     that became support, or the opposite).
//  4. Levels below the price are supports, above are resistances; strength 1–5.
import { atr } from './index.js';

function pivots(candles, len) {
  const out = [];
  for (let i = len; i < candles.length - len; i++) {
    let hi = true; let lo = true;
    for (let k = 1; k <= len && (hi || lo); k++) {
      if (candles[i - k].high >= candles[i].high || candles[i + k].high > candles[i].high) hi = false;
      if (candles[i - k].low <= candles[i].low || candles[i + k].low < candles[i].low) lo = false;
    }
    if (hi) out.push({ type: 'high', price: candles[i].high, index: i, time: candles[i].time, volume: candles[i].volume || 0 });
    if (lo) out.push({ type: 'low', price: candles[i].low, index: i, time: candles[i].time, volume: candles[i].volume || 0 });
  }
  return out;
}

/**
 * @returns {{ price:number, tol:number, atr:number, supports:Level[], resistances:Level[], all:Level[] }}
 * Level = { price, low, high, role:'support'|'resistance', touches, lastTime, lastIndex, flip, strength (1–5), score, distPct }
 */
export function supportResistance(candles, { len = 5, tolAtr = 0.6, maxPerSide = 5 } = {}) {
  if (!candles || candles.length < len * 4 + 20) return null;
  const n = candles.length;
  const a = atr(candles, 14);
  const lastAtr = a[n - 1] || a.filter(Boolean).at(-1);
  const price = candles[n - 1].close;
  const tol = Math.max(lastAtr * tolAtr, price * 0.0012);
  const piv = pivots(candles, len).sort((x, y) => x.price - y.price);
  const avgVol = candles.reduce((s, c) => s + (c.volume || 0), 0) / n || 1;

  // Greedy clustering on price.
  const clusters = [];
  for (const p of piv) {
    const c = clusters.at(-1);
    if (c && p.price - c.sum / c.items.length <= tol) { c.items.push(p); c.sum += p.price; } else clusters.push({ items: [p], sum: p.price });
  }

  const levels = clusters.map((c) => {
    const items = c.items;
    // Recent pivots weigh more in the level's price.
    let w = 0; let pw = 0;
    for (const p of items) { const wt = 1 + p.index / n; w += wt; pw += p.price * wt; }
    const lvl = pw / w;
    const last = items.reduce((m, p) => (p.index > m.index ? p : m), items[0]);
    const highs = items.filter((p) => p.type === 'high').length;
    const lows = items.length - highs;
    // Reactions: candles that pierced the zone with a wick but closed back on the far side.
    let reactions = 0;
    for (let i = Math.max(0, n - 300); i < n; i++) {
      const k = candles[i];
      if (k.low <= lvl + tol / 2 && k.low >= lvl - tol && k.close > lvl + tol / 2) reactions++;
      else if (k.high >= lvl - tol / 2 && k.high <= lvl + tol && k.close < lvl - tol / 2) reactions++;
    }
    const vol = items.reduce((s, p) => s + p.volume, 0) / items.length / avgVol;
    const recency = last.index / n; // 0 old … 1 now
    const score = items.length * 1.2 + Math.min(reactions, 8) * 0.35 + recency * 2 + (Number.isFinite(vol) ? Math.min(vol, 3) * 0.4 : 0) + (highs && lows ? 1 : 0);
    return {
      price: lvl, low: lvl - tol / 2, high: lvl + tol / 2, role: lvl < price ? 'support' : 'resistance', touches: items.length, reactions,
      lastTime: last.time, lastIndex: last.index, flip: highs > 0 && lows > 0, score, distPct: ((lvl - price) / price) * 100,
    };
  });

  // Strength 1–5 relative to the best level on the chart.
  const top = Math.max(1, ...levels.map((l) => l.score));
  for (const l of levels) l.strength = Math.max(1, Math.min(5, Math.round((l.score / top) * 5)));
  // Keep the nearest meaningful levels on each side (a lone old pivot far away adds noise).
  const useful = levels.filter((l) => l.touches >= 2 || l.lastIndex > n - 120);
  const supports = useful.filter((l) => l.role === 'support').sort((x, y) => y.price - x.price).slice(0, maxPerSide);
  const resistances = useful.filter((l) => l.role === 'resistance').sort((x, y) => x.price - y.price).slice(0, maxPerSide);
  return { price, tol, atr: lastAtr, supports, resistances, all: [...resistances.slice().reverse(), ...supports] };
}

/** Marks levels that also exist on other timeframes (within the larger tolerance). */
export function confluence(byTf) {
  const tfs = Object.keys(byTf).filter((k) => byTf[k]);
  for (const tf of tfs) {
    for (const l of byTf[tf].all) {
      l.tfs = [tf];
      for (const o of tfs) {
        if (o === tf) continue;
        const tol = Math.max(byTf[o].tol, byTf[tf].tol);
        if (byTf[o].all.some((m) => Math.abs(m.price - l.price) <= tol)) l.tfs.push(o);
      }
    }
  }
  return byTf;
}
