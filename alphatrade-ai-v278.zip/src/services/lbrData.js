// Deep 5-minute history for the London Breakout (LBR) proof. LBR trades about 8 times a month, so it needs months of 5-minute candles
// to reach MIN_TRADES — far more than the 1000 candles of the other tests. Binance pages 1000 candles per request; one load is shared
// for 30 minutes. Other providers cannot go this deep, so LBR has no proof (and publishes nothing) there.
import { getHistory } from './market/index.js';
import { getInstrument } from '../config/instruments.js';

export const LBR_BARS = 45000;   // ≈ 156 days of 5-minute candles
const TTL = 30 * 60_000;
const cache = new Map();

/** Resolves to a live dataset with at least 5000 candles, or null. */
export function lbrHistory(symbol) {
  if (getInstrument(symbol)?.provider !== 'binance') return Promise.resolve(null);
  const c = cache.get(symbol);
  if (c && Date.now() - c.at < TTL) return c.job;
  const job = getHistory(symbol, '5m', LBR_BARS).then((ds) => (ds?.mode === 'live' && ds.candles?.length >= 5000 ? ds : null)).catch(() => null);
  cache.set(symbol, { at: Date.now(), job });
  job.then((ds) => { if (!ds && cache.get(symbol)?.job === job) cache.delete(symbol); });
  return job;
}
