// Risk guard for the signals channel and chart notifications. A new signal is held
// back when: the day's realised loss reached the limit, too many losses in a row, too many signals
// already open (or too many correlated ones in the same direction), or a high-impact news event is
// close. Pure logic — the caller supplies the signals, the settings, the clock and the calendar.

export const GUARD_DEFAULTS = { dailyLossPts: 0, monthlyLossPts: 0, enabled: true, dailyLossR: 3, maxActive: 0, maxCorrelated: 2, newsMinutes: 30, streakPause: 3, derivFilter: true, accountSize: 1000, riskPct: 1, dailyLossPct: 2, corrDynamic: true, corrLimit: 0.75 };
export const CRYPTO_GROUP = ['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'BNBUSDT'];
import { getInstrument } from '../config/instruments.js';

const DAY = 86400_000;
const dayStart = (ms) => Math.floor(ms / DAY) * DAY;

/** Realised result of a closed signal in R (risk units). A third of the position leaves at each target. */
export function signalR(s) {
  const risk = Math.abs(s.entry - s.stop);
  if (!(risk > 0) || s.status === 'active') return 0;
  const sign = s.direction === 'long' ? 1 : -1;
  if (s.status === 'sl') return -1;
  let r = 0;
  for (let k = 0; k < Math.min(3, s.hits || 0); k++) r += (Math.abs(s.targets[k] - s.entry) / risk) / 3;
  return r; // 'be' / 'tp3': the rest left at the entry (0) or at TP3 (counted above)
}

/** Realised result of a closed signal in points (a third of the position leaves at each target). */
export function signalPts(s, pointSize) {
  const ps = pointSize > 0 ? pointSize : (getInstrument(s.symbol)?.pointSize || 1);
  const risk = Math.abs(s.entry - s.stop);
  if (!(risk > 0) || s.status === 'active') return 0;
  if (s.status === 'sl') return -risk / ps;
  let pts = 0;
  for (let k = 0; k < Math.min(3, s.hits || 0); k++) pts += Math.abs(s.targets[k] - s.entry) / ps / 3;
  return pts;
}

/** What the guard says about the day so far (no candidate signal). */
export function guardState(signals, cfg, now = Date.now()) {
  const c = { ...GUARD_DEFAULTS, ...cfg };
  const today = signals.filter((s) => s.status !== 'active' && s.closedAt && s.closedAt >= dayStart(now));
  const dailyR = today.reduce((a, s) => a + signalR(s), 0);
  // Circuit breaker: the account-% limit expressed in R (2% daily limit / 1% risk per trade = 2R); falls back to dailyLossR
  const limitR = c.dailyLossPct > 0 && c.riskPct > 0 ? c.dailyLossPct / c.riskPct : c.dailyLossR;
  const mStart = (() => { const d = new Date(now); return Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), 1); })();
  const monthPts = signals.filter((s) => s.status !== 'active' && s.closedAt && s.closedAt >= mStart).reduce((a, s) => a + signalPts(s), 0);
  const dayPts = today.reduce((a, s) => a + signalPts(s), 0);
  const recent = [...today].sort((a, b) => b.closedAt - a.closedAt);
  let streak = 0;
  for (const s of recent) { if (s.status === 'sl') streak++; else break; }
  const active = signals.filter((s) => s.status === 'active');
  return { dayPts, monthPts, dailyR, limitR, dailyPct: dailyR * (c.riskPct || 0), streak, active: active.length, closedToday: today.length, c, activeList: active };
}

/**
 * @param candidate { symbol, direction }
 * @param events    calendar events [{ title, country, time(ms), impact }] (optional)
 * @param impact    { USD: ['XAUUSD', …] } currency → affected symbols
 * @param deriv     result of derivCheck() from derivatives.js (optional)
 * @returns { ok:true } | { ok:false, key:'daily'|'monthly'|'streak'|'active'|'corr'|'news'|'deriv', params }
 */
export function guardCheck({ signals, candidate, cfg, now = Date.now(), events = [], impact = {}, deriv = null, corr = null }) {
  const g = guardState(signals, cfg, now);
  const c = g.c;
  if (!c.enabled) return { ok: true, state: g };
  if (g.limitR > 0 && g.dailyR <= -g.limitR) return { ok: false, key: 'daily', params: { r: +g.limitR.toFixed(2), pct: +(g.limitR * c.riskPct).toFixed(2) }, state: g };
  if (c.dailyLossPts > 0 && Math.max(0, -g.dayPts) + (Number(candidate.riskPts) || 0) > c.dailyLossPts) return { ok: false, key: 'dailyPts', params: { cap: c.dailyLossPts, lost: Math.round(Math.max(0, -g.dayPts)) }, state: g };
  const cap = Number(c.monthlyLossBySymbol?.[candidate.symbol]) > 0 ? Number(c.monthlyLossBySymbol[candidate.symbol]) : c.monthlyLossPts;
  if (cap > 0) {
    // block when the month's realised loss plus the worst case of this signal (its full stop) would pass the cap
    const lost = Math.max(0, -g.monthPts); const cand = Number(candidate.riskPts) || 0;
    if (lost + cand > cap) return { ok: false, key: 'monthly', params: { cap, lost: Math.round(lost) }, state: g };
  }
  if (c.streakPause > 0 && g.streak >= c.streakPause) return { ok: false, key: 'streak', params: { n: g.streak }, state: g };
  if (c.maxActive > 0 && g.active >= c.maxActive) return { ok: false, key: 'active', params: { n: c.maxActive }, state: g };
  if (c.maxCorrelated > 0 && CRYPTO_GROUP.includes(candidate.symbol)) {
    const same = g.activeList.filter((s) => CRYPTO_GROUP.includes(s.symbol) && s.direction === candidate.direction).length;
    if (same >= c.maxCorrelated) return { ok: false, key: 'corr', params: { n: same }, state: g };
  }
  if (c.newsMinutes > 0) {
    const win = c.newsMinutes * 60_000;
    const hit = events.find((e) => String(e.impact).toLowerCase() === 'high' && Math.abs(e.time - now) <= win
      && (impact[e.country] || impact.ALL || []).includes(candidate.symbol));
    if (hit) return { ok: false, key: 'news', params: { m: c.newsMinutes, title: hit.title }, state: g };
  }
  // statistical correlation with an open signal on another symbol (same direction, or opposite with negative correlation)
  if (c.corrDynamic !== false && corr) return { ok: false, key: 'corrDyn', params: { sym: corr.symbol, r: +corr.r.toFixed(2) }, state: g };
  // futures positioning (funding / open interest): crowded side or a liquidation sweep just happened
  if (c.derivFilter !== false && deriv && deriv.ok === false) return { ok: false, key: 'deriv', params: { why: deriv.key, f: deriv.params?.f }, state: g };
  return { ok: true, state: g };
}
