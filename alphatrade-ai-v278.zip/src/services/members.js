// Members features in the page: sign-in alert trigger, message centre (bell), referral claim, settings sync between devices.
import { auth } from './auth/index.js';
import { apiRequest } from './ai/gateway.js';
import { storage } from '../utils/storage.js';
import { getLang } from '../i18n/index.js';

const api = (m, p, b, ms = 15000) => apiRequest(m, p, b, ms);
const listeners = new Set();
let state = { items: [], unread: 0, broadcast: null, ok: false };
let timer = 0; let started = null;
export const noticeState = () => state;
export const onNotices = (fn) => { listeners.add(fn); return () => listeners.delete(fn); };
const emit = () => listeners.forEach((fn) => { try { fn(state); } catch { /* */ } });

/** "iPhone · Safari", "Windows · Chrome"… (only the kind of device — no fingerprinting). */
export function deviceName(ua = navigator.userAgent) {
  const os = /iPhone/.test(ua) ? 'iPhone' : /iPad/.test(ua) ? 'iPad' : /Android/.test(ua) ? 'Android' : /Windows/.test(ua) ? 'Windows' : /Mac OS X|Macintosh/.test(ua) ? 'Mac' : /Linux/.test(ua) ? 'Linux' : 'Device';
  const br = /Edg\//.test(ua) ? 'Edge' : /SamsungBrowser/.test(ua) ? 'Samsung' : /OPR\//.test(ua) ? 'Opera' : /Firefox\//.test(ua) ? 'Firefox' : /CriOS|Chrome\//.test(ua) ? 'Chrome' : /Safari\//.test(ua) ? 'Safari' : 'Browser';
  return `${os} · ${br}`;
}

export async function refreshNotices() {
  if (!auth.current()?.uid) return state;
  try { const r = await api('GET', '/api/me/notices'); state = { ...r, ok: true }; } catch { state = { ...state, ok: false }; }
  emit(); return state;
}
export async function markNoticesRead(id = null) {
  state = { ...state, items: state.items.map((n) => (!id || n.id === id ? { ...n, read: true } : n)), unread: id ? Math.max(0, state.unread - 1) : 0 }; emit();
  try { await api('POST', '/api/me/notices/read', id ? { id } : {}); } catch { /* next refresh fixes it */ }
}
export async function dismissBroadcast(id) { state = { ...state, broadcast: null }; emit(); try { await api('POST', '/api/me/broadcast/dismiss', { id }); } catch { /* */ } }

/* ── settings sync: a small set of preferences follows the account to every device ── */
const SYNC_KEYS = () => { const uid = auth.current()?.uid || 'guest'; return ['settings', 'symbol', 'theme', 'lang', `assist-settings:${uid}`, `assist-watch:${uid}`, 'alerts', 'radar-rules', 'academy-done']; };
let pushTimer = 0; let applying = false;
function collect() { const out = {}; for (const k of SYNC_KEYS()) { const v = storage.get(k, undefined); if (v !== undefined) out[k] = v; } return out; }
async function pushSync() { const ts = Date.now(); storage.set('sync-ts', ts); try { await api('PUT', '/api/me/sync', { data: collect(), ts }); } catch { /* offline */ } }
async function pullSync() {
  try {
    const { sync } = await api('GET', '/api/me/sync');
    const local = Number(storage.get('sync-ts', 0)) || 0;
    if (sync?.data && sync.ts > local) {
      applying = true;
      for (const [k, v] of Object.entries(sync.data)) if (SYNC_KEYS().includes(k)) storage.set(k, v);
      storage.set('sync-ts', sync.ts); applying = false;
      return true;   // the caller re-renders with the synced settings
    }
    if (!sync) pushSync();
  } catch { /* server not reachable */ }
  return false;
}

/** Once per page load, after sign-in: report the sign-in (server sends the alert), claim a referral, sync, start the bell. */
export function startMembers({ onSynced } = {}) {
  const uid = auth.current()?.uid; if (!uid || auth.mode === 'local') return () => {};
  if (started === uid) return () => {};
  started = uid;
  api('POST', '/api/me/signin', { device: deviceName(), lang: getLang() }).catch(() => {});
  const ref = storage.get('ref-code', null);
  if (ref) api('POST', '/api/me/referral', { code: ref }).finally(() => storage.remove('ref-code')).catch(() => {});
  flushPhone();
  pullSync().then((changed) => { if (changed) onSynced?.(); });
  const off = storage.onSet((k) => { if (applying || k === 'sync-ts' || !SYNC_KEYS().includes(k)) return; clearTimeout(pushTimer); pushTimer = setTimeout(pushSync, 4000); });
  refreshNotices(); clearInterval(timer); timer = setInterval(refreshNotices, 60_000);
  const vis = () => { if (document.visibilityState === 'visible') refreshNotices(); };
  document.addEventListener('visibilitychange', vis);
  return () => { off(); clearInterval(timer); document.removeEventListener('visibilitychange', vis); started = null; };
}
/** Remember ?ref=CODE from an invite link until the person has signed in. */
export function rememberReferral() { const m = /[?&]ref=([A-Za-z0-9]{4,12})/.exec(location.hash || ''); if (m) storage.set('ref-code', m[1].toUpperCase()); }

/* ── phone number from the sign-up form (v228): kept per account until the server has it (the server re-validates it) ── */
const phoneKey = (uid) => `phone-pending:${uid}`;
/** Saves the validated number { e164, iso } for the signed-in account; retried on the next sign-in if the server is unreachable. */
export async function savePhone(rec) {
  const uid = auth.current()?.uid; if (!uid || !rec?.e164 || !rec?.iso) return false;
  storage.set(phoneKey(uid), { e164: rec.e164, iso: rec.iso });
  return flushPhone();
}
async function flushPhone() {
  const uid = auth.current()?.uid; if (!uid || auth.mode === 'local') return false;
  const rec = storage.get(phoneKey(uid), null); if (!rec?.e164) return false;
  try { await api('PUT', '/api/me/phone', { phone: rec.e164, country: rec.iso }); storage.remove(phoneKey(uid)); return true; }
  catch (e) { if (e?.status === 400) storage.remove(phoneKey(uid)); return false; }   // 400 = refused by the server rules: never retried
}
