// Adaptive market-condition gate. Learns which conditions (see regime.js) were clearly bad for a
// strategy on this symbol/timeframe — and only returns them when the walk-forward check (lossAnalysis.js)
// showed that blocking them helped on data that was NOT used to learn them. Otherwise nothing is blocked.
import { runStrategy } from './backtest.js';
import { regimeSeries } from './regime.js';
import { tagTrades, walkForward, learnGate } from './lossAnalysis.js';

const memo = new Map();
const NONE = { blocked: [], R: null, wf: null };

export function gateFor(strategy, candles, rules, id = '') {
  if (!candles || candles.length < 300) return NONE;
  const k = [strategy, id, candles.length, candles.at(-1).time, JSON.stringify({ ...rules, htfCandles: undefined, regimeBlock: undefined, regimeR: undefined })].join('|');
  if (memo.has(k)) return memo.get(k);
  const R = regimeSeries(candles);
  const run = runStrategy(strategy, candles, { ...rules, openOnLast: false, regimeBlock: null, regimeR: null });
  const tagged = tagTrades(run.trades, candles, R);
  const wf = walkForward(tagged);
  const out = { blocked: wf.improved ? learnGate(tagged) : [], R, wf };
  if (memo.size > 24) memo.delete(memo.keys().next().value);
  memo.set(k, out);
  return out;
}
