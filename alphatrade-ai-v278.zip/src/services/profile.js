// Profile photo: resized in the browser to a small square JPEG and kept per account
// in this browser (localStorage). A cloud copy would need Firebase Storage.
import { storage } from '../utils/storage.js';

const key = (user) => `avatar:${user?.uid || user?.email || 'guest'}`;
const listeners = new Set();

export const getAvatar = (user) => storage.get(key(user), null);
export function setAvatar(user, dataUrl) {
  if (dataUrl) storage.set(key(user), dataUrl); else storage.remove(key(user));
  listeners.forEach((fn) => fn(dataUrl));
}
export function onAvatarChange(fn) { listeners.add(fn); return () => listeners.delete(fn); }

export const MAX_UPLOAD_BYTES = 8 * 1024 * 1024;

/** Read an image file, centre-crop it to a square and scale it to `size` px. */
export function resizeImage(file, size = 256) {
  return new Promise((resolve, reject) => {
    if (!file || !/^image\//.test(file.type)) { reject(new Error('type')); return; }
    if (file.size > MAX_UPLOAD_BYTES) { reject(new Error('size')); return; }
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      const side = Math.min(img.naturalWidth, img.naturalHeight);
      const sx = (img.naturalWidth - side) / 2;
      const sy = (img.naturalHeight - side) / 2;
      const c = document.createElement('canvas');
      c.width = size; c.height = size;
      const ctx = c.getContext('2d');
      ctx.imageSmoothingQuality = 'high';
      ctx.drawImage(img, sx, sy, side, side, 0, 0, size, size);
      URL.revokeObjectURL(url);
      resolve(c.toDataURL('image/jpeg', 0.86));
    };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('read')); };
    img.src = url;
  });
}

/** Avatar markup: the photo if set, otherwise the first letter. */
export function avatarInner(user) {
  const src = getAvatar(user);
  if (typeof src === 'string' && /^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/.test(src)) return `<img src="${src}" alt="" class="avatar-img"/>`;
  const ch = (user?.name || user?.email || '?').slice(0, 1).toUpperCase();
  return ch.replace(/[<>&"']/g, '');
}
