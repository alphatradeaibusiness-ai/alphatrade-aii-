// Runs every indicator for the current dataset + settings, in one place, so the chart,
// side cards, pressure card and AI context always reflect the same calculation.
import {
  rsi, ema, autoFibAnchors, fibLevels, fibZones, pressureSeries, pressureTotals, priceDirectionShare, momentumScore, FIB_RATIOS,
} from '../indicators/index.js';
import { bollinger } from '../indicators/index.js';
import { aviewOn } from './aview.js';
import { trailUpdate } from './quant.js';
import { STOP_LOSS_POINTS, TARGET_POINTS, getInstrument } from '../config/instruments.js';
import { edhZones } from './edhZones.js';
import { runStrategy, rulesFrom, edhLevels, edhTargets, edhStep } from './backtest.js';
import { gateFor } from './adaptive.js';
import { regimeSeries } from './regime.js';
import { fibBreaks, strongZones, legAnchors } from './fibSignals.js';
import { htfTrendSeries } from './zoneStrategy.js';
import { positionSize } from './sizing.js';
import { smcFull, sessionLevels } from '../indicators/smc.js';
import { TIMEFRAMES } from '../config/market.js';
import { signalState } from './signals.js';
import { gateTrade, confirmCfg } from './gate.js';
import { htfCandles, htfSignature } from './htfData.js';
import { prepare as smc2Prepare, explain as smc2Explain } from './smc2.js';
import { prepare as zonePrepare, explain as zoneExplain } from './zoneStrategy.js';

// Replaying the strategy over ~500 candles costs a few ms; prices tick every second. The replay
// over CLOSED candles is cached and only redone when a candle closes (or rules change); the
// forming candle is then applied to the open trade alone, which is cheap.
let replayMemo = { key: null, run: null };
let smcMemo = { key: null, value: null };
let smc2Memo = { key: null, value: null };
/** Where SMC v2 stands on the last closed candle (which condition is still missing). */
function smc2Status(dataset, candles, rules) {
  const closed = candles.slice(0, -1);
  if (closed.length < 120) return null;
  const key = [dataset.symbol, dataset.tf, closed.length, closed.at(-1).time, htfSignature(rules.htfCandles), rules.smcMinScore, rules.smcKillZone, rules.smcHtf].join('|');
  if (smc2Memo.key !== key) {
    const S = smc2Prepare(closed, { htf: rules.htfCandles || null });
    S.o = { ...S.o, minScore: rules.smcMinScore, killZone: rules.smcKillZone, htf: rules.smcHtf };
    smc2Memo = { key, value: smc2Explain(S, closed.length - 1) };
  }
  return smc2Memo.value;
}
let volMemo = { key: null, value: null };
/** Volatility rank (0–1) of the last closed candle against the previous 500. */
function volRankNow(dataset, candles) {
  const closed = candles.slice(0, -1);
  if (closed.length < 150) return null;
  const key = [dataset.symbol, dataset.tf, closed.length, closed.at(-1).time].join('|');
  if (volMemo.key !== key) { const R = regimeSeries(closed); volMemo = { key, value: R.volRank[closed.length - 1] }; }
  return volMemo.value;
}
let fibMemo = { key: null, value: null };
/** Fibonacci breaks (live) + strong confluence zones (once per closed candle). Lines 0 and 1 are the swing ends and never "break". */
function fibSignalsFor(dataset, candles, fib, smc) {
  const closed = candles.slice(0, -1);
  if (!fib || closed.length < 80) return null;
  const levels = fib.levels.filter((l) => l.ratio > 0 && l.ratio < 1);
  const key = [dataset.symbol, dataset.tf, closed.length, closed.at(-1).time, fib.high, fib.low, smc ? 1 : 0].join('|');
  if (fibMemo.key !== key) {
    const tfSec = candles.length > 1 ? candles[1].time - candles[0].time : 60;
    fibMemo = { key, value: { htf: htfTrendSeries(closed, tfSec), strong: strongZones(closed, levels, { smc, hasVolume: dataset.volumeKind !== 'none' }) } };
  }
  const { htf, strong } = fibMemo.value;
  const htfAll = htf.concat([htf.at(-1) || 0]); // the forming candle uses the last closed reading
  return { breaks: fibBreaks(candles, levels, { htf: htfAll }), strong };
}
let zoneMemo = { key: null, value: null };
/** Where the zone strategy stands on the last closed candle (nearest zones, which gate is next). */
function zoneStatus(dataset, candles, rules) {
  const closed = candles.slice(0, -1);
  if (closed.length < 120) return null;
  const key = [dataset.symbol, dataset.tf, closed.length, closed.at(-1).time, rules.zoneMinScore, rules.zoneHtf, rules.zoneRequireVp, rules.zoneMinVol, rules.zoneMinRR, rules.zoneQuant, rules.zoneRegimeW, rules.zoneZGate, rules.zoneFlowGate].join('|');
  if (zoneMemo.key !== key) {
    const S = zonePrepare(closed);
    S.o = { ...S.o, minScore: rules.zoneMinScore, htf: rules.zoneHtf, requireVp: rules.zoneRequireVp, minVolRatio: rules.zoneMinVol, minRR: rules.zoneMinRR, quant: rules.zoneQuant !== false, regimeWeights: rules.zoneRegimeW !== false, zGate: rules.zoneZGate || 0, flowGate: !!rules.zoneFlowGate };
    zoneMemo = { key, value: zoneExplain(S, closed.length - 1) };
  }
  return zoneMemo.value;
}
function smcCached(dataset, candles) {
  const lastClosed = candles.at(-2);
  const key = [dataset.symbol, dataset.tf, candles.length, lastClosed?.time, lastClosed?.close].join('|');
  if (smcMemo.key !== key) smcMemo = { key, value: smcFull(candles.slice(0, -1)) };
  const v = smcMemo.value;
  if (!v) return null;
  const close = candles.at(-1).close;
  return { ...v, bars: candles.length, range: v.range ? { ...v.range, zone: close > v.range.eq ? 'premium' : 'discount' } : null };
}
// EDH zones come from CLOSED candles only and are kept until the next candle closes, so the sweep boxes and Order Blocks stay put
// while the forming candle moves every second (an Order Block cannot appear / vanish with a wick).
const edhZoneCache = new Map();
function edhZonesCached(dataset, candles, E) {
  const closed = candles.slice(0, -1);
  const key = [dataset.symbol, dataset.tf, closed.at(-1)?.time, closed.length, E.pivLen, E.dispMult, E.maxOb, E.maxSw].join('|');
  const hit = edhZoneCache.get(dataset.symbol + '|' + dataset.tf);
  if (hit && hit.key === key) return hit.z;
  const z = edhZones(closed, { pivot: E.pivLen, disp: E.dispMult, maxObs: E.maxOb, maxSweeps: E.maxSw });
  edhZoneCache.set(dataset.symbol + '|' + dataset.tf, { key, z });
  return z;
}

/** The EDH trend filter's reading now: which side the N-hour EMA allows (null when off or not enough history). */
function edhTrend(candles, E, h4) {
  const hrs = Number(E.trendHours) || 0;
  if (!(hrs > 0)) return null;
  const px = candles.at(-1).close;
  let e = null;
  if (h4?.length) {
    const closed = h4.filter((x) => x.time + 14400 <= candles.at(-1).time + edhStep(candles));
    const per = Math.max(2, Math.round(hrs / 4));
    if (closed.length > per) e = ema(closed.map((x) => x.close), per).at(-1);
  } else {
    const per = Math.round((hrs * 3600) / edhStep(candles));
    if (candles.length > per) e = ema(candles.map((x) => x.close), Math.max(2, per)).at(-1);
  }
  return Number.isFinite(e) ? { ema: e, side: px >= e ? 'long' : 'short', hours: hrs } : null;
}

function replayCached(dataset, strategy, rules, candles) {
  const closed = candles.slice(0, -1);
  const lastClosed = closed.at(-1);
  const key = [dataset.symbol, dataset.tf, strategy, JSON.stringify({ ...rules, htfCandles: undefined, edhDaily: undefined, regimeR: undefined }), htfSignature(rules.htfCandles), rules.edhDaily?.length, rules.edhDaily?.at(-1)?.time, closed.length, lastClosed?.time, lastClosed?.close].join('|');
  if (replayMemo.key !== key) {
    const r = runStrategy(strategy, closed, { ...rules, openOnLast: true });
    replayMemo = { key, run: r };
  }
  const base = replayMemo.run;
  const forming = candles.at(-1);
  if (!forming || !base) return base;
  // Apply the forming candle to copies (the cached run must stay untouched).
  const trades = base.trades.slice();
  let open = base.open ? { ...base.open, targets: base.open.targets.slice() } : null;
  let pending = base.pending ? { ...base.pending } : null;
  if (open) {
    const done = applyCandle(open, forming, rules);
    if (done) { trades.push(done); open = null; }
  } else if (pending) {
    const long = pending.direction === 'long';
    if (long ? forming.low <= pending.entry : forming.high >= pending.entry) {
      open = { ...pending, hits: 0, openTime: forming.time };
      pending = null;
      if (long ? forming.low <= open.stop : forming.high >= open.stop) { trades.push(closeTrade(open, forming, 'sl', open.stop, rules)); open = null; }
    }
  }
  return { trades, open, pending };
}

function closeTrade(t, c, outcome, exit, o) {
  const sign = t.direction === 'long' ? 1 : -1;
  let pts = 0;
  for (let k = 0; k < t.hits; k++) pts += ((t.targets[k] - t.entry) * sign) / o.pointSize / 3;
  pts += (((exit - t.entry) * sign) / o.pointSize) * ((3 - t.hits) / 3);
  pts -= ((o.feePct || 0) / 100) * t.entry / o.pointSize;
  return { ...t, outcome, closeTime: c.time, exit, points: pts };
}

function applyCandle(t, c, o) {
  const long = t.direction === 'long';
  if (long ? c.low <= t.stop : c.high >= t.stop) return closeTrade(t, c, t.hits === 0 && !t.beMoved ? 'sl' : 'be', t.stop, o);
  while (t.hits < 3 && (long ? c.high >= t.targets[t.hits] : c.low <= t.targets[t.hits])) {
    t.hits++;
    if (t.hits === 1) t.stop = t.entry;
  }
  if (t.hits === 3) return closeTrade(t, c, 'tp3', t.targets[2], o);
  if (o.beAtR > 0 && !t.beMoved && t.hits === 0 && (long ? c.high >= t.entry + o.beAtR * t.risk : c.low <= t.entry - o.beAtR * t.risk)) {
    t.beMoved = true; t.stop = t.entry;
    if (long ? c.low <= t.entry : c.high >= t.entry) return closeTrade(t, c, 'be', t.entry, o);
  }
  if (trailUpdate(t, c, o)) return closeTrade(t, c, 'be', t.stop, o);
  return null;
}

export function computeAnalysis(dataset, settings) {
  const candles = dataset?.candles || [];
  if (!candles.length) return null;
  const inst = getInstrument(dataset.symbol);
  const closes = candles.map((c) => c.close);
  const hasVolume = dataset.volumeKind !== 'none' && candles.some((c) => Number.isFinite(c.volume) && c.volume > 0);

  const rsiValues = rsi(closes, Math.max(2, settings.rsi.period | 0));
  const ema20 = ema(closes, 20);
  const ema50 = ema(closes, 50);

  const pSeries = hasVolume ? pressureSeries(candles, dataset.volumeKind) : null;
  const pTotals = pSeries ? pressureTotals(pSeries, settings.pressure.window) : null;

  const momentum = momentumScore({ candles, rsiValues, pressure: pTotals });
  const strength = pTotals
    ? { buyPct: pTotals.buyPct, sellPct: pTotals.sellPct, basis: 'volume' }
    : { ...priceDirectionShare(candles, settings.pressure.window), basis: 'price' };

  // Fibonacci anchors: auto (lookback extremes) or manual (user prices / picked points).
  let anchors = (settings.fib.mode !== 'manual' && settings.fib.follow !== false && legAnchors(candles, settings.fib.lookback)) || autoFibAnchors(candles, settings.fib.lookback);
  // Manual points belong to the symbol they were set on.
  if (settings.fib.mode === 'manual' && (!settings.fib.symbol || settings.fib.symbol === dataset.symbol) && Number.isFinite(settings.fib.high) && Number.isFinite(settings.fib.low) && settings.fib.high > settings.fib.low) {
    anchors = {
      high: settings.fib.high, low: settings.fib.low,
      highTime: settings.fib.highTime ?? anchors?.highTime, lowTime: settings.fib.lowTime ?? anchors?.lowTime,
    };
  }
  const fib = anchors ? { ...anchors, levels: fibLevels(anchors.high, anchors.low, FIB_RATIOS) } : null;
  const zones = anchors ? fibZones(anchors.high, anchors.low) : null;

  const last = candles[candles.length - 1];
  const pointSize = Number(settings.pointSizes?.[dataset.symbol]) > 0 ? Number(settings.pointSizes[dataset.symbol]) : inst.pointSize;
  // The plan comes from the same engine as the results page: the strategy is replayed over the
  // loaded candles, so the entry is the price at the signal and stays fixed until the trade ends.
  // New trades only open on closed candles (the forming candle can still change).
  const strategy = settings.strategy === 'smc' ? 'smc' : settings.strategy === 'zone' ? 'zone' : settings.strategy === 'edh' ? 'edh' : 'classic';
  // SMC reads the whole loaded history (500 candles) every time — not only when there is a trade.
  // Cached per closed candle; the forming candle only moves the last price.
  const smc = strategy === 'smc' ? smcCached(dataset, candles) : null;
  const rules = { ...rulesFrom(settings, inst), pointSize, slPoints: STOP_LOSS_POINTS, tpPoints: TARGET_POINTS, volumeKind: hasVolume ? dataset.volumeKind : 'none', openOnLast: false, htfCandles: strategy === 'zone' ? null : htfCandles(dataset.symbol), edhDaily: strategy === 'edh' ? htfCandles(dataset.symbol)?.d1 : null };
  if (settings.regime?.enabled) {
    const g = gateFor(strategy, candles.slice(0, -1), rules, `${dataset.symbol}|${dataset.tf}`);
    rules.regimeBlock = g.blocked; rules.regimeR = g.R;
  }
  const fibSig = settings.fib?.enabled ? fibSignalsFor(dataset, candles, fib, smc) : null;
  const run = replayCached(dataset, strategy, rules, candles);
  const smc2 = strategy === 'smc' ? smc2Status(dataset, candles, rules) : null;
  const zone = strategy === 'zone' ? zoneStatus(dataset, candles, rules) : null;
  const lastTrade = run.trades.at(-1) || null;
  let current = run.open ? { ...run.open, status: 'active' } : run.pending ? { ...run.pending, status: 'pending', hits: 0 } : null;
  // A live signal from the signals channel for this symbol and timeframe is drawn too, so every
  // signal that was announced (and notified) is also visible on the chart with its targets.
  if (!current && dataset.mode === 'live') {
    const sg = signalState().signals.find((x) => x.status === 'active' && x.symbol === dataset.symbol && x.tf === dataset.tf);
    if (sg) current = { strategy: sg.strategy, direction: sg.direction, entry: sg.entry, stop: sg.hits ? sg.entry : sg.stop, initialStop: sg.stop, targets: sg.targets.slice(), risk: Math.abs(sg.entry - sg.stop), hits: sg.hits, openTime: sg.openTime, status: 'active', fromSignal: true };
  }
  // Strict confirmation: a plan is drawn (BUY / SELL) only when the confirmation engine accepts it. Otherwise NO TRADE, with the reasons.
  let gate = null;
  const cfg = confirmCfg(settings);
  if (current && cfg.enabled && dataset.mode === 'live') {
    gate = gateTrade({ symbol: dataset.symbol, tf: dataset.tf, mode: dataset.mode, candles, trade: { ...current, openTime: current.openTime ?? current.createdTime }, strategy, feePct: Number(settings.plan?.feePct) || 0, cfg });
    if (gate && gate.verdict !== 'trade' && current.status === 'pending') current = null;     // a pending entry that fails is not shown
    else if (gate && gate.verdict !== 'trade' && !current.hits && current.status === 'active' && current.openTime >= candles[Math.max(0, candles.length - 3)].time) current = null;   // a brand-new one too; an older running trade stays visible (it is already open)
    if (!current) gate = { ...gate, rejected: true };
  }
  const previous = lastTrade ? { direction: lastTrade.direction, entry: lastTrade.entry, status: lastTrade.outcome, hits: lastTrade.hits, points: lastTrade.points, closeTime: lastTrade.closeTime } : null;
  const plan = current ? {
    ...current, strategy, stopMode: rules.stopMode, atrMult: rules.atrMult, tpR: rules.tpR, pointSize,
    distance: current.risk, points: current.risk / pointSize,
    rr: current.targets.map((tp) => Math.abs(tp - current.entry) / current.risk),
    targetPoints: current.targets.map((tp) => Math.abs(tp - current.entry) / pointSize),
    targetDistances: current.targets.map((tp) => Math.abs(tp - current.entry)),
    openedTime: current.openTime ?? current.createdTime, previous,
    sizing: positionSize({ account: Number(settings.risk?.accountSize), riskPct: Number(settings.risk?.riskPct), entry: current.entry, stop: current.initialStop ?? current.stop, volRank: volRankNow(dataset, candles) }),
  } : null;

  return {
    symbol: dataset.symbol, tf: dataset.tf, mode: dataset.mode, source: dataset.source, volumeKind: dataset.volumeKind,
    hasVolume, gate, rsi: rsiValues, ema20, ema50, pressure: pSeries, pressureTotals: pTotals, momentum, strength, fib, zones, plan, previousTrade: previous, rules, last, strategy, smc, edhT: strategy === 'edh' ? edhTargets(rules.edh, edhStep(candles)) : null, edh: strategy === 'edh' ? (() => { const l = edhLevels(candles, htfCandles(dataset.symbol)?.d1); if (!l) return null; const E = rules.edh || {}; return { ...l, trend: edhTrend(candles, E, htfCandles(dataset.symbol)?.h4), ...(E.showZones === false ? { sweeps: [], obs: [] } : edhZonesCached(dataset, candles, E)) }; })() : null, strategyTrades: run.trades,
    precision: inst.precision, smc2, zone, fibSig,
    // Liquidity map (chart toggle, independent of the strategy): SMC structure + session highs/lows. Display only — it never feeds a strategy.
    liq: settings.liqMap || aviewOn(settings) ? (smc || smcCached(dataset, candles)) : null,
    bb: settings.bb?.enabled || aviewOn(settings) ? bollinger(closes, settings.bb?.period || 20, settings.bb?.mult || 2) : null,
    sessions: settings.liqMap || aviewOn(settings) ? sessionLevels(candles.slice(0, -1), TIMEFRAMES.find((x) => x.id === dataset.tf)?.seconds || 0) : null,
  };
}

/** Compact snapshot sent to the AI assistant as context. */
export function aiContext(analysis) {
  if (!analysis) return { note: 'No data loaded' };
  const r = (v) => (Number.isFinite(v) ? Number(v.toFixed(analysis.precision)) : null);
  return {
    symbol: analysis.symbol,
    timeframe: analysis.tf,
    mode: analysis.mode,
    dataSource: analysis.source,
    warning: analysis.mode === 'demo' ? 'DEMO DATA — generated, not real market prices' : undefined,
    lastClose: r(analysis.last.close),
    lastBarTimeUtc: new Date(analysis.last.time * 1000).toISOString(),
    rsi: Number.isFinite(analysis.rsi.at(-1)) ? Number(analysis.rsi.at(-1).toFixed(1)) : null,
    ema20: r(analysis.ema20.at(-1)),
    ema50: r(analysis.ema50.at(-1)),
    momentum: analysis.momentum ? { score: Math.round(analysis.momentum.score), trend: analysis.momentum.descKey } : null,
    buyerSellerPct: { buyers: Math.round(analysis.strength.buyPct), sellers: Math.round(analysis.strength.sellPct), basis: analysis.strength.basis },
    fibonacci: analysis.fib ? { high: r(analysis.fib.high), low: r(analysis.fib.low), levels: analysis.fib.levels.map((l) => [l.ratio, r(l.price)]) } : null,
    strategy: analysis.strategy,
    smc: analysis.smc ? { trend: analysis.smc.trend, lastBreaks: analysis.smc.events.map((e) => `${e.kind} ${e.dir} @ ${r(e.level)}`), orderBlock: analysis.smc.ob ? [r(analysis.smc.ob.bottom), r(analysis.smc.ob.top)] : null } : undefined,
    plan: analysis.plan ? {
      direction: analysis.plan.direction, entry: r(analysis.plan.entry), stopLoss: r(analysis.plan.stop), targets: analysis.plan.targets.map(r),
      status: analysis.plan.status, targetsHit: analysis.plan.hits,
      rule: analysis.strategy === 'edh' ? `EDH: a 5-minute candle closes beyond yesterday's high/low; stop ${analysis.edhT?.sl ?? 30} pips, T1 ${analysis.edhT?.t1 ?? 30} pips, T2 = T1 + 50 points, T3 = T2 + 30 points (Settings → Plan)` : analysis.strategy === 'zone' ? 'Zones: reaction at a fresh supply/demand zone + volume and fixed-profile POC/HVN + RSI filter + Fibonacci pocket, market entry, score >= minimum' : analysis.strategy === 'smc' ? 'SMC: entry at order block edge, stop beyond the block, targets at liquidity pools, 200 EMA trend filter' : analysis.plan.stopMode === 'atr' ? `Signal: momentum crosses 60/40 with 200 EMA trend filter; stop ${analysis.plan.atrMult} x ATR(14); targets ${analysis.plan.tpR.join(' / ')} R` : `Signal: momentum crosses 60/40; stop ${STOP_LOSS_POINTS} points; targets ${TARGET_POINTS.join(' / ')} points`,
      note: 'Entry is fixed for this trade. A third closes at each target; after TP1 the stop moves to entry.',
    } : { status: 'no open trade — waiting for the next signal', lastTrade: analysis.previousTrade },
    volumeAvailable: analysis.hasVolume,
    aiEngine: analysis.ai?.ready ? { side: analysis.ai.side, probTargetBeforeStop: analysis.ai.tp.map((x) => (x ? Math.round(x.p * 100) : null)), outOfSampleAuc: analysis.ai.m ? Number(analysis.ai.m.oos.auc.toFixed(2)) : null, statisticalEdge: Boolean(analysis.ai.m?.edge), aiOnly: analysis.ai.m ? Math.round(analysis.ai.m.aiP * 100) : null, indicatorsOnly: analysis.ai.m?.indP != null ? Math.round(analysis.ai.m.indP * 100) : null, indicatorWinRates: (analysis.ai.m?.indicators || []).filter((i) => i.available).map((i) => ({ indicator: i.key, reading: i.vote > 0 ? 'supports' : i.vote < 0 ? 'against' : 'neutral', winRatePct: i.rate == null ? null : Math.round(i.rate * 100), cases: i.n, provenEdge: i.proven })), forecastUpProb: analysis.ai.forecast?.pUp != null ? Math.round(analysis.ai.forecast.pUp * 100) : null, note: 'Statistical model trained on this symbol\'s own history and tested out-of-sample; when edge=false the number is just the historical base rate.' } : undefined,
  };
}
