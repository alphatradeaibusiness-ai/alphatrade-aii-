// Statistics of the user's own journal (manual trades + imported closed signals). Only what was recorded: no backtests mixed in.

/**
 * @param rows [{ usd, r, closedAt, strategy }] trade results
 * @returns { n, wins, losses, winRate, net, grossWin, grossLoss, profitFactor, maxDrawdown, maxDrawdownPct, avgR, byStrategy: [...] }
 *   maxDrawdown = largest peak-to-trough fall of the cumulative result (money), in closing order.
 */
export function journalStats(rows) {
  const list = [...rows].filter((x) => Number.isFinite(x.usd)).sort((a, b) => a.closedAt - b.closedAt);
  const one = (arr) => {
    const wins = arr.filter((x) => x.usd > 0).length; const losses = arr.filter((x) => x.usd < 0).length;
    const gw = arr.filter((x) => x.usd > 0).reduce((a, x) => a + x.usd, 0);
    const gl = -arr.filter((x) => x.usd < 0).reduce((a, x) => a + x.usd, 0);
    let eq = 0, peak = 0, dd = 0, ddPeakAt = 0;
    for (const x of arr) { eq += x.usd; if (eq > peak) peak = eq; if (peak - eq > dd) { dd = peak - eq; ddPeakAt = peak; } }
    const rs = arr.filter((x) => Number.isFinite(x.r));
    return {
      n: arr.length, wins, losses, winRate: arr.length ? (100 * wins) / arr.length : 0, net: eq, grossWin: gw, grossLoss: gl,
      profitFactor: gl > 0 ? gw / gl : gw > 0 ? Infinity : null, maxDrawdown: dd, maxDrawdownPct: ddPeakAt > 0 ? (100 * dd) / ddPeakAt : null,
      avgR: rs.length ? rs.reduce((a, x) => a + x.r, 0) / rs.length : null,
    };
  };
  const all = one(list);
  const keys = [...new Set(list.map((x) => x.strategy || 'other'))];
  all.byStrategy = keys.map((k) => ({ strategy: k, ...one(list.filter((x) => (x.strategy || 'other') === k)) })).sort((a, b) => b.net - a.net);
  return all;
}
