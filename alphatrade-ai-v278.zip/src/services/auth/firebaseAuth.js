// Firebase Authentication: email/password, password-reset email, Google and Apple.
// Loaded lazily, only when VITE_FIREBASE_* variables are present.
import { authConfig } from '../../config/auth.js';
import { AuthError, fromFirebase } from './errors.js';

let fb = null; // { auth, mod }
const listeners = new Set();
let currentUser = null;

function toUser(u) {
  return u ? { email: u.email, name: u.displayName || (u.email || '').split('@')[0], provider: u.providerData?.[0]?.providerId || 'password', uid: u.uid } : null;
}

// Official Firebase browser build (ES modules) from Google's CDN, loaded only when Firebase is configured.
const FIREBASE_VERSION = '12.19.0';
const CDN = `https://www.gstatic.com/firebasejs/${FIREBASE_VERSION}`;

async function load() {
  if (fb) return fb;
  const appUrl = `${CDN}/firebase-app.js`;
  const authUrl = `${CDN}/firebase-auth.js`;
  const [{ initializeApp }, mod] = await Promise.all([import(/* @vite-ignore */ appUrl), import(/* @vite-ignore */ authUrl)]);
  const app = initializeApp(authConfig.firebase);
  const auth = mod.getAuth(app);
  fb = { auth, mod, app };
  return fb;
}

/** The initialised Firebase app (shared with Firestore for the signals market). */

export const firebaseAuth = {
  mode: 'firebase',
  async init() {
    const { auth, mod } = await load();
    // Complete a redirect sign-in, if one is in progress (errors surface on the next attempt).
    mod.getRedirectResult(auth).catch(() => {});
    return new Promise((resolve) => {
      let first = true;
      mod.onAuthStateChanged(auth, (u) => {
        currentUser = toUser(u);
        listeners.forEach((fn) => fn(currentUser));
        if (first) { first = false; resolve(currentUser); }
      });
    });
  },
  current: () => currentUser,
  onChange(fn) { listeners.add(fn); return () => listeners.delete(fn); },

  /** Face sign-in: the server checked the passkey and minted a Firebase custom token. */
  async signInWithToken(token) {
    const { auth, mod } = await load();
    try { await mod.setPersistence(auth, mod.browserLocalPersistence); const cred = await mod.signInWithCustomToken(auth, token); currentUser = toUser(cred.user); return currentUser; }
    catch (e) { throw fromFirebase(e); }
  },
  async signIn(email, password, remember) {
    const { auth, mod } = await load();
    try {
      await mod.setPersistence(auth, remember ? mod.browserLocalPersistence : mod.browserSessionPersistence);
      const cred = await mod.signInWithEmailAndPassword(auth, email.trim(), password);
      return toUser(cred.user);
    } catch (e) { throw fromFirebase(e); }
  },

  async signUp(name, email, password) {
    const { auth, mod } = await load();
    try {
      const cred = await mod.createUserWithEmailAndPassword(auth, email.trim(), password);
      if (name) await mod.updateProfile(cred.user, { displayName: name.trim() });
      currentUser = toUser(cred.user);
      return currentUser;
    } catch (e) { throw fromFirebase(e); }
  },

  async requestReset(email) {
    const { auth, mod } = await load();
    try {
      await mod.sendPasswordResetEmail(auth, email.trim());
    } catch (e) {
      // Do not reveal whether an account exists.
      if (e?.code !== 'auth/user-not-found') throw fromFirebase(e);
    }
    return { sent: true };
  },

  async localResetPassword() { throw new AuthError('unknown', { msg: 'Use the emailed link to reset your password.' }); },

  async signInWithProvider(provider) {
    if (!authConfig.providers[provider]) throw new AuthError('providerMissing', { provider: provider === 'google' ? 'Google' : 'Apple' });
    const { auth, mod } = await load();
    const p = provider === 'google' ? new mod.GoogleAuthProvider() : new mod.OAuthProvider('apple.com');
    if (provider === 'apple') { p.addScope('email'); p.addScope('name'); }
    p.setCustomParameters?.({ ...(provider === 'google' ? { prompt: 'select_account' } : {}), locale: document.documentElement.lang || 'ar' });
    try {
      const cred = await mod.signInWithPopup(auth, p);
      return toUser(cred.user);
    } catch (e) {
      // Pop-up blocked (some in-app browsers): fall back to a full-page redirect.
      if (e?.code === 'auth/popup-blocked' || e?.code === 'auth/operation-not-supported-in-this-environment') {
        await mod.signInWithRedirect(auth, p);
        return null;
      }
      throw fromFirebase(e);
    }
  },

  async updateName(name) {
    const { auth, mod } = await load();
    try {
      await mod.updateProfile(auth.currentUser, { displayName: name });
      currentUser = toUser(auth.currentUser);
      listeners.forEach((fn) => fn(currentUser));
      return currentUser;
    } catch (e) { throw fromFirebase(e); }
  },

  /** Confirm it is really you (password, or the Google / Apple window again) — needed before deleting the account. */
  async reauth(password) {
    const { auth, mod } = await load();
    const u = auth.currentUser; if (!u) throw new AuthError('unknown');
    try {
      const prov = u.providerData?.[0]?.providerId || 'password';
      if (prov === 'password') await mod.reauthenticateWithCredential(u, mod.EmailAuthProvider.credential(u.email, password || ''));
      else { const p = prov === 'google.com' ? new mod.GoogleAuthProvider() : new mod.OAuthProvider('apple.com'); await mod.reauthenticateWithPopup(u, p); }
      await u.getIdToken(true);   // fresh token → the server sees the new sign-in time
      return true;
    } catch (e) {
      if (e?.code === 'auth/wrong-password' || e?.code === 'auth/invalid-credential') throw new AuthError('wrongPassword');
      throw fromFirebase(e);
    }
  },
  async deleteUser() { const { auth, mod } = await load(); if (auth.currentUser) await mod.deleteUser(auth.currentUser); currentUser = null; },

  async changePassword(current, next) {
    const { auth, mod } = await load();
    const u = auth.currentUser;
    try {
      // Firebase requires a recent sign-in: confirm the current password first.
      await mod.reauthenticateWithCredential(u, mod.EmailAuthProvider.credential(u.email, current));
      await mod.updatePassword(u, next);
      return true;
    } catch (e) {
      if (e?.code === 'auth/wrong-password' || e?.code === 'auth/invalid-credential') throw new AuthError('wrongPassword');
      throw fromFirebase(e);
    }
  },

  // Accounts created with Google/Apple have no password to change here.
  canChangePassword: () => currentUser?.provider === 'password',
  /** Signed Firebase ID token for the server (refreshed by Firebase when needed). */
  async idToken() { try { const f = await load(); return f.auth.currentUser ? await f.auth.currentUser.getIdToken() : null; } catch { return null; } },

  async signOut() {
    const { auth, mod } = await load();
    await mod.signOut(auth);
  },
};
