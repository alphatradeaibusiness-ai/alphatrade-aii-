// Local demo account store — used only when Firebase is not configured.
// Accounts live in this browser's localStorage; passwords are salted SHA-256 hashes.
// It exists so the full sign-up / sign-in / recovery flow can be tested offline.
import { storage } from '../../utils/storage.js';
import { AuthError } from './errors.js';

const USERS_KEY = 'demo-users';
const SESSION_KEY = 'demo-session';
const delay = (ms) => new Promise((r) => setTimeout(r, ms));
const LOCK_KEY = 'demo-lock';
// The lock-out survives a page reload (it used to reset on refresh, so it could be bypassed).
let failed = storage.get(LOCK_KEY, null, 'local') || { count: 0, until: 0 };
const saveFailed = () => storage.set(LOCK_KEY, failed, 'local');
const listeners = new Set();
let currentUser = null;

// PBKDF2-SHA256 (210k rounds) — slow on purpose so a stolen localStorage can't be guessed quickly.
// Accounts created by older versions used one round of SHA-256; they still sign in and are upgraded.
const ITER = 210_000;
async function hash(password, salt, legacy = false) {
  const enc = new TextEncoder();
  if (legacy) {
    const buf = await crypto.subtle.digest('SHA-256', enc.encode(`${salt}:${password}`));
    return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, '0')).join('');
  }
  const key = await crypto.subtle.importKey('raw', enc.encode(password), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt: enc.encode(salt), iterations: ITER }, key, 256);
  return `p2$${[...new Uint8Array(bits)].map((b) => b.toString(16).padStart(2, '0')).join('')}`;
}
const newSalt = () => [...crypto.getRandomValues(new Uint8Array(16))].map((b) => b.toString(16).padStart(2, '0')).join('');
/** Constant-time compare of two hex strings. */
function same(a, b) {
  if (a.length !== b.length) return false;
  let d = 0; for (let i = 0; i < a.length; i++) d |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return d === 0;
}
const matches = async (u, password) => same(await hash(password, u.salt, !String(u.hash).startsWith('p2$')), u.hash);

const users = () => storage.get(USERS_KEY, {});
const saveUsers = (u) => storage.set(USERS_KEY, u);
const norm = (e) => String(e || '').trim().toLowerCase();

function setUser(u, remember) {
  currentUser = u;
  storage.remove(SESSION_KEY);
  if (u) storage.set(SESSION_KEY, u, remember ? 'local' : 'session');
  listeners.forEach((fn) => fn(u));
}

export const localAuth = {
  mode: 'local',
  async init() {
    currentUser = storage.get(SESSION_KEY, null, 'session') || storage.get(SESSION_KEY, null, 'local');
    return currentUser;
  },
  current: () => currentUser,
  onChange(fn) { listeners.add(fn); return () => listeners.delete(fn); },

  async signIn(email, password, remember) {
    await delay(650);
    if (Date.now() < failed.until) throw new AuthError('tooMany');
    const u = users()[norm(email)];
    if (!u || !(await matches(u, password))) {
      failed.count += 1;
      if (failed.count >= 5) {
        const strikes = failed.strikes || 0;
        failed = { count: 0, strikes: strikes + 1, until: Date.now() + 60_000 * Math.min(30, 2 ** Math.min(5, strikes)) };
      }
      saveFailed();
      throw new AuthError('invalidCredentials');
    }
    failed = { count: 0, until: 0 }; saveFailed();
    if (!String(u.hash).startsWith('p2$')) { // upgrade an old SHA-256 account to PBKDF2 on this successful sign-in
      const all = users(); const key = norm(email);
      all[key].salt = newSalt(); all[key].hash = await hash(password, all[key].salt); saveUsers(all);
    }
    setUser({ email: norm(email), name: u.name, provider: 'local' }, remember);
    return currentUser;
  },

  async signUp(name, email, password) {
    await delay(750);
    const all = users();
    const key = norm(email);
    if (all[key]) throw new AuthError('emailInUse');
    const salt = newSalt();
    all[key] = { name: name.trim(), salt, hash: await hash(password, salt), created: Date.now() };
    saveUsers(all);
    setUser({ email: key, name: name.trim(), provider: 'local' }, true);
    return currentUser;
  },

  /** No email can be sent in demo mode; caller then offers a local reset form. */
  async requestReset(email) {
    await delay(600);
    if (!users()[norm(email)]) throw new AuthError('userNotFound');
    return { demo: true };
  },

  async localResetPassword(email, newPassword) {
    await delay(500);
    const all = users();
    const u = all[norm(email)];
    if (!u) throw new AuthError('userNotFound');
    u.salt = newSalt();
    u.hash = await hash(newPassword, u.salt);
    saveUsers(all);
    return true;
  },

  /** Local accounts exist only in this browser: there is nothing the server could verify. */
  async idToken() { return null; },
  async signInWithProvider(provider) {
    throw new AuthError('providerMissing', { provider });
  },

  async updateName(name) {
    await delay(300);
    const all = users();
    const u = all[currentUser.email];
    if (u) { u.name = name; saveUsers(all); }
    const remember = Boolean(storage.get(SESSION_KEY, null, 'local'));
    setUser({ ...currentUser, name }, remember);
    return currentUser;
  },

  async changePassword(current, next) {
    await delay(500);
    const all = users();
    const u = all[currentUser.email];
    if (!u || !(await matches(u, current))) throw new AuthError('wrongPassword');
    u.salt = newSalt();
    u.hash = await hash(next, u.salt);
    saveUsers(all);
    return true;
  },

  canChangePassword: () => true,

  async signOut() { setUser(null); },
  async signInWithToken() { throw new AuthError('unknown', { msg: 'Face sign-in needs the online account.' }); },
  async reauth(password) { const u = users()[currentUser?.email]; if (!u || !(await matches(u, password || ''))) throw new AuthError('wrongPassword'); return true; },
  async deleteUser() { const all = users(); delete all[currentUser?.email]; saveUsers(all); setUser(null); },
};
