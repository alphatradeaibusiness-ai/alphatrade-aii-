// Auth facade: Firebase when configured, otherwise the clearly-labelled local demo store.
import { authConfig } from '../../config/auth.js';
import { localAuth } from './localAuth.js';
import { AuthError } from './errors.js';
import { audit } from '../audit.js';

// Sign-in attempts (success and failure), sign-ups, sign-outs and password changes go to the local audit log (never the password).
const logged = (action, fn, who) => async (...a) => {
  try { const r = await fn(...a); audit(action, { email: who(a), ok: true }); return r; }
  catch (e) { audit(action, { email: who(a), ok: false, code: e?.code || '' }); throw e; }
};

let impl = localAuth;
if (authConfig.firebaseConfigured) {
  // Lazy import keeps Firebase out of the bundle path when it is not used.
  const { firebaseAuth } = await import('./firebaseAuth.js');
  impl = firebaseAuth;
}

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

/** Field validation shared by every form. Returns { field: errorKey } (empty when valid). */
export function validate({ name, email, password, confirm }, mode) {
  const errs = {};
  if (mode === 'signup' && !String(name || '').trim()) errs.name = 'nameRequired';
  if (email !== undefined) {
    if (!String(email).trim()) errs.email = 'emailRequired';
    else if (!EMAIL_RE.test(String(email).trim())) errs.email = 'emailInvalid';
  }
  if (password !== undefined) {
    if (!password) errs.password = 'passwordRequired';
    else if (mode !== 'signin') {
      if (password.length < authConfig.minPasswordLength) errs.password = 'passwordShort';
      else if (!/[A-Za-z؀-ۿ]/.test(password) || !/\d/.test(password)) errs.password = 'passwordWeak';
    }
  }
  if (confirm !== undefined && confirm !== password) errs.confirm = 'passwordMismatch';
  return errs;
}

export const auth = {
  get mode() { return impl.mode; },
  providerConfigured: (p) => Boolean(authConfig.providers[p]),
  init: () => impl.init(),
  current: () => impl.current(),
  onChange: (fn) => impl.onChange(fn),
  signIn: logged('auth.signin', (e, p, r) => impl.signIn(e, p, r), (a) => a[0]),
  signUp: logged('auth.signup', (n, e, p) => impl.signUp(n, e, p), (a) => a[1]),
  requestReset: (e) => impl.requestReset(e),
  localResetPassword: logged('auth.reset', (e, p) => impl.localResetPassword(e, p), (a) => a[0]),
  async signInWithProvider(provider) {
    if (!authConfig.providers[provider]) throw new AuthError('providerMissing', { provider: provider === 'google' ? 'Google' : 'Apple' });
    return impl.signInWithProvider(provider);
  },
  signOut: () => { audit('auth.signout', { email: impl.current()?.email || '' }); return impl.signOut(); },
  updateName: (n) => impl.updateName(n),
  changePassword: logged('auth.password', (c, n) => impl.changePassword(c, n), () => impl.current()?.email || ''),
  canChangePassword: () => impl.canChangePassword(),
  reauth: (p) => impl.reauth(p),
  signInWithToken: logged('auth.face', (tk) => impl.signInWithToken(tk), () => 'face'),
  deleteUser: logged('auth.delete', () => impl.deleteUser(), () => impl.current()?.email || ''),
  /** Server-verifiable sign-in token (Firebase), or null for local accounts. */
  idToken: () => (impl.idToken ? impl.idToken() : Promise.resolve(null)),
};
