export class AuthError extends Error {
  /** @param {string} code key under auth.err.* (or 'providerMissing'), @param {object} params */
  constructor(code, params = {}) {
    super(code);
    this.code = code;
    this.params = params;
  }
}

/** Map Firebase error codes to our translated error keys. */
export function fromFirebase(err) {
  const map = {
    'auth/invalid-credential': 'invalidCredentials',
    'auth/wrong-password': 'invalidCredentials',
    'auth/user-not-found': 'userNotFound',
    'auth/invalid-email': 'emailInvalid',
    'auth/email-already-in-use': 'emailInUse',
    'auth/weak-password': 'passwordWeak',
    'auth/too-many-requests': 'tooMany',
    'auth/network-request-failed': 'network',
    'auth/popup-closed-by-user': 'popupClosed',
    'auth/cancelled-popup-request': 'popupClosed',
    'auth/operation-not-allowed': 'providerDisabled',
    'auth/unauthorized-domain': 'unauthorizedDomain',
    'auth/account-exists-with-different-credential': 'differentCredential',
  };
  const code = map[err?.code];
  return code ? new AuthError(code) : new AuthError('unknown', { msg: err?.message || String(err) });
}

export function authErrorMessage(err, t) {
  if (!(err instanceof AuthError)) return t('auth.err.unknown', { msg: err?.message || String(err) });
  if (err.code === 'providerMissing') return t('auth.providerMissing', err.params);
  return t(`auth.err.${err.code}`, { ...err.params, msg: err.params?.msg || '' });
}
