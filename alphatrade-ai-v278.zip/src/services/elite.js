// Alpha Elite Signals (v231) — a premium live channel: at most TWO trades at the opening of each market session.
// Pure module, used by the server (one shared feed for every member, computed every 20 s from the 24/7 worker's
// recommendations) and by the page as a fallback when no server is reachable (same rules on the local channel).
//
// Rules (deterministic, no strategy is changed — EDH and every engine keep their own conditions):
//  • Sessions: Sydney 07:00, Tokyo 09:00, London 08:00, New York 08:00 — each in its OWN time zone, so daylight saving is
//    handled by the calendar. Opens that fall on a local Saturday or Sunday are skipped (forex / indices are closed).
//  • Window: a recommendation counts for a session when the channel issued it within OPEN_WINDOW_MS after the open.
//  • Elite quality: a proven combination (≥ 30 back-test trades, win rate ≥ 62 %, positive out-of-sample — the channel's
//    "qualified" tier) OR an engine trade with reward ≥ 2 × risk to target 2. The "watch" tier is never used.
//  • Instant: a qualifying recommendation is picked as soon as it appears (only if it is fresh: ≤ FRESH_MS old) —
//    until the session has its 2. One market per session at most once (no two trades on the same symbol).
//  • A pick is frozen once published (never replaced by a later one); only its status follows the original
//    recommendation (targets / stop / expiry), so the history is honest.
export const ELITE_BRAND = 'Alpha Elite Signals';
export const MAX_PER_OPEN = 2;
export const OPEN_WINDOW_MS = 90 * 60_000;
export const FRESH_MS = 15 * 60_000;
export const KEEP_DAYS = 14;
export const SESSIONS = [
  { id: 'sydney', tz: 'Australia/Sydney', h: 7, m: 0 },
  { id: 'tokyo', tz: 'Asia/Tokyo', h: 9, m: 0 },
  { id: 'london', tz: 'Europe/London', h: 8, m: 0 },
  { id: 'newyork', tz: 'America/New_York', h: 8, m: 0 },
];
const DAY = 86_400_000;
const LIVE = ['active', 'pending'];

/* ───────── time zones without a library ───────── */
const fmts = new Map();
const fmt = (tz) => { let f = fmts.get(tz); if (!f) { f = new Intl.DateTimeFormat('en-US', { timeZone: tz, hourCycle: 'h23', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', weekday: 'short' }); fmts.set(tz, f); } return f; };
function parts(t, tz) {
  const o = {}; for (const p of fmt(tz).formatToParts(new Date(t))) o[p.type] = p.value;
  return { y: +o.year, mo: +o.month, d: +o.day, h: +o.hour % 24, mi: +o.minute, s: +o.second, wd: o.weekday };
}
/** UTC ms of a wall-clock time in `tz` (two passes settle the DST offset). */
export function zonedToUtc(y, mo, d, h, mi, tz) {
  let guess = Date.UTC(y, mo - 1, d, h, mi);
  for (let i = 0; i < 2; i++) { const p = parts(guess, tz); const asUtc = Date.UTC(p.y, p.mo - 1, p.d, p.h, p.mi, p.s); guess += Date.UTC(y, mo - 1, d, h, mi) - asUtc; }
  return guess;
}
/** Session opens between `from` and `to` (UTC ms), oldest first: [{ id, key, openAt }]. Weekend opens are skipped. */
export function opensBetween(from, to) {
  const out = [];
  for (const s of SESSIONS) {
    for (let t = from - DAY; t <= to + DAY; t += DAY) {
      const p = parts(t, s.tz);
      const at = zonedToUtc(p.y, p.mo, p.d, s.h, s.m, s.tz);
      const local = parts(at, s.tz);
      if (local.wd === 'Sat' || local.wd === 'Sun') continue;
      if (at < from || at > to) continue;
      const key = `${local.y}-${String(local.mo).padStart(2, '0')}-${String(local.d).padStart(2, '0')}|${s.id}`;
      if (!out.some((x) => x.key === key)) out.push({ id: s.id, key, openAt: at });
    }
  }
  return out.sort((a, b) => a.openAt - b.openAt);
}

/* ───────── quality ───────── */
export const rrOf = (s) => { const risk = Math.abs((s.entry ?? 0) - (s.stop ?? 0)); const t2 = s.targets?.[1]; return risk > 0 && Number.isFinite(t2) ? Math.abs(t2 - s.entry) / risk : 0; };
export function eliteEligible(s) {
  if (!s || typeof s.id !== 'string' || !LIVE.includes(s.status) || !Number.isFinite(s.entry) || !Number.isFinite(s.stop) || s.targets?.length !== 3) return false;
  if (s.tier === 'watch') return false;
  if (s.tier === 'engine') return rrOf(s) >= 2;
  return (Number(s.accuracy) || 0) >= 62 && (Number(s.trades) || 0) >= 30;   // proven combination (the channel's qualified tier)
}
/** Ranking when several qualify at the same moment: proven first, then accuracy, then reward-to-risk. */
export const eliteScore = (s) => (s.tier === 'engine' ? 0 : 100) + (Number(s.accuracy) || 0) + Math.min(rrOf(s), 4) * 5;

const snapshot = (s, open, now) => ({
  eid: `elite|${open.key}|${s.id}`, sid: s.id, session: open.id, sessionKey: open.key, openAt: open.openAt, pickedAt: now,
  symbol: s.symbol, tf: s.tf, strategy: s.strategy, direction: s.direction, precision: s.precision, pointSize: s.pointSize,
  entry: s.entry, stop: s.stop, initialStop: s.initialStop ?? s.stop, targets: s.targets.slice(0, 3), order: s.order || 'market',
  tier: s.tier, accuracy: s.accuracy ?? null, trades: s.trades ?? null, rr: Math.round(rrOf(s) * 100) / 100,
  status: s.status, hits: s.hits || 0, price: s.price ?? null, createdAt: s.createdAt, closedAt: s.closedAt ?? null, brand: ELITE_BRAND,
});

/**
 * Advances the Elite channel. `state` = { picks: [] } (mutated and returned) · `signals` = the channel's recommendations.
 * → { state, added: [new picks], changed }
 */
export function eliteUpdate(state, signals, now = Date.now()) {
  const st = state && Array.isArray(state.picks) ? state : { picks: [] };
  let changed = false; const added = [];
  const byId = new Map((signals || []).filter((s) => s && typeof s.id === 'string').map((s) => [s.id, s]));
  // 1. published picks follow their recommendation (status only — entry / stop / targets stay as published)
  for (const p of st.picks) {
    const s = byId.get(p.sid); if (!s) continue;
    for (const k of ['status', 'hits', 'price', 'closedAt', 'stop']) if (s[k] !== undefined && s[k] !== p[k]) { p[k] = s[k]; changed = true; }
  }
  // 2. instant picks for the sessions whose window is open now
  for (const open of opensBetween(now - OPEN_WINDOW_MS, now)) {
    const mine = st.picks.filter((p) => p.sessionKey === open.key);
    let slots = MAX_PER_OPEN - mine.length; if (slots <= 0) continue;
    const used = new Set(mine.map((p) => p.symbol)); const picked = new Set(st.picks.map((p) => p.sid));
    const cands = [...byId.values()].filter((s) => s.createdAt >= open.openAt && s.createdAt <= open.openAt + OPEN_WINDOW_MS && now - s.createdAt <= FRESH_MS
      && !picked.has(s.id) && !used.has(s.symbol) && eliteEligible(s)).sort((a, b) => eliteScore(b) - eliteScore(a) || a.createdAt - b.createdAt);
    const batch = [];
    for (const s of cands) {
      if (slots <= 0) break; if (used.has(s.symbol)) continue;
      const p = snapshot(s, open, now); batch.push(p); added.push(p); used.add(s.symbol); slots--; changed = true;
    }
    st.picks.unshift(...batch);   // best of the batch listed first
  }
  // 3. keep 14 days, newest first
  const keepFrom = now - KEEP_DAYS * DAY; const before = st.picks.length;
  st.picks = st.picks.filter((p) => p.pickedAt >= keepFrom).sort((a, b) => b.pickedAt - a.pickedAt).slice(0, 300);   // stable sort keeps the batch order
  if (st.picks.length !== before) changed = true;
  return { state: st, added, changed };
}

/** Live board: per session its state now (open window · in session · closed), slots used today and the next open. */
export function sessionBoard(picks, now = Date.now()) {
  const SESSION_HOURS = { sydney: 9, tokyo: 9, london: 9, newyork: 9 };
  const recent = opensBetween(now - DAY - OPEN_WINDOW_MS, now); const next = opensBetween(now, now + 4 * DAY);
  return SESSIONS.map((s) => {
    const last = recent.filter((o) => o.id === s.id).at(-1) || null; const nx = next.find((o) => o.id === s.id) || null;
    const used = last ? (picks || []).filter((p) => p.sessionKey === last.key).length : 0;
    const age = last ? now - last.openAt : Infinity;
    const state = age < OPEN_WINDOW_MS ? 'window' : age < SESSION_HOURS[s.id] * 3600_000 ? 'open' : 'closed';
    return { id: s.id, tz: s.tz, state, used, max: MAX_PER_OPEN, lastOpenAt: last?.openAt ?? null, nextOpenAt: nx?.openAt ?? null, windowEndsAt: last ? last.openAt + OPEN_WINDOW_MS : null };
  });
}

/** Results of the closed picks (counts only; R computed like the channel: a third per target, stop to entry after TP1). */
export function eliteStats(picks) {
  const closed = (picks || []).filter((p) => !LIVE.includes(p.status));
  const win = closed.filter((p) => (p.hits || 0) > 0 || p.status?.startsWith('tp')).length;
  return { total: (picks || []).length, open: (picks || []).filter((p) => LIVE.includes(p.status)).length, closed: closed.length, wins: win, winRate: closed.length ? Math.round((win / closed.length) * 100) : null };
}

/** v237: the one-line alert text of a pick (the same on the page, the phone push and Telegram). Market names and prices are
 * wrapped in Unicode isolates so an Arabic sentence never reorders them ("دخول 4065.25 · وقف 4048.60" stays in this order). */
export function eliteAlertBody(p, lang = 'ar', name = (s) => s) {
  const ar = lang === 'ar'; const iso = (v) => `\u2068${v}\u2069`;
  const dir = p.direction === 'short' ? (ar ? 'بيع' : 'Sell') : (ar ? 'شراء' : 'Buy');
  const tps = (Array.isArray(p.targets) ? p.targets : []).filter((v) => Number.isFinite(Number(v))).slice(0, 3);
  const tp = tps.length ? ` · ${ar ? 'الأهداف' : 'Targets'} ${tps.map((v, i) => iso(`TP${i + 1} ${v}`)).join(' · ')}` : '';   // v238: the targets too
  return `${iso(name(p.symbol))} · ${dir} · ${ar ? 'دخول' : 'Entry'} ${iso(p.entry)} · ${ar ? 'وقف' : 'Stop'} ${iso(p.stop)}${tp}`;
}

/** v238: the Telegram message of a pick — one value per line, so nothing wraps or flips in Arabic. */
export function eliteTelegramText(p, lang = 'ar', name = (s) => s) {
  const ar = lang === 'ar'; const iso = (v) => `\u2068${v}\u2069`; const long = p.direction !== 'short';
  const lines = [`${long ? '🟢' : '🔴'} ${iso(name(p.symbol))} · ${long ? (ar ? 'شراء' : 'Buy') : (ar ? 'بيع' : 'Sell')}`, `${ar ? 'دخول' : 'Entry'}: ${iso(p.entry)}`, `${ar ? 'وقف' : 'Stop'}: ${iso(p.stop)}`];
  (Array.isArray(p.targets) ? p.targets : []).filter((v) => Number.isFinite(Number(v))).slice(0, 3).forEach((v, i) => lines.push(`${ar ? `الهدف ${i + 1}` : `TP${i + 1}`}: ${iso(v)}`));
  return lines.join('\n');
}
