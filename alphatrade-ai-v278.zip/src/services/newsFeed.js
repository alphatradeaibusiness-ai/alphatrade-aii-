// What the news ticker shows for the selected asset: the Forex Factory economic calendar (impact level, forecast,
// previous, actual — straight from the feed) and Forex Factory headlines that mention the asset's topics.
// "Impact" is Forex Factory's own rating plus the list of the site's markets that release usually moves
// (CCY_IMPACT in news.js). It is not a prediction of direction.
import { CCY_IMPACT } from './news.js';
import { getInstrument } from '../config/instruments.js';

const RX = {
  usd: /\b(fed|fomc|powell|usd|dollar|treasur|yields?|cpi|pce|nfp|payrolls?|jobs|jobless|unemployment|gdp|ism|retail sales|inflation|tariff|trump|white house)\b/i,
  gold: /\b(gold|xau|bullion|precious|safe[- ]haven|geopolit|war|iran|israel|russia|ukraine|oil)\b/i,
  crypto: /\b(bitcoin|btc|crypto|ether(eum)?|eth|solana|binance|bnb|etf|stablecoin|sec)\b/i,
  stocks: /\b(stocks?|equit|nasdaq|s&p|dow|spx|ndx|earnings|nvidia|apple|tesla|microsoft|wall street)\b/i,
  eur: /\b(ecb|lagarde|euro|eur|eurozone|germany)\b/i, gbp: /\b(boe|bailey|pound|gbp|uk)\b/i, jpy: /\b(boj|ueda|yen|jpy)\b/i,
};
const FX_RX = { USD: RX.usd, EUR: RX.eur, GBP: RX.gbp, JPY: RX.jpy };

const isFx = (symbol) => getInstrument(symbol)?.type === 'forex';

/** Does this calendar event usually move the symbol? */
export function eventMoves(e, symbol) {
  if (isFx(symbol)) return e.country === symbol.slice(0, 3) || e.country === symbol.slice(3);
  return (CCY_IMPACT[e.country] || []).includes(symbol);
}

/** Does this headline concern the symbol? (topic words; a headline that matches nothing is not shown) */
export function headlineMatches(title, symbol) {
  const type = getInstrument(symbol)?.type;
  if (type === 'forex') return [symbol.slice(0, 3), symbol.slice(3)].some((c) => (FX_RX[c] || /$^/).test(title));
  if (type === 'crypto') return RX.crypto.test(title) || RX.usd.test(title);
  if (type === 'metal') return RX.gold.test(title) || RX.usd.test(title);
  if (type === 'index') return RX.stocks.test(title) || RX.usd.test(title);
  return RX.usd.test(title);
}

/**
 * Items for the ticker: events (High/Medium, from 3 h ago to 24 h ahead) and matching headlines, newest first within
 * each group; events come first (they are the scheduled risk), at most `limit` items in total.
 * @returns {{ kind: 'event'|'news', id, title, impact, time, country?, forecast?, previous?, actual?, url?, source?, ago?, moves: boolean }[]}
 */
export function tickerItems(symbol, events, headlines, now = Date.now(), limit = 14) {
  const ev = (Array.isArray(events) ? events : [])
    .filter((e) => (e.impact === 'High' || e.impact === 'Medium') && e.time >= now - 3 * 3600e3 && e.time <= now + 24 * 3600e3 && eventMoves(e, symbol))
    .sort((a, b) => a.time - b.time)
    .map((e) => ({ kind: 'event', id: e.id, title: e.title, impact: e.impact, time: e.time, country: e.country, forecast: e.forecast, previous: e.previous, actual: e.actual, moves: true }));
  const nw = (Array.isArray(headlines) ? headlines : [])
    .filter((n) => headlineMatches(n.title, symbol))
    .map((n) => ({ kind: 'news', id: n.id, title: n.title, impact: n.impact === 'High' ? 'High' : '', time: n.time, url: n.url, source: n.source, ago: n.ago, moves: true }));
  return [...ev.slice(0, 8), ...nw].slice(0, limit);
}
