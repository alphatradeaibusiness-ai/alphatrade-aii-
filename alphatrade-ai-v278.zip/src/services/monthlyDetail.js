// Month-by-month results: every month on its own (never one pile of many months), closed trades separate from open ones.
// Pure functions. A trade's result is REALISED only: `points` is set when it closes (stop, target or secured stop); the open
// trade is reported separately with its floating result and is never added to a month.
export const monthOf = (timeSec) => new Date(timeSec * 1000).toISOString().slice(0, 7);

/** @param trades closed trades ({points, r, hits, closeTime}); @param pipPts points per pip of the instrument (>0). */
export function monthlyDetail(trades, pipPts = 1) {
  const pip = (x) => x / (pipPts > 0 ? pipPts : 1);
  const by = new Map();
  for (const t of [...trades].sort((a, b) => a.closeTime - b.closeTime)) {
    const k = monthOf(t.closeTime);
    if (!by.has(k)) by.set(k, []);
    by.get(k).push(t);
  }
  return [...by.entries()].map(([month, list]) => {
    const wins = list.filter((t) => t.points > 0), losses = list.filter((t) => t.points <= 0);
    const grossWin = pip(wins.reduce((a, t) => a + t.points, 0)), grossLoss = pip(-losses.reduce((a, t) => a + t.points, 0));
    let eq = 0, pk = 0, dd = 0, run = 0, streak = 0;
    for (const t of list) { eq += t.points; pk = Math.max(pk, eq); dd = Math.max(dd, pk - eq); if (t.points <= 0) { run++; streak = Math.max(streak, run); } else run = 0; }
    return {
      month, trades: list.length, wins: wins.length, losses: losses.length, winRate: list.length ? (100 * wins.length) / list.length : 0,
      grossWinPips: grossWin, grossLossPips: grossLoss, netPips: grossWin - grossLoss,
      avgWinPips: wins.length ? grossWin / wins.length : 0, avgLossPips: losses.length ? grossLoss / losses.length : 0,
      maxLossStreak: streak, maxDrawdownPips: pip(dd),
    };
  });
}

/** Floating (unrealised) result of an open trade, in pips, kept apart from the realised months. */
export function openFloating(open, price, pointSize, pipPts = 1) {
  if (!open || !Number.isFinite(price)) return null;
  const sign = open.direction === 'long' ? 1 : -1;
  return { direction: open.direction, entry: open.entry, price, floatingPips: ((price - open.entry) * sign) / (pointSize || 1) / (pipPts > 0 ? pipPts : 1), hits: open.hits || 0 };
}

/** Total of the months shown (a summary only; the months stay visible). */
export function totalOf(months) {
  const t = months.reduce((a, m) => ({ trades: a.trades + m.trades, wins: a.wins + m.wins, losses: a.losses + m.losses, grossWinPips: a.grossWinPips + m.grossWinPips, grossLossPips: a.grossLossPips + m.grossLossPips, maxLossStreak: Math.max(a.maxLossStreak, m.maxLossStreak) }), { trades: 0, wins: 0, losses: 0, grossWinPips: 0, grossLossPips: 0, maxLossStreak: 0 });
  return { ...t, netPips: t.grossWinPips - t.grossLossPips, winRate: t.trades ? (100 * t.wins) / t.trades : 0 };
}
