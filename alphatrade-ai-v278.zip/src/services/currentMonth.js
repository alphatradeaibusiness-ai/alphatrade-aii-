// Calendar accounting in the user's market timezone. Close time determines attribution.
export function monthKeyAt(date = new Date(), timeZone = 'Asia/Jerusalem') {
  const parts = new Intl.DateTimeFormat('en-US', { timeZone, year: 'numeric', month: '2-digit' }).formatToParts(date);
  return `${parts.find(p => p.type === 'year').value}-${parts.find(p => p.type === 'month').value}`;
}
export function currentMonthTrades(trades, now = new Date()) {
  const key = monthKeyAt(now);
  return trades.filter(t => Number.isFinite(t.closeTime) && t.closeTime * 1000 <= now.getTime() && monthKeyAt(new Date(t.closeTime * 1000)) === key);
}
