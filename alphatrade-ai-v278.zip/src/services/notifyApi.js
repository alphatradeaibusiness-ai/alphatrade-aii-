// Phone-alert settings (Telegram bot + ntfy topic), owner only. The values live on the server, encrypted; the browser
// sends them once when the owner saves and afterwards only sees "set" flags and the last characters.
import { apiRequest } from './ai/gateway.js';

let last = null; const listeners = new Set();
export const onNotify = (fn) => { listeners.add(fn); return () => listeners.delete(fn); };
export const lastNotify = () => last;
function publish(st) { last = { ...st, at: Date.now() }; listeners.forEach((fn) => { try { fn(last); } catch { /* one view must not break the others */ } }); return last; }

export async function notifyStatus() {
  try { return publish(await apiRequest('GET', '/api/notify/status', undefined, 10000)); }
  catch (e) { return publish({ owner: false, state: e.code === 'server_missing' || e.code === 'server_unreachable' ? 'no_server' : 'unknown', error: e.code }); }
}
async function owner(method, path, body, ms) { const r = await apiRequest(method, path, body, ms); if (r.status) publish(r.status); return r; }
export const saveNotify = (cfg) => owner('PUT', '/api/notify/config', cfg, 30000);
export const testNotify = () => owner('POST', '/api/notify/config/test', {}, 30000);
export const deleteNotify = (channel) => owner('DELETE', `/api/notify/config${channel ? `?channel=${encodeURIComponent(channel)}` : ''}`, undefined, 20000);
