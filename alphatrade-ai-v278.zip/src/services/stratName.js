// Display name of a strategy id ('classic' | 'smc' | 'zone' | 'edh' | 'lbr').
import { t, getLang } from '../i18n/index.js';
export const stratName = (s) => (s === 'trend' ? (getLang() === 'ar' ? 'تتبّع الاتجاه' : 'Trend') : s === 'mean_reversion' ? (getLang() === 'ar' ? 'الارتداد للمتوسط' : 'Mean reversion') : s === 'smc' ? 'SMC' : s === 'zone' ? t('zs.name') : s === 'edh' ? 'EDH' : s === 'lbr' ? t('lbr.name') : t('perf.classic'));
