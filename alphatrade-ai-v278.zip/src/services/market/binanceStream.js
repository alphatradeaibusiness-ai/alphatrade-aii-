// Binance real-time market data over WebSocket (public, no key).
// Docs: https://developers.binance.com/docs/binance-spot-api-docs/web-socket-streams
//  • <symbol>@miniTicker  → 24h ticker, pushed every second
//  • <symbol>@kline_<tf>  → the forming candle, pushed every ~1–2 s
//  • <symbol>@aggTrade    → every trade as it happens (the chart symbol only): real-time price
import { marketConfig } from '../../config/market.js';

/**
 * @param {{ symbols: string[], kline?: {symbol:string, interval:string}|null,
 *           onTicker?: (t:object)=>void, onKline?: (k:object)=>void, onStatus?: (s:'connecting'|'open'|'closed')=>void }} opts
 * @returns {{ close: () => void, isOpen: () => boolean }}
 */
export function openBinanceStream({ symbols, kline = null, onTicker, onKline, onTrade, onStatus }) {
  const streams = symbols.map((s) => `${s.toLowerCase()}@miniTicker`);
  if (kline) {
    streams.push(`${kline.symbol.toLowerCase()}@kline_${kline.interval}`);
    if (onTrade) streams.push(`${kline.symbol.toLowerCase()}@aggTrade`);
  }
  const url = `${marketConfig.binanceWsUrl}/stream?streams=${streams.join('/')}`;
  let ws = null;
  let closed = false;
  let open = false;
  let retry = 0;
  let timer = null;

  const connect = () => {
    if (closed || typeof WebSocket === 'undefined') return;
    onStatus?.('connecting');
    ws = new WebSocket(url);
    ws.onopen = () => { open = true; retry = 0; onStatus?.('open'); };
    ws.onmessage = (ev) => {
      let msg;
      try { msg = JSON.parse(ev.data); } catch { return; }
      const d = msg && msg.data;
      if (!d) return;
      if (d.e === '24hrMiniTicker') {
        const price = +d.c;
        const o = +d.o;
        onTicker?.({ symbol: d.s, price, changePct: o ? ((price - o) / o) * 100 : 0, high: +d.h, low: +d.l, volume: +d.v });
      } else if (d.e === 'aggTrade') {
        onTrade?.({ symbol: d.s, price: +d.p, time: d.T });
      } else if (d.e === 'kline' && d.k) {
        const k = d.k;
        onKline?.({ symbol: k.s, interval: k.i, time: Math.floor(k.t / 1000), open: +k.o, high: +k.h, low: +k.l, close: +k.c, volume: +k.v, buyVolume: +k.V });
      }
    };
    ws.onclose = () => {
      open = false;
      if (closed) return;
      onStatus?.('closed');
      // Reconnect with back-off: 1 s, 2 s, 4 s … up to 30 s.
      timer = setTimeout(connect, Math.min(30_000, 1000 * 2 ** retry++));
    };
    ws.onerror = () => { try { ws.close(); } catch { /* ignore */ } };
  };
  connect();

  return {
    isOpen: () => open,
    close() {
      closed = true;
      clearTimeout(timer);
      if (ws) { ws.onclose = null; try { ws.close(); } catch { /* ignore */ } }
      open = false;
    },
  };
}
