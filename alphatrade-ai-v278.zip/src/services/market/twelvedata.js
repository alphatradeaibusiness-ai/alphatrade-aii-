// Twelve Data (XAUUSD and the US indices). The browser uses the server proxy (key saved on the owner page or TWELVEDATA_API_KEY);
// the headless worker may call it directly with TWELVEDATA_API_KEY. Docs: https://twelvedata.com/docs
import { marketConfig } from '../../config/market.js';
import { fetchJson, RequestError } from '../../utils/http.js';

import { readEnv } from '../../config/env.js';

export const TWELVE_SOURCE = 'Twelve Data';
const BASE = readEnv('VITE_TWELVEDATA_BASE_URL', 'https://api.twelvedata.com').replace(/\/$/, '');

function check(body) {
  if (body && body.status === 'error') throw new RequestError('provider', body.message || 'Twelve Data error');
  return body;
}

async function request(endpoint, params) {
  if (marketConfig.twelveDataKey) {
    const url = new URL(`${BASE}/${endpoint}`);
    url.search = new URLSearchParams({...params, apikey:marketConfig.twelveDataKey});
    return check(await fetchJson(url.toString(), {timeoutMs:marketConfig.requestTimeoutMs}));
  }
  return check(await fetchJson('/api/market/twelve', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({endpoint,...params}),timeoutMs:marketConfig.requestTimeoutMs}));
}

export async function fetchTwelveCandles(providerSymbol, interval, limit = marketConfig.candleLimit) {
  const body = await request('time_series', {symbol:providerSymbol,interval,outputsize:limit,order:'ASC',timezone:'UTC'});
  const values = body.values || [];
  return values.map((v) => {
    const vol = v.volume !== undefined ? +v.volume : null;
    return {
      time: Math.floor(Date.parse(`${v.datetime.replace(' ', 'T')}${v.datetime.length > 10 ? '' : 'T00:00:00'}Z`) / 1000),
      open: +v.open, high: +v.high, low: +v.low, close: +v.close,
      volume: Number.isFinite(vol) && vol > 0 ? vol : null,
      buyVolume: null,
    };
  });
}

export async function fetchTwelveQuote(providerSymbol) {
  const q = await request('quote', {symbol:providerSymbol});
  return { at: Number(q.timestamp) > 0 ? Number(q.timestamp) * 1000 : null, price: +q.close, changePct: +q.percent_change, high: +q.high, low: +q.low, volume: q.volume ? +q.volume : null };
}
