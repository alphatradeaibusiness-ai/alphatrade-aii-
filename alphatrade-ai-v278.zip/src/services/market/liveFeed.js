// Live candles for one symbol/timeframe: Binance WebSocket (forming candle every ~1–2 s) or,
// for Twelve Data instruments, polling (their free plan has no stream).
import { getInstrument } from '../../config/instruments.js';
import { marketConfig, TIMEFRAMES } from '../../config/market.js';
import { openBinanceStream } from './binanceStream.js';
import { getCandles } from './index.js';

export function openLiveCandles(symbol, tf, { onCandle, onTicker, onStatus } = {}) {
  const inst = getInstrument(symbol);
  const tfDef = TIMEFRAMES.find((x) => x.id === tf);
  if (inst.provider === 'binance' && marketConfig.streaming && marketConfig.mode !== 'demo') {
    const s = openBinanceStream({ symbols: [symbol], kline: { symbol, interval: tfDef.binance }, onKline: (k) => onCandle?.(k), onTicker, onStatus });
    return { close: () => s.close(), live: true };
  }
  let stop = false;
  const poll = async () => {
    if (stop) return;
    try {
      const ds = await getCandles(symbol, tf);
      if (!stop && ds.candles.length) { onCandle?.(ds.candles.at(-1)); onStatus?.(ds.mode === 'live' ? 'open' : 'closed'); }
    } catch { onStatus?.('closed'); }
  };
  // Refresh every second for real-time price movement (Yahoo quotes are cached 5 s server-side).
  const id = setInterval(poll, 1000);
  return { close: () => { stop = true; clearInterval(id); }, live: false };
}
