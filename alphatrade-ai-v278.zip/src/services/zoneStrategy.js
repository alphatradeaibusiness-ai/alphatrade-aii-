// Zone strategy — supply/demand zones confirmed by volume, a fixed volume profile, RSI and Fibonacci,
// scored out of 100 (default minimum 80). Made for the short timeframes (1m / 5m / 15m) but works on
// any. A trade is only produced when ALL the hard gates pass and the score reaches the minimum:
//
//   Gate  HTF          the trend of a higher timeframe (1m→5m, 5m→15m, 15m→1h …) agrees with the trade
//   Gate  Zone         the closed candle reacts at a fresh supply/demand zone (a base followed by an
//                      impulse of >= 1.5 ATR); a candle outside every zone never produces a signal
//   Gate  Volume       the reaction candle's volume is >= 1.3 x its 20-candle average
//   Gate  Profile      the zone overlaps the POC or a high-volume node of the fixed volume profile
//   Gate  RSI          no buying at RSI >= 70, no selling at RSI <= 30
//   Gate  Reward       target 1 is at least `minRR` times the stop distance
//
//   Score (100)  zone 30 · volume + profile 25 · Fibonacci 25 · RSI 20
//
// Entry is a MARKET entry at the close of the reaction candle (no pending orders). The stop sits
// beyond the zone; targets come from the Fibonacci leg: its end (0.0), then the 1.272 and 1.618
// extensions. Pure functions — nothing here reads the store or the network.
import { atr, rsi, ema, volumeProfile } from '../indicators/index.js';
import { findSwings } from '../indicators/smc.js';
import { aggregate } from './smc2.js';
import { cvdSeries, hasFlow, flowRead, zScoreSeries, zPoints, classifyRegime, REGIME_MULT, SPIKE_EXTRA_SCORE } from './quant.js';

export const ZONE_DEFAULTS = { minScore: 80, htf: true, requireVp: true, minVolRatio: 1.3, minRR: 1, tp1Cap: 0, quant: true, regimeWeights: true, zGate: 0, flowGate: false };
export const ZONE_WEIGHTS = { zone: 30, vp: 25, fib: 25, rsi: 20 };
// Added by the quant layer (order flow + statistical stretch); they join the score only when `quant` is on.
export const QUANT_WEIGHTS = { flow: 15, stat: 10 };
const MAX_AGE = 400;      // candles a zone stays usable
const MAX_RISK_ATR = 4;   // stops wider than this are skipped
const RSI_HIGH = 70;
const RSI_LOW = 30;
const LEG_LOOKBACK = 120; // candles searched for the impulse leg

const body = (c) => Math.abs(c.close - c.open);

/* ───────── Higher-timeframe trend (closed bars only) ───────── */
const htfFactor = (tfSec) => (tfSec <= 60 ? 5 : tfSec <= 300 ? 3 : tfSec <= 3600 ? 4 : 4);
export function htfTrendSeries(candles, tfSec) {
  const out = new Array(candles.length).fill(0);
  const span = tfSec * htfFactor(tfSec);
  const bars = aggregate(candles, span);
  if (bars.length < 40) return out;
  const e = ema(bars.map((b) => b.close), 34);
  let g = -1;
  for (let i = 0; i < candles.length; i++) {
    // last HTF bar fully closed at this candle's close
    while (g + 1 < bars.length && bars[g + 1].time + span <= candles[i].time + tfSec) g++;
    if (g >= 0 && e[g] != null) out[i] = bars[g].close > e[g] ? 1 : -1;
  }
  return out;
}

/* ───────── Zones ───────── */
/** Every supply/demand zone with the candle on which it became known (the impulse close). */
function findZones(c, a) {
  const zones = [];
  const lastE = { long: -1, short: -1 };
  for (let j = 20; j < c.length - 3; j++) {
    const at = a[j - 1];
    if (!(at > 0)) continue;
    for (const dir of ['long', 'short']) {
      const long = dir === 'long';
      if (j <= lastE[dir]) continue;
      if (!(body(c[j]) >= 0.8 * at && (long ? c[j].close > c[j].open : c[j].close < c[j].open))) continue;
      // base: 1–3 quiet candles right before the impulse
      let bi = j - 1;
      let lo = Infinity; let hi = -Infinity; let n = 0;
      while (bi >= j - 3 && n < 3 && c[bi].high - c[bi].low <= 1.0 * at && body(c[bi]) <= 0.7 * at) {
        lo = Math.min(lo, c[bi].low); hi = Math.max(hi, c[bi].high); n++; bi--;
      }
      if (!n) continue;
      const height = hi - lo;
      if (!(height > 0.1 * at) || height > 1.5 * at) continue;
      let e = -1;
      for (let m = 0; m <= 2; m++) {
        const k = j + m;
        if (long ? c[k].close >= hi + 1.5 * at : c[k].close <= lo - 1.5 * at) { e = k; break; }
      }
      if (e < 0) continue;
      const disp = (long ? c[e].close - hi : lo - c[e].close) / at;
      zones.push({ id: `${dir}|${c[j].time}`, dir, bottom: lo, top: hi, baseIndex: bi + 1, impulse: j, known: e, disp, atr: at, time: c[bi + 1].time });
      lastE[dir] = e;
    }
  }
  zones.sort((x, y) => x.known - y.known);
  // when does each zone die (close through it) and when does price touch it
  for (const z of zones) {
    const long = z.dir === 'long';
    z.dead = c.length;
    z.episodes = [];
    let prev = false;
    for (let k = z.known + 1; k < c.length; k++) {
      if (long ? c[k].close < z.bottom : c[k].close > z.top) { z.dead = k; break; }
      const touch = long ? c[k].low <= z.top : c[k].high >= z.bottom;
      if (touch && !prev) z.episodes.push(k);
      prev = touch;
    }
  }
  return zones;
}

export function prepare(candles, opts = {}) {
  const o = { ...ZONE_DEFAULTS, ...opts };
  const tfSec = candles.length > 1 ? candles[1].time - candles[0].time : 60;
  const a = atr(candles, 14);
  const closes = candles.map((x) => x.close);
  const vol = candles.map((x) => (Number.isFinite(x.volume) ? x.volume : 0));
  const sum = new Array(candles.length + 1).fill(0);
  for (let i = 0; i < candles.length; i++) sum[i + 1] = sum[i] + vol[i];
  return {
    c: candles, o, tfSec, atr: a,
    rsi: rsi(candles.map((x) => x.close), 14),
    sw: findSwings(candles, 2),
    htf: htfTrendSeries(candles, tfSec),
    zones: findZones(candles, a),
    vol, volSum: sum,
    hasVolume: sum[candles.length] > 0,
    closes, z: zScoreSeries(closes, 50), cvd: cvdSeries(candles), flowOk: hasFlow(candles), regimeAt: new Array(candles.length),
  };
}

/** Average volume of the 20 candles before `i`. */
const volAvg = (S, i) => (i >= 20 ? (S.volSum[i] - S.volSum[i - 20]) / 20 : 0);

/* ───────── Fixed volume profile ───────── */
/** Profile anchored at the start of the current UTC day (or the last 200 candles early in the day). */
function fixedProfile(S, i) {
  const { c } = S;
  const dayStart = Math.floor(c[i].time / 86400) * 86400;
  let from = i;
  while (from > 0 && c[from - 1].time >= dayStart && i - from < 600) from--;
  if (i - from < 60) from = Math.max(0, i - 199);
  return volumeProfile(c, { rows: 40, from, to: i, valueAreaPct: 70 });
}

/* ───────── Divergence ───────── */
/**
 * Confirmed RSI divergence between the last two swings:
 *   regular — price makes a lower low (buy) / higher high (sell) but RSI does not: a reversal signal;
 *   hidden  — price makes a higher low (buy) / lower high (sell) but RSI makes the opposite: the trend continues.
 * Returns 'regular' | 'hidden' | null.
 */
export function divergence(S, i, dir) {
  const long = dir === 'long';
  const pts = [];
  for (let k = S.sw.length - 1; k >= 0 && pts.length < 2; k--) {
    const p = S.sw[k];
    if (p.index + 2 > i) continue;
    if (p.index < i - 60) break;
    if (p.type === (long ? 'low' : 'high') && S.rsi[p.index] != null) pts.push(p);
  }
  if (pts.length < 2) return null;
  const [b, a] = pts; // b = newer, a = older
  if (b.index - a.index < 5) return null;
  const dr = S.rsi[b.index] - S.rsi[a.index];
  if (long) {
    if (b.price <= a.price && dr > 2) return 'regular';
    if (b.price > a.price && dr < -2) return 'hidden';
  } else {
    if (b.price >= a.price && dr < -2) return 'regular';
    if (b.price < a.price && dr > 2) return 'hidden';
  }
  return null;
}

/* ───────── Detection ───────── */
const FIB_EXT = [0, 1.272, 1.618];

export function detect(S, i, dir) {
  const { c, o } = S;
  const long = dir === 'long';
  const at = S.atr[i];
  S.stage = 'none';
  if (!(at > 0) || i < 60) return null;
  const k = c[i];
  const range = k.high - k.low;
  if (!(range > 0)) return null;

  // 1 — a fresh zone this candle reacts at
  let zone = null; let touchNo = 0;
  for (let zi = S.zones.length - 1; zi >= 0; zi--) {
    const z = S.zones[zi];
    if (z.known >= i) continue;
    if (i - z.known > MAX_AGE) break;
    if (z.dir !== dir || z.dead <= i) continue;
    if (!(long ? k.low <= z.top : k.high >= z.bottom)) continue;
    // the reaction candle is the first (or second) candle of a touch; that touch must be the 1st or 2nd
    let n = 0; let s = -1;
    for (const ep of z.episodes) { if (ep <= i) { n++; s = ep; } else break; }
    if (n < 1 || n > 2 || i > s + 1) continue;
    // closes back out of the zone with a rejection shape
    const wick = long ? Math.min(k.open, k.close) - k.low : k.high - Math.max(k.open, k.close);
    const dirCandle = long ? k.close > k.open : k.close < k.open;
    if (!(long ? k.close > z.bottom : k.close < z.top)) continue;
    if (!(dirCandle || wick >= 0.5 * range)) continue;
    if (!(wick >= 0.5 * body(k) || dirCandle)) continue;
    zone = z; touchNo = n; break;
  }
  if (!zone) return null;
  S.stage = 'zone';
  if (S.stats) S.stats.zone++;

  // gate: higher-timeframe trend
  const htf = S.htf[i];
  const htfOk = !o.htf || htf === (long ? 1 : -1);
  if (!htfOk) return { rejected: 'htf', zone };
  S.stage = 'htf';
  if (S.stats) S.stats.htf++;

  // gate: RSI extremes
  const r = S.rsi[i];
  if (r == null) return null;
  if (long ? r >= RSI_HIGH : r <= RSI_LOW) return { rejected: 'rsi', zone };
  S.stage = 'rsi';
  if (S.stats) S.stats.rsi++;

  // gate: volume supports the move
  const va = volAvg(S, i);
  const vr = va > 0 ? S.vol[i] / va : 0;
  if (S.hasVolume && !(vr >= o.minVolRatio)) return { rejected: 'volume', zone };
  S.stage = 'volume';
  if (S.stats) S.stats.volume++;

  // gate: zone overlaps the POC or a high-volume node of the fixed profile
  let vp = null; let vpHit = 'none';
  if (S.hasVolume) {
    vp = fixedProfile(S, i);
    if (vp) {
      const tol = vp.step * 0.5;
      const overlap = (x0, x1) => zone.bottom - tol <= x1 && x0 <= zone.top + tol;
      if (overlap(vp.poc - vp.step / 2, vp.poc + vp.step / 2)) vpHit = 'poc';
      else if (vp.bins.some((b) => b.volume >= 0.6 * vp.maxVolume && overlap(b.low, b.high))) vpHit = 'hvn';
      else if (overlap(long ? vp.val - vp.step : vp.vah, long ? vp.val : vp.vah + vp.step)) vpHit = 'edge';
      else if (zone.bottom >= vp.val && zone.top <= vp.vah) vpHit = 'inside';
    }
    if (o.requireVp && !(vpHit === 'poc' || vpHit === 'hvn')) return { rejected: 'profile', zone };
  }
  S.stage = 'profile';
  if (S.stats) S.stats.profile++;

  // Fibonacci leg = the latest impulse before this pullback: from the lowest low of the lookback to
  // the highest high after it (mirrored for sells). The entry should sit in the 0.5–0.618 pocket.
  const from = Math.max(0, i - LEG_LOOKBACK);
  let ai = from;
  for (let j = from; j < i; j++) if (long ? c[j].low < c[ai].low : c[j].high > c[ai].high) ai = j;
  let bi2 = ai;
  for (let j = ai; j < i; j++) if (long ? c[j].high > c[bi2].high : c[j].low < c[bi2].low) bi2 = j;
  const A = long ? c[ai].low : c[ai].high;
  const B = long ? c[bi2].high : c[bi2].low;
  const leg = long ? B - A : A - B;
  if (!(leg >= 2 * at) || bi2 <= ai) return { rejected: 'fib', zone };
  const entry = k.close;
  const ratio = long ? (B - entry) / leg : (entry - B) / leg;
  if (ratio < 0.382 || ratio > 0.786) return { rejected: 'fib', zone };

  // stop beyond the zone and this candle's extreme; capped
  const ext = long ? Math.min(zone.bottom, k.low) : Math.max(zone.top, k.high);
  const stop = long ? ext - 0.2 * at : ext + 0.2 * at;
  const risk = Math.abs(entry - stop);
  if (!(risk > 0) || risk > MAX_RISK_ATR * at) return { rejected: 'risk', zone };
  const sign = long ? 1 : -1;
  const targets = FIB_EXT.map((x) => B + sign * x * leg);
  // optional cap: target 1 is never farther than `tp1Cap` x the stop distance (more hits, smaller wins)
  if (o.tp1Cap > 0 && (targets[0] - entry) * sign > o.tp1Cap * risk) targets[0] = entry + sign * o.tp1Cap * risk;
  // ensure targets lie beyond the entry; the leg end is the first
  if ((targets[0] - entry) * sign < risk * o.minRR) return { rejected: 'rr', zone };
  S.stage = 'setup';
  if (S.stats) S.stats.setup++;

  const wick = long ? Math.min(k.open, k.close) - k.low : k.high - Math.max(k.open, k.close);
  return {
    direction: dir, entry, stop, risk, targets, key: `${zone.id}|${touchNo}|${c[i].time}`, createdTime: c[i].time,
    zone, touchNo, vr, vpHit, vp, ratio, leg: { A, B }, rsi: r, wick: wick / range, htf,
    div: divergence(S, i, dir), index: i,
  };
}

/* ───────── Scoring ───────── */
/** Points per condition out of the 4 weights; volume/profile is "n/a" when the feed has no volume. */
export function scoreSetup(S, s) {
  const parts = {}; const na = {};
  // zone quality: freshness 12 · impulse strength 8 · rejection shape 10
  const fresh = s.touchNo === 1 ? 12 : 7;
  const imp = s.zone.disp >= 3 ? 8 : s.zone.disp >= 2 ? 6 : 4;
  const rej = s.wick >= 0.6 ? 10 : s.wick >= 0.4 ? 7 : 4;
  parts.zone = fresh + imp + rej;
  // volume 10 + profile 15
  if (!S.hasVolume) { na.vp = true; parts.vp = 0; } else {
    const v = s.vr >= 2 ? 10 : s.vr >= 1.5 ? 8 : 6;
    const p = s.vpHit === 'poc' ? 15 : s.vpHit === 'hvn' ? 12 : s.vpHit === 'edge' ? 9 : s.vpHit === 'inside' ? 4 : 0;
    parts.vp = v + p;
  }
  // Fibonacci: the golden pocket 0.5–0.65 is the ideal entry
  const r = s.ratio;
  parts.fib = r >= 0.5 && r <= 0.65 ? 25 : (r >= 0.382 && r < 0.5) || (r > 0.65 && r <= 0.786) ? 15 : 8;
  // RSI: not stretched (10, full at <=55 for buys) + a confirmed divergence (regular 10, hidden 7)
  const long = s.direction === 'long';
  const calm = long ? s.rsi <= 55 : s.rsi >= 45;
  parts.rsi = (calm ? 10 : 6) + (s.div === 'regular' ? 10 : s.div === 'hidden' ? 7 : 0);
  // quant layer: order flow (CVD absorption / imbalance) and z-score stretch, plus regime-dependent weights
  const q = S.o.quant !== false;
  let regime = 'mixed'; let flow = null;
  const W = { ...ZONE_WEIGHTS };
  if (q) {
    Object.assign(W, QUANT_WEIGHTS);
    flow = S.flowOk ? flowRead(S.c, S.cvd, s.index, s.direction) : { ok: false, points: 0, kinds: [] };
    if (!flow.ok) { na.flow = true; parts.flow = 0; } else parts.flow = flow.points;
    parts.stat = zPoints(S.z[s.index], s.direction);
    if (S.regimeAt[s.index] == null) S.regimeAt[s.index] = classifyRegime(S.c, S.atr, S.closes, s.index);
    regime = S.regimeAt[s.index];
  }
  const mult = q && S.o.regimeWeights !== false ? REGIME_MULT[regime] : null;
  let applicable = 0; let earned = 0;
  for (const k of Object.keys(W)) {
    if (na[k]) continue;
    const m = mult ? mult[k] ?? 1 : 1;
    applicable += W[k] * m; earned += (parts[k] || 0) * m;
  }
  return { score: applicable ? (earned / applicable) * 100 : 0, parts, na, regime, flow, z: q ? S.z[s.index] : null };
}

export function evaluate(S, i, { forced = null } = {}) {
  let best = null; let rejected = null;
  for (const dir of ['long', 'short']) {
    if (forced && forced !== dir) continue;
    const s = detect(S, i, dir);
    if (!s) continue;
    if (s.rejected) { rejected = { reason: s.rejected, setup: { key: `${s.zone.id}|${i}`, direction: dir } }; continue; }
    const sc = scoreSetup(S, s);
    s.score = sc.score; s.scoreParts = sc.parts; s.scoreNa = sc.na; s.regime = sc.regime; s.flow = sc.flow; s.zscore = sc.z;
    // a price spike needs a higher score (the quant layer treats spikes as the riskiest regime)
    const need = S.o.minScore + (S.o.quant !== false && S.o.regimeWeights !== false && sc.regime === 'spike' ? SPIKE_EXTRA_SCORE : 0);
    if (s.score < need) { rejected = { reason: 'score', setup: s }; continue; }
    // optional hard gates (off by default): mean-reversion stretch and order-flow confirmation
    if (S.o.quant !== false && S.o.zGate > 0 && (sc.parts.stat ?? 0) < zPoints(dir === 'long' ? -S.o.zGate : S.o.zGate, dir)) { rejected = { reason: 'zscore', setup: s }; continue; }
    if (S.o.quant !== false && S.o.flowGate && !sc.na.flow && sc.flow.points < 8) { rejected = { reason: 'flow', setup: s }; continue; }
    if (!best || s.score > best.score) best = s;
  }
  return { setup: best, rejected: best ? null : rejected };
}

/** Where the strategy stands on candle `i`: nearest zones and how far each side got. */
export function explain(S, i) {
  const { c } = S;
  const out = { time: c[i].time, htf: S.htf[i] || null, rsi: S.rsi[i], stage: {}, zones: { demand: null, supply: null } };
  const price = c[i].close;
  for (const dir of ['long', 'short']) {
    detect(S, i, dir);
    out.stage[dir] = S.stage;
    let nearest = null;
    for (const z of S.zones) {
      if (z.known >= i || i - z.known > MAX_AGE || z.dir !== dir || z.dead <= i) continue;
      const n = z.episodes.filter((e) => e <= i).length;
      if (n > 2) continue;
      const d = dir === 'long' ? price - z.top : z.bottom - price;
      if (d < -z.atr) continue; // price already far inside/through
      if (!nearest || d < nearest.d) nearest = { d, bottom: z.bottom, top: z.top, fresh: n === 0, time: z.time };
    }
    out.zones[dir === 'long' ? 'demand' : 'supply'] = nearest;
  }
  return out;
}
