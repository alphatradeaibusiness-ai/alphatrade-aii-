// v251 Strategy Studio — the rule-based strategy builder, its back-test, the Strategy DNA (digital fingerprint) and the
// similarity between strategies. Pure functions (no DOM, no network): the page, the server (Anonymous Strategy Arena) and the
// tests run exactly the same code on the same candles. Indicators come from the platform's own library.
//
// A strategy spec (validated, bounded):
//   { name, market, symbol, tf, side: 'long'|'short'|'both',
//     entry: [rule…] (ALL must hold on the closed candle; entry at the NEXT candle's open),
//     exit: { stopAtr, rr, maxBars, trail: bool } }
// Rules: ema_cross {fast, slow, dir} · price_ema {len, dir} · rsi {len, op, level} · bb_touch {len, mult, band} ·
//        adx {len, op, level} · breakout {len, dir} · macd {dir} · session {name} · atr_pct {op, level}
// The back-test is conservative: costs are charged, a candle that touches both stop and target counts as a stop.
import { ema, rsi, atr, bollinger } from '../indicators/index.js';
import { adx as adxCalc, macd as macdCalc } from './multiStrategy.js';

export const LAB_TFS = ['15m', '1h', '4h', '1D'];
export const LAB_SYMBOLS = ['BTCUSDT', 'ETHUSDT', 'XAUUSD', 'XAGUSD', 'EURUSD', 'GBPUSD', 'USDJPY', 'US100', 'US30', 'SPX500', 'GER40'];
export const RULES = {
  ema_cross: { p: { fast: [3, 100, 20], slow: [5, 300, 50], dir: ['up', 'down'] }, kind: 'trend', ar: 'تقاطع متوسطين', en: 'EMA cross' },
  price_ema: { p: { len: [5, 300, 200], dir: ['above', 'below'] }, kind: 'trend', ar: 'السعر فوق/تحت متوسط', en: 'Price vs EMA' },
  rsi: { p: { len: [2, 50, 14], op: ['lt', 'gt'], level: [5, 95, 30] }, kind: 'meanrev', ar: 'مؤشر RSI', en: 'RSI' },
  bb_touch: { p: { len: [5, 100, 20], mult: [1, 4, 2], band: ['lower', 'upper'] }, kind: 'meanrev', ar: 'لمس حد بولينجر', en: 'Bollinger touch' },
  adx: { p: { len: [5, 50, 14], op: ['gt', 'lt'], level: [5, 60, 20] }, kind: 'filter', ar: 'قوة الاتجاه ADX', en: 'ADX strength' },
  breakout: { p: { len: [5, 200, 20], dir: ['up', 'down'] }, kind: 'breakout', ar: 'اختراق أعلى/أدنى N شمعة', en: 'N-bar breakout' },
  macd: { p: { dir: ['up', 'down'] }, kind: 'momentum', ar: 'تقاطع MACD', en: 'MACD cross' },
  session: { p: { name: ['asia', 'london', 'newyork'] }, kind: 'filter', ar: 'جلسة التداول', en: 'Session' },
  atr_pct: { p: { op: ['gt', 'lt'], level: [0.02, 10, 0.3] }, kind: 'filter', ar: 'التذبذب (ATR %)', en: 'Volatility (ATR %)' },
};
const COST_PCT = { crypto: 0.08, forex: 0.02, metal: 0.04, index: 0.03 };   // round trip, % of price
export const assetClass = (sym) => (/USDT$/.test(sym) ? 'crypto' : /^X(AU|AG|PT|PD)/.test(sym) ? 'metal' : /^(US|GER|UK|SPX|JP|HK|FRA|EU|AUS)/.test(sym) ? 'index' : 'forex');

const num = (v, [lo, hi]) => { const n = Number(v); return Number.isFinite(n) ? Math.min(hi, Math.max(lo, n)) : null; };
/** A clean, bounded spec — or { error }. Never trust a spec from a page. */
export function cleanSpec(s = {}) {
  const symbol = LAB_SYMBOLS.includes(s.symbol) ? s.symbol : null; if (!symbol) return { error: 'symbol' };
  const tf = LAB_TFS.includes(s.tf) ? s.tf : null; if (!tf) return { error: 'tf' };
  const side = ['long', 'short', 'both'].includes(s.side) ? s.side : 'both';
  const entry = [];
  for (const r of Array.isArray(s.entry) ? s.entry.slice(0, 6) : []) {
    const def = RULES[r?.type]; if (!def) return { error: 'rule' };
    const p = {};
    for (const [k, d] of Object.entries(def.p)) {
      if (typeof d[0] === 'string') { p[k] = d.includes(r[k]) ? r[k] : d[0]; continue; }
      const v = num(r[k] ?? d[2], d); if (v == null) return { error: 'param' }; p[k] = d[1] <= 10 && k !== 'len' ? +v.toFixed(2) : Math.round(v);
    }
    if (r.type === 'ema_cross' && p.fast >= p.slow) return { error: 'ema_order' };
    entry.push({ type: r.type, ...p });
  }
  if (!entry.length) return { error: 'no_rules' };
  const ex = s.exit || {};
  const exit = { stopAtr: num(ex.stopAtr ?? 1.5, [0.3, 6]), rr: num(ex.rr ?? 2, [0.5, 8]), maxBars: Math.round(num(ex.maxBars ?? 48, [3, 500])), trail: Boolean(ex.trail) };
  return { name: String(s.name || '').replace(/[\u0000-\u001f<>]/g, '').trim().slice(0, 60) || 'Strategy', symbol, tf, side, entry, exit, market: assetClass(symbol) };
}

/* ───────── indicators per spec (computed once) ───────── */
function series(c, spec) {
  const closes = c.map((x) => x.close); const S = { closes, atr: atr(c, 14) };
  const memo = (k, f) => (S[k] ||= f());
  for (const r of spec.entry) {
    if (r.type === 'ema_cross') { memo(`e${r.fast}`, () => ema(closes, r.fast)); memo(`e${r.slow}`, () => ema(closes, r.slow)); }
    if (r.type === 'price_ema') memo(`e${r.len}`, () => ema(closes, r.len));
    if (r.type === 'rsi') memo(`r${r.len}`, () => rsi(closes, r.len));
    if (r.type === 'bb_touch') memo(`b${r.len}_${r.mult}`, () => bollinger(closes, r.len, r.mult));
    if (r.type === 'adx') memo(`a${r.len}`, () => adxCalc(c, r.len));
    if (r.type === 'macd') memo('macd', () => macdCalc(closes));
  }
  return S;
}
const sessionOf = (t) => { const h = new Date(t * 1000).getUTCHours(); return h < 7 ? 'asia' : h < 13 ? 'london' : h < 21 ? 'newyork' : 'asia'; };
/** Does rule r hold on candle i for this direction? (rules with a direction are mirrored for shorts when side is 'both') */
function holds(r, i, c, S, dir) {
  const flip = (v, a, b) => (dir === 'short' ? (v === a ? b : v === b ? a : v) : v);
  const cmp = (x, op, lvl) => x != null && (op === 'gt' ? x > lvl : x < lvl);
  switch (r.type) {
    case 'ema_cross': { const f = S[`e${r.fast}`], s = S[`e${r.slow}`]; if (f[i] == null || s[i] == null || f[i - 1] == null) return false; const up = f[i] > s[i] && f[i - 1] <= s[i - 1]; const dn = f[i] < s[i] && f[i - 1] >= s[i - 1]; return flip(r.dir, 'up', 'down') === 'up' ? up : dn; }
    case 'price_ema': { const e = S[`e${r.len}`][i]; if (e == null) return false; return flip(r.dir, 'above', 'below') === 'above' ? c[i].close > e : c[i].close < e; }
    case 'rsi': { const v = S[`r${r.len}`][i]; const op = flip(r.op, 'lt', 'gt'); const lvl = dir === 'short' && r.op !== op ? 100 - r.level : r.level; return cmp(v, op, lvl); }
    case 'bb_touch': { const b = S[`b${r.len}_${r.mult}`]; const band = flip(r.band, 'lower', 'upper'); return band === 'lower' ? b.lower[i] != null && c[i].low <= b.lower[i] : b.upper[i] != null && c[i].high >= b.upper[i]; }
    case 'adx': return cmp(S[`a${r.len}`][i], r.op, r.level);
    case 'breakout': { if (i < r.len + 1) return false; let hi = -Infinity, lo = Infinity; for (let k = i - r.len; k < i; k++) { hi = Math.max(hi, c[k].high); lo = Math.min(lo, c[k].low); } return flip(r.dir, 'up', 'down') === 'up' ? c[i].close > hi : c[i].close < lo; }
    case 'macd': { const m = S.macd; const a = m?.macd || m?.line, s = m?.signal; if (!a || !s || a[i] == null || s[i] == null || a[i - 1] == null || s[i - 1] == null) return false; const up = a[i] > s[i] && a[i - 1] <= s[i - 1]; const dn = a[i] < s[i] && a[i - 1] >= s[i - 1]; return flip(r.dir, 'up', 'down') === 'up' ? up : dn; }
    case 'session': return sessionOf(c[i].time) === r.name;
    case 'atr_pct': { const a = S.atr[i]; return a != null && cmp((a / c[i].close) * 100, r.op, r.level); }
    default: return false;
  }
}

/**
 * Back-test a clean spec on closed candles. → { trades: [{ i, dir, entry, stop, target, exitI, exit, r, why }], metrics, equity }
 * from/to: candle index window (signals only inside it — used for in-sample / out-of-sample splits).
 */
export function backtest(spec, candles, { from = 0, to = candles.length - 1 } = {}) {
  const c = candles; const S = series(c, spec); const costR = (COST_PCT[spec.market] ?? 0.05) / 100;
  const dirs = spec.side === 'both' ? ['long', 'short'] : [spec.side];
  const trades = []; let busyUntil = -1;
  for (let i = Math.max(from, 60); i < Math.min(to, c.length - 2); i++) {
    if (i <= busyUntil) continue;
    const a = S.atr[i]; if (!(a > 0)) continue;
    const dir = dirs.find((d) => spec.entry.every((r) => holds(r, i, c, S, d))); if (!dir) continue;
    const sg = dir === 'long' ? 1 : -1; const entry = c[i + 1].open; const risk = spec.exit.stopAtr * a;
    let stop = entry - sg * risk; const target = entry + sg * risk * spec.exit.rr;
    let exitI = null, exit = null, why = null;
    for (let k = i + 1; k < c.length && k <= i + spec.exit.maxBars; k++) {
      const hitStop = sg > 0 ? c[k].low <= stop : c[k].high >= stop; const hitT = sg > 0 ? c[k].high >= target : c[k].low <= target;
      if (hitStop) { exitI = k; exit = stop; why = 'stop'; break; }   // a candle touching both counts as the stop (conservative)
      if (hitT) { exitI = k; exit = target; why = 'target'; break; }
      if (spec.exit.trail && S.atr[k] > 0) { const t = c[k].close - sg * spec.exit.stopAtr * S.atr[k]; if ((t - stop) * sg > 0) stop = t; }
    }
    if (exitI == null) { const k = Math.min(c.length - 1, i + spec.exit.maxBars); if (k <= i + 1 && k >= c.length - 1) break; exitI = k; exit = c[k].close; why = 'time'; }
    const r = ((exit - entry) * sg) / risk - (costR * entry) / risk;
    trades.push({ i, t: c[i + 1].time, dir, entry, stop: entry - sg * risk, target, exitI, exit, r: +r.toFixed(3), why, bars: exitI - i });
    busyUntil = exitI;
  }
  return { trades, metrics: metrics(trades, Math.max(1, Math.min(to, c.length - 1) - Math.max(from, 60))), equity: trades.reduce((a, t) => { a.push(+((a.at(-1) || 0) + t.r).toFixed(3)); return a; }, []) };
}
export function metrics(trades, bars = 1) {
  const rs = trades.map((t) => t.r); const n = rs.length;
  const wins = rs.filter((r) => r > 0); const gw = wins.reduce((s, r) => s + r, 0); const gl = -rs.filter((r) => r < 0).reduce((s, r) => s + r, 0);
  let eq = 0, peak = 0, dd = 0; for (const r of rs) { eq += r; peak = Math.max(peak, eq); dd = Math.max(dd, peak - eq); }
  const mean = n ? rs.reduce((s, r) => s + r, 0) / n : 0; const sd = n > 1 ? Math.sqrt(rs.reduce((s, r) => s + (r - mean) ** 2, 0) / (n - 1)) : 0;
  return { n, winRate: n ? +(wins.length / n * 100).toFixed(1) : 0, expR: +mean.toFixed(3), totalR: +eq.toFixed(2), pf: gl ? +(gw / gl).toFixed(2) : (gw ? 99 : 0), maxDdR: +dd.toFixed(2),
    sharpe: sd ? +((mean / sd) * Math.sqrt(n)).toFixed(2) : 0, perHundred: +((n / bars) * 100).toFixed(2), avgBars: n ? +(trades.reduce((s, t) => s + t.bars, 0) / n).toFixed(1) : 0 };
}
/** In-sample (first 70 %) vs out-of-sample (last 30 %) on the same candles. */
export function splitTest(spec, candles) {
  const cut = Math.floor(candles.length * 0.7);
  return { all: backtest(spec, candles).metrics, is: backtest(spec, candles, { to: cut }).metrics, oos: backtest(spec, candles, { from: cut }).metrics };
}

/* ───────── Strategy DNA ───────── */
export const DNA_AXES = [
  ['trend', 'اتجاه', 'Trend'], ['meanrev', 'ارتداد', 'Mean reversion'], ['breakout', 'اختراق', 'Breakout'], ['momentum', 'زخم', 'Momentum'],
  ['filters', 'فلاتر', 'Filters'], ['risk', 'مخاطرة', 'Risk'], ['reward', 'عائد', 'Reward'], ['speed', 'سرعة', 'Speed'], ['frequency', 'تكرار', 'Frequency'], ['edge', 'أفضلية', 'Edge'],
];
const TFR = { '15m': 0.9, '1h': 0.65, '4h': 0.4, '1D': 0.15 };
/** The fingerprint vector (0..1 per axis) from the rules and, when given, the back-test behaviour. */
export function dnaVector(spec, m = null) {
  const k = { trend: 0, meanrev: 0, breakout: 0, momentum: 0, filter: 0 };
  for (const r of spec.entry) k[RULES[r.type].kind] += 1;
  const tot = Math.max(1, spec.entry.length);
  const v = {
    trend: k.trend / tot, meanrev: k.meanrev / tot, breakout: k.breakout / tot, momentum: k.momentum / tot, filters: Math.min(1, k.filter / 2),
    risk: Math.min(1, spec.exit.stopAtr / 4), reward: Math.min(1, spec.exit.rr / 5), speed: TFR[spec.tf] ?? 0.5,
    frequency: m ? Math.min(1, (m.perHundred || 0) / 5) : 0.5, edge: m ? Math.max(0, Math.min(1, 0.5 + (m.expR || 0))) : 0.5,
  };
  return DNA_AXES.map(([a]) => +v[a].toFixed(3));
}
const canon = (spec) => JSON.stringify({ s: spec.symbol, t: spec.tf, d: spec.side, e: [...spec.entry].map((r) => Object.keys(r).sort().map((x) => `${x}=${r[x]}`).join(',')).sort(), x: spec.exit });
/** FNV-1a 64-bit (BigInt) — deterministic in node and the browser. */
function fnv64(str) { let h = 0xcbf29ce484222325n; for (const ch of new TextEncoder().encode(str)) { h ^= BigInt(ch); h = (h * 0x100000001b3n) & 0xffffffffffffffffn; } return h.toString(16).padStart(16, '0'); }
/** → { id: 'DNA-XXXX-XXXX-XXXX', vector, family, genes: [...] } */
export function strategyDna(spec, m = null) {
  const vector = dnaVector(spec, m); const h = fnv64(canon(spec)).toUpperCase();
  const top = DNA_AXES.slice(0, 4).map((a, i) => [a, vector[i]]).sort((x, y) => y[1] - x[1])[0][0];
  const genes = spec.entry.map((r) => `${r.type}(${Object.entries(r).filter(([x]) => x !== 'type').map(([, v]) => v).join(',')})`);
  return { id: `DNA-${h.slice(0, 4)}-${h.slice(4, 8)}-${h.slice(8, 12)}`, vector, family: top[0], familyName: { ar: top[1], en: top[2] }, genes, tf: spec.tf, market: spec.market, symbol: spec.symbol };
}
/** Cosine similarity of two DNA vectors (0..1). */
export function dnaSimilarity(a, b) {
  let d = 0, x = 0, y = 0; for (let i = 0; i < Math.min(a.length, b.length); i++) { d += a[i] * b[i]; x += a[i] ** 2; y += b[i] ** 2; }
  return x && y ? +(d / Math.sqrt(x * y)).toFixed(3) : 0;
}

/* ───────── Anonymous Strategy Arena scoring (transparent) ───────── */
/**
 * Score of one entry from its out-of-sample and forward (after submission) results. A minimum of 10 trades counts; fewer → unranked.
 * score = 60 × clamp(expR on OOS+forward, −1..1) mapped to 0..60 + 25 × profit-factor (capped at 3) / 3 − 15 × drawdown share.
 */
export function arenaScore(oos, fwd = null) {
  const n = (oos?.n || 0) + (fwd?.n || 0); if (n < 10) return { ranked: false, score: null, n };
  const expR = ((oos?.expR || 0) * (oos?.n || 0) + (fwd?.expR || 0) * (fwd?.n || 0)) / n;
  const pf = Math.min(3, ((oos?.pf || 0) * (oos?.n || 0) + (fwd?.pf || 0) * (fwd?.n || 0)) / n);
  const dd = Math.max(oos?.maxDdR || 0, fwd?.maxDdR || 0); const tot = Math.abs((oos?.totalR || 0) + (fwd?.totalR || 0)) || 1;
  const s = 30 * (Math.max(-1, Math.min(1, expR)) + 1) + (25 * pf) / 3 - 15 * Math.min(1, dd / (dd + tot));
  return { ranked: true, score: +s.toFixed(1), n, expR: +expR.toFixed(3), pf: +pf.toFixed(2), dd };
}
