// Short phone alerts for a trade's events (target hit, final target, stop, closed at entry), in the style
// "Take Profit 1 Smashed! 🎯 — XAU/USD hit TP1 ($3926.92)! Stop Loss moved to Entry ($3964.64) — trade is now Risk-Free."
// Pure: no DOM, no i18n store, so the browser, the worker and the server all use the same text.
// The stop really moves to the entry after TP1 in both engines (signals.js trackOnce and smcAssist.trackTrade);
// the percentage is the PRICE move from the entry, not an account return — the text says so.

const CCY = ['USD', 'EUR', 'GBP', 'JPY', 'CHF', 'CAD', 'AUD', 'NZD'];
const METALS = ['XAU', 'XAG', 'XPT', 'XPD'];
const USD_INDICES = ['US30', 'US100', 'SPX500', 'USOIL', 'UKOIL', 'NATGAS', 'COPPER'];

/** BTCUSDT → BTC/USDT, XAUUSD → XAU/USD, EURJPY → EUR/JPY; anything else stays as it is (US30, GER40, NATGAS). */
export function pairName(symbol) {
  const s = String(symbol || '').toUpperCase().slice(0, 15);
  if (/^[A-Z0-9]{2,10}USDT$/.test(s)) return `${s.slice(0, -4)}/USDT`;
  if (/^[A-Z]{6}$/.test(s)) {
    const a = s.slice(0, 3), b = s.slice(3);
    if ((CCY.includes(a) || METALS.includes(a)) && CCY.includes(b)) return `${a}/${b}`;
  }
  return s;
}

function num(v, precision) {
  const x = Number(v);
  if (!Number.isFinite(x)) return '';
  const d = Number.isInteger(precision) && precision >= 0 && precision <= 10 ? precision
    : Math.abs(x) >= 1000 ? 2 : Math.abs(x) >= 1 ? 4 : Math.abs(x) >= 0.01 ? 6 : 8;
  return x.toLocaleString('en-US', { minimumFractionDigits: Math.min(d, 2), maximumFractionDigits: d });
}

/** "$3,926.92" for prices quoted in dollars, the bare number otherwise. */
export function priceText(symbol, v, precision) {
  const s = String(symbol || '').toUpperCase();
  const usd = s.endsWith('USD') || s.endsWith('USDT') || USD_INDICES.includes(s);
  const n = num(v, precision);
  return n && usd ? `$${n}` : n;
}

/** Signed price move from the entry, in the trade's favour: "+1.92%" / "−0.58%". */
export function movePct(direction, entry, price) {
  const e = Number(entry), p = Number(price);
  if (!(e > 0) || !Number.isFinite(p)) return '';
  const v = ((direction === 'short' ? e - p : p - e) / e) * 100;
  const a = Math.abs(v).toFixed(2);
  return v >= 0 ? `+${a}%` : `−${a}%`;
}

const LRI = '⁦', PDI = '⁩'; // keeps "$3,926.92" and "+1.92%" in order inside right-to-left text
const iso = (x) => (x ? `${LRI}${x}${PDI}` : x);

const TXT = {
  ar: {
    tp: { title: 'تحقق الهدف {n}! 🎯', body: '{pair} وصل TP{n} ({price})! الستوب انتقل لسعر الدخول ({entry}) — الصفقة صارت بدون مخاطرة.' },
    tpMore: { title: 'تحقق الهدف {n}! 🎯', body: '{pair} وصل TP{n} ({price})! ربح {pct} من سعر الدخول، والستوب على الدخول ({entry}).' },
    final: { title: 'الهدف تحقق! 🚀', body: '{pair} وصل هدف الربح عند {price}. حققت {pct} من سعر الدخول!' },
    sl: { title: 'ضرب الوقف 🛑', body: '{pair} ضرب الوقف عند {stop} ({pct} من سعر الدخول).' },
    be: { title: 'طلعت على الدخول 🛡️', body: '{pair} رجع لسعر الدخول ({entry}) بعد TP{n} — بدون خسارة على الباقي.' },
    beNoTp: { title: 'طلعت على الدخول 🛡️', body: '{pair} رجع لسعر الدخول ({entry}) بعد ما انتقل الستوب — بدون خسارة.' },
    trail: { title: 'تسكّرت بالستوب المتحرك 🔒', body: '{pair} تسكّرت عند {price} — {pct} من سعر الدخول.' },
  },
  en: {
    tp: { title: 'Take Profit {n} Smashed! 🎯', body: '{pair} hit TP{n} ({price})! Stop Loss moved to Entry ({entry}) — trade is now Risk-Free.' },
    tpMore: { title: 'Take Profit {n} Smashed! 🎯', body: '{pair} hit TP{n} ({price})! {pct} from entry, Stop Loss stays at Entry ({entry}).' },
    final: { title: 'Target Smashed! 🚀', body: '{pair} hit its profit target at {price}. You secured a {pct} move from entry!' },
    sl: { title: 'Stop Loss Hit 🛑', body: '{pair} hit the stop at {stop} ({pct} from entry).' },
    be: { title: 'Closed at Entry 🛡️', body: '{pair} came back to Entry ({entry}) after TP{n} — no loss on the rest.' },
    beNoTp: { title: 'Closed at Entry 🛡️', body: '{pair} came back to Entry ({entry}) after the stop moved — no loss.' },
    trail: { title: 'Trailing Stop Locked In 🔒', body: '{pair} closed at {price} — {pct} from entry.' },
  },
};

/**
 * kind: 'tp' (a target that is not the last) · 'final' (last target) · 'sl' · 'be' · 'trail' (closed by the trailing stop beyond the entry)
 * d: { symbol, direction, n, price, entry, stop, precision }
 * → { title, body }, or null when the data is incomplete (the caller then keeps its old text).
 */
export function tradeAlert(kind, d = {}, lang = 'ar') {
  const L = TXT[lang === 'en' ? 'en' : 'ar'];
  const n = Number(d.n) || 0;
  const key = kind === 'tp' ? (n <= 1 ? 'tp' : 'tpMore') : kind === 'be' ? (n >= 1 ? 'be' : 'beNoTp') : kind;
  const tpl = L[key];
  if (!tpl || !d.symbol || !(Number(d.entry) > 0)) return null;
  const at = kind === 'sl' ? d.stop : d.price;
  const v = {
    pair: pairName(d.symbol), n: String(n),
    price: iso(priceText(d.symbol, d.price, d.precision)), entry: iso(priceText(d.symbol, d.entry, d.precision)),
    stop: iso(priceText(d.symbol, d.stop, d.precision)), pct: iso(movePct(d.direction, d.entry, at)),
  };
  if ((key !== 'sl' && key !== 'be' && key !== 'beNoTp' && !v.price) || (key === 'sl' && !v.stop)) return null;
  const fill = (s) => s.replace(/\{(\w+)\}/g, (_, k) => v[k] ?? '');
  return { title: fill(tpl.title), body: fill(tpl.body) };
}
