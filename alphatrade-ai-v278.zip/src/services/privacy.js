// Privacy screen for the web app. A website cannot stop the phone's own screenshot buttons (only a native Android app can,
// with FLAG_SECURE — see docs/PRIVACY_SCREEN.md), so this does the strongest thing the browser allows:
//   • the moment the app leaves the screen (app switcher, home button, another tab/window), the content is covered, so the
//     "recent apps" preview and a screenshot taken from the switcher show only the cover;
//   • Print Screen and the macOS screenshot shortcuts cover the page at once and clear the copied image where the browser allows;
//   • printing the page prints only a notice.
const COVER = 'privacy-cover';
let timer = null;
const html = () => document.documentElement;
export function cover(ms = 0) { html().classList.add(COVER); clearTimeout(timer); if (ms) timer = setTimeout(uncover, ms); }
export function uncover() { if (document.visibilityState === 'visible' && document.hasFocus()) html().classList.remove(COVER); }

export function startPrivacyScreen() {
  if (typeof document === 'undefined' || html().dataset.privacy) return;
  html().dataset.privacy = 'on';
  document.addEventListener('visibilitychange', () => (document.visibilityState === 'hidden' ? cover() : setTimeout(uncover, 120)));
  window.addEventListener('pagehide', () => cover());
  // focus moving into an embedded player (live broadcast) also blurs the window: that is not leaving the app
  window.addEventListener('blur', () => setTimeout(() => { if (document.activeElement?.tagName !== 'IFRAME') cover(); }, 0));
  window.addEventListener('focus', () => setTimeout(uncover, 120));
  window.addEventListener('keydown', (e) => {
    const mac = e.metaKey && e.shiftKey && ['3', '4', '5', '6'].includes(e.key);
    if (e.key === 'PrintScreen' || mac) { cover(1500); try { navigator.clipboard?.writeText?.(''); } catch { /* not allowed */ } }
  }, true);
  window.addEventListener('keyup', (e) => { if (e.key === 'PrintScreen') { cover(1500); try { navigator.clipboard?.writeText?.(''); } catch { /* */ } } }, true);
}
