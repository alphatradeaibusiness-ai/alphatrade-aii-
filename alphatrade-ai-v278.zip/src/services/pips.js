// Pip helpers shared by the signals engine, the channel and the monthly results.

/** Points per pip: 10 on crypto and gold, 1 on indices (same as the EDH pip). */
export const pipPoints = (inst) => (inst?.type === 'index' ? 1 : 10);

/** Net pips per calendar day over the tested window (idle days count, so a rare strategy is not flattered). */
export function dailyPipsOf(points, pipPts, windowSec) {
  const days = Math.max(1, windowSec / 86400);
  return { dailyPips: points / pipPts / days, windowDays: days };
}
