// v251 AI Trading Council — independent analytical agents on the same closed candles, then a synthesis that keeps their
// disagreements. Pure and deterministic: every statement comes from a number computed here (no invented probabilities,
// no sentiment feed we do not have). Also: Market X-Ray (liquidity zones — ESTIMATED from price action, kept apart from the
// REAL order-book walls when a live depth snapshot is given) and the scenario engine (probabilities only from historical
// analogs on this asset, with the sample size; below 20 analogs no probability is shown).
import { ema, rsi, atr } from '../indicators/index.js';
import { adx as adxCalc } from './multiStrategy.js';

const last = (a) => { for (let i = a.length - 1; i >= 0; i--) if (a[i] != null) return a[i]; return null; };
const pct = (a, b) => ((a - b) / b) * 100;
const r2 = (v, p = 2) => (Number.isFinite(v) ? +v.toFixed(p) : null);

/* ───────── Market X-Ray ───────── */
/** Pivot highs / lows with k bars on each side. */
function pivots(c, k = 3) {
  const hi = [], lo = [];
  for (let i = k; i < c.length - k; i++) {
    let h = true, l = true;
    for (let j = i - k; j <= i + k; j++) { if (j === i) continue; if (c[j].high >= c[i].high) h = false; if (c[j].low <= c[i].low) l = false; }
    if (h) hi.push(i); if (l) lo.push(i);
  }
  return { hi, lo };
}
/**
 * → { zones: [{ kind: 'buy_side'|'sell_side'|'fvg_bull'|'fvg_bear'|'wall_bid'|'wall_ask', lo, hi, strength 0..1, touches, source: 'estimated'|'order_book', note }],
 *     sweeps: [{ i, side, level }], falseBreaks: [{ i, side, level }] }
 */
export function xray(c, { depth = null, atrLen = 14 } = {}) {
  const A = atr(c, atrLen); const a = last(A) || (c.at(-1).high - c.at(-1).low) || 1; const n = c.length; const px = c.at(-1).close;
  const { hi, lo } = pivots(c, 3); const zones = []; const tol = 0.15 * a;
  const untapped = (i, side) => { for (let j = i + 1; j < n; j++) if (side === 'hi' ? c[j].high > c[i].high : c[j].low < c[i].low) return false; return true; };
  const cluster = (idx, side) => {
    const lv = idx.filter((i) => untapped(i, side)).map((i) => ({ i, p: side === 'hi' ? c[i].high : c[i].low }));
    const out = [];
    for (const x of lv) { const g = out.find((o) => Math.abs(o.p - x.p) <= tol); if (g) { g.n += 1; g.p = (g.p * (g.n - 1) + x.p) / g.n; g.last = Math.max(g.last, x.i); } else out.push({ p: x.p, n: 1, last: x.i }); }
    return out;
  };
  for (const g of cluster(hi, 'hi')) zones.push({ kind: 'buy_side', lo: r2(g.p - 0.1 * a, 6), hi: r2(g.p + 0.1 * a, 6), touches: g.n, strength: r2(Math.min(1, 0.35 + 0.2 * (g.n - 1) + 0.25 * (g.last / n)), 2), source: 'estimated', note: g.n > 1 ? 'equal_highs' : 'swing_high' });
  for (const g of cluster(lo, 'lo')) zones.push({ kind: 'sell_side', lo: r2(g.p - 0.1 * a, 6), hi: r2(g.p + 0.1 * a, 6), touches: g.n, strength: r2(Math.min(1, 0.35 + 0.2 * (g.n - 1) + 0.25 * (g.last / n)), 2), source: 'estimated', note: g.n > 1 ? 'equal_lows' : 'swing_low' });
  // unfilled fair value gaps (imbalances)
  for (let i = Math.max(2, n - 150); i < n; i++) {
    const p = c[i - 2], q = c[i];
    if (q.low > p.high && q.low - p.high > 0.2 * a) { let filled = false; for (let j = i + 1; j < n; j++) if (c[j].low <= p.high) { filled = true; break; } if (!filled) zones.push({ kind: 'fvg_bull', lo: r2(p.high, 6), hi: r2(q.low, 6), touches: 0, strength: r2(Math.min(1, (q.low - p.high) / a), 2), source: 'estimated', note: 'imbalance' }); }
    if (q.high < p.low && p.low - q.high > 0.2 * a) { let filled = false; for (let j = i + 1; j < n; j++) if (c[j].high >= p.low) { filled = true; break; } if (!filled) zones.push({ kind: 'fvg_bear', lo: r2(q.high, 6), hi: r2(p.low, 6), touches: 0, strength: r2(Math.min(1, (p.low - q.high) / a), 2), source: 'estimated', note: 'imbalance' }); }
  }
  // sweeps (wick beyond a pivot, close back inside) and false breakouts (close beyond, back inside within 3 candles) — last 60 candles
  const sweeps = [], falseBreaks = [];
  for (let i = Math.max(4, n - 60); i < n; i++) {
    for (const h of hi.filter((k) => k < i - 2 && k > i - 80).slice(-6)) {
      const L = c[h].high; if (c[i].high > L && c[i].close < L) sweeps.push({ i, side: 'buy_side', level: L });
      if (c[i].close > L && c.slice(i + 1, i + 4).some((x) => x.close < L)) falseBreaks.push({ i, side: 'up', level: L });
    }
    for (const l of lo.filter((k) => k < i - 2 && k > i - 80).slice(-6)) {
      const L = c[l].low; if (c[i].low < L && c[i].close > L) sweeps.push({ i, side: 'sell_side', level: L });
      if (c[i].close < L && c.slice(i + 1, i + 4).some((x) => x.close > L)) falseBreaks.push({ i, side: 'down', level: L });
    }
  }
  // REAL order-book walls (crypto, a live depth snapshot) — bucketed, the biggest by size
  if (depth && Array.isArray(depth.bids) && Array.isArray(depth.asks)) {
    const bucket = 0.1 * a; const agg = (rows, side) => { const m = new Map(); for (const [p, q] of rows) { const P = Number(p), Q = Number(q); if (!(P > 0 && Q > 0)) continue; const k = Math.round(P / bucket); m.set(k, (m.get(k) || 0) + Q * P); } return [...m].map(([k, v]) => ({ p: k * bucket, v, side })); };
    const all = [...agg(depth.bids, 'bid'), ...agg(depth.asks, 'ask')]; const max = Math.max(...all.map((x) => x.v), 1);
    for (const w of all.sort((x, y) => y.v - x.v).slice(0, 6)) zones.push({ kind: w.side === 'bid' ? 'wall_bid' : 'wall_ask', lo: r2(w.p - bucket / 2, 6), hi: r2(w.p + bucket / 2, 6), touches: 0, strength: r2(w.v / max, 2), source: 'order_book', notional: Math.round(w.v), note: 'live_depth' });
  }
  const near = (z) => Math.abs((z.lo + z.hi) / 2 - px) / a;
  zones.sort((x, y) => near(x) - near(y));
  return { zones: zones.slice(0, 40), sweeps: sweeps.slice(-8), falseBreaks: falseBreaks.slice(-8), atr: a, price: px };
}

/* ───────── scenarios from historical analogs ───────── */
function regimeAt(i, R, X, E, c) { return [R[i] == null ? null : R[i] < 35 ? 'rsiLo' : R[i] > 65 ? 'rsiHi' : 'rsiMid', X[i] == null ? null : X[i] > 25 ? 'trend' : X[i] < 18 ? 'range' : 'mid', E[i] == null ? null : c[i].close > E[i] ? 'above' : 'below'].join('|'); }
/** → { horizon, n, up, down, range, expansion (shares 0..1 or null when n < 20), now: regime key } */
export function analogs(c, { horizon = 12 } = {}) {
  const closes = c.map((x) => x.close); const R = rsi(closes, 14); const X = adxCalc(c, 14); const E = ema(closes, 50); const A = atr(c, 14);
  const i0 = c.length - 1; const key = regimeAt(i0, R, X, E, c); let n = 0, up = 0, down = 0, range = 0, exp = 0;
  for (let i = 60; i < c.length - horizon - 1; i++) {
    if (regimeAt(i, R, X, E, c) !== key || !(A[i] > 0)) continue;
    n += 1; const p = c[i].close, a = A[i]; let res = 'range', mx = 0;
    for (let j = i + 1; j <= i + horizon; j++) { mx = Math.max(mx, c[j].high - p, p - c[j].low); if (c[j].high >= p + a && c[j].low <= p - a) { res = 'down'; break; } if (c[j].high >= p + a) { res = 'up'; break; } if (c[j].low <= p - a) { res = 'down'; break; } }
    if (res === 'up') up++; else if (res === 'down') down++; else range++;
    if (mx >= 2 * a) exp++;
  }
  const sh = (k) => (n >= 20 ? r2(k / n, 2) : null);
  return { horizon, n, up: sh(up), down: sh(down), range: sh(range), expansion: sh(exp), now: key };
}

/* ───────── the agents ───────── */
const stanceOf = (score) => (score >= 2 ? 'bullish' : score <= -2 ? 'bearish' : 'neutral');
/**
 * in: { candles (closed), symbol, tf, asset, quote?, events? (calendar [{title, country, impact, time}]), depth?, costPct?, spreadPct? }
 * → { agents: [{ id, stance, evidence: [{ for: 'up'|'down'|'risk'|'info', ar, en }], invalid?: [...] }], synthesis, xray, scenarios }
 */
export function runCouncil({ candles: c, symbol, tf, asset = 'crypto', quote = null, events = [], depth = null, costPct = null, spreadPct = null, now = Date.now() }) {
  if (!Array.isArray(c) || c.length < 120) return { error: 'few_candles' };
  const closes = c.map((x) => x.close); const px = Number.isFinite(quote?.price) ? quote.price : c.at(-1).close;
  const E20 = ema(closes, 20), E50 = ema(closes, 50), E200 = ema(closes, 200); const R = rsi(closes, 14); const A = atr(c, 14); const X = adxCalc(c, 14);
  const e20 = last(E20), e50 = last(E50), e200 = last(E200), r = last(R), a = last(A), adx = last(X);
  const ev = (side, ar, en) => ({ for: side, ar, en });
  const agents = [];
  // 1. Trend AI
  { let s = 0; const e = [];
    if (e20 > e50) { s++; e.push(ev('up', `EMA20 فوق EMA50 (${r2(e20)} > ${r2(e50)})`, `EMA20 above EMA50 (${r2(e20)} > ${r2(e50)})`)); } else { s--; e.push(ev('down', `EMA20 تحت EMA50`, `EMA20 below EMA50`)); }
    if (e200 != null) { if (px > e200) { s++; e.push(ev('up', `السعر فوق EMA200 (${r2(pct(px, e200))}%)`, `Price above EMA200 (${r2(pct(px, e200))}%)`)); } else { s--; e.push(ev('down', `السعر تحت EMA200 (${r2(pct(px, e200))}%)`, `Price below EMA200 (${r2(pct(px, e200))}%)`)); } }
    const slope = E50.at(-1) != null && E50.at(-11) != null ? pct(E50.at(-1), E50.at(-11)) : 0; if (slope > 0.05) { s++; e.push(ev('up', `ميل EMA50 صاعد (${r2(slope)}% بـ10 شموع)`, `EMA50 rising (${r2(slope)}% over 10 candles)`)); } else if (slope < -0.05) { s--; e.push(ev('down', `ميل EMA50 هابط (${r2(slope)}%)`, `EMA50 falling (${r2(slope)}%)`)); }
    e.push(ev('info', `ADX ${r2(adx, 1)} — ${adx > 25 ? 'اتجاه قوي' : adx < 18 ? 'سوق عرضي' : 'اتجاه متوسط'}`, `ADX ${r2(adx, 1)} — ${adx > 25 ? 'strong trend' : adx < 18 ? 'ranging market' : 'moderate trend'}`));
    agents.push({ id: 'trend', score: s, stance: stanceOf(s), evidence: e, invalid: e50 ? [{ ar: `إغلاق ${s > 0 ? 'تحت' : 'فوق'} EMA50 ${r2(e50)}`, en: `A close ${s > 0 ? 'below' : 'above'} EMA50 ${r2(e50)}` }] : [] }); }
  // 2. Liquidity AI (Market X-Ray)
  const xr = xray(c, { depth });
  { let s = 0; const e = []; const above = xr.zones.filter((z) => z.lo > px && ['buy_side', 'wall_ask', 'fvg_bear'].includes(z.kind)).slice(0, 2); const below = xr.zones.filter((z) => z.hi < px && ['sell_side', 'wall_bid', 'fvg_bull'].includes(z.kind)).slice(0, 2);
    for (const z of above) e.push(ev('info', `${z.source === 'order_book' ? 'جدار بيع حقيقي (دفتر الأوامر)' : 'سيولة شراء مقدّرة'} عند ${r2(z.lo)}–${r2(z.hi)}`, `${z.source === 'order_book' ? 'Real ask wall (order book)' : 'Estimated buy-side liquidity'} at ${r2(z.lo)}–${r2(z.hi)}`));
    for (const z of below) e.push(ev('info', `${z.source === 'order_book' ? 'جدار شراء حقيقي (دفتر الأوامر)' : 'سيولة بيع مقدّرة'} عند ${r2(z.lo)}–${r2(z.hi)}`, `${z.source === 'order_book' ? 'Real bid wall (order book)' : 'Estimated sell-side liquidity'} at ${r2(z.lo)}–${r2(z.hi)}`));
    const sw = xr.sweeps.filter((x) => x.i >= c.length - 6).at(-1);
    if (sw) { s += sw.side === 'sell_side' ? 2 : -2; e.push(ev(sw.side === 'sell_side' ? 'up' : 'down', `سحب سيولة ${sw.side === 'sell_side' ? 'تحت قاع' : 'فوق قمة'} ${r2(sw.level)} ورجع السعر`, `Liquidity sweep ${sw.side === 'sell_side' ? 'below a low' : 'above a high'} ${r2(sw.level)} with a close back inside`)); }
    if (!depth) e.push(ev('info', 'مناطق السيولة مقدّرة من حركة السعر، مش أوامر حقيقية', 'Liquidity zones are estimated from price action, not real orders'));
    agents.push({ id: 'liquidity', score: s, stance: stanceOf(s), evidence: e }); }
  // 3. News AI
  { const e = []; const cur = String(symbol).replace(/USDT$/, 'USD'); const ccy = asset === 'crypto' ? ['USD'] : [cur.slice(0, 3), cur.slice(3, 6)].filter((x) => /^[A-Z]{3}$/.test(x));
    const soon = (events || []).filter((x) => /high/i.test(x.impact || '') && (ccy.includes(x.country) || x.country === 'USD') && x.time > now && x.time - now < 24 * 3600_000).sort((p, q) => p.time - q.time);
    if (!events || !events.length) e.push(ev('risk', 'تقويم الأخبار مش متاح — تأكد بنفسك', 'News calendar unavailable — check it yourself'));
    for (const x of soon.slice(0, 3)) e.push(ev('risk', `${x.title} (${x.country}) بعد ${Math.round((x.time - now) / 60_000)} دقيقة`, `${x.title} (${x.country}) in ${Math.round((x.time - now) / 60_000)} min`));
    if (events?.length && !soon.length) e.push(ev('info', 'ما في خبر قوي خلال 24 ساعة', 'No high-impact news in the next 24 h'));
    const blk = soon.some((x) => x.time - now < 30 * 60_000);
    agents.push({ id: 'news', score: 0, stance: blk ? 'caution' : 'neutral', evidence: e }); }
  // 4. Risk AI
  { const e = []; const atrPct = (a / px) * 100; const hist = A.slice(-100).filter((x) => x != null); const avg = hist.reduce((s, x) => s + x, 0) / Math.max(1, hist.length);
    e.push(ev('info', `ATR ${r2(atrPct, 3)}% من السعر — وقف منطقي ≈ ${r2(1.5 * a)} (1.5 ATR)`, `ATR ${r2(atrPct, 3)}% of price — a sensible stop ≈ ${r2(1.5 * a)} (1.5 ATR)`));
    const hot = a > avg * 1.5; if (hot) e.push(ev('risk', `التذبذب أعلى من معدله بـ${r2((a / avg - 1) * 100, 0)}% — صغّر الحجم`, `Volatility ${r2((a / avg - 1) * 100, 0)}% above its average — size down`));
    agents.push({ id: 'risk', score: 0, stance: hot ? 'caution' : 'neutral', evidence: e }); }
  // 5. Pattern AI
  { let s = 0; const e = []; const k = c.at(-1), p = c.at(-2);
    const body = Math.abs(k.close - k.open), rng = k.high - k.low || 1;
    if (k.close > k.open && p.close < p.open && k.close > p.open && k.open < p.close) { s += 2; e.push(ev('up', 'شمعة ابتلاعية صاعدة', 'Bullish engulfing candle')); }
    if (k.close < k.open && p.close > p.open && k.close < p.open && k.open > p.close) { s -= 2; e.push(ev('down', 'شمعة ابتلاعية هابطة', 'Bearish engulfing candle')); }
    if ((Math.min(k.open, k.close) - k.low) / rng > 0.6 && body / rng < 0.3) { s += 1; e.push(ev('up', 'ذيل سفلي طويل (رفض للأسعار المنخفضة)', 'Long lower wick (rejection of lower prices)')); }
    if ((k.high - Math.max(k.open, k.close)) / rng > 0.6 && body / rng < 0.3) { s -= 1; e.push(ev('down', 'ذيل علوي طويل (رفض للأسعار العالية)', 'Long upper wick (rejection of higher prices)')); }
    const fb = xr.falseBreaks.filter((x) => x.i >= c.length - 6).at(-1); if (fb) { s += fb.side === 'up' ? -1 : 1; e.push(ev(fb.side === 'up' ? 'down' : 'up', `اختراق كاذب ${fb.side === 'up' ? 'لأعلى' : 'لأسفل'} عند ${r2(fb.level)}`, `False breakout ${fb.side} at ${r2(fb.level)}`)); }
    if (!e.length) e.push(ev('info', 'ما في نمط شموع واضح على آخر شمعة', 'No clear candle pattern on the last candle'));
    agents.push({ id: 'pattern', score: s, stance: stanceOf(s), evidence: e }); }
  // 6. Sentiment AI — price-based proxy only (no social / funding feed is connected)
  { let s = 0; const e = [];
    if (r > 70) { s -= 1; e.push(ev('down', `RSI ${r2(r, 1)}: تشبّع شراء`, `RSI ${r2(r, 1)}: overbought`)); } else if (r < 30) { s += 1; e.push(ev('up', `RSI ${r2(r, 1)}: تشبّع بيع`, `RSI ${r2(r, 1)}: oversold`)); } else e.push(ev('info', `RSI ${r2(r, 1)}: محايد`, `RSI ${r2(r, 1)}: neutral`));
    const up = c.slice(-20).filter((x) => x.close > x.open).length; e.push(ev(up >= 13 ? 'up' : up <= 7 ? 'down' : 'info', `${up}/20 شمعة صاعدة`, `${up}/20 candles up`)); s += up >= 13 ? 1 : up <= 7 ? -1 : 0;
    e.push(ev('info', 'مؤشر مبني على السعر بس (ما في مصدر مشاعر أو تمويل مربوط)', 'Price-based proxy only (no sentiment or funding feed connected)'));
    agents.push({ id: 'sentiment', score: s, stance: stanceOf(s), evidence: e }); }
  // 7. Execution AI
  { const e = []; const cost = Number.isFinite(costPct) ? costPct : asset === 'crypto' ? 0.08 : asset === 'forex' ? 0.02 : 0.04; const costR = (cost / 100) * px / (1.5 * a);
    e.push(ev('info', `التكلفة التقريبية ${r2(cost, 3)}% ≈ ${r2(costR, 2)}R على وقف 1.5 ATR`, `Estimated cost ${r2(cost, 3)}% ≈ ${r2(costR, 2)}R on a 1.5 ATR stop`));
    if (Number.isFinite(spreadPct)) e.push(ev(spreadPct > 0.1 ? 'risk' : 'info', `السبريد ${r2(spreadPct, 3)}%`, `Spread ${r2(spreadPct, 3)}%`));
    const h = new Date(now).getUTCHours(); const thin = asset !== 'crypto' && (h >= 21 || h < 1); if (thin) e.push(ev('risk', 'وقت سيولة ضعيفة (بين الجلسات)', 'Thin liquidity hours (between sessions)'));
    agents.push({ id: 'execution', score: 0, stance: costR > 0.25 || thin ? 'caution' : 'neutral', evidence: e }); }
  // 8. Devil's advocate — every reason the majority view could fail
  const tally = agents.reduce((s, x) => s + (x.score || 0), 0); const view = tally >= 2 ? 'up' : tally <= -2 ? 'down' : null;
  { const e = []; for (const x of agents) for (const y of x.evidence) if ((view && y.for !== 'info' && y.for !== view) || y.for === 'risk') e.push({ ...y, from: x.id });
    if (!e.length) e.push(ev('info', 'ما لقيت دليل قوي ضد الرأي الغالب — هاد بحد ذاته سبب للحذر من الثقة الزايدة', 'No strong evidence against the majority — itself a reason to avoid overconfidence'));
    agents.push({ id: 'devil', score: 0, stance: 'critic', evidence: e.slice(0, 8) }); }
  // synthesis (never forced to agree)
  const voting = agents.filter((x) => ['bullish', 'bearish'].includes(x.stance));
  const bulls = voting.filter((x) => x.stance === 'bullish').map((x) => x.id), bears = voting.filter((x) => x.stance === 'bearish').map((x) => x.id);
  const caution = agents.filter((x) => x.stance === 'caution').map((x) => x.id);
  const core = agents.filter((x) => x.id !== 'devil');
  const supporting = view ? core.flatMap((x) => x.evidence.filter((y) => y.for === view).map((y) => ({ ...y, from: x.id }))) : [];
  const contra = view ? core.flatMap((x) => x.evidence.filter((y) => y.for !== 'info' && y.for !== 'risk' && y.for !== view).map((y) => ({ ...y, from: x.id }))) : [];
  const risks = core.flatMap((x) => x.evidence.filter((y) => y.for === 'risk').map((y) => ({ ...y, from: x.id })));
  const noTrade = !view || (bulls.length && bears.length && Math.min(bulls.length, bears.length) >= 2) || caution.includes('news');
  const synthesis = { view: noTrade ? 'no_trade' : view === 'up' ? 'bullish' : 'bearish', tally, agree: view === 'up' ? bulls : view === 'down' ? bears : [], disagree: view === 'up' ? bears : view === 'down' ? bulls : [...bulls, ...bears], caution,
    supporting, contra, risks, invalid: agents.find((x) => x.id === 'trend').invalid,
    why: noTrade ? (caution.includes('news') ? 'news' : !view ? 'no_majority' : 'conflict') : null, price: px, atr: a };
  // scenarios
  const an = analogs(c, { horizon: tf === '1D' ? 5 : 12 });
  const hiZ = xr.zones.find((z) => z.lo > px), loZ = xr.zones.find((z) => z.hi < px);
  const lvl = (v) => r2(v, 6);
  const scenarios = [
    { id: 'bull', p: an.up, levels: { trigger: lvl(px + 0.5 * a), target: lvl(hiZ ? hiZ.lo : px + 2 * a), invalid: lvl(px - 1.2 * a) } },
    { id: 'bear', p: an.down, levels: { trigger: lvl(px - 0.5 * a), target: lvl(loZ ? loZ.hi : px - 2 * a), invalid: lvl(px + 1.2 * a) } },
    { id: 'range', p: an.range, levels: { top: lvl(px + a), bottom: lvl(px - a) } },
    { id: 'volatile', p: an.expansion, levels: { up: lvl(px + 2 * a), down: lvl(px - 2 * a) } },
    { id: 'liquidity', p: null, levels: { above: hiZ ? lvl(hiZ.hi) : null, below: loZ ? lvl(loZ.lo) : null } },
  ];
  return { agents, synthesis, xray: xr, scenarios, analogs: an, price: px, at: now, candles: c.length };
}
