// Saved AI-signal trades, watched while the app is open: every event (pending order filled, each target, stop, closed at
// entry) becomes a notification in the tradeMessages.js style ("Take Profit 1 Smashed! 🎯 …"). The server watches the same
// trades with the browser closed (server/tradeWatch.js); when it does and this device gets its push messages, this watcher
// only updates the trade quietly, so one event never arrives twice.
import { listTrades, refreshOutcomes, syncState, cancelTrade, expireStale } from './assistTrades.js';
import { getCalendar } from './news.js';
import { newsRisk } from './synthesis.js';
import { getHistory } from './market/index.js';
import { getInstrument } from '../config/instruments.js';
import { TIMEFRAMES } from '../config/market.js';
import { notify } from './signals.js';
import { tradeAlert, pairName, priceText } from './tradeMessages.js';
import { getLang } from '../i18n/index.js';

const CRYPTO_MS = 60_000;          // Binance: free, every minute
const OTHER_MS = 5 * 60_000;       // gold / forex / indices use the market key's credits: every 5 minutes
const MAX_OPEN = 12;

/** Events between two states of one trade (pure; also used by the tests). */
export function tradeEvents(before, after, total) {
  const ev = [];
  if (before.status === 'pending' && after.status !== 'pending' && after.filledAt) ev.push({ kind: 'filled' });
  const last = Math.min(total, after.hits || 0);
  for (let n = (before.hits || 0) + 1; n <= last; n++) ev.push({ kind: n >= total || (after.status === 'done' && n === last) ? 'final' : 'tp', n });
  if (after.status === 'stopped' && before.status !== 'stopped') ev.push({ kind: 'sl' });
  if (after.status === 'breakeven' && before.status !== 'breakeven') ev.push({ kind: 'be', n: after.hits || 0 });
  if (['expired', 'missed'].includes(after.status) && after.status !== before.status) ev.push({ kind: after.status });
  return ev;
}

/** Title + body of one event. */
export function eventMessage(x, e, lang = getLang()) {
  const L = (ar, en) => (lang !== 'ar' ? en : ar);
  const prec = getInstrument(x.symbol)?.precision ?? 2;
  const px = (v) => `\u2066${priceText(x.symbol, v, prec)}\u2069`;   // keeps "$3,964.64" in order inside Arabic text
  if (e.kind === 'filled') return { title: L('تفعّل الأمر المعلّق ✅', 'Pending order filled ✅'), body: L(`${pairName(x.symbol)} وصل سعر الدخول ${px(x.entry)} والصفقة صارت شغّالة.`, `${pairName(x.symbol)} reached the entry ${px(x.entry)}; the trade is now active.`) };
  if (e.kind === 'expired') return { title: L('انتهى الأمر المعلّق ⌛', 'Pending order expired ⌛'), body: L(`${pairName(x.symbol)}: ما وصل السعر لـ ${px(x.entry)} بالوقت، فالأمر انلغى.`, `${pairName(x.symbol)}: price did not reach ${px(x.entry)} in time; the order was cancelled.`) };
  if (e.kind === 'news') return { title: L('انلغى الأمر المعلّق 📰', 'Pending order cancelled 📰'), body: L(`${pairName(x.symbol)}: في خبر قوي قريب قبل ما يتفعّل الأمر عند ${px(x.entry)}، فانلغى للأمان.`, `${pairName(x.symbol)}: high-impact news is close before the order at ${px(x.entry)} activated; it was cancelled for safety.`) };
  if (e.kind === 'missed') return { title: L('فاتت الصفقة ⏭️', 'Trade missed ⏭️'), body: L(`${pairName(x.symbol)}: السعر وصل الهدف الأول قبل ما يتفعّل الأمر، فانلغى.`, `${pairName(x.symbol)}: price reached TP1 before the order filled; it was cancelled.`) };
  const price = e.kind === 'tp' || e.kind === 'final' ? x.targets[e.n - 1] : x.stop;
  return tradeAlert(e.kind, { symbol: x.symbol, direction: x.direction, n: e.n, price, entry: x.entry, stop: x.stop, precision: prec }, lang)
    || { title: pairName(x.symbol), body: e.kind };
}

let timer = null; let busy = false; const lastAt = new Map(); let newsAt = 0;
/** v234 («توصية AI» orders only): a pending order is cancelled when high-impact news for its market is close (±30 min). */
async function newsCancel(list) {
  const pend = list.filter((x) => x.status === 'pending' && x.engine);
  if (!pend.length || Date.now() - newsAt < 5 * 60_000) return;
  newsAt = Date.now();
  let cal; try { cal = await getCalendar(); } catch { return; }
  const events = Array.isArray(cal?.events) ? cal.events : Array.isArray(cal) ? cal : null; if (!events) return;
  for (const x of pend) {
    const r = newsRisk(x.symbol, events, Date.now(), { aheadMin: 30 });
    if (r?.known && r.level === 'high') { const c = cancelTrade(x.id, 'news'); if (c) { const m = eventMessage(c, { kind: 'news' }); notify(m.title, m.body, `aiw-${c.id}-news`); } }
  }
}
async function pushActive() {
  try { const reg = await navigator.serviceWorker?.getRegistration(); return Boolean(await reg?.pushManager?.getSubscription()); } catch { return false; }
}
async function tick() {
  if (busy) return; busy = true;
  try {
    try { expireStale(); } catch { /* v248: never blocks the watcher */ }
    const open = listTrades().filter((x) => x.mode === 'live' && ['pending', 'active'].includes(x.status)).slice(0, MAX_OPEN);
    const groups = new Map();
    for (const x of open) { const k = `${x.symbol}|${x.tf}`; if (!groups.has(k)) groups.set(k, x); else if (x.createdAt < groups.get(k).createdAt) groups.set(k, x); }
    await newsCancel(open).catch(() => {});
    const sync = syncState(); const push = await pushActive();
    for (const [k, oldest] of groups) {
      const crypto = oldest.asset === 'crypto';
      if (Date.now() - (lastAt.get(k) || 0) < (crypto ? CRYPTO_MS : OTHER_MS) - 2000) continue;
      lastAt.set(k, Date.now());
      const sec = TIMEFRAMES.find((t) => t.id === oldest.tf)?.seconds || 900;
      const bars = Math.min(1500, Math.max(100, Math.ceil((Date.now() / 1000 - oldest.createdAt) / sec) + 20));
      let ds; try { ds = await getHistory(oldest.symbol, oldest.tf, bars); } catch { continue; }
      const sec2 = sec; const closed = (ds.candles || []).filter((c) => c.time + sec2 <= Date.now() / 1000);   // judge closed candles only, like the server
      const changes = refreshOutcomes(oldest.symbol, oldest.tf, closed, ds.mode);
      const serverDoes = sync.state === 'synced' && push && (crypto ? sync.watch?.crypto : sync.watch?.other);
      if (serverDoes) continue;   // the server's push brings these events: do not show them twice
      for (const { item, before } of changes) {
        for (const e of tradeEvents(before, item, item.targets.length)) {
          const m = eventMessage(item, e);
          notify(m.title, m.body, `aiw-${item.id}-${e.kind}-${e.n || 0}`);
        }
      }
    }
  } finally { busy = false; }
}

/** Starts the watcher (once); returns a stop function. */
export function startAiTradeWatch() {
  if (timer) return () => {};
  const first = setTimeout(tick, 8000);
  timer = setInterval(tick, 30_000);
  return () => { clearTimeout(first); clearInterval(timer); timer = null; };
}
