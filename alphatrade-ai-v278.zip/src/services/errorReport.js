// Sends uncaught browser errors to the server log (message + code location only, no user data, max 5 per page load).
const MAX = 5;
let sent = 0; const seen = new Set();
const clip = (s, n) => String(s || '').slice(0, n);

export function report(kind, message, at = '') {
  if (sent >= MAX || typeof fetch !== 'function') return;
  const key = `${kind}|${clip(message, 120)}`; if (seen.has(key)) return; seen.add(key); sent++;
  const page = (location.hash || '').replace(/^#\/?/, '').split(/[/?]/).slice(0, 2).join('/');
  const body = JSON.stringify({ kind, message: clip(message, 300), at: clip(at, 200), where: location.pathname, page, v: document.documentElement.dataset.release || '' });
  try { fetch('/api/client-error', { method: 'POST', headers: { 'content-type': 'application/json' }, body, keepalive: true }).catch(() => {}); } catch { /* ignore */ }
}

export function startErrorReports() {
  window.addEventListener('error', (e) => {
    if (!e.error && !e.message) return;   // resource load errors (images, scripts) carry no message
    // v276: "Script error." with no file = a script from ANOTHER origin (in-app browsers such as Instagram inject their own);
    // the browser hides its details, it is not this app's code (every app script is same-origin), so it is noise in the log.
    if (/^Script error\.?$/i.test(e.message || '') && !e.filename) return;
    const at = e.filename ? `${e.filename.replace(location.origin, '')}:${e.lineno}:${e.colno}` : '';
    report('error', e.message || String(e.error), at);
  });
  window.addEventListener('unhandledrejection', (e) => {
    const r = e.reason; const msg = r?.message || String(r);
    if (/abort|network|failed to fetch|load failed/i.test(msg)) return;   // offline / cancelled requests are not bugs
    report('promise', msg, clip(r?.stack?.split('\n')[1]?.trim(), 200));
  });
}
