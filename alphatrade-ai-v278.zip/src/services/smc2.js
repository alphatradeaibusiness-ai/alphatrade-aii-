// SMC v2 — a stricter Smart Money strategy. A trade is only produced when ALL of this happened,
// in this order, and the 100-point score reaches the minimum (default 80):
//
//   1. HTF alignment (gate)   market structure on 4h and Daily agrees with the trade direction
//                             (small timeframes need both; 4h needs Daily; 1D has no higher frame).
//   2. Liquidity sweep (gate) a wick took out an unbroken swing low/high (or equal lows/highs, or a
//                             minor "inducement" swing) and closed back inside.
//   3. High-quality OB        the last opposite candle of the displacement that followed the sweep.
//                             An order block without a prior sweep is never used.
//   4. Confirmation (gate)    price returned into the OB, then a CHoCH (close beyond the first
//                             lower-high / higher-low) AND a fair value gap formed. The entry is a
//                             MARKET entry on that candle's close — no pending/limit orders.
//   5. Kill zone (gate)       London 02:00–05:00 and New York 07:00–10:00 (New York time) on
//                             timeframes below 4h. Higher timeframes span several sessions: not applied.
//   6. Volume profile         the OB overlapping the point of control / value-area edge adds points;
//                             a heavy volume node right in front of the target takes points away.
//
// Pure functions — nothing here reads the store or the network.
import { atr, rsi, volumeProfile } from '../indicators/index.js';
import { findSwings, findStructure } from '../indicators/smc.js';

export const SMC2_DEFAULTS = { minScore: 80, killZone: true, htf: true };
// Optional, user-adjustable rules. The defaults reproduce the original strict behaviour exactly.
//   htfMode   'both' (4h AND Daily agree, default) | 'h4' (4h only) | 'd1' (Daily only)   — used when htf is on
//   reversal  allow a counter-trend setup only when it is a major sweep (swing/equal) + displacement >= 2 ATR + CHoCH strength >= 0.3
//   minDisp   minimum displacement (candle body / ATR) of the impulse after the sweep
//   fvgMin    minimum fair value gap (in ATR) inside the confirmation leg
//   maxAfterTap  candles allowed between the order-block tap and the CHoCH
//   stopBufAtr   stop distance beyond the sweep / order block (ATR);  maxRiskAtr  setups with a wider stop are skipped
//   rsiGate   momentum filter only: no long when RSI(14) > rsiHi, no short when RSI(14) < rsiLo
export const SMC2_OPTS = { htfMode: 'both', reversal: false, minDisp: 1.0, fvgMin: 0.1, maxAfterTap: 15, stopBufAtr: 0.2, maxRiskAtr: 5, rsiGate: false, rsiHi: 75, rsiLo: 25 };
export const WEIGHTS = { htf: 25, sweep: 20, ob: 15, confirm: 20, session: 10, volume: 10 };
const H4 = 14400;
const D1 = 86400;
const WINDOW = 90;        // candles searched back from the entry candle
const MAX_IMPULSE = 25;    // candles between the OB tap and the confirmation

/* ───────── Kill zones (New York time, DST-aware) ───────── */
const etFmt = new Intl.DateTimeFormat('en-US', { timeZone: 'America/New_York', hour: 'numeric', minute: 'numeric', hourCycle: 'h23' });
const zoneCache = new Map();
export function killZone(timeSec) {
  const k = Math.floor(timeSec / 300);
  if (zoneCache.has(k)) return zoneCache.get(k);
  const parts = etFmt.formatToParts(new Date(k * 300_000));
  const m = Number(parts.find((p) => p.type === 'hour').value) * 60 + Number(parts.find((p) => p.type === 'minute').value);
  const z = m >= 120 && m < 300 ? 'london' : m >= 420 && m < 600 ? 'ny' : null;
  if (zoneCache.size > 5000) zoneCache.clear();
  zoneCache.set(k, z);
  return z;
}

/* ───────── Higher-timeframe structure ───────── */
/** Group candles into bars of `span` seconds (UTC aligned). The last bar may still be forming. */
export function aggregate(candles, span) {
  const out = [];
  for (const c of candles) {
    const key = Math.floor(c.time / span);
    const last = out.at(-1);
    if (last && last.key === key) {
      last.high = Math.max(last.high, c.high); last.low = Math.min(last.low, c.low); last.close = c.close; last.volume = (last.volume || 0) + (c.volume || 0);
    } else out.push({ key, time: key * span, open: c.open, high: c.high, low: c.low, close: c.close, volume: c.volume || 0 });
  }
  return out;
}

/** Market-structure trend after each bar; query by time returns the trend known when that time came. */
export function structureTimeline(bars, span, minBars = 12) {
  if (bars.length < minBars) return () => null;
  const swings = findSwings(bars, 2);
  const { events } = findStructure(bars, swings, 2);
  const trendAt = new Array(bars.length).fill(null);
  let e = 0; let trend = null;
  for (let g = 0; g < bars.length; g++) {
    while (e < events.length && events[e].index <= g) trend = events[e++].dir;
    trendAt[g] = g + 1 >= minBars ? trend : null;
  }
  return (t) => {
    // last bar that was already closed at time t
    let lo = 0; let hi = bars.length - 1; let ans = -1;
    while (lo <= hi) { const mid = (lo + hi) >> 1; if (bars[mid].time + span <= t) { ans = mid; lo = mid + 1; } else hi = mid - 1; }
    return ans >= 0 ? trendAt[ans] : null;
  };
}

/** HTF context from the loaded candles, or from separately loaded 4h / Daily candles. */
export function htfContext(candles, tfSec, external = null) {
  const make = (span, ext) => {
    if (ext && ext.length) return structureTimeline(ext, span, 12);
    if (tfSec >= span) return null; // the chart itself is that frame or higher
    return structureTimeline(aggregate(candles, span), span, 12);
  };
  return { h4: make(H4, external?.h4), d1: make(D1, external?.d1) };
}

/* ───────── Detection ───────── */
export function prepare(candles, opts = {}) {
  const o = { ...SMC2_DEFAULTS, ...SMC2_OPTS, ...opts };
  const tfSec = candles.length > 1 ? candles[1].time - candles[0].time : 3600;
  const S = {
    c: candles, o, tfSec,
    atr: atr(candles, 14),
    sw: findSwings(candles, 2),      // confirmed 2 bars later
    mn: findSwings(candles, 1),      // minor swings, confirmed 1 bar later
    htf: htfContext(candles, tfSec, opts.htf),
    rsi: null,                        // RSI(14), built only when the optional momentum gate is on
  };
  return S;
}

const body = (c) => Math.abs(c.close - c.open);

/** Items of an index-sorted swing list with lo <= index <= hi (binary search, then a short slice). */
function between(arr, lo, hi) {
  let a = 0; let b = arr.length;
  while (a < b) { const m = (a + b) >> 1; if (arr[m].index < lo) a = m + 1; else b = m; }
  let e = a;
  while (e < arr.length && arr[e].index <= hi) e++;
  return arr.slice(a, e);
}

function latestSweep(S, i, dir) {
  const { c } = S;
  const long = dir === 'long';
  const a = S.atr[i];
  const liq = long ? 'low' : 'high';
  const from = Math.max(2, i - WINDOW);
  const sw = between(S.sw, from - 12, i); const mn = between(S.mn, from - 6, i);
  const taken = (p, j) => { for (let k = p.index + 1; k < j; k++) if (long ? c[k].low < p.price : c[k].high > p.price) return true; return false; };
  const swept = (pv, j) => (long ? c[j].low < pv.price - 0.02 * a && c[j].close > pv.price : c[j].high > pv.price + 0.02 * a && c[j].close < pv.price);
  for (let j = i - 3; j >= from; j--) {
    // major swings (len 2) first
    const cands = sw.filter((p) => p.type === liq && p.index >= from - 12 && p.index + 2 <= j && swept(p, j) && !taken(p, j));
    if (cands.length) {
      const p = cands.reduce((x, y) => ((long ? y.price > x.price : y.price < x.price) ? y : x));
      const equal = sw.some((q) => q !== p && q.type === liq && q.index + 2 <= j && Math.abs(q.price - p.price) <= 0.15 * a && !taken(q, j));
      return { index: j, level: p.price, type: equal ? 'equal' : 'swing', pivotIndex: p.index };
    }
    const minor = mn.filter((p) => p.type === liq && p.index >= from - 6 && p.index + 1 <= j && swept(p, j) && !taken(p, j));
    if (minor.length) return { index: j, level: minor[0].price, type: 'inducement', pivotIndex: minor[0].index };
  }
  return null;
}

/** Looks for a complete setup whose confirmation candle is `i`. Returns the setup or null. */
export function detect(S, i, dir) {
  const { c } = S;
  const a = S.atr[i];
  if (!(a > 0) || i < 60) return null;
  const sw = between(S.sw, i - WINDOW - 30, i); const mn = between(S.mn, i - WINDOW - 30, i);
  const long = dir === 'long';
  S.stage = 'none';
  const mark = (n) => { S.stage = n; if (S.stats) S.stats[n]++; };
  if (S.stats) S.stats.try++;
  const sweep = latestSweep(S, i, dir);
  if (!sweep) return null;
  mark('sweep');
  const j = sweep.index;

  // Structure break after the sweep: close beyond the last opposite swing, with a real displacement.
  const brk = long ? 'high' : 'low';
  const prior = [...sw].reverse().find((p) => p.type === brk && p.index + 2 <= j && p.index < j);
  if (!prior) return null;
  let b = -1;
  for (let k = j + 1; k <= Math.min(i, j + MAX_IMPULSE); k++) if (long ? c[k].close > prior.price : c[k].close < prior.price) { b = k; break; }
  if (b < 0) return null;
  let disp = 0;
  for (let k = j; k <= b; k++) disp = Math.max(disp, body(c[k]) / a);
  if (disp < S.o.minDisp) return null;
  mark('brk');

  // Order block = last opposite candle at the extreme of the move (must sit at/after the sweep).
  let ext = j;
  for (let k = j; k <= b; k++) if (long ? c[k].low < c[ext].low : c[k].high > c[ext].high) ext = k;
  let obIdx = -1;
  for (let k = ext; k >= Math.max(j - 2, ext - 5, 0); k--) if (long ? c[k].close < c[k].open : c[k].close > c[k].open) { obIdx = k; break; }
  if (obIdx < 0) return null;
  const ob = { index: obIdx, top: c[obIdx].high, bottom: c[obIdx].low };
  for (let k = b + 1; k <= i; k++) if (long ? c[k].close < ob.bottom : c[k].close > ob.top) return null; // OB broken
  mark('ob');

  // Imbalance created by the displacement.
  let impFvg = false;
  for (let k = j + 1; k <= b; k++) if (long ? c[k].low > c[k - 2].high : c[k].high < c[k - 2].low) { impFvg = true; break; }

  // Price must come back into the OB…
  let t = -1;
  for (let k = b + 1; k <= i; k++) if (long ? c[k].low <= ob.top : c[k].high >= ob.bottom) { t = k; break; }
  if (t < 0 || i - t > S.o.maxAfterTap) return null;
  mark('tap');

  // …then CHoCH: first close beyond the last minor opposite swing formed after the impulse.
  const P = [...mn].reverse().find((p) => p.type === brk && p.index >= b && p.index + 1 <= i && p.index < i);
  if (!P) return null;
  mark('minor');
  if (!(long ? c[i].close > P.price : c[i].close < P.price)) return null;
  for (let k = P.index + 1; k < i; k++) if (long ? c[k].close > P.price : c[k].close < P.price) return null; // already broken earlier
  // …and a fair value gap on the entry timeframe inside that confirmation leg.
  let fvg = 0;
  for (let k = Math.max(t, 2); k <= i; k++) {
    const gap = long ? c[k].low - c[k - 2].high : c[k - 2].low - c[k].high;
    if (gap > fvg) fvg = gap;
  }
  mark('choch');
  if (!(fvg >= S.o.fvgMin * a)) return null;
  mark('fvg');

  if (S.o.rsiGate) {
    S.rsi = S.rsi || rsi(c.map((x) => x.close), 14);
    const r = S.rsi[i];
    if (Number.isFinite(r) && (long ? r > S.o.rsiHi : r < S.o.rsiLo)) return null;   // momentum filter: do not buy an overbought / sell an oversold market
  }
  const entry = c[i].close;
  const stopRef = long ? Math.min(c[sweep.index].low, ob.bottom) : Math.max(c[sweep.index].high, ob.top);
  const stop = long ? stopRef - S.o.stopBufAtr * a : stopRef + S.o.stopBufAtr * a;
  const risk = Math.abs(entry - stop);
  if (!(risk > 0) || risk > S.o.maxRiskAtr * a) return null; // stop must be sensible
  return {
    direction: dir, entry, stop, risk, createdTime: c[sweep.index].time, key: `${dir}|${c[sweep.index].time}`,
    sweep: { type: sweep.type, level: sweep.level, time: c[sweep.index].time },
    ob: { ...ob, time: c[obIdx].time, disp, impFvg },
    choch: { level: P.price, time: c[i].time, strength: Math.abs(c[i].close - P.price) / a },
    fvg: { size: fvg / a },
    tapTime: c[t].time,
  };
}

/** Targets: unbroken swing levels in the trade direction between 1R and 6R, else 2 / 3 / 4.5 R. */
export function targetsFor(S, i, s) {
  const { c } = S;
  const sw = between(S.sw, i - 300, i);
  const long = s.direction === 'long';
  const sign = long ? 1 : -1;
  const pools = sw.filter((p) => p.type === (long ? 'high' : 'low') && p.index + 2 <= i && (p.price - s.entry) * sign >= s.risk && (p.price - s.entry) * sign <= 6 * s.risk && p.index > i - 300)
    .filter((p) => { for (let k = p.index + 1; k <= i; k++) if (long ? c[k].high > p.price : c[k].low < p.price) return false; return true; })
    .map((p) => p.price).sort((x, y) => (x - y) * sign);
  const out = [];
  const fb = [2, 3, 4.5];
  for (let k = 0; k < 3; k++) {
    const prev = k ? out[k - 1] : s.entry;
    const pool = pools.find((p) => (p - prev) * sign > s.risk * 0.25);
    out.push(pool ?? (long ? Math.max(s.entry + fb[k] * s.risk, prev + s.risk) : Math.min(s.entry - fb[k] * s.risk, prev - s.risk)));
  }
  return out;
}

/* ───────── Scoring ───────── */
/** Points per condition, normalised to 100 over the conditions that apply on this timeframe. */
export function scoreSetup(S, i, s, targets, { volumeOk = true } = {}) {
  const { c, tfSec, o } = S;
  const want = s.direction === 'long' ? 'bull' : 'bear';
  const parts = {};
  const na = {};
  // 1 HTF alignment
  const t4 = S.htf.h4 ? S.htf.h4(c[i].time) : undefined;
  const t1 = S.htf.d1 ? S.htf.d1(c[i].time) : undefined;
  const needs = [];
  const mode = o.htfMode || 'both';
  if (tfSec < H4) { if (mode !== 'd1') needs.push(t4); if (mode !== 'h4') needs.push(t1); } else if (tfSec < D1) needs.push(t1);
  if (!o.htf || !needs.length) { na.htf = true; parts.htf = 0; } else parts.htf = needs.every((x) => x === want) ? WEIGHTS.htf : 0;
  let htfOk = na.htf || parts.htf > 0;
  // Declared reversal rule: against the HTF bias only for a major sweep with a strong displacement and CHoCH. Then HTF is not scored (na).
  s.reversal = false;
  if (!htfOk && o.reversal && s.sweep.type !== 'inducement' && s.ob.disp >= 2 && s.choch.strength >= 0.3) { htfOk = true; na.htf = true; parts.htf = 0; s.reversal = true; }
  // 2 sweep
  parts.sweep = WEIGHTS.sweep * (s.sweep.type === 'equal' ? 1 : s.sweep.type === 'swing' ? 0.85 : 0.7);
  // 3 order block quality
  parts.ob = WEIGHTS.ob * (s.ob.disp >= 2 ? 1 : s.ob.disp >= 1.5 ? 0.85 : 0.7) * (s.ob.impFvg ? 1 : 0.85);
  // 4 confirmation: CHoCH 14 + FVG up to 6
  parts.confirm = 14 * (s.choch.strength >= 0.3 ? 1 : 0.85) + 6 * Math.min(1, s.fvg.size / 0.5);
  // 5 kill zone
  const kz = killZone(c[i].time);
  if (!o.killZone || tfSec >= H4) { na.session = true; parts.session = 0; } else parts.session = kz ? WEIGHTS.session : 0;
  const sessionOk = na.session || parts.session > 0;
  // 6 volume profile
  const hasVol = volumeOk && c.slice(Math.max(0, i - 199), i + 1).some((x) => x.volume > 0);
  if (!hasVol) { na.volume = true; parts.volume = 0; } else {
    const vp = volumeProfile(c, { rows: 40, from: i - 199, to: i, valueAreaPct: 70 });
    if (!vp) { na.volume = true; parts.volume = 0; } else {
      const tol = (vp.max - vp.min) / 40;
      const overlap = (x) => s.ob.bottom - tol <= x && x <= s.ob.top + tol;
      const long = s.direction === 'long';
      const edge = long ? vp.val : vp.vah;
      let v = overlap(vp.poc) ? 1 : overlap(edge) ? 0.8 : (s.entry >= vp.val && s.entry <= vp.vah ? 0.4 : 0.2);
      // A heavy node between entry and the first target is resistance for the trade.
      const dir = long ? 1 : -1;
      const heavy = vp.bins.some((b) => b.volume > vp.maxVolume * 0.8 && ((b.low + b.high) / 2 - s.entry) * dir > 0 && ((b.low + b.high) / 2 - targets[0]) * dir < 0 && Math.abs((b.low + b.high) / 2 - s.entry) < s.risk * 1.5);
      if (heavy) v = Math.max(0, v - 0.4);
      parts.volume = WEIGHTS.volume * v;
    }
  }
  const applicable = Object.keys(WEIGHTS).filter((k) => !na[k]).reduce((a, k) => a + WEIGHTS[k], 0);
  const earned = Object.values(parts).reduce((a, v) => a + v, 0);
  const score = applicable ? (earned / applicable) * 100 : 0;
  return { score, parts, na, applicable, gates: { htf: htfOk, session: sessionOk }, htf: { h4: t4 ?? null, d1: t1 ?? null }, zone: kz };
}

/** Full decision for candle `i`: the best qualifying setup of either side, or why it was rejected. */
export function evaluate(S, i, { forced = null } = {}) {
  let best = null;
  let rejected = null;
  for (const dir of ['long', 'short']) {
    if (forced && forced !== dir) continue;
    const s = detect(S, i, dir);
    if (!s) continue;
    s.targets = targetsFor(S, i, s);
    const sc = scoreSetup(S, i, s, s.targets);
    s.score = sc.score; s.reversal = !!s.reversal; s.scoreParts = sc.parts; s.scoreNa = sc.na; s.zone = sc.zone; s.htf = sc.htf;
    if (!sc.gates.htf) { rejected = { reason: 'htf', setup: s }; continue; }
    if (!sc.gates.session) { rejected = { reason: 'session', setup: s }; continue; }
    if (sc.score < S.o.minScore) { rejected = { reason: 'score', setup: s }; continue; }
    if (!best || s.score > best.score) best = s;
  }
  return { setup: best, rejected: best ? null : rejected };
}

/** Why there is no trade right now: how far each side got, the HTF bias, and the session. */
export function explain(S, i) {
  const { c, tfSec, o } = S;
  const out = { time: c[i].time, tfSec };
  out.h4 = S.htf.h4 ? S.htf.h4(c[i].time) : null;
  out.d1 = S.htf.d1 ? S.htf.d1(c[i].time) : null;
  out.zone = killZone(c[i].time);
  out.zoneApplies = o.killZone && tfSec < H4;
  out.htfApplies = Boolean(o.htf) && tfSec < D1;
  out.needsH4 = tfSec < H4;
  out.stage = {};
  for (const dir of ['long', 'short']) { detect(S, i, dir); out.stage[dir] = S.stage; }
  return out;
}
