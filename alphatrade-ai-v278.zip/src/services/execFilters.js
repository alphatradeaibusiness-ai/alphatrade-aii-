// Execution filters shared by every strategy (classic / SMC / zone) and the live signal channel.
// Pure functions, no look-ahead: a value at candle i only uses candles <= i.
//   kz     London / New York killzone hours (UTC)          sb  Silver Bullet hours (New York local 03-04, 10-11, 14-15)
//   vol    ATR band: pause when ATR is below `atrLo` x or above `atrHi` x its 20-candle average
//   sweep  PDH / PDL / Asian high-low swept (wick through, close back inside) within the last `sweepBars` candles, opposite direction
//   cvd    block a buy on bearish CVD divergence, a sell on bullish divergence (needs taker-buy volume; otherwise skipped)
//   void   block entries inside an unmitigated imbalance gap (FVG) bigger than 1 ATR until >= 50% is filled
// Everything is OFF by default: on the real BTC data none of these gave a robust out-of-sample edge (docs/ENHANCEMENTS.md).
import { atr } from '../indicators/index.js';
import { candleDelta, cvdSeries } from './quant.js';

export const EXEC_DEFAULTS = {
  killzone: false, kzLondon: [7, 10], kzNy: [12, 15], silverBullet: false,
  atrBand: false, atrLo: 0.7, atrHi: 3,
  sweep: false, sweepBars: 12, sweepMaxAtr: 1.5, asiaEnd: 7,
  cvd: false, cvdBars: 20,
  voidCheck: false,
  htfOb: false, obBucketSec: 14400, obMaxAge: 60,   // entry must sit inside a same-direction 4h order block
  anomaly: false,                                    // reject long adverse wick / news-spike bar / contradicting volume
};

export function normalizeExec(e = {}) {
  const x = { ...EXEC_DEFAULTS, ...(e || {}) };
  const num = (v, d) => (Number.isFinite(Number(v)) && Number(v) > 0 ? Number(v) : d);
  x.obBucketSec = Math.round(num(x.obBucketSec, 14400)); x.obMaxAge = Math.round(num(x.obMaxAge, 60));
  x.atrLo = num(x.atrLo, EXEC_DEFAULTS.atrLo); x.atrHi = num(x.atrHi, EXEC_DEFAULTS.atrHi);
  x.sweepBars = Math.round(num(x.sweepBars, 12)); x.cvdBars = Math.round(num(x.cvdBars, 20));
  x.kzLondon = Array.isArray(x.kzLondon) ? x.kzLondon : EXEC_DEFAULTS.kzLondon; x.kzNy = Array.isArray(x.kzNy) ? x.kzNy : EXEC_DEFAULTS.kzNy;
  return x;
}
export const execActive = (x) => !!x && (x.killzone || x.silverBullet || x.atrBand || x.sweep || x.cvd || x.voidCheck || x.htfOb || x.anomaly);

const utcHour = (t) => new Date(t * 1000).getUTCHours();
const nyFmt = typeof Intl !== 'undefined' ? new Intl.DateTimeFormat('en-US', { timeZone: 'America/New_York', hour: 'numeric', hourCycle: 'h23' }) : null;
export const nyHour = (t) => (nyFmt ? Number(nyFmt.format(new Date(t * 1000))) : (utcHour(t) + 19) % 24);
export const inKillzone = (t, x) => { const h = utcHour(t); return (h >= x.kzLondon[0] && h < x.kzLondon[1]) || (h >= x.kzNy[0] && h < x.kzNy[1]); };
export const inSilverBullet = (t) => [3, 10, 14].includes(nyHour(t));

/** Per UTC day: high/low and the Asian-session (00:00 → asiaEnd UTC) high/low. */
function dayLevels(candles, asiaEnd) {
  const m = new Map();
  for (const c of candles) {
    const k = Math.floor(c.time / 86400);
    let o = m.get(k);
    if (!o) { o = { hi: -Infinity, lo: Infinity, ah: -Infinity, al: Infinity }; m.set(k, o); }
    o.hi = Math.max(o.hi, c.high); o.lo = Math.min(o.lo, c.low);
    if (utcHour(c.time) < asiaEnd) { o.ah = Math.max(o.ah, c.high); o.al = Math.min(o.al, c.low); }
  }
  return m;
}

export function prepareExec(candles, execCfg) {
  const x = normalizeExec(execCfg);
  if (!execActive(x)) return null;
  const A = atr(candles, 14);
  return { x, candles, A, days: x.sweep ? dayLevels(candles, x.asiaEnd) : null, cvd: x.cvd ? cvdSeries(candles) : null, obs: x.htfOb ? htfOrderBlocks(candles, x.obBucketSec) : null, flow: x.cvd && candles.some((c) => candleDelta(c) != null) };
}

export function atrRatio(A, i, n = 20) {
  if (i < n + 15 || !(A[i] > 0)) return null;
  let s = 0, k = 0;
  for (let j = i - n; j < i; j++) if (A[j] > 0) { s += A[j]; k++; }
  return k ? A[i] / (s / k) : null;
}

/** Which key level did price just sweep? returns { dir, level, extreme } or null. */
export function levelSweep(X, i) {
  const { candles: C, A, days, x } = X;
  const c = C[i]; const k = Math.floor(c.time / 86400);
  const prev = days.get(k - 1); const today = days.get(k);
  if (!prev) return null;
  const lv = { PDH: prev.hi, PDL: prev.lo };
  if (utcHour(c.time) >= x.asiaEnd && today && today.ah > -Infinity) { lv.AH = today.ah; lv.AL = today.al; }
  const from = Math.max(1, i - x.sweepBars);
  for (let j = from; j <= i; j++) {
    const a = A[j] || A[i] || 0;
    for (const name of ['PDL', 'AL']) {
      const v = lv[name]; if (v == null) continue;
      const pen = v - C[j].low;
      if (pen > 0 && (!a || pen <= x.sweepMaxAtr * a) && c.close > v) return { dir: 'long', level: name, extreme: Math.min(...C.slice(from, i + 1).map((q) => q.low)) };
    }
    for (const name of ['PDH', 'AH']) {
      const v = lv[name]; if (v == null) continue;
      const pen = C[j].high - v;
      if (pen > 0 && (!a || pen <= x.sweepMaxAtr * a) && c.close < v) return { dir: 'short', level: name, extreme: Math.max(...C.slice(from, i + 1).map((q) => q.high)) };
    }
  }
  return null;
}

function pivots(C, field, from, to, L = 3) {
  const out = [];
  for (let j = from + L; j <= to - L; j++) {
    let ok = true;
    for (let q = 1; q <= L && ok; q++) ok = field === 'high' ? C[j].high > C[j - q].high && C[j].high >= C[j + q].high : C[j].low < C[j - q].low && C[j].low <= C[j + q].low;
    if (ok) out.push(j);
  }
  return out;
}

/** Bearish divergence (price higher high, CVD lower high) blocks buys; bullish (lower low, higher low) blocks sells. */
export function cvdDivergence(X, i, dir) {
  if (!X.flow) return null;
  const { candles: C, cvd, x } = X; const L = 3;
  const from = Math.max(0, i - x.cvdBars), to = i;
  if (dir === 'long') {
    const p = pivots(C, 'high', from, to, L).slice(-2);
    if (p.length === 2 && C[p[1]].high > C[p[0]].high && cvd[p[1]] < cvd[p[0]]) return 'bearish';
  } else {
    const p = pivots(C, 'low', from, to, L).slice(-2);
    if (p.length === 2 && C[p[1]].low < C[p[0]].low && cvd[p[1]] > cvd[p[0]]) return 'bullish';
  }
  return null;
}

/** Entry inside an unmitigated FVG larger than 1 ATR (an aggressive imbalance): wait until >= 50% is filled. */
export function inVoid(X, i, entry) {
  const { candles: C, A } = X; const a = A[i]; if (!(a > 0)) return false;
  for (let j = i; j >= Math.max(2, i - 40); j--) {
    const bull = C[j].low > C[j - 2].high, bear = C[j].high < C[j - 2].low;
    if (!bull && !bear) continue;
    const bottom = bull ? C[j - 2].high : C[j].high, top = bull ? C[j].low : C[j - 2].low, size = top - bottom;
    if (!(size > a)) continue;
    let filled = 0;
    for (let q = j + 1; q <= i; q++) filled = Math.max(filled, bull ? top - C[q].low : C[q].high - bottom);
    if (filled / size < 0.5 && entry >= bottom && entry <= top) return true;
  }
  return false;
}

/* ───────── Higher-timeframe order blocks ───────── */
/** Closed higher-timeframe bars built from the same candles (bucket = UTC-aligned slot; only complete slots). */
export function htfBars(candles, bucketSec) {
  const out = []; let cur = null;
  for (const c of candles) {
    const slot = Math.floor(c.time / bucketSec) * bucketSec;
    if (!cur || cur.time !== slot) { if (cur) out.push(cur); cur = { time: slot, open: c.open, high: c.high, low: c.low, close: c.close, volume: c.volume || 0, n: 0 }; }
    cur.high = Math.max(cur.high, c.high); cur.low = Math.min(cur.low, c.low); cur.close = c.close; cur.n++;
  }
  if (cur) out.push({ ...cur, partial: true });
  return out;
}

/**
 * Order blocks on the higher timeframe: the last opposite candle before a displacement bar (range >= 1.5 ATR that closes
 * beyond the previous bar's extreme). `known` = close of the displacement bar; `dead` = close of the first HTF bar that
 * closed beyond the far side of the zone; `fvg` = imbalance (gap >= 0.5 ATR) left by the displacement.
 */
export function htfOrderBlocks(candles, bucketSec) {
  const H = htfBars(candles, bucketSec).filter((b) => !b.partial);
  if (H.length < 20) return [];
  const A = atr(H, 14);
  const out = [];
  for (let j = 15; j < H.length - 1; j++) {
    const c = H[j]; const a = A[j];
    if (!(a > 0) || c.high - c.low < 1.5 * a) continue;
    const up = c.close > c.open && c.close > H[j - 1].high; const dn = c.close < c.open && c.close < H[j - 1].low;
    const b = H[j - 1];
    let dir = null;
    if (up && b.close < b.open) dir = 'long'; else if (dn && b.close > b.open) dir = 'short';
    if (!dir) continue;
    const gap = dir === 'long' ? H[j + 1].low - b.high : b.low - H[j + 1].high;
    let dead = Infinity;
    for (let q = j + 1; q < H.length; q++) { if (dir === 'long' ? H[q].close < b.low : H[q].close > b.high) { dead = H[q].time + bucketSec; break; } }
    out.push({ dir, lo: b.low, hi: b.high, atr: a, known: c.time + bucketSec, dead, fvg: gap >= 0.5 * a, bucketSec });
  }
  return out;
}

/** The order block (same direction, alive, not older than obMaxAge bars) that contains `entry` (0.25 ATR tolerance). */
export function obAt(X, t, dir, entry) {
  const { obs, x } = X;
  for (let k = obs.length - 1; k >= 0; k--) {
    const o = obs[k];
    if (o.dir !== dir || o.known > t || o.dead <= t || t - o.known > x.obMaxAge * o.bucketSec) continue;
    const slack = 0.25 * o.atr;
    if (entry >= o.lo - slack && entry <= o.hi + slack) return o;
  }
  return null;
}

/** Anomaly filter on the signal candle: long adverse wick, news-like spike, volume that does not confirm. */
export function anomaly(X, i, dir) {
  const { candles: C, A, x } = X; const c = C[i];
  const range = c.high - c.low; if (!(range > 0)) return 'flat';
  const body = Math.abs(c.close - c.open);
  const adverse = dir === 'long' ? c.high - Math.max(c.open, c.close) : Math.min(c.open, c.close) - c.low;
  if (adverse / range >= 0.5 || adverse > 2 * Math.max(body, 0.05 * range)) return 'wick';
  if (A[i] > 0 && range > 3 * A[i]) return 'spike';
  if (c.volume > 0 && i >= 22) {
    let s = 0; for (let j = i - 20; j < i; j++) s += C[j].volume || 0;
    const vr = c.volume / (s / 20 || 1);
    if (vr < 0.8) return 'weakVol';
    if ((dir === 'long' ? c.close < c.open : c.close > c.open) && vr > 1.5) return 'opposingVol';
  }
  return null;
}

/** The single gate used by the engines. Returns null (allowed) or the key of the filter that blocked it. */
export function execBlock(X, i, dir, entry) {
  if (!X) return null;
  const { x, candles: C, A } = X; const t = C[i].time;
  if (x.killzone && !inKillzone(t, x)) return 'kz';
  if (x.silverBullet && !inSilverBullet(t)) return 'sb';
  if (x.atrBand) { const r = atrRatio(A, i); if (r != null && (r < x.atrLo || r > x.atrHi)) return 'vol'; }
  if (x.sweep) { const s = levelSweep(X, i); if (!s || s.dir !== dir) return 'sweep'; }
  if (x.anomaly && anomaly(X, i, dir)) return 'anom';
  if (x.htfOb && !obAt(X, t, dir, entry)) return 'ob';
  if (x.cvd && cvdDivergence(X, i, dir)) return 'cvd';
  if (x.voidCheck && inVoid(X, i, entry)) return 'void';
  return null;
}

/** Live order-book wall check (Binance depth snapshot: { bids:[[price,qty]], asks:[[price,qty]] }). Not backtestable. */
export function domWall(book, dir, entry, risk, { k = 5, maxDistR = 1 } = {}) {
  const side = dir === 'long' ? book?.asks : book?.bids;
  if (!side?.length) return null;
  const q = side.map((l) => Number(l[1])).sort((a, b) => a - b);
  const med = q[Math.floor(q.length / 2)] || 0;
  if (!(med > 0)) return null;
  const wall = side.find((l) => Number(l[1]) >= k * med && Math.abs(Number(l[0]) - entry) <= maxDistR * risk);
  return wall ? { price: Number(wall[0]), qty: Number(wall[1]), times: Number(wall[1]) / med } : null;
}
