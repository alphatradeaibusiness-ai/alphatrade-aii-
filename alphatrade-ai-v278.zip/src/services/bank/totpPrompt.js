// Asks for the 6-digit authenticator code (or a backup code) in a small dialog. Resolves with the text, or null if cancelled.
import { t } from '../../i18n/index.js';

export function askTotpCode() {
  return new Promise((resolve) => {
    const prev = document.activeElement;
    const wrap = document.createElement('div');
    wrap.className = 'totp-modal'; wrap.setAttribute('role', 'dialog'); wrap.setAttribute('aria-modal', 'true'); wrap.setAttribute('aria-labelledby', 'totp-h');
    const box = document.createElement('form'); box.className = 'card totp-box'; box.autocomplete = 'off';
    const h = document.createElement('h2'); h.id = 'totp-h'; h.className = 'card-title'; h.textContent = t('tools.bank.totp.promptTitle');
    const p = document.createElement('p'); p.className = 'muted tool-note'; p.textContent = t('tools.bank.totp.promptNote');
    const inp = document.createElement('input'); inp.className = 'input mono totp-input'; inp.inputMode = 'numeric'; inp.maxLength = 12; inp.autocomplete = 'one-time-code'; inp.setAttribute('aria-label', t('tools.bank.totp.code'));
    const row = document.createElement('div'); row.className = 'totp-row';
    const ok = document.createElement('button'); ok.type = 'submit'; ok.className = 'btn btn-primary'; ok.textContent = t('tools.bank.totp.confirm');
    const no = document.createElement('button'); no.type = 'button'; no.className = 'btn'; no.textContent = t('tools.bank.totp.cancel');
    row.append(ok, no); box.append(h, p, inp, row); wrap.append(box); document.body.append(wrap); inp.focus();
    const done = (v) => { wrap.remove(); document.removeEventListener('keydown', esc, true); prev?.focus?.(); resolve(v); };
    const esc = (e) => { if (e.key === 'Escape') { e.preventDefault(); done(null); } };
    document.addEventListener('keydown', esc, true);
    box.addEventListener('submit', (e) => { e.preventDefault(); const v = inp.value.replace(/[\s-]/g, ''); if (v) done(v); });
    no.addEventListener('click', () => done(null));
  });
}
