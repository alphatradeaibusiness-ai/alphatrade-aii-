// Browser side of passkeys (WebAuthn). The fingerprint / face check happens on the device; the server receives a public key
// once and then signatures over challenges it issued for one specific action.
import { bankApi } from './api.js';

const b2a = (s) => { const b = s.replace(/-/g, '+').replace(/_/g, '/'); return Uint8Array.from(atob(b + '==='.slice((b.length + 3) % 4)), (c) => c.charCodeAt(0)); };
const a2b = (buf) => { let s = ''; for (const x of new Uint8Array(buf)) s += String.fromCharCode(x); return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''); };
export const passkeysSupported = () => typeof window !== 'undefined' && Boolean(window.PublicKeyCredential && navigator.credentials?.create);

/** Creates a passkey on this device and returns what the server needs to store it. */
export async function createPasskey() {
  const o = await bankApi.passkeyOptions();
  const pk = o.publicKey;
  const cred = await navigator.credentials.create({ publicKey: { ...pk, challenge: b2a(pk.challenge), user: { ...pk.user, id: b2a(pk.user.id) }, excludeCredentials: (pk.excludeCredentials || []).map((c) => ({ ...c, id: b2a(c.id) })) } });
  if (!cred) throw Object.assign(new Error('cancelled'), { code: 'passkey_cancelled' });
  return { challengeId: o.challengeId, credential: { id: cred.id, rawId: a2b(cred.rawId), type: cred.type, response: { clientDataJSON: a2b(cred.response.clientDataJSON), attestationObject: a2b(cred.response.attestationObject) } } };
}

/** Asks the device to sign a challenge the server bound to (purpose, params). Returns the `passkey` field for the request body. */
export async function signFor(purpose, params) {
  const o = await bankApi.passkeyChallenge(purpose, params);
  const pk = o.publicKey;
  let a;
  try { a = await navigator.credentials.get({ publicKey: { ...pk, challenge: b2a(pk.challenge), allowCredentials: (pk.allowCredentials || []).map((c) => ({ ...c, id: b2a(c.id) })) } }); }
  catch { throw Object.assign(new Error('cancelled'), { code: 'passkey_cancelled' }); }
  if (!a) throw Object.assign(new Error('cancelled'), { code: 'passkey_cancelled' });
  return { challengeId: o.challengeId, id: a.id, type: a.type, response: { clientDataJSON: a2b(a.response.clientDataJSON), authenticatorData: a2b(a.response.authenticatorData), signature: a2b(a.response.signature), userHandle: a.response.userHandle ? a2b(a.response.userHandle) : null } };
}
