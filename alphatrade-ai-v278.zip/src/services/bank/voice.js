// Voice commands for the bank (browser speech recognition, Arabic or English). The parser is plain rules, testable without a
// browser. Read-only commands run directly; anything that moves money only opens a confirmation — the voice alone never moves money.
// Note: in some browsers the audio is turned into text by the browser vendor's service; the page says so before the first use.
const AR_DIGITS = { '٠': '0', '١': '1', '٢': '2', '٣': '3', '٤': '4', '٥': '5', '٦': '6', '٧': '7', '٨': '8', '٩': '9', '٫': '.' };
const norm = (s) => String(s || '').replace(/[\u064B-\u0652\u0640]/g, '').replace(/[٠-٩٫]/g, (d) => AR_DIGITS[d]).replace(/[إأآ]/g, 'ا').replace(/ة/g, 'ه').replace(/ى/g, 'ي').toLowerCase().replace(/\s+/g, ' ').trim();
const WORDS = {
  ar: ['عشره', 'عشرين', 'ثلاثين', 'خمسين', 'ميه', 'مية', 'مائه', 'مئه'], n: [10, 20, 30, 50, 100, 100, 100, 100],
};
const CATS = [[/(اكل|مطعم|مطاعم|food|dining|restaurant)/, 'dining'], [/(سوبر ?ماركت|بقاله|خضار|grocer|supermarket)/, 'groceries'], [/(مواصلات|تاكسي|باص|transport|taxi|uber)/, 'transport'],
  [/(اشتراك|subscription)/, 'subscriptions'], [/(تسوق|ملابس|shopping)/, 'shopping'], [/(فاتوره|فواتير|كهربا|bills?)/, 'bills'], [/(سفر|طيران|فندق|travel|hotel|flight)/, 'travel']];
const TABS = [[/(بطاق|card)/, 'cards'], [/(امان|حمايه|بصمه|security|passkey)/, 'security'], [/(دعم|مساعده|support|help)/, 'support'], [/(مكاف|نقاط|reward|points)/, 'rewards'],
  [/(ميزاني|ادخار|اشتراكات|budget|saving)/, 'money'], [/(استثمار|invest)/, 'invest'], [/(تحليل|احصائ|رؤي|insight|dashboard|analytics)/, 'insights'], [/(محفظ|wallet|رصيد)/, 'wallet'],
  [/(سحب|تحويل دولي|withdraw|transfer)/, 'withdraw'], [/(ايداع|deposit)/, 'deposit'], [/(هويه|توثيق|identity|kyc)/, 'identity']];
const amountOf = (s) => {
  const m = /(\d+(?:\.\d{1,2})?)/.exec(s); if (m) return m[1];
  const i = WORDS.ar.findIndex((w) => s.includes(w)); return i >= 0 ? String(WORDS.n[i]) : null;
};

/** Same normalisation for pocket names, so "السفر" said aloud matches a pocket called "سفر". */
export const normName = (s) => norm(s).replace(/^ال/, '');

/** text → { intent, ...params } | { intent: 'unknown' } */
export function parseCommand(text) {
  const s = norm(text); if (!s) return { intent: 'unknown' };
  if (/(جمد|جمّد|اوقف كل|freeze)/.test(s) && !/(فك|unfreeze)/.test(s)) return { intent: 'freeze' };
  const verb = /(?:^|\s)(حول|حط|انقل|خبي|وفر|move|put|save|transfer)\s+(.+)$/.exec(s);
  if (verb && !/(دولي|international|abroad)/.test(s)) {
    const rest = verb[2]; const amt = /(\d+(?:\.\d{1,2})?)/.exec(rest) || null; const amount = amt ? amt[1] : amountOf(rest);
    if (amount) {
      let pocket = amt ? rest.slice(amt.index + amt[0].length) : rest.replace(/^\S+\s*/, '');
      pocket = pocket.replace(/^\s*(دولار|يورو|usd|eur|dollars?|euros?)\s*/, '').replace(/^\s*(علي|عال|ع|الي|لل|في|ب|ل|to|into|in)\s*/, '').replace(/^(the\s+)?(ال)?(جيب|محفظه|pocket)\s*/, '').replace(/^ال/, '').trim();
      if (pocket) return { intent: 'pocket_in', amount, pocket };
    }
  }
  if (/(صرفت|مصروف|مصاريف|spent|spending|spend)/.test(s)) { const c = CATS.find(([re]) => re.test(s)); return { intent: 'spending', category: c ? c[1] : null }; }
  if (/(رصيد|كم معي|كم عندي|كم في|balance|how much)/.test(s)) return { intent: 'balance' };
  if (/(افتح|روح|ورجيني|اعرض|open|go to|show)/.test(s)) { const tb = TABS.find(([re]) => re.test(s)); if (tb) return { intent: 'open', tab: tb[1] }; }
  return { intent: 'unknown' };
}

export const voiceSupported = () => typeof window !== 'undefined' && Boolean(window.SpeechRecognition || window.webkitSpeechRecognition);
/** One utterance → onText(text). Returns a stop function. */
export function listenOnce(lang, onText, onError) {
  const R = window.SpeechRecognition || window.webkitSpeechRecognition; if (!R) { onError?.('voice_unsupported'); return () => {}; }
  const rec = new R(); rec.lang = ({ ar: 'ar-JO', he: 'he-IL', es: 'es-ES', zh: 'zh-CN' })[lang] || 'en-US'; rec.interimResults = false; rec.maxAlternatives = 1; rec.continuous = false;
  rec.onresult = (e) => onText(e.results?.[0]?.[0]?.transcript || '');
  rec.onerror = (e) => onError?.(e.error === 'not-allowed' ? 'voice_denied' : 'voice_failed');
  try { rec.start(); } catch { onError?.('voice_failed'); }
  return () => { try { rec.stop(); } catch { /* */ } };
}
