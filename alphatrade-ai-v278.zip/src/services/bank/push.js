// Web Push for bank notifications: the browser creates a subscription for this site's VAPID key; the server stores it encrypted
// and sends end-to-end encrypted messages through the browser vendor's push service.
import { bankApi } from './api.js';

const b2a = (s) => { const b = s.replace(/-/g, '+').replace(/_/g, '/'); return Uint8Array.from(atob(b + '==='.slice((b.length + 3) % 4)), (c) => c.charCodeAt(0)); };
export const pushSupported = () => typeof window !== 'undefined' && 'serviceWorker' in navigator && 'PushManager' in window && 'Notification' in window;

export async function currentSubscription() {
  if (!pushSupported()) return null;
  const reg = await navigator.serviceWorker.getRegistration(); return reg ? reg.pushManager.getSubscription() : null;
}
export async function enablePush() {
  if (!pushSupported()) throw Object.assign(new Error('unsupported'), { code: 'push_unsupported' });
  const perm = await Notification.requestPermission(); if (perm !== 'granted') throw Object.assign(new Error('denied'), { code: 'push_denied' });
  const reg = (await navigator.serviceWorker.getRegistration()) || (await navigator.serviceWorker.register('/sw.js'));
  const { publicKey } = await bankApi.pushKey();
  let sub = await reg.pushManager.getSubscription();
  if (sub && sub.options?.applicationServerKey) { const cur = new Uint8Array(sub.options.applicationServerKey); const want = b2a(publicKey); if (cur.length !== want.length || cur.some((x, i) => x !== want[i])) { await sub.unsubscribe(); sub = null; } }
  sub ||= await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: b2a(publicKey) });
  await bankApi.pushSubscribe(sub.toJSON());
  return true;
}
export async function disablePush() {
  const sub = await currentSubscription(); if (!sub) return true;
  await bankApi.pushUnsubscribe(sub.endpoint).catch(() => {}); await sub.unsubscribe(); return true;
}
