// Radar scoring shared by Alpha Radar, the multi-screen view and the heat scan.
import { getInstrument, STOP_LOSS_POINTS, TARGET_POINTS } from '../config/instruments.js';
import { ema, rsi, atr, momentumScore } from '../indicators/index.js';
import { smcAnalysis } from '../indicators/smc.js';
import { backtestClassic, backtestSmc, summarize, rulesFrom } from './backtest.js';
import { store } from '../state/store.js';
import { radarParts, radarBias } from './radarBias.js';
import { htfCandles } from './htfData.js';
import { radarFilters, radarVerdict } from './radarFilters.js';

const pointSizeOf = (symbol) => {
  const v = Number(store.get('settings').pointSizes?.[symbol]);
  return v > 0 ? v : getInstrument(symbol).pointSize || 1;
};

/** Fast directional bias (no backtest): −1 … +1 from EMA 50/200 trend, momentum, SMC and RSI. */
export function biasOf(c) {
  if (!c || c.length < 220) return null;
  const closes = c.map((x) => x.close);
  const last = closes.length - 1;
  const price = closes[last];
  const e50 = ema(closes, 50)[last]; const e200 = ema(closes, 200)[last];
  const rs = rsi(closes, 14);
  const r = rs[last];
  const mom = momentumScore({ candles: c, rsiValues: rs, pressure: null });
  const smc = smcAnalysis(c);
  const lastEv = smc?.events?.at(-1) || null;
  const fresh = lastEv && last - lastEv.index <= 20;
  const trend = price > e50 && e50 > e200 ? 1 : price < e50 && e50 < e200 ? -1 : price > e200 ? 0.4 : -0.4;
  const bias = radarBias(radarParts({ price, e50, e200, rsi: r, momentum: mom?.score ?? null, smcTrend: smc?.trend, smcFresh: fresh }));
  const a = atr(c, 14)[last];
  const chg = c.length > 1 ? (price / c[last - 1].close - 1) * 100 : 0;
  return { bias, price, rsi: r, trend, momentum: mom?.score ?? null, smcTrend: smc?.trend || null, event: lastEv ? { kind: lastEv.kind, dir: lastEv.dir, ago: last - lastEv.index } : null, atrPct: (a / price) * 100, chg };
}

/** Full radar score of one dataset (bias + the strategies' recent accuracy + open setup). */
export function radarScore(ds, settings) {
  const c = ds.candles;
  if (!c || c.length < 220) return null;
  const inst = getInstrument(ds.symbol);
  const closes = c.map((x) => x.close);
  const last = closes.length - 1;
  const price = closes[last];
  const e50 = ema(closes, 50)[last]; const e200 = ema(closes, 200)[last];
  const r = rsi(closes, 14)[last];
  const a = atr(c, 14);
  const atrPct = (Array.isArray(a) ? a[last] : a) / price * 100;
  const mom = momentumScore({ candles: c, rsiValues: rsi(closes, 14), pressure: null });
  const smc = smcAnalysis(c);
  const lastEv = smc?.events?.at(-1) || null;

  const fresh = lastEv && last - lastEv.index <= 20;
  const parts = radarParts({ price, e50, e200, rsi: r, momentum: mom?.score ?? null, smcTrend: smc?.trend, smcFresh: fresh });
  const trend = parts[0][1];
  const bias = radarBias(parts);
  const direction = bias >= 0 ? 'long' : 'short';

  // Recent accuracy of both strategies on the same candles (fees included) and any open setup.
  const pointSize = pointSizeOf(ds.symbol);
  const rules = { ...rulesFrom(settings, inst), forced: null, maxPerDay: 0, pointSize, slPoints: STOP_LOSS_POINTS, tpPoints: TARGET_POINTS, volumeKind: ds.volumeKind, openOnLast: true, htfCandles: htfCandles(ds.symbol) };
  const runs = { classic: backtestClassic(c.slice(0, -1), rules), smc: backtestSmc(c.slice(0, -1), rules) };
  const stats = Object.fromEntries(Object.entries(runs).map(([k, v]) => [k, summarize(v.trades).total]));
  const bestKey = (stats.smc.trades >= 5 ? stats.smc.winRate : 0) >= (stats.classic.trades >= 5 ? stats.classic.winRate : 0) ? 'smc' : 'classic';
  const best = stats[bestKey];
  const setup = runs[bestKey].open || runs[bestKey].pending || runs[bestKey === 'smc' ? 'classic' : 'smc'].open || null;
  const aligned = setup && setup.direction === direction;

  let score = Math.abs(bias) * 55;
  if (best.trades >= 5) score += Math.max(0, best.winRate - 35) * 0.5; // up to ≈ +30
  if (aligned) score += 12;
  if (atrPct > 0 && atrPct < 3.5) score += 3;
  if ((direction === 'long' && r > 78) || (direction === 'short' && r < 22)) score -= 10; // stretched
  // RSI + volume + ATR read directly from the candles; weak and unstable readings are graded and excluded by the radar list.
  const filters = radarFilters(c, direction);
  if (filters) score += filters.delta;
  score = Math.max(0, Math.min(100, score));
  const verdict = radarVerdict(filters, score);

  return {
    filters, verdict,
    symbol: ds.symbol, tf: ds.tf, mode: ds.mode, price, precision: inst.precision, direction, score, bias,
    trend, rsi: r, atrPct, momentum: mom?.score ?? null, smcTrend: smc?.trend || null, event: lastEv ? { kind: lastEv.kind, dir: lastEv.dir, ago: last - lastEv.index } : null,
    strategy: bestKey, winRate: best.winRate, trades: best.trades, points: best.points, setup: setup ? { direction: setup.direction, entry: setup.entry, stop: setup.initialStop ?? setup.stop, targets: setup.targets, status: runs[bestKey].open === setup || runs.classic.open === setup ? 'active' : 'pending' } : null, aligned,
  };
}

