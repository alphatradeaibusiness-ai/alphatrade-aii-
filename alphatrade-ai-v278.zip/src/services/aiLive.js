// Connects the AI engine to the live app: trains on a deeper history than the 500 chart candles
// (3000 on Binance, 1500 elsewhere — fetched once, refreshed every 15 min) and sizes the question
// to the current plan (its stop distance and its three targets).
import { aiAnalyze } from './aiEngine.js';
import { aiRun, aiJobKey } from './aiCore.js';

export { aiRun, aiJobKey };
import { getHistory } from './market/index.js';
import { getInstrument } from '../config/instruments.js';
import { atr } from '../indicators/index.js';

const hist = new Map(); // "symbol|tf" -> { ts, candles }
const pending = new Map();

export const aiEnabled = (settings) => settings?.ai?.enabled !== false;

/** Load deeper history in the background. Resolves true when something new arrived. */
export async function prefetchHistory(symbol, tf) {
  const key = `${symbol}|${tf}`;
  const h = hist.get(key);
  if (h && Date.now() - h.ts < 15 * 60_000) return false;
  if (pending.has(key)) return pending.get(key);
  const bars = getInstrument(symbol).provider === 'binance' ? 3000 : 1500;
  const job = getHistory(symbol, tf, bars).then((ds) => {
    if (ds.mode === 'live' && ds.candles.length > 600) { hist.set(key, { ts: Date.now(), candles: ds.candles }); return true; }
    hist.set(key, { ts: Date.now(), candles: null });
    return false;
  }).catch(() => false).finally(() => pending.delete(key));
  pending.set(key, job);
  return job;
}

function series(dataset) {
  const h = hist.get(`${dataset.symbol}|${dataset.tf}`);
  const live = dataset.candles;
  if (!h?.candles || !live.length) return { candles: live, deep: false };
  const older = h.candles.filter((c) => c.time < live[0].time);
  return { candles: older.concat(live), deep: older.length > 0 };
}

/** Everything the AI engine needs for the open chart, as plain data (so it can also run in a Web Worker). */
export function aiJob(dataset, an) {
  if (!dataset?.candles?.length || !an) return null;
  const { candles, deep } = series(dataset);
  const pl = an.plan;
  const rules = an.rules || {};
  const a = atr(dataset.candles.slice(-80), 14);
  const lastAtr = a.at(-2) || a.at(-1);
  const firstR = rules.firstTargetR > 0 ? rules.firstTargetR : rules.tpR?.[0] || 1;
  const rrs = pl ? pl.rr.slice(0, 3) : [firstR, rules.tpR?.[1] || 2, rules.tpR?.[2] || 3.5];
  const riskAtr = pl && lastAtr > 0 ? pl.distance / lastAtr : rules.stopMode === 'atr' ? rules.atrMult || 2 : 2;
  const base = { key: `${dataset.symbol}|${dataset.tf}`, riskAtr, volumeKind: dataset.volumeKind || 'none' };
  return { candles, deep, base, rrs, trades: an.strategyTrades || null, planSide: pl?.direction || null, demo: dataset.mode !== 'live' };
}

/** Light version for lists (radar, signals): chance that `direction` reaches a target at `rr1` × risk first. */
export function aiQuick(dataset, { direction, risk, rr1 }) {
  if (!dataset?.candles?.length || dataset.mode !== 'live') return null;
  const { candles, deep } = series(dataset);
  const a = atr(dataset.candles.slice(-80), 14);
  const lastAtr = a.at(-2) || a.at(-1);
  const riskAtr = risk > 0 && lastAtr > 0 ? risk / lastAtr : 2;
  const r = aiAnalyze(candles, { key: `${dataset.symbol}|${dataset.tf}`, rr1: rr1 > 0 ? rr1 : 1, riskAtr, skipForecast: true, volumeKind: dataset.volumeKind || 'none' });
  const m = r.ready ? r[direction] : null;
  return m ? { p: m.p, edge: m.edge, grade: m.grade, deep } : null;
}

/**
 * A suggested trade drawn on the chart when the strategy has no open trade but the AI engine leans one way:
 * entry = last closed price, stop = the plan's ATR distance, targets = the plan's R multiples, and for every
 * target the model's own historical chance of reaching it before the stop. It is a proposal, not an open trade.
 */
export function aiProposal(dataset, an) {
  const ai = an?.ai;
  if (!ai?.ready || !ai.m || an.plan || an.gate?.rejected || !dataset?.candles?.length) return null;
  const closed = dataset.candles.slice(0, -1);
  const lastC = closed.at(-1);
  if (!lastC) return null;
  const a = atr(dataset.candles.slice(-80), 14);
  const lastAtr = a.at(-2) || a.at(-1);
  const rules = an.rules || {};
  const riskAtr = Number(ai.riskAtr) || (rules.stopMode === 'atr' ? rules.atrMult || 2 : 2);
  const risk = riskAtr * lastAtr;
  if (!(risk > 0)) return null;
  const long = ai.side === 'long';
  const s = long ? 1 : -1;
  const entry = lastC.close; // last CLOSED price; the forming candle never moves it
  const rrs = ai.rrs?.length === 3 ? ai.rrs : [1, 2, 3.5];
  return {
    proposal: true, direction: ai.side, entry, stop: entry - s * risk, initialStop: entry - s * risk,
    targets: rrs.map((r) => entry + s * r * risk), rr: rrs, risk, distance: risk,
    probs: ai.tp.map((x) => (x ? x.p : null)), edge: Boolean(ai.m.edge), openedTime: lastC.time, hits: 0, status: 'proposal',
  };
}

/**
 * Keeps a proposal FIXED: entry, stop and targets stay where they were first drawn while the same side holds.
 * A new one is issued only when the side flips, the stop or the last target was reached, or it is older than `maxBars` candles.
 */
export function stickyProposal(prev, fresh, candles, maxBars = 20) {
  if (!fresh) return null;
  if (!prev || prev.direction !== fresh.direction) return fresh;
  const long = prev.direction === 'long';
  const after = candles.filter((c) => c.time > prev.openedTime);
  if (after.length > maxBars) return fresh;
  const tp3 = prev.targets[prev.targets.length - 1];
  for (const c of after) if (long ? c.low <= prev.stop || c.high >= tp3 : c.high >= prev.stop || c.low <= tp3) return fresh;
  return { ...prev, probs: fresh.probs, edge: fresh.edge };
}
