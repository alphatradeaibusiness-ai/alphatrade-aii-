// AI analysis engine: a small statistical model (logistic regression) trained ONLY on the loaded
// candles of the current symbol/timeframe — no outside data, no invented numbers.
//
//  1. Every past candle is a sample. Its features (trend, EMA stack, RSI, momentum, extension,
//     higher-timeframe trend, volatility, candle body, range position) are known at that candle's close.
//  2. The label is what really happened next, with the plan's own stop/target (triple barrier):
//     did price reach the first target before the stop?  (Same-candle stop+target counts as a loss.)
//  3. The model is trained on the older 70% and tested on the newest 30% (with a gap, so nothing
//     leaks). The test result is the honest "out of sample" accuracy shown to the user.
//  4. If the test shows no real edge (AUC < 0.55 or too few cases), the engine says so and falls
//     back to the plain historical base rate instead of pretending to predict.
import { ema, rsi, atr, pressureSeries } from '../indicators/index.js';
import { htfTrend, momentumSeries } from './backtest.js';
import { smcAnalysis } from '../indicators/smc.js';
import { radarParts, radarBias } from './radarBias.js';

export const FEATURES = ['trend', 'stack', 'rsi', 'roc', 'ext', 'htf', 'vol', 'body', 'pos', 'smc', 'radar'];
const WARM = 210;
const HORIZON = 48;       // bars a trade may run before it counts as "no result"
const FORECAST_H = 12;    // bars ahead for the direction forecast
const MIN_TEST = 120;
const MIN_Z = 2.5;        // AUC must beat a coin flip by 2.5 standard errors (with overlapping samples discounted)
const MIN_AUC = 0.55;

export const INDICATORS = ['ema', 'rsiMom', 'rsiRev', 'momentum', 'pressure', 'htf', 'smc', 'radar'];
const SMC_WINDOW = 300;
const clip = (v, a) => Math.max(-a, Math.min(a, v));

/** Feature vectors for every candle (long perspective). `null` where history is too short. */
export function buildFeatures(candles) {
  const n = candles.length;
  const closes = candles.map((c) => c.close);
  const e20 = ema(closes, 20); const e50 = ema(closes, 50); const e200 = ema(closes, 200);
  const rs = rsi(closes, 14);
  const at = atr(candles, 14);
  const htf = htfTrend(candles, 4, 50);
  const rows = new Array(n).fill(null);
  const atrPct = at.map((a, i) => (a != null && closes[i] ? a / closes[i] : null));
  for (let i = WARM - 1; i < n; i++) {
    const a = at[i];
    if (!(a > 0) || e200[i] == null || e50[i] == null || e20[i] == null || rs[i] == null) continue;
    const c = candles[i];
    let lo = Infinity; let hi = -Infinity;
    for (let k = i - 19; k <= i; k++) { lo = Math.min(lo, candles[k].low); hi = Math.max(hi, candles[k].high); }
    // volatility percentile of the last 100 candles
    let below = 0; let tot = 0;
    for (let k = i - 99; k <= i; k++) { if (atrPct[k] != null) { tot++; if (atrPct[k] <= atrPct[i]) below++; } }
    rows[i] = [
      clip((c.close - e200[i]) / a, 6) / 3,
      clip((e20[i] - e50[i]) / a, 4) / 2,
      (rs[i] - 50) / 25,
      clip((c.close - closes[i - 10]) / a, 8) / 4,
      clip((c.close - e20[i]) / a, 4) / 2,
      htf[i],
      tot ? below / tot - 0.5 : 0,
      clip((c.close - c.open) / a, 2),
      hi > lo ? (c.close - lo) / (hi - lo) - 0.5 : 0,
    ];
  }
  return { rows, atr: at };
}

const orient = (row, s) => row.map((v, k) => (k === 6 ? v : v * s)); // volatility is not directional

/** Triple-barrier outcome from candle i: 1 target first, 0 stop first, null still open after HORIZON. */
export function barrier(candles, i, dir, risk, rr) {
  const e = candles[i].close;
  const stop = dir === 'long' ? e - risk : e + risk;
  const tp = dir === 'long' ? e + rr * risk : e - rr * risk;
  const end = Math.min(candles.length - 1, i + HORIZON);
  for (let j = i + 1; j <= end; j++) {
    const c = candles[j];
    const hitSl = dir === 'long' ? c.low <= stop : c.high >= stop;
    if (hitSl) return 0;
    if (dir === 'long' ? c.high >= tp : c.low <= tp) return 1;
  }
  return i + HORIZON <= candles.length - 1 ? null : undefined; // undefined = future not known yet
}

const sigmoid = (z) => 1 / (1 + Math.exp(-z));

export function fitLogistic(X, y, { lambda = 0.08, iters = 350, lr = 0.5 } = {}) {
  const d = X[0].length;
  const w = new Array(d).fill(0);
  let b = 0;
  const n = X.length;
  for (let it = 0; it < iters; it++) {
    const gw = new Array(d).fill(0); let gb = 0;
    for (let i = 0; i < n; i++) {
      let z = b; for (let k = 0; k < d; k++) z += w[k] * X[i][k];
      const e = sigmoid(z) - y[i];
      gb += e; for (let k = 0; k < d; k++) gw[k] += e * X[i][k];
    }
    b -= (lr * gb) / n;
    for (let k = 0; k < d; k++) w[k] -= lr * (gw[k] / n + lambda * w[k]);
  }
  return { w, b };
}
export const predict = (m, x) => { let z = m.b; for (let k = 0; k < x.length; k++) z += m.w[k] * x[k]; return sigmoid(z); };

/** Area under the ROC curve (0.5 = coin flip). */
export function auc(scores, labels) {
  let pos = 0; let neg = 0; let sum = 0;
  for (let i = 0; i < scores.length; i++) {
    if (labels[i] === 1) { pos++; for (let j = 0; j < scores.length; j++) if (labels[j] === 0) sum += scores[i] > scores[j] ? 1 : scores[i] === scores[j] ? 0.5 : 0; } else neg++;
  }
  return pos && neg ? sum / (pos * neg) : 0.5;
}

/** Train on the older part, test on the newest part, then refit on everything for live use. */
function trainAndTest(samples, { minTest = MIN_TEST, overlap = 12 } = {}) {
  // samples: [{ i, x, y }] sorted by i
  if (samples.length < 120) return null;
  const lastI = samples.at(-1).i;
  const firstI = samples[0].i;
  const cut = firstI + Math.floor((lastI - firstI) * 0.7);
  const train = samples.filter((s) => s.i <= cut - HORIZON);
  const test = samples.filter((s) => s.i > cut);
  if (train.length < 80 || test.length < 30) return null;
  const m1 = fitLogistic(train.map((s) => s.x), train.map((s) => s.y));
  const ps = test.map((s) => predict(m1, s.x));
  const ys = test.map((s) => s.y);
  const baseTrain = train.reduce((a, s) => a + s.y, 0) / train.length;
  const baseTest = ys.reduce((a, v) => a + v, 0) / ys.length;
  const a = auc(ps, ys);
  // Hit rate of the model's confident calls (prediction clearly above the training base rate).
  const hi = ps.map((p, k) => (p >= baseTrain + 0.05 ? k : -1)).filter((k) => k >= 0);
  const hitN = hi.length;
  const hitRate = hitN ? hi.reduce((s, k) => s + ys[k], 0) / hitN : null;
  const brier = ps.reduce((s, p, k) => s + (p - ys[k]) ** 2, 0) / ps.length;
  const brierBase = ys.reduce((s, v) => s + (baseTrain - v) ** 2, 0) / ys.length;
  // Neighbouring candles share the same future, so they are not independent: discount the sample size.
  const pos = ys.filter((v) => v === 1).length; const neg = ys.length - pos;
  const nEff = Math.max(2, ys.length / overlap);
  const se = Math.sqrt((nEff + 1) / (12 * Math.max(1, (pos / ys.length) * nEff) * Math.max(1, (neg / ys.length) * nEff)));
  const z = (a - 0.5) / se;
  const all = fitLogistic(samples.map((s) => s.x), samples.map((s) => s.y));
  const base = samples.reduce((s, v) => s + v.y, 0) / samples.length;
  return {
    model: all, base,
    oos: { auc: a, z, n: test.length, baseTest, hitRate, hitN, brierSkill: brierBase > 0 ? 1 - brier / brierBase : 0, accuracy: ps.reduce((s, p, k) => s + ((p >= 0.5 ? 1 : 0) === ys[k] ? 1 : 0), 0) / ps.length },
    edge: a >= MIN_AUC && z >= MIN_Z && test.length >= minTest,
    nTrain: train.length,
  };
}

const gradeOf = (t) => (!t || !t.edge ? 'none' : t.oos.auc >= 0.62 && t.oos.n >= 150 ? 'A' : t.oos.auc >= 0.58 ? 'B' : 'C');

/** Blend the model with the base rate by how much real (out-of-sample) skill it showed. */
function calibrated(t, x) {
  const raw = predict(t.model, x);
  if (!t.edge) return { p: t.base, raw, used: false };
  const k = Math.min(1, (t.oos.auc - 0.5) / 0.1);
  return { p: Math.max(0.15, Math.min(0.88, t.base + (raw - t.base) * k)), raw, used: true };
}

function drivers(t, x) {
  if (!t.edge) return [];
  return FEATURES.map((key, k) => ({ key, v: t.model.w[k] * x[k] }))
    .filter((d) => Math.abs(d.v) > 0.02)
    .sort((a, b) => Math.abs(b.v) - Math.abs(a.v)).slice(0, 3)
    .map((d) => ({ key: d.key, sign: d.v > 0 ? 1 : -1 }));
}

const votesMemo = new Map();
/**
 * What each of the app's indicators "says" at every closed candle, from the long side:
 * +1 bullish, −1 bearish, 0 neutral. Used to measure how often each one was right in the past.
 */
export function buildVotes(closed, volumeKind = 'none', key = '') {
  const mk = [key, volumeKind, closed.length, closed.at(-1).time, closed.at(-1).close].join('|');
  if (votesMemo.has(mk)) return votesMemo.get(mk);
  const n = closed.length;
  const closes = closed.map((c) => c.close);
  const e20 = ema(closes, 20); const e50 = ema(closes, 50); const e200 = ema(closes, 200);
  const rs = rsi(closes, 14);
  const mom = momentumSeries(closed, volumeKind);
  const htf = htfTrend(closed, 4, 50);
  const ps = volumeKind !== 'none' ? pressureSeries(closed, volumeKind) : null;
  const pre = ps ? [0] : null; const preS = ps ? [0] : null;
  if (ps) for (let i = 0; i < n; i++) { pre.push(pre[i] + ps[i].buy); preS.push(preS[i] + ps[i].sell); }
  const rows = new Array(n).fill(null);
  const smcArr = new Array(n).fill(0); const radarArr = new Array(n).fill(0);
  let smcLast = { trend: null, fresh: false };
  for (let i = WARM - 1; i < n; i++) {
    if (e200[i] == null || rs[i] == null) continue;
    // SMC structure is read on the last 300 candles (like the strategy); every 2nd candle, carried forward.
    if ((i - (WARM - 1)) % 2 === 0 || i === n - 1) {
      const a = smcAnalysis(closed.slice(Math.max(0, i - SMC_WINDOW + 1), i + 1));
      const ev = a?.events?.at(-1);
      const len = Math.min(i + 1, SMC_WINDOW);
      smcLast = { trend: a?.trend || null, fresh: Boolean(ev && len - 1 - ev.index <= 20) };
    }
    const c = closes[i];
    const ema_ = c > e200[i] && e20[i] > e50[i] ? 1 : c < e200[i] && e20[i] < e50[i] ? -1 : 0;
    const rm = rs[i] > 55 ? 1 : rs[i] < 45 ? -1 : 0;
    const rr = rs[i] > 70 ? -1 : rs[i] < 30 ? 1 : 0;
    const mo = mom[i] == null ? 0 : mom[i] > 60 ? 1 : mom[i] < 40 ? -1 : 0;
    let pr = 0;
    if (ps) { const a = Math.max(0, i - 49); const b = pre[i + 1] - pre[a]; const sl = preS[i + 1] - preS[a]; const tot = b + sl; if (tot > 0) { const pct = (b / tot) * 100; pr = pct > 55 ? 1 : pct < 45 ? -1 : 0; } }
    const parts = radarParts({ price: c, e50: e50[i], e200: e200[i], rsi: rs[i], momentum: mom[i], smcTrend: smcLast.trend, smcFresh: smcLast.fresh });
    const rb = radarBias(parts);
    const sm = smcLast.fresh ? (smcLast.trend === 'bull' ? 1 : smcLast.trend === 'bear' ? -1 : 0) : 0;
    smcArr[i] = smcLast.trend === 'bull' ? 1 : smcLast.trend === 'bear' ? -1 : 0; radarArr[i] = rb;
    rows[i] = [ema_, rm, rr, mo, pr, htf[i], sm, rb > 0.25 ? 1 : rb < -0.25 ? -1 : 0];
  }
  const out = { rows, hasPressure: Boolean(ps), smc: smcArr, radar: radarArr };
  votesMemo.set(mk, out);
  if (votesMemo.size > 12) votesMemo.delete(votesMemo.keys().next().value);
  return out;
}

/** How often did each indicator's current reading turn out right (target before stop), in the past? */
function indicatorStats(samples, voteRows, nowVotes, s, base, cutI, hasPressure) {
  return INDICATORS.map((key, k) => {
    const vote = nowVotes[k] * s;
    const all = []; const late = [];
    for (const sm of samples) {
      const v = voteRows[sm.i][k] * s;
      if (v !== vote) continue;
      all.push(sm.y); if (sm.i > cutI) late.push(sm.y);
    }
    const n = all.length;
    const rate = n ? all.reduce((a, v) => a + v, 0) / n : null;
    const nEff = Math.max(1, n / 8);
    const z = rate == null ? 0 : (rate - base) / Math.sqrt(Math.max(1e-6, base * (1 - base)) / nEff);
    return {
      key, vote, n, rate, z,
      oosN: late.length, oosRate: late.length ? late.reduce((a, v) => a + v, 0) / late.length : null,
      available: key !== 'pressure' || hasPressure,
      proven: n >= 30 && Math.abs(z) >= 2.5,
    };
  });
}

const memo = new Map();

/**
 * @param candles  loaded candles (the last one may still be forming — it is ignored)
 * @param opts     { key, rr1 (first target in R), riskAtr (stop in ATR multiples) }
 */
export function aiAnalyze(candles, { key = '', rr1 = 1, riskAtr = 2, strategyTrades = null, skipForecast = false, volumeKind = 'none' } = {}) {
  const closed = candles.slice(0, -1);
  if (closed.length < WARM + HORIZON + 60) return { ready: false, reason: 'short', need: WARM + HORIZON + 60, have: closed.length };
  const rr = Math.max(0.5, Math.min(6, Number(rr1) || 1));
  const rk = Math.max(0.5, Math.min(6, Number(riskAtr) || 2));
  const mk = [key, closed.length, closed.at(-1).time, closed.at(-1).close, rr.toFixed(2), rk.toFixed(2), skipForecast ? 'nf' : 'f', volumeKind].join('|');
  const hit = memo.get(mk);
  if (hit) return hit;

  const { rows, atr: at } = buildFeatures(closed);
  const lastI = closed.length - 1;
  const xNow = rows[lastI];
  if (!xNow) return { ready: false, reason: 'short' };

  const step = closed.length > 1200 ? 2 : 1;
  const V = buildVotes(closed, volumeKind, key);
  const vNow = V.rows[lastI] || INDICATORS.map(() => 0);
  // The AI model also sees the Alpha Radar score and the SMC structure as continuous inputs.
  const ext = (i) => rows[i].concat([V.smc[i], V.radar[i] * 2]);
  const per = {};
  for (const dir of ['long', 'short']) {
    const s = dir === 'long' ? 1 : -1;
    const samples = [];
    for (let i = WARM - 1; i < closed.length; i += step) {
      if (!rows[i] || !V.rows[i]) continue;
      const y = barrier(closed, i, dir, rk * at[i], rr);
      if (y === 0 || y === 1) samples.push({ i, x: orient(ext(i), s), y });
    }
    const t = trainAndTest(samples, { overlap: 8 });
    if (!t) { per[dir] = null; continue; }
    const x = orient(ext(lastI), s);
    const c = calibrated(t, x);
    // Second model: only the indicators' own votes (EMA, RSI, momentum, pressure, higher timeframe).
    const vs = samples.map((sm) => ({ i: sm.i, y: sm.y, x: V.rows[sm.i].map((v) => v * s) }));
    const t2 = trainAndTest(vs, { overlap: 8 });
    const xv = vNow.map((v) => v * s);
    const c2 = t2 ? calibrated(t2, xv) : null;
    // Combine only the models that proved skill out-of-sample; otherwise stay at the plain base rate.
    const used = [];
    if (t.edge) used.push(c.p - t.base);
    if (t2?.edge) used.push(c2.p - t2.base);
    const final = used.length ? Math.max(0.15, Math.min(0.88, t.base + used.reduce((a, v) => a + v, 0) / used.length)) : t.base;
    const cutI = samples[0].i + Math.floor((samples.at(-1).i - samples[0].i) * 0.7);
    const best = t2?.edge && (!t.edge || t2.oos.auc > t.oos.auc) ? t2 : t;
    per[dir] = {
      p: final, aiP: c.p, indP: c2 ? c2.p : null, raw: c.raw, usedModel: used.length > 0, base: t.base,
      edge: used.length > 0, aiEdge: t.edge, indEdge: Boolean(t2?.edge), grade: gradeOf(best),
      oos: t.oos, indOos: t2 ? t2.oos : null, samples: t.nTrain + t.oos.n, drivers: drivers(t, x),
      indicators: indicatorStats(samples, V.rows, vNow, s, t.base, cutI, V.hasPressure),
    };
  }

  // Direction forecast for the next FORECAST_H candles (only reported when the test shows skill).
  let forecast = null;
  if (!skipForecast) {
    const samples = [];
    for (let i = WARM - 1; i + FORECAST_H < closed.length; i += step) {
      if (!rows[i]) continue;
      samples.push({ i, x: ext(i), y: closed[i + FORECAST_H].close > closed[i].close ? 1 : 0 });
    }
    const t = trainAndTest(samples, { overlap: FORECAST_H });
    const rets = [];
    for (let i = WARM - 1; i + FORECAST_H < closed.length; i++) rets.push(Math.log(closed[i + FORECAST_H].close / closed[i].close));
    rets.sort((a, b) => a - b);
    const q = (f) => rets[Math.min(rets.length - 1, Math.max(0, Math.floor(f * (rets.length - 1))))];
    const price = closed[lastI].close;
    const range = rets.length >= 60 ? { h: FORECAST_H, lo: price * Math.exp(q(0.05)), mid: price * Math.exp(q(0.5)), hi: price * Math.exp(q(0.95)) } : null;
    if (t) {
      const accOk = t.oos.accuracy >= 0.54;
      const c = calibrated(t, ext(lastI));
      forecast = { pUp: t.edge && accOk ? c.p : null, baseUp: t.base, edge: t.edge && accOk, auc: t.oos.auc, accuracy: t.oos.accuracy, n: t.oos.n, h: FORECAST_H, range };
    } else forecast = { pUp: null, edge: false, range };
  }

  const st = strategyTrades && strategyTrades.length >= 5
    ? { n: strategyTrades.length, winRate: strategyTrades.filter((x) => x.points > 0).length / strategyTrades.length } : null;
  const out = { ready: true, long: per.long, short: per.short, forecast, strategy: st, rr, riskAtr: rk, price: closed[lastI].close, time: closed[lastI].time };
  memo.set(mk, out);
  if (memo.size > 60) memo.delete(memo.keys().next().value);
  return out;
}

/** The side the model likes more (or null when neither side shows an edge). */
export function bestSide(ai) {
  if (!ai?.ready) return null;
  const l = ai.long; const s = ai.short;
  if (!l && !s) return null;
  const pl = l?.edge ? l.p : -1; const ps = s?.edge ? s.p : -1;
  if (pl < 0 && ps < 0) return null;
  return pl >= ps ? 'long' : 'short';
}
