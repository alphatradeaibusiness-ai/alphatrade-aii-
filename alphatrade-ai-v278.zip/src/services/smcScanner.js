// Market scanner for the SMC / ICT assistant: the same reading on every market of one timeframe, real data only.
// A few requests at a time (the market-data providers rate-limit); a market that only has demo data is listed as such.
import { getHistory } from './market/index.js';
import { htfCandles } from './htfData.js';
import { analyzeSmcIct } from './smcAssist.js';
import { INSTRUMENTS } from '../config/instruments.js';
import { TIMEFRAMES } from '../config/market.js';

const TYPE_TO_ASSET = { crypto: 'crypto', metal: 'metal', index: 'index', energy: 'energy', forex: 'forex', stock: 'stock' };
const ORDER = { trade: 0, wait: 1, no_trade: 2, insufficient: 3, no_data: 4, error: 5 };

/** Sort: tradeable first, then waiting, then by the R:R that was checked. */
export const sortRows = (rows) => [...rows].sort((a, b) => (ORDER[a.verdict] ?? 9) - (ORDER[b.verdict] ?? 9) || (b.rrMain ?? -9) - (a.rrMain ?? -9));

export async function scanMarkets({ tf, inputs, symbols = INSTRUMENTS.map((i) => i.symbol), onRow, isCancelled, concurrency = 3 }) {
  const tfSec = TIMEFRAMES.find((x) => x.id === tf)?.seconds || 3600;
  const queue = [...symbols]; const rows = [];
  const one = async (symbol) => {
    const inst = INSTRUMENTS.find((i) => i.symbol === symbol);
    let row;
    try {
      const ds = await getHistory(symbol, tf, 500);
      if (ds.mode !== 'live' || ds.candles.length < 80) row = { symbol, verdict: 'no_data' };
      else {
        const r = analyzeSmcIct(ds.candles, { ...inputs, asset: inputs.asset === 'auto' || !inputs.asset ? TYPE_TO_ASSET[inst?.type] || 'crypto' : inputs.asset, symbol, tfSec, htf: htfCandles(symbol) });
        row = { symbol, verdict: r.verdict, direction: r.direction || null, price: r.price, entry: r.plan?.entry ?? null, stop: r.plan?.stop ?? null, rrMain: r.plan?.rrMain ?? null,
          score: r.score || null, reasons: r.reasons, poi: r.plan?.poi?.kind ?? null, execution: r.plan?.execution ?? null, precision: inst?.precision ?? 2 };
      }
    } catch { row = { symbol, verdict: 'error' }; }
    rows.push(row); onRow?.(row, rows.length, symbols.length);
  };
  const workers = Array.from({ length: Math.min(concurrency, queue.length) }, async () => {
    while (queue.length && !isCancelled?.()) await one(queue.shift());
  });
  await Promise.all(workers);
  return sortRows(rows);
}
