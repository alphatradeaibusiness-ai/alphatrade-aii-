// The heavy, pure parts of the channel scan, run in a Web Worker (scanWorker.js) so the page never freezes while it scans
// (v223): the deep back-test proof of a strategy (thousands of candles) and the multi-strategy engine (SMC reading included).
// Same code and same inputs as on the main thread, so the results do not change — only where they are computed.
import { runStrategy } from './backtest.js';
import { evaluateCombo } from './comboEval.js';
import { runAllStrategies } from './multiStrategy.js';
import { analyzeSmcIct, cleanInputs } from './smcAssist.js';

export const SCAN_JOBS = {
  /** { strategy, candles, rules } → { all, oos, qualified, watch, accuracy, open, firstTime, lastTime } */
  proof({ strategy, candles, rules }) {
    const run = runStrategy(strategy, candles, rules);
    const ev = evaluateCombo(run.trades);
    return { ...ev, open: run.open || null };
  },
  /** { strategy, candles, rules } → { open } — the live check (only the newest open trade is needed). */
  live({ strategy, candles, rules }) {
    const run = runStrategy(strategy, candles, rules);
    return { open: run.open || null };
  },
  /** Multi-strategy engine on the closed candles; returns only what the channel needs. */
  engine({ input, smc, cfg }) {
    const reading = () => { try { return analyzeSmcIct(input.candles, { ...cleanInputs({ asset: smc.asset, execution: 'market' }), symbol: input.symbol, tfSec: input.tfSec, htf: input.htf, news: smc.news }); } catch { return null; } };
    const m = runAllStrategies({ ...input, reading }, cfg);
    return { final: m.final, emitted: m.emitted || [], minRR: m.minRR };
  },
};
