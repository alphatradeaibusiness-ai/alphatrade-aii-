// Full-analysis view switch: draws the liquidity map (SMC/ICT) and Bollinger Bands for the selected asset.
// It never applies on the EDH chart, which keeps its own drawings.
export const aviewOn = (settings) => Boolean(settings?.aview) && settings.strategy !== 'edh';
