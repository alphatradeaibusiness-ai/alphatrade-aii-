// Sensitivity of the multi-strategy engine (AI signal page + channel + server worker). Fixed to 'balanced' (v212): half-way
// between the research defaults and the looser 'more' preset — the balanced values are not back-tested either.
export const engineMode = () => 'balanced';
