// One-click "Apply on MT5" for a recommendation (v217): sends it to the customer's linked MetaTrader 5 terminal through the
// bridge (server/mt5Bridge.js → the AlphaTradeBridge EA). Market entry with the recommendation's own stop and targets.
//   • Lot: the customer's own "one-click lot" (MT5 page, default 0.01). From 0.03 lots the volume is split in three orders,
//     one per target (TP1 / TP2 / TP3), like the channel manages it; below that, one order with target 2.
//   • The AI signal page passes its own position size (lots from the customer's capital and risk) when it has one.
//   • Only an ACTIVE recommendation (a pending limit order is applied when it activates), only to a connected terminal whose
//     EA allows trading (the server and the EA check this again), and never twice for the same recommendation.
import { apiRequest } from './ai/gateway.js';
import { storage } from '../utils/storage.js';

const LOT_KEY = 'mt5-lot', DONE_KEY = 'mt5-applied';
export const oneClickLot = () => { const v = Number(storage.get(LOT_KEY, 0.01)); return v > 0 && v <= 100 ? Math.round(v * 100) / 100 : 0.01; };
export const setOneClickLot = (v) => { const n = Math.round(Number(v) * 100) / 100; if (n > 0 && n <= 100) storage.set(LOT_KEY, n); return oneClickLot(); };
const doneList = () => { const a = storage.get(DONE_KEY, []); return Array.isArray(a) ? a : []; };
export const wasApplied = (id) => doneList().includes(String(id));
const markApplied = (id) => storage.set(DONE_KEY, [String(id), ...doneList().filter((x) => x !== String(id))].slice(0, 300));

/** Platform symbol → the usual MT5 name (crypto quoted in USDT → USD). The broker suffix is added by the EA. */
export function mt5Symbol(sym) {
  const s = String(sym || '').toUpperCase();
  return /^[A-Z0-9]{2,10}USDT$/.test(s) ? `${s.slice(0, -4)}USD` : s;
}

/** The orders one recommendation becomes (pure, exported for tests). */
export function ordersFor(s, lot) {
  const side = s.direction === 'short' ? 'sell' : 'buy';
  const base = { side, symbol: mt5Symbol(s.symbol), sl: Number(s.stop) || 0, comment: `ATAI ${String(s.strategy || '').slice(0, 10)}` };
  const step = 0.01;
  if (lot >= 0.03 && Array.isArray(s.targets) && s.targets.length >= 3) {
    const part = Math.floor((lot / 3) / step) * step;
    const last = Math.round((lot - part * 2) * 100) / 100;
    return [0, 1, 2].map((k) => ({ ...base, volume: Math.round((k === 2 ? last : part) * 100) / 100, tp: Number(s.targets[k]) || 0 }));
  }
  return [{ ...base, volume: lot, tp: Number(s.targets?.[1] ?? s.targets?.[0]) || 0 }];
}

/** Sends the recommendation to the first connected terminal that allows trading. Throws { code } on refusal. */
export async function applySignal(s, { lot = null } = {}) {
  if (wasApplied(s.id)) throw Object.assign(new Error('applied'), { code: 'already_applied' });
  if (s.status !== 'active') throw Object.assign(new Error('status'), { code: 'not_active' });
  const { links = [] } = await apiRequest('GET', '/api/mt5', undefined, 8000);
  if (!links.length) throw Object.assign(new Error('nolink'), { code: 'no_link' });
  const L = links.find((x) => x.connected && x.terminal?.allowTrading) || links.find((x) => x.connected);
  if (!L) throw Object.assign(new Error('offline'), { code: 'terminal_offline' });
  if (!L.terminal?.allowTrading) throw Object.assign(new Error('off'), { code: 'trading_disabled' });
  const orders = ordersFor(s, lot > 0 ? Math.round(lot * 100) / 100 : oneClickLot());
  const sent = [];
  for (const o of orders) sent.push(await apiRequest('POST', `/api/mt5/link/${L.id}/order`, o, 8000));
  markApplied(s.id);
  return { link: L, orders, sent };
}
