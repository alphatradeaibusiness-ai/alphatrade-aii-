// Pending orders are observations only. Invalid/stale/out-of-order quotes never activate a setup.
export function pendingTransition(s, quote, now=Date.now()) {
  if(s.status!=='pending')return s;
  if(Number.isFinite(s.expiresAt)&&now>=s.expiresAt)return {...s,status:'expired',closedAt:now};
  if(!quote || !Number.isFinite(quote.price)||quote.price<=0 || !Number.isFinite(quote.at) || quote.at<=Math.max(s.createdAt,s.priceAt||0) || now-quote.at>30000 || quote.at>now+5000)return s;
  const sign=s.direction==='long'?1:-1;
  if((quote.price-s.stop)*sign<=0)return {...s,status:'cancelled',closedAt:now,price:quote.price,priceAt:quote.at};
  if((quote.price-s.entry)*sign<=0)return {...s,status:'active',activatedAt:quote.at,price:quote.price,priceAt:quote.at};
  return {...s,price:quote.price,priceAt:quote.at};
}
