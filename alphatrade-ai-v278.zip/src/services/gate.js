// Applies the strict confirmation engine (confirm.js) to a trade the app is about to show or publish.
// The verdict is taken on the decision bar: only CLOSED candles before the trade opened are read, so it never
// flips while the trade runs and never looks ahead. Results are memoised per trade.
import { confirmTrade } from './confirm.js';
import { htfCandles } from './htfData.js';

export const CONFIRM_DEFAULTS = { enabled: true, maxActive: 2, edhMinRR: 0.6 };
export const confirmCfg = (settings) => ({ ...CONFIRM_DEFAULTS, ...(settings?.confirm || {}) });

const memo = new Map();

/**
 * @param o.candles  chart candles (the forming one may be last)
 * @param o.trade    { direction, entry, stop, initialStop?, targets, openTime? }
 * @param o.strategy 'classic'|'smc'|'zone'|'edh'
 * @param o.at       'open' (use candles before trade.openTime) | 'now' (all closed candles, for proposals)
 */
export function gateTrade({ symbol, tf, mode = 'live', candles, trade, strategy, news = null, feePct = 0, cfg = CONFIRM_DEFAULTS, at = 'open', htf }) {
  if (!trade || !candles?.length) return null;
  const key = `${symbol}|${tf}|${strategy}|${at}|${trade.openTime ?? ''}|${trade.direction}|${Math.round(trade.entry * 1e6)}|${candles.length}|${candles.at(-1).time}|${news?.level || ''}`;
  if (memo.has(key)) return memo.get(key);
  let closed = candles.slice(0, -1);
  if (at === 'open' && trade.openTime != null) closed = closed.filter((c) => c.time < trade.openTime);
  const rules = strategy === 'edh' ? { minRR: cfg.edhMinRR } : {};   // EDH has fixed point targets; its reward / risk bar is configurable (Settings)
  const r = confirmTrade({ candles: closed, direction: trade.direction, entry: trade.entry, stop: trade.initialStop ?? trade.stop, targets: trade.targets, htf: htf ?? htfCandles(symbol), news, mode, feePct, rules });
  if (memo.size > 400) memo.clear();
  memo.set(key, r);
  return r;
}

