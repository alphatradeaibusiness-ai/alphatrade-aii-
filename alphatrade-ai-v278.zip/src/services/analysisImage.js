// A static PNG from actual provider OHLC. No embedded or interactive chart.
export function analysisImage(bars,zones,{symbol,tf,source}) {
  const c=document.createElement('canvas');c.width=1200;c.height=600;
  const g=c.getContext('2d'), b=bars.slice(-65), W=1080,H=455,top=75,left=30;
  const min=Math.min(...b.map(x=>x.low)),max=Math.max(...b.map(x=>x.high)),span=(max-min)||1;
  const y=p=>top+H*.05+(max-p)/span*H*.9,step=W/b.length;
  g.fillStyle='#0b0b18';g.fillRect(0,0,1200,600);
  g.font='bold 24px sans-serif';g.fillStyle='#c4b5fd';g.fillText(`ALPHA TRADE AI  ·  ${symbol}  ·  ${tf}`,30,40);
  g.font='15px sans-serif';g.fillStyle='#8f95ae';g.fillText(`${source} · ${new Date(b.at(-1).time*1000).toISOString()} · UTC`,30,580);
  for(let i=0;i<6;i++){const yy=top+i*H/5;g.strokeStyle='#242338';g.beginPath();g.moveTo(left,yy);g.lineTo(1110,yy);g.stroke();g.fillStyle='#9299b4';g.fillText((max-((yy-top-H*.05)/(H*.9))*span).toFixed(symbol.includes('JPY')?3:symbol.match(/^(EUR|GBP|AUD|NZD|USD)/)?5:2),1118,yy+5);}
  b.forEach((v,i)=>{const x=left+(i+.5)*step,col=v.close>=v.open?'#22c997':'#f2687d';g.strokeStyle=col;g.fillStyle=col;g.beginPath();g.moveTo(x,y(v.high));g.lineTo(x,y(v.low));g.stroke();g.fillRect(x-step*.3,Math.min(y(v.open),y(v.close)),step*.6,Math.max(2,Math.abs(y(v.close)-y(v.open))));});
  for(const z of zones){
    if(z.low>max||z.high<min)continue;
    const x=z.time?left+Math.max(0,b.findIndex(v=>v.time>=z.time))*step:W*.55;
    const ya=y(Math.min(max,z.high)),yb=y(Math.max(min,z.low));
    g.fillStyle=z.label==='OB'?'#389df033':'#9271ff33';g.fillRect(x,ya,1110-x,Math.max(3,yb-ya));
    g.strokeStyle=z.label==='OB'?'#60a5fa':'#a78bfa';g.strokeRect(x,ya,1110-x,Math.max(3,yb-ya));g.fillStyle='#e5ddff';g.font='bold 16px sans-serif';g.fillText(z.label,x+8,Math.min(525,Math.max(90,ya-8)));
  }
  return c.toDataURL('image/png');
}
