// Basic audit log of sensitive actions on this device: sign-in / sign-out, account and settings changes (never a secret),
// trading-mode changes, strategy-version restores and settings exports. Newest first, capped, viewable and exportable in Profile.
import { storage } from '../utils/storage.js';

const KEY = 'audit-log';
const MAX = 500;
// Values that must never be written to the log, whatever the caller passes.
const SECRET = /secret|password|pass|token|key|topic/i;

const clean = (details) => {
  const out = {};
  for (const [k, v] of Object.entries(details || {})) {
    if (SECRET.test(k)) { out[k] = '••••'; continue; }
    out[k] = typeof v === 'string' ? v.slice(0, 120) : typeof v === 'number' || typeof v === 'boolean' || v == null ? v : JSON.stringify(v).slice(0, 120);
  }
  return out;
};

/** Records one action: audit('settings.update', { key: 'plan' }). */
export function audit(action, details = {}, now = Date.now()) {
  const list = storage.get(KEY, []);
  list.unshift({ at: now, action: String(action), details: clean(details) });
  storage.set(KEY, list.slice(0, MAX));
}
export const auditLog = () => storage.get(KEY, []);
export const clearAudit = () => storage.set(KEY, []);
