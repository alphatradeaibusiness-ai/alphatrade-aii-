// Web Worker for the channel scan (see scanJobs.js). Receives { id, kind, payload }, answers { id, result } or { id, error }.
import { SCAN_JOBS } from './scanJobs.js';

self.onmessage = (e) => {
  const { id, kind, payload } = e.data || {};
  try { self.postMessage({ id, result: SCAN_JOBS[kind](payload) }); } catch (err) { self.postMessage({ id, error: String(err?.message || err) }); }
};
