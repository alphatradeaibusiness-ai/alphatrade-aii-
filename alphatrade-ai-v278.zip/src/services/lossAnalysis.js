// Explains the losing trades of a backtest and learns which market conditions to avoid.
//   tagTrades      → every trade gets the flags (see regime.js) it was opened with
//   flagStats      → per flag: how many trades, win rate and average R with it vs without it
//   lossCauses     → how the losers died (stopped within 3 candles, wick-only stop, fees ate a small win, …)
//   drawdown       → max drawdown in R, longest losing streak, worst day
//   walkForward    → learn the blocked flags on the OLDER part of the trades, then measure the effect on the
//                    NEWER part only. A condition is only blocked when it was clearly bad in the older part
//                    and the result on the newer part really improved — never tuned on the data it is judged on.
import { flagsAt, FLAGS } from './regime.js';

const MIN_N = 20;          // trades a flag needs before it can be judged
const BAD_AVG_R = -0.1;    // average R (net of fees) at or below this counts as bad
const rOf = (t) => (Number.isFinite(t.r) ? t.r : 0);
const avg = (l) => (l.length ? l.reduce((a, t) => a + rOf(t), 0) / l.length : 0);
const wins = (l) => l.filter((t) => t.points > 0).length;
const rate = (l) => (l.length ? (wins(l) / l.length) * 100 : 0);
const variance = (l) => { if (l.length < 2) return 0; const m = avg(l); return l.reduce((a, t) => a + (rOf(t) - m) ** 2, 0) / (l.length - 1); };
const MAX_Z = -2.5;        // how clearly worse than the rest (z-score) a condition must be to be blocked

function indexOfTime(candles, time) {
  let lo = 0; let hi = candles.length - 1; let ans = -1;
  while (lo <= hi) { const m = (lo + hi) >> 1; if (candles[m].time <= time) { ans = m; lo = m + 1; } else hi = m - 1; }
  return ans;
}

/** Adds `entryIndex` and `flags` to every trade (copies — the input is not changed). */
export function tagTrades(trades, candles, R) {
  return trades.map((t) => {
    const idx = indexOfTime(candles, t.openTime);
    return { ...t, entryIndex: idx, flags: idx >= 0 ? flagsAt(R, idx, t.direction) : [] };
  });
}

export function flagStats(tagged) {
  return FLAGS.map((flag) => {
    const withF = tagged.filter((t) => t.flags.includes(flag));
    const without = tagged.filter((t) => !t.flags.includes(flag));
    const se = Math.sqrt(variance(withF) / Math.max(1, withF.length) + variance(without) / Math.max(1, without.length));
    const z = se > 0 ? (avg(withF) - avg(without)) / se : 0;
    return { flag, n: withF.length, win: rate(withF), avgR: avg(withF), restN: without.length, restWin: rate(without), restAvgR: avg(without), z };
  });
}

/** How the losing trades ended (counts; one trade may fit several). */
export function lossCauses(tagged, candles) {
  const losers = tagged.filter((t) => t.points <= 0);
  const c = { losers: losers.length, quick: 0, wick: 0, feesOnly: 0, afterTp1: 0, flagged: 0 };
  for (const t of losers) {
    const sign = t.direction === 'long' ? 1 : -1;
    if (t.hits >= 1) c.afterTp1++;
    // fees turned a flat/small positive move into a loss
    const gross = ((t.exit - t.entry) * sign);
    if (gross >= 0 || (t.hits >= 1)) c.feesOnly++;
    const exitIdx = indexOfTime(candles, t.closeTime);
    if (exitIdx >= 0 && t.entryIndex >= 0) {
      if (t.outcome === 'sl' && exitIdx - t.entryIndex <= 3) c.quick++;
      // the stop candle closed back on the right side: a wick took us out
      if (t.outcome === 'sl' && (sign > 0 ? candles[exitIdx].close > t.stop : candles[exitIdx].close < t.stop)) c.wick++;
    }
    if (t.flags.length) c.flagged++;
  }
  return c;
}

/** Drawdown in R over the closed trades, in time order. */
export function drawdown(trades) {
  const list = [...trades].sort((a, b) => a.closeTime - b.closeTime);
  let eq = 0; let peak = 0; let maxDd = 0; let streak = 0; let maxStreak = 0;
  const day = new Map();
  for (const t of list) {
    eq += rOf(t); peak = Math.max(peak, eq); maxDd = Math.max(maxDd, peak - eq);
    if (t.points <= 0) { streak++; maxStreak = Math.max(maxStreak, streak); } else streak = 0;
    const d = new Date(t.closeTime * 1000).toISOString().slice(0, 10);
    day.set(d, (day.get(d) || 0) + rOf(t));
  }
  let worstDay = 0; for (const v of day.values()) worstDay = Math.min(worstDay, v);
  return { netR: eq, maxDrawdownR: maxDd, longestLosingStreak: maxStreak, worstDayR: worstDay };
}

/** Flags that were clearly bad on these trades. */
export function learnGate(tagged, { minN = MIN_N, badAvgR = BAD_AVG_R } = {}) {
  return flagStats(tagged).filter((s) => s.n >= minN && s.avgR <= badAvgR && s.z <= MAX_Z).map((s) => s.flag);
}

/**
 * Walk-forward check. Trades are split by time (`split` = share used for learning). The gate learned on the
 * older part is applied to the newer part; the result says whether it really helped there.
 */
export function walkForward(tagged, { split = 0.6, minTest = 15 } = {}) {
  const list = [...tagged].sort((a, b) => a.openTime - b.openTime);
  const cut = Math.floor(list.length * split);
  const train = list.slice(0, cut); const test = list.slice(cut);
  const blocked = learnGate(train);
  const kept = test.filter((t) => !t.flags.some((f) => blocked.includes(f)));
  const stat = (l) => ({ n: l.length, win: rate(l), avgR: avg(l), netR: l.reduce((a, t) => a + rOf(t), 0) });
  const before = stat(test); const after = stat(kept);
  const improved = blocked.length > 0 && kept.length >= Math.min(minTest, test.length) && after.avgR > before.avgR + 0.02 && after.win >= before.win;
  return { blocked, train: stat(train), before, after, improved, enoughData: list.length >= MIN_N * 3 };
}

/** Everything the results page shows for one set of trades. */
export function analyzeTrades(trades, candles, R) {
  const tagged = tagTrades(trades, candles, R);
  return { tagged, flags: flagStats(tagged), causes: lossCauses(tagged, candles), dd: drawdown(trades), wf: walkForward(tagged), gate: learnGate(tagged) };
}
