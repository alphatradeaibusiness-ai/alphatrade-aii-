// AlphaRadar signal filters: RSI + volume + ATR read straight from the candles, so the radar works on its own
// (no dependency on the dashboard strategy) on every timeframe. A reading is graded:
//   strong   : nothing wrong and the score is high enough
//   weak     : thin volume, RSI against the direction, a dead market or a low score
//   unstable : a volatility spike, an extreme range or a bias that flipped during the last 3 closed candles
// weak / unstable readings are excluded from the radar list (they can be shown on demand).
import { ema, rsi, atr } from '../indicators/index.js';

export const RADAR_LIMITS = { rsiHigh: 75, rsiLow: 25, atrSpike: 2.2, atrDead: 0.5, atrPctMax: 6, volThin: 0.6, volStrong: 1.2, minScore: 55 };
const avg = (a) => a.reduce((s, x) => s + x, 0) / (a.length || 1);

/** Cheap directional bias (EMA trend + RSI), used only to check that the call did not flip. */
function quickBias(closes) {
  const last = closes.length - 1; const e50 = ema(closes, 50)[last]; const e200 = ema(closes, 200)[last]; const p = closes[last];
  const trend = p > e50 && e50 > e200 ? 1 : p < e50 && e50 < e200 ? -1 : p > e200 ? 0.4 : -0.4;
  const r = rsi(closes, 14)[last];
  return trend * 0.7 + (Number.isFinite(r) ? Math.max(-1, Math.min(1, (r - 50) / 20)) : 0) * 0.3;
}

/** Reads RSI, ATR and volume of the newest CLOSED candle (the forming one is ignored). */
export function radarFilters(candles, direction, L = RADAR_LIMITS) {
  const c = candles.slice(0, -1); // closed candles only
  if (c.length < 220) return null;
  const closes = c.map((x) => x.close); const last = c.length - 1;
  const r = rsi(closes, 14)[last];
  const A = atr(c, 14); const a = A[last]; const price = closes[last];
  const atrPct = (a / price) * 100;
  const atrRatio = a / avg(A.slice(-50).filter(Number.isFinite));
  const vols = c.map((x) => x.volume).filter((v) => Number.isFinite(v));
  const hasVolume = vols.length >= 25 && vols.slice(-20).some((v) => v > 0);
  const volRatio = hasVolume ? avg(vols.slice(-3)) / (avg(vols.slice(-23, -3)) || 1) : null;
  const long = direction === 'long';
  const weak = []; const unstable = []; let delta = 0;
  // RSI
  if (long ? r > L.rsiHigh : r < L.rsiLow) { weak.push('rsiStretched'); delta -= 12; }
  else if (long ? r < 45 : r > 55) { weak.push('rsiAgainst'); delta -= 8; }
  else if (long ? r >= 50 : r <= 50) delta += 6;
  // ATR (volatility)
  if (atrRatio > L.atrSpike || atrPct > L.atrPctMax) { unstable.push('atrSpike'); delta -= 12; }
  else if (atrRatio < L.atrDead) { weak.push('atrDead'); delta -= 8; }
  else delta += 3;
  // Volume (skipped, neutral, when the feed has none — e.g. some index / metal data)
  if (hasVolume) {
    if (volRatio < L.volThin) { weak.push('volThin'); delta -= 10; } else if (volRatio >= L.volStrong) delta += 5;
  }
  // Stability: the same side on each of the last 3 closed candles
  const sides = [0, 1, 2].map((k) => Math.sign(quickBias(closes.slice(0, closes.length - k))));
  const flip = sides.some((s) => s !== sides[0]);
  if (flip) { unstable.push('flipping'); delta -= 10; }
  return { rsi: r, atrPct, atrRatio, volRatio, hasVolume, weak, unstable, delta, stable: !flip };
}

/** Final grade from the filters and the final score. */
export function radarVerdict(f, score, L = RADAR_LIMITS) {
  if (!f) return 'weak';
  if (f.unstable.length) return 'unstable';
  if (f.weak.length || score < L.minScore) return 'weak';
  return 'strong';
}
