import { storage } from '../utils/storage.js';

// Only the active language is downloaded (ar and en have exactly the same keys — tests/i18nKeys.test.js). The other one is
// fetched when the user switches. Top-level await: nothing that imports `t` runs before its dictionary is in place.
// Hebrew, Spanish and Chinese: their own translations for the menus, buttons, sign-in, account, plans and the new sections;
// any text not translated yet falls back to English (never to a missing key).
const LOADERS = { ar: () => import('./ar.js'), en: () => import('./en.js'), he: () => import('./he.js'), es: () => import('./es.js'), zh: () => import('./zh.js') };
/** Languages offered in the selectors (native names). */
export const LANGS = [['ar', 'العربية'], ['en', 'English'], ['he', 'עברית'], ['es', 'Español'], ['zh', '中文']];
const RTL = new Set(['ar', 'he']);
/** First browser language we support (used on the first visit / at sign-up), else Arabic. */
export function detectLang(list = typeof navigator !== 'undefined' ? navigator.languages || [navigator.language] : []) {
  for (const l of list || []) { const k = String(l || '').toLowerCase().slice(0, 2); if (k === 'iw') return 'he'; if (LOADERS[k]) return k; }
  return 'ar';
}
const dictionaries = {};
const saved = storage.get('lang', null);
let current = LOADERS[saved] ? saved : detectLang();
dictionaries[current] = (await LOADERS[current]()).default;
const listeners = new Set();

function lookup(dict, key) {
  return key.split('.').reduce((o, k) => (o && o[k] !== undefined ? o[k] : undefined), dict);
}

/** Translate a dotted key, replacing {placeholders} with params. */
export function t(key, params = {}) {
  let v = lookup(dictionaries[current], key);
  if (v === undefined) return key;
  if (typeof v !== 'string') return v;
  return v.replace(/\{(\w+)\}/g, (_, k) => (params[k] !== undefined ? params[k] : `{${k}}`));
}

export const getLang = () => current;
export const getDir = () => (RTL.has(current) ? 'rtl' : 'ltr');
/** Locale for dates and numbers (Latin digits in Arabic). */
export const getLocale = () => ({ ar: 'ar-EG-u-nu-latn', en: 'en-GB', he: 'he-IL', es: 'es-ES', zh: 'zh-CN' }[current] || 'en-GB');

export function applyDocumentLang() {
  const html = document.documentElement;
  html.lang = current;
  html.dir = getDir();
}

export async function setLang(lang) {
  if (!LOADERS[lang] || lang === current) return;
  dictionaries[lang] ||= (await LOADERS[lang]()).default;
  if (lang === current) return;   // a second click while the file was loading
  current = lang;
  storage.set('lang', lang);
  applyDocumentLang();
  listeners.forEach((fn) => fn(lang));
}

export function onLangChange(fn) {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

