// v276 translation batch 1 (menus, sign-in, account, plans, errors). Merged over the language file.
export default {
 "auth": {
  "providerMissing": "El inicio de sesión con {provider} aún no está configurado. Añade la configuración de Firebase y activa el proveedor (ver .env.example).",
  "demoAuthNote": "Cuentas de demostración: se guardan solo en este navegador y no se envían correos. Añade Firebase para una autenticación real.",
  "firebaseNote": "Autenticación con Firebase",
  "resetDemo": "Modo demostración: no se puede enviar correo. Puedes poner una contraseña nueva a esta cuenta local directamente.",
  "err": {
   "providerDisabled": "Este proveedor no está activado en Firebase.",
   "wrongPassword": "Tu contraseña actual no es correcta.",
   "samePassword": "La contraseña nueva es igual a la actual.",
   "unauthorizedDomain": "Este dominio no está autorizado en Firebase (Authentication → Settings → Authorized domains).",
   "differentCredential": "Este correo ya usa otro método de acceso. Entra con ese método."
  }
 },
 "navShort": {
  "noticeSettings": "Ajustes de avisos y enlaces →",
  "paper": "Simulación"
 },
 "nav": {
  "smart-images": "Imágenes inteligentes",
  "paper": "Operativa simulada",
  "confluence": "Laboratorio de confluencias",
  "radar-tf": "Mejor marco temporal (1–15 min)",
  "radar-vol": "Monitor de volatilidad",
  "radar-liq": "Detector de liquidez",
  "radar-risk": "Riesgo automático",
  "radar-corr": "Correlación entre marcos temporales",
  "radar-perf": "Panel de rendimiento",
  "radar-heat": "Mapa de calor del mercado",
  "portfolio": "Cartera",
  "autotest": "Backtest automático",
  "correlation": "Matriz de correlación",
  "learn": "Estrategias explicadas",
  "more": "Más",
  "snapshot": "Análisis de mercado con IA",
  "performance": "Resultados de las estrategias",
  "palette": "Colores del sitio",
  "pal_violet": "Violeta",
  "pal_ocean": "Océano",
  "pal_teal": "Turquesa",
  "pal_gold": "Oro",
  "pal_aurora": "Aurora (violeta + cian)",
  "pal_sunset": "Atardecer (rosa + naranja)",
  "pal_royal": "Real (índigo + oro)",
  "pal_orchid": "Orquídea (rosa + violeta)",
  "pal_graphite": "Grafito"
 },
 "status": {
  "demoPartial": "Modo demostración para {symbols}: datos de prueba generados, no son precios reales. Los demás símbolos van en directo.",
  "whyDemo": "Motivo",
  "fallback": "No se pudo conectar con la fuente de datos ({msg}). Se activó el modo demostración.",
  "providerDemo": "No hay clave API para este símbolo: modo demostración."
 },
 "profile": {
  "photoHint": "JPG o PNG de hasta 8 MB. La foto se guarda en este dispositivo.",
  "photoSaved": "Foto actualizada.",
  "photoRemoved": "Foto eliminada.",
  "photoType": "Elige un archivo de imagen (JPG o PNG).",
  "photoSize": "La imagen pesa más de 8 MB.",
  "photoRead": "No se pudo leer la imagen.",
  "providers": {
   "password": "Correo y contraseña",
   "local": "Cuenta local (este navegador)"
  },
  "noPassword": "Entraste con {provider}, así que aquí no hay contraseña que cambiar. Gestiónala en tu cuenta de {provider}."
 },
 "ent": {
  "locked": "Incluido desde el plan {plan}.",
  "lockedTitle": "Mejora tu plan para desbloquear",
  "seePlans": "Ver planes",
  "alertsFull": "Tu plan permite {n} alertas y reglas. Quita una o mejora tu plan.",
  "aiOut": "Has usado los análisis profundos de IA de este mes. Mejora tu plan para tener más; el motor de análisis integrado sigue sin límite.",
  "moreSignals": "Has llegado al cupo mensual. Añade recomendaciones o mejora tu plan.",
  "tier": {
   "free": "Sin plan",
   "trader": "Trader",
   "pro": "Pro",
   "elite": "Élite",
   "institutional": "Institucional"
  },
  "aiLine": "{n} análisis profundos de IA al mes",
  "carry": "los no usados pasan {m} mes(es)",
  "noCarry": "sin traspaso",
  "localLine": "Motor de análisis integrado: ilimitado",
  "yourPlan": "Tu plan",
  "usage": "Análisis profundos de IA este mes: {used} de {total}",
  "compare": "Comparar planes",
  "row": "Función",
  "unlimited": "Ilimitado",
  "rows": {
   "core": "Gráfico profesional, indicadores, plan clásico, diario",
   "frvp": "Perfil de volumen de rango fijo",
   "strategies": "Estrategias SMC v2 + Zone",
   "radarFull": "Todas las herramientas de Alpha Radar",
   "autotest": "Laboratorio de optimización y backtest",
   "quant": "Capa cuantitativa y análisis de pérdidas",
   "multiScreen": "Análisis multipantalla",
   "earlyAccess": "Acceso anticipado",
   "signals": "Recomendaciones al mes",
   "alerts": "Alertas y reglas",
   "ai": "Análisis profundos de IA al mes"
  },
  "feat": {
   "monthly": [
    "Precios en directo, gráfico profesional y herramientas de dibujo",
    "RSI, rupturas de Fibonacci y zonas fuertes, perfil de volumen",
    "Plan clásico: entrada, stop y 3 objetivos",
    "Canal de señales: 30 recomendaciones al mes"
   ],
   "quarterly": [
    "Todo lo de Trader, y además:",
    "Perfil de volumen de rango fijo, POC y área de valor",
    "Estrategias SMC v2 y Zone con puntuación 0–100",
    "Todas las herramientas de Alpha Radar",
    "Optimización y backtest automáticos"
   ],
   "semiannual": [
    "Todo lo de Pro, y además:",
    "Análisis en directo multipantalla",
    "Análisis de pérdidas, aprendizaje del régimen y capa cuantitativa",
    "Soporte prioritario · 100 alertas"
   ],
   "annual": [
    "Todo lo de Élite, y además:",
    "Acceso anticipado a funciones nuevas",
    "La mayor cuota de IA con traspaso de 2 meses",
    "Alertas ilimitadas · soporte más rápido"
   ],
   "prime": [
    "Todo lo del anual, y además:",
    "Estudio de patrones"
   ],
   "apex": [
    "Todo lo de Prime, y además:",
    "Consejo de IA: varios modelos revisan la misma operación"
   ],
   "max": [
    "Todo lo de Apex, y además:",
    "Mapa de liquidez en directo (mapa de calor del libro de órdenes)"
   ]
  }
 },
 "pricing": {
  "perMonth": "≈ ${v} / mes",
  "save": "Ahorras un {pct}% (${v})",
  "notConfigured": "El pago de este plan aún no está configurado. Añade su enlace de pago en .env y vuelve a publicar.",
  "redirect": "La página de pago segura se abre en una pestaña nueva.",
  "paidOk": "Pago recibido, gracias. Tu plan se activa en un minuto (cuando Stripe lo confirme). Actualiza si aún no aparece.",
  "signIn": "Inicia sesión primero para que el pago quede vinculado a tu cuenta.",
  "payFail": "No se pudo abrir el pago seguro. Inténtalo de nuevo en un momento.",
  "needSub": "Para señales extra necesitas antes un plan o suscripción al canal activos.",
  "note": "El pago se hace en la página segura del proveedor de pagos. La suscripción se activa cuando se confirma el pago."
 },
 "errors": {
  "http": "Error del servidor ({status})",
  "network": "No se pudo conectar con {host} (red, bloqueo o política del navegador)",
  "planRequired": "no incluido en el plan de tu proveedor de datos",
  "symbolInvalid": "el proveedor de datos no reconoce el símbolo",
  "badKey": "clave API no válida",
  "rateLimit": "se alcanzó el límite de peticiones del proveedor; se reintentará más tarde"
 }
};
