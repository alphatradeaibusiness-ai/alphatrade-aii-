// Inline texts for the newer sections in all five languages: tx({ ar, en, he, es, zh }) → the current language (English fallback).
import { getLang } from './index.js';
export const tx = (o) => (o ? o[getLang()] ?? o.en ?? o.ar ?? '' : '');
