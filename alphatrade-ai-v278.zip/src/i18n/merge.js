// Deep merge used by the extra languages: the base (English) dictionary with the translated parts on top.
export function deepMerge(base, over) {
  if (Array.isArray(over) || typeof over !== 'object' || over === null) return over === undefined ? base : over;
  const out = Array.isArray(base) ? [...base] : { ...(base || {}) };
  for (const [k, v] of Object.entries(over)) out[k] = typeof v === 'object' && v !== null && !Array.isArray(v) ? deepMerge(base?.[k], v) : v;
  return out;
}
