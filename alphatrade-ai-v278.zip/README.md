# AlphaTrade AI

Bilingual (العربية / English) trading-analysis dashboard with a login page, built in plain JavaScript (ES modules + Vite) on **TradingView Lightweight Charts** (the official open-source TradingView library, Apache-2.0 — its required attribution logo is shown on the chart).

> The trading plan is analysis shown in the interface. **No trades are ever placed.**
> Without API keys / network, every price is labelled **Demo Mode** — generated data, never shown as live.

## Run it locally

Requirements: **Node.js 18+**.

```bash
npm install
cp .env.example .env        # optional — everything works without keys in Demo Mode
npm run server              # terminal 1: AI-assistant proxy on :8787 (only needed for the AI chat)
npm run dev                 # terminal 2: app on http://localhost:5173
```

Open http://localhost:5173 → create an account → you land on the dashboard.

Production build: `npm run build && npm start` (serves `dist/` and the AI API on one port, default 8787).

Tests: `npm test` (indicator math, 30-point stop-loss rule for every instrument, demo-data integrity).

## What you can configure (`.env`)

| Area | Variables | Without them |
|---|---|---|
| Market data | `VITE_MARKET_MODE` (`auto`/`demo`/`live`), `VITE_BINANCE_BASE_URL`, `VITE_MARKET_REFRESH_SECONDS` (market keys never in `VITE_`: `TWELVEDATA_API_KEY` on the server) | BTC/ETH/SOL/BNB use Binance public data (no key). XAUUSD needs a Twelve Data key — the owner pastes it once on the **AI key** page (stored encrypted on the server, tested against the provider, shows which market classes the plan unlocks; see `docs/AI_SETUP.md`); otherwise XAUUSD is Demo Mode. The indices US30, US100 and SPX500 also come from Twelve Data (tickers DJI, NDX, SPX — overridable with `VITE_TD_SYMBOL_*`); if your Twelve Data plan does not include indices, the banner shows the provider's message and those symbols stay in Demo Mode. If Binance is unreachable, `auto` falls back to Demo Mode and says so. |
| Authentication | `VITE_FIREBASE_*`, `VITE_AUTH_GOOGLE_ENABLED`, `VITE_AUTH_APPLE_ENABLED` | Local demo accounts stored in this browser only (salted SHA-256), no emails sent; Google/Apple buttons show “Not configured”. |
| AI (all features) | Key saved once on the **AI key** page (owner only), stored encrypted on the server; needs `AI_KEY_SECRET`, `FIREBASE_PROJECT_ID`, `ADMIN_EMAILS` — see `docs/AI_SETUP.md` | Every AI feature shows “Not connected” — it never returns canned answers. |
| Digital bank | `BANK_MASTER_KEY` (32+ chars), `BANK_MODE` (`sandbox`/`live`), optional `BANK_*` incl. `BANK_RP_ID`/`BANK_ORIGINS` for passkeys — see `docs/BANK.md`. Node 22.13+. | The **Digital bank** page says it is not enabled; `/api/bank/*` answers 503. Sandbox = test funds and simulators (test card issuer, demo Open Banking). No bank, card issuer, custodian, transfer partner or broker is connected in any mode. |

### Firebase (real sign-in, password-reset email, Google, Apple)

The Firebase SDK is loaded from Google's official CDN (`www.gstatic.com/firebasejs/12.19.0`) only when the `VITE_FIREBASE_*` values are set. Google and Apple use a pop-up, with a full-page redirect fallback where pop-ups are blocked.

1. Create a Firebase project → add a Web app → copy apiKey, authDomain, projectId, appId into `.env`.
2. Authentication → Sign-in method → enable **Email/Password**.
3. Google: enable the Google provider, then set `VITE_AUTH_GOOGLE_ENABLED=true`.
4. Apple: enable the Apple provider (needs an Apple Developer Services ID, key and team ID), then set `VITE_AUTH_APPLE_ENABLED=true`.
5. Add your domain (e.g. `localhost` and your `*.netlify.app` domain) under Authentication → Settings → Authorized domains.
6. Apple requires a paid Apple Developer account: create a Services ID with Sign in with Apple, set its return URL to `https://<project-id>.firebaseapp.com/__/auth/handler`, create a key, and paste the Services ID, Team ID, Key ID and private key into the Apple provider in Firebase.

### AI
One central setting: the owner saves the provider key on the **AI key** page; the server tests it with a real request, stores it encrypted and routes every AI feature (assistant, support, explain, screenshot vision, smart images) through `/api/ai/*` with user verification and rate limits. Details: `docs/AI_SETUP.md`.

## The 30-point stop-loss rule

Stop loss = entry ∓ **30 × point size**, always on the opposite side of the trade. Targets are fixed distances in the trade's direction: **TP1 = 50 points, TP2 = 80 points (30 after TP1), TP3 = 130 points (50 after TP2)** from the entry (`TARGET_POINTS` in `src/config/instruments.js`). A “point” differs by market, so each symbol defines it and you can change it in **Settings** (gear icon above the chart, or click the rule line under the plan):

| Symbol | Default point | Stop (30 pts) | TP1 / TP2 / TP3 (50 / 80 / 130 pts) |
|---|---|---|---|
| BTCUSDT | 1 USDT | 30 | 50 / 80 / 130 |
| ETHUSDT | 0.10 | 3.00 | 5.00 / 8.00 / 13.00 |
| SOLUSDT | 0.01 | 0.30 | 0.50 / 0.80 / 1.30 |
| BNBUSDT | 0.10 | 3.00 | 5.00 / 8.00 / 13.00 |
| XAUUSD | 0.01 (MetaTrader point) | 0.30 | 0.50 / 0.80 / 1.30 — set 0.10 if your broker calls $0.10 a point |
| US30 / US100 / SPX500 | 1 index point | 30 | 50 / 80 / 130 |

Forex example (not listed): EURUSD 5-digit quote → 1 point = 0.00001. Edit `src/config/instruments.js` to add symbols.

**Fixed entry per trade** (`src/services/trades.js`): when a trade opens, its entry is the price at that moment and it stays fixed. The trade closes when price reaches the stop or target 3, or (auto mode) when momentum clearly reverses (score ≥ 55 / ≤ 45). Then a new trade opens at the current price. Reached targets are ticked in the plan card, the previous result is shown, and "New trade at current price" restarts it manually. Trades are kept per symbol and timeframe in the browser. Direction is automatic from momentum or forced long/short in Settings.

## Indicators (all computed in `src/indicators/index.js` from the loaded candles)

- **Volume Profile** — volume by price, visible range or all data; rows, width, value-area %, POC.
- **Fixed Range Volume Profile** — pick the start and end bar on the chart (side toolbar or Indicators panel).
- **RSI** — Wilder RSI in its own pane; period, overbought and oversold editable.
- **Buyer / seller pressure** — Binance taker-buy volume per candle (exact split). Sources without a split use a close-location estimate, labelled as an estimate. If a source has no volume (common for spot gold), volume indicators are switched off and the UI says why.
- **Fibonacci** — auto (highest high / lowest low in N bars) or manual prices, or pick both points on the chart; choose which levels to draw. Sell zone = 0 → 0.236, buy zone = 0.786 → 1.
- **Momentum gauge** — 40% RSI, 30% EMA 20/50 trend, 30% buyer pressure.

## Project structure

```
index.html, vite.config.js, .env.example
server/index.js                 AI proxy + production static server (no dependencies)
src/
  main.js, router.js            boot, hash routes (#/login, #/signup, #/forgot, #/app/…)
  config/                       auth.js, market.js, ai.js, instruments.js (point sizes), env.js
  i18n/                         ar.js, en.js, index.js (translation + RTL/LTR switch)
  state/store.js                symbol, timeframe, persisted settings
  services/
    auth/                       Firebase + local demo auth, validation, error mapping
    market/                     Binance, Twelve Data, demo generator, fallback logic
    ai/client.js                assistant API client
    analysis.js                 runs every indicator once per update
  indicators/index.js           pure calculations (unit-tested)
  components/                   header, market cards, chart panel, chart/ (Lightweight Charts wrapper + overlay primitive),
                                side cards, pressure card, AI assistant, indicator & settings panels, icons, toasts/modals
  pages/                        login, app shell, dashboard, guide/strategies/markets/indicators
  styles/                       base.css, login.css, dashboard.css
tests/indicators.test.js
```

## Real-time prices

BTC, ETH, SOL and BNB stream from Binance over WebSocket (`src/services/market/binanceStream.js`): the cards and the forming candle update every second, and the analysis/plan refreshes once per second. If the stream drops it reconnects automatically and polling takes over meanwhile. Gold and the indices come from Twelve Data's REST API (free plan: 8 requests/minute), so they refresh every 2–5 minutes; per-second updates for them need a paid Twelve Data plan with WebSocket access.

## Subscriptions

`#/app/pricing` shows four plans — monthly $70, 3 months $180, 6 months $330, yearly $600 (set in `src/config/billing.js`). Each button opens the hosted checkout link from `.env` (`VITE_PAY_LINK_MONTHLY`, `_3M`, `_6M`, `_12M`) — e.g. Stripe Payment Links. Without a link the page says payment is not set up. Locking the platform to paying users needs a backend that receives the provider's payment webhook; the static site cannot verify payments by itself.

## Chart navigation

- **Zoom buttons** (side toolbar) zoom around the centre of the current view with a short animation; they dim at the limits (12 bars minimum).
- **Reset** returns to a width-based default (about 8 px per candle: ~40 bars on a phone, ~140 on a desktop) and re-enables price autoscale.
- **Pan**: drag with the mouse or swipe horizontally on touch screens (with inertia). Vertical swipes over the charts scroll the page.
- The price scale always includes the entry, stop and all three targets, and their labels are spread apart so they never overlap or leave the chart.

## Motion

`src/styles/motion.css` and `src/utils/motion.js`: staggered fade-in on load, hover/press feedback on cards and buttons, numbers that count to new values, a short chart transition on symbol/timeframe change, a slow purple pulse on the logo, slow waves and a few points of light on the login page, and soft transitions for language changes, menus and pages. Only `transform`, `opacity` and `box-shadow` are animated. With the system setting *Reduce motion* on, all of it is switched off and numbers update instantly.

## Notes

- **RTL:** Arabic mirrors the whole layout (logo and navigation on the right, analysis column on the left). The chart itself stays left-to-right (time flows left→right, price axis on the right), as in TradingView.
- The reference’s fifth menu item was unreadable placeholder text, so it is **Indicators** (المؤشرات).
- The image’s sample prices are not used as market prices; demo data is generated and labelled.
- Reduced-motion users get no animations (`prefers-reduced-motion`).

## Subscription tiers
Plans (`src/config/billing.js`): $80 / $190 / $350 / $650. What each includes lives in `src/config/entitlements.js`
(Trader → Pro → Elite → Institutional: AI deep-analysis quota 30/60/100/150 per month with carry-over, alert and signal limits,
and which tools unlock). Enforcement is **off** by default (`VITE_ENFORCE_PLANS`), because a static site cannot verify payments.
To enforce: add a backend that confirms payment and writes the plan (`setPlan(id, untilMs)`), keep the AI counter server-side,
then set `VITE_ENFORCE_PLANS=true`.

## Multi-asset research (BTC, ETH, SOL)
`npm run research` downloads Binance candles (2022 → today) for BTCUSDT, ETHUSDT, SOLUSDT, runs the classic / SMC v2 / Zone strategies with the app's own engine, with and without a strict monthly loss cap, and writes `results/report.md` (win rate, net points, worst month per asset and timeframe, walk-forward parameter grid).
Options: `--tfs 1m,5m,15m,30m,1h,4h --from 2022-01-01 --fee 0.04 --cap 1000 --offline`. The sandbox this project was built in could not reach exchanges, so `docs/BTC_REPORT.md` covers BTC only; run the script yourself for ETH and SOL.
