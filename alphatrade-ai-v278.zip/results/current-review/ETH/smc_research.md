# SMC v2 research — ETHUSDT
Costs: fee 0.1% + slippage 0.02% round trip (no spread data for crypto candles). Entry = market at the confirmation candle's close; stops/targets from the engine; a trade is "win" when net points > 0 after costs. R = result in units of the risk taken. Daily context built from 1h candles.

## Entry timeframe 15m
Data 2026-09-28 → 2026-10-08 (999 candles). **Development** 2026-09-28 → 2026-10-04 · **Out of sample** 2026-10-04 → 2026-10-08.

| Variant | Dev trades | Dev win | Dev PF | Dev R/trade | Dev maxDD (R) | Dev loss streak | OOS trades | OOS win | OOS PF | OOS R/trade | OOS maxDD (R) |
|---|---|---|---|---|---|---|---|---|---|---|---|
| A strict (current) | 0 (0.00/mo) | — | — | — | — | — | 0 (0.00/mo) | — | — | — | — |
| B 4h bias only | 0 (0.00/mo) | — | — | — | — | — | 0 (0.00/mo) | — | — | — | — |
| C no kill zone | 0 (0.00/mo) | — | — | — | — | — | 0 (0.00/mo) | — | — | — | — |
| D 4h only + no kill zone | 0 (0.00/mo) | — | — | — | — | — | 0 (0.00/mo) | — | — | — | — |
| E D + score 70 | 0 (0.00/mo) | — | — | — | — | — | 0 (0.00/mo) | — | — | — | — |
| F D + reversal rule | 0 (0.00/mo) | — | — | — | — | — | 0 (0.00/mo) | — | — | — | — |
| G D + RSI gate | 0 (0.00/mo) | — | — | — | — | — | 0 (0.00/mo) | — | — | — | — |
| H D + displacement ≥1.5 | 0 (0.00/mo) | — | — | — | — | — | 0 (0.00/mo) | — | — | — | — |
| I D + FVG ≥0.3 ATR | 0 (0.00/mo) | — | — | — | — | — | 0 (0.00/mo) | — | — | — | — |
| J D + CHoCH within 25 | 0 (0.00/mo) | — | — | — | — | — | 0 (0.00/mo) | — | — | — | — |
| K no HTF, kill zone on | 0 (0.00/mo) | — | — | — | — | — | 0 (0.00/mo) | — | — | — | — |
| L 4h only + kill zone | 0 (0.00/mo) | — | — | — | — | — | 0 (0.00/mo) | — | — | — | — |

## Entry timeframe 5m
Data 2026-10-05 → 2026-10-08 (999 candles). **Development** 2026-10-05 → 2026-10-07 · **Out of sample** 2026-10-07 → 2026-10-08.

| Variant | Dev trades | Dev win | Dev PF | Dev R/trade | Dev maxDD (R) | Dev loss streak | OOS trades | OOS win | OOS PF | OOS R/trade | OOS maxDD (R) |
|---|---|---|---|---|---|---|---|---|---|---|---|
| A strict (current) | 0 (0.00/mo) | — | — | — | — | — | 0 (0.00/mo) | — | — | — | — |
| B 4h bias only | 0 (0.00/mo) | — | — | — | — | — | 0 (0.00/mo) | — | — | — | — |
| C no kill zone | 1 (14.42/mo) | 0.00% | 0.00 | -1.24 | 1.24 | 1 | 0 (0.00/mo) | — | — | — | — |
| D 4h only + no kill zone | 1 (14.42/mo) | 0.00% | 0.00 | -1.24 | 1.24 | 1 | 0 (0.00/mo) | — | — | — | — |
| E D + score 70 | 1 (14.42/mo) | 0.00% | 0.00 | -1.24 | 1.24 | 1 | 0 (0.00/mo) | — | — | — | — |
| F D + reversal rule | 1 (14.42/mo) | 0.00% | 0.00 | -1.24 | 1.24 | 1 | 0 (0.00/mo) | — | — | — | — |
| G D + RSI gate | 1 (14.42/mo) | 0.00% | 0.00 | -1.24 | 1.24 | 1 | 0 (0.00/mo) | — | — | — | — |
| H D + displacement ≥1.5 | 0 (0.00/mo) | — | — | — | — | — | 0 (0.00/mo) | — | — | — | — |
| I D + FVG ≥0.3 ATR | 1 (14.42/mo) | 0.00% | 0.00 | -1.24 | 1.24 | 1 | 0 (0.00/mo) | — | — | — | — |
| J D + CHoCH within 25 | 1 (14.42/mo) | 0.00% | 0.00 | -1.24 | 1.24 | 1 | 0 (0.00/mo) | — | — | — | — |
| K no HTF, kill zone on | 0 (0.00/mo) | — | — | — | — | — | 0 (0.00/mo) | — | — | — | — |
| L 4h only + kill zone | 0 (0.00/mo) | — | — | — | — | — | 0 (0.00/mo) | — | — | — | — |
